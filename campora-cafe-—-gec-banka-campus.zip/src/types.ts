export type DietaryTag = 
  | 'veg' 
  | 'vegan' 
  | 'gluten-free' 
  | 'contains-nuts' 
  | 'dairy-free' 
  | 'chef-special' 
  | 'spicy-mild' 
  | 'spicy-medium' 
  | 'spicy-hot';

export interface MenuItemSize {
  name: string;
  priceDelta: number;
}

export interface MenuItemAddon {
  id: string;
  name: string;
  price: number;
  category?: 'milk' | 'syrup' | 'topping' | 'side' | 'extra';
}

export interface CustomerReview {
  id: string;
  userName: string;
  rating: number;
  date: string;
  comment: string;
  avatar?: string;
}

export interface MenuItem {
  id: string;
  name: string;
  tagline?: string;
  category: 'beverages' | 'pastries' | 'mains' | 'desserts' | 'healthy';
  subcategory?: string;
  description: string;
  price: number;
  originalPrice?: number;
  image: string;
  galleryImages?: string[];
  dietaryTags: DietaryTag[];
  isAvailable: boolean;
  stockCount: number; // e.g. 15 or 0 for sold out
  isPopular?: boolean;
  isChefSpecial?: boolean;
  rating: number;
  reviewCount: number;
  preparationTimeMinutes: number;
  // Nutrition & Allergens
  calories?: number;
  protein?: number;
  carbs?: number;
  fat?: number;
  ingredients: string[];
  allergenWarnings: string[];
  // Customization
  sizes?: MenuItemSize[];
  addons?: MenuItemAddon[];
  reviews?: CustomerReview[];
}

export interface CartItemAddon {
  id: string;
  name: string;
  price: number;
}

export interface CartItem {
  cartItemId: string; // unique ID per customized cart item instance
  menuItemId: string;
  name: string;
  unitPrice: number;
  calculatedPrice: number;
  quantity: number;
  image: string;
  selectedSize?: MenuItemSize;
  selectedAddons?: CartItemAddon[];
  specialInstructions?: string;
}

export type BookingMode = 'dine-in' | 'takeout' | 'delivery';

export type TableZone = 'indoor' | 'patio' | 'booth' | 'lounge' | 'counter';

export type TableStatus = 'available' | 'reserved' | 'occupied' | 'cleaning';

export interface CafeTable {
  id: string;
  tableNumber: string;
  name: string;
  capacity: number;
  zone: TableZone;
  status: TableStatus;
  currentBookingId?: string;
  coordinates?: { x: number; y: number }; // For visual floor plan
}

export type OrderStatus = 'confirmed' | 'preparing' | 'ready' | 'completed' | 'cancelled';

export interface BookingCustomer {
  name: string;
  phone: string;
  email: string;
  specialRequests?: string;
  sendWhatsAppNotification?: boolean;
}

export interface DineInDetails {
  date: string; // YYYY-MM-DD
  timeSlot: string; // e.g., "11:30 AM", "01:00 PM"
  guestCount: number;
  tableId?: string;
  tableNumber?: string;
  zone: TableZone;
  occasion?: 'casual' | 'birthday' | 'anniversary' | 'business' | 'date';
}

export interface TakeoutDetails {
  pickupTime: string;
  vehicleOrNote?: string;
}

export interface DeliveryDetails {
  deliveryAddress: string;
  landmark?: string;
  postalCode?: string;
  deliveryInstructions?: string;
  hostelOrBuilding?: string;
  roomOrFloor?: string;
}

export interface OrderPricing {
  subtotal: number;
  discountAmount: number;
  discountCode?: string;
  gstTax: number;
  serviceFee: number;
  deliveryFee: number;
  tip: number;
  total: number;
}

export interface BookingOrder {
  id: string; // e.g. "BK-9421"
  createdAt: string;
  userId?: string; // Links order to customer user UID
  customerId?: string; // Links order to customer user profile UID
  deviceSessionSlug: string; // Unique client device session identifier (e.g. "gec-dev-k9s3-a712")
  bookingMode: BookingMode;
  status: OrderStatus;
  customer: BookingCustomer;
  dineInDetails?: DineInDetails;
  takeoutDetails?: TakeoutDetails;
  deliveryDetails?: DeliveryDetails;
  items: CartItem[];
  pricing: OrderPricing;
  paymentMethod: 'card' | 'counter' | 'apple_pay' | 'google_pay' | 'upi' | 'cash';
  paymentStatus: 'paid' | 'pay_on_arrival';
  qrCodePayload: string;
  estimatedReadyTime: string;
  adminNotes?: string;
  cancellationPolicyNotice?: string;
  updatedAt?: string;
  completedAt?: string;
  cancelledAt?: string;
  cancellationReason?: string;
  cancelledBy?: 'customer' | 'admin';
  feedback?: {
    rating: number;
    comment: string;
    submittedAt: string;
  };
}

export interface CustomerRecord {
  id: string;
  name: string;
  phone: string;
  email: string;
  totalBookings: number;
  totalSpent: number;
  isVIP: boolean;
  lastVisit: string;
  favoriteItems: string[];
  loyaltyPoints: number;
  notes?: string;
}

export interface PromoCode {
  code: string;
  discountType: 'percentage' | 'fixed';
  discountValue: number; // e.g. 15 for 15% or 5 for $5
  minOrderAmount: number;
  description: string;
  isActive: boolean;
  validUntil?: string;
}

export interface CafeOperatingHour {
  day: string;
  open: string;
  close: string;
  isClosed?: boolean;
}

export type UserRole = 'owner' | 'admin' | 'staff' | 'customer';

export type StaffRole = 'owner' | 'manager' | 'staff';

export type StaffPosition =
  | 'Café Staff'
  | 'Cashier'
  | 'Kitchen Staff'
  | 'Counter Staff'
  | 'Manager'
  | 'Other';

export type StaffStatus = 'active' | 'inactive' | 'suspended';

export type IdProofType =
  | 'College ID'
  | 'Aadhaar'
  | 'PAN'
  | 'Driving Licence'
  | 'Other';

export type StaffPermission =
  | 'view_orders'
  | 'update_order_status'
  | 'create_counter_sale'
  | 'view_counter_sales'
  | 'manage_menu'
  | 'manage_tables'
  | 'view_customer_info'
  | 'view_crm'
  | 'view_sales_reports'
  | 'manage_staff'
  | 'change_cafe_status'
  | 'manage_settings';

export interface StaffMember {
  id: string; // Document ID or internal ID
  uid?: string; // Linked Firebase Auth UID
  staffId: string; // e.g. "CC-STF-101"
  fullName: string;
  mobile: string;
  email: string;
  dateOfJoining: string; // YYYY-MM-DD
  role: StaffRole;
  position: StaffPosition | string;
  status: StaffStatus;
  address?: string;
  emergencyContact?: string;
  idProofType?: IdProofType;
  idProofNumber?: string;
  idProofDocumentUrl?: string; // Document upload preview / storage
  photoUrl?: string;
  notes?: string;
  permissions: StaffPermission[];
  createdAt: string;
  updatedAt?: string;
  lastLoginAt?: string;
  addedByUid?: string;
  addedByName?: string;
}

export type AttendanceStatus = 'present' | 'absent' | 'weekly_off' | 'leave' | 'holiday';

export interface AttendanceCorrectionLog {
  changedByUid: string;
  changedByName: string;
  changedAt: string; // ISO string
  originalStatus?: AttendanceStatus;
  newStatus: AttendanceStatus;
  reason?: string;
}

export interface StaffAttendanceRecord {
  id: string; // e.g., `${staffId}_${date}`
  staffId: string; // e.g. "CC-STF-101"
  staffDocId?: string; // profile document ID
  staffName: string;
  date: string; // YYYY-MM-DD
  status: AttendanceStatus;
  checkInTime?: string; // e.g. "09:30"
  checkOutTime?: string; // e.g. "18:00"
  totalWorkingMinutes?: number;
  totalWorkingHoursFormatted?: string; // e.g. "8h 30m"
  notes?: string;
  correctionReason?: string;
  markedByUid: string;
  markedByName: string;
  createdAt: string; // ISO
  updatedAt?: string; // ISO
  history?: AttendanceCorrectionLog[];
}

export interface MonthlyAttendanceSummary {
  year: number;
  month: number; // 1-12
  monthName: string; // e.g. "September 2026"
  totalDaysInMonth: number;
  totalWorkingDays: number; // Present + Absent (+ Leave)
  presentDays: number;
  absentDays: number;
  weeklyOffDays: number;
  leaveDays: number;
  holidayDays: number;
  attendancePercentage: number; // e.g. 90.9
  totalWorkingMinutes: number;
  totalWorkingHoursFormatted: string; // e.g. "170h 0m"
}

export interface StaffAuditLog {
  id: string;
  staffName: string;
  staffId: string;
  staffUid?: string;
  action: string;
  category: 'order' | 'counter_sale' | 'table' | 'menu' | 'cafe_status' | 'staff' | 'settings';
  date: string; // YYYY-MM-DD
  time: string; // HH:mm:ss
  timestamp: string; // ISO string
  relevantId?: string; // e.g., order ID, counter sale ID, table ID
  details?: string;
}

export interface AdminProfile {
  uid: string;
  email: string;
  displayName: string;
  role: 'owner' | 'admin' | 'staff';
  permissions: string[];
  assignedBy?: string;
  createdAt: string;
  lastLoginAt?: string;
  isActive: boolean;
}

export interface UserProfile {
  uid: string;
  email: string;
  displayName: string;
  role: UserRole;
  permissions: string[];
  assignedBy?: string;
  createdAt: string;
  lastLoginAt?: string;
  // Customer-specific profile fields
  phone?: string;
  departmentOrHostel?: string;
  roomNumber?: string;
  savedDeliveryAddress?: string;
  preferredPaymentMethod?: 'upi' | 'cash' | 'counter' | 'card';
  loyaltyPoints?: number;
}

export interface CafeSettings {
  name: string;
  tagline: string;
  campusName: string;
  address: string;
  city: string;
  state: string;
  pincode: string;
  phone: string;
  whatsapp: string;
  email: string;
  upiId: string;
  upiName: string;
  googleMapEmbedUrl: string;
  googleMapsDirectionsUrl: string;
  currency: string;
  taxRatePercent: number; // e.g. 5% GST
  serviceFeeFixed: number; // e.g. 0 or 5
  deliveryFeeFixed: number; // e.g. 10
  minimumOrderForDelivery: number;
  operatingHours: CafeOperatingHour[];
  isOpen?: boolean; // Real-time store status: true = Open, false = Closed
  closedNotice?: string; // Optional custom announcement message when closed
  hygieneCertifications: {
    title: string;
    badge: string;
    issuer: string;
    verifiedYear: string;
  }[];
  announcements: {
    id: string;
    text: string;
    type: 'promo' | 'info' | 'alert';
    active: boolean;
  }[];
}

export type CounterSalePaymentMethod = 'cash' | 'upi' | 'other';

export interface CounterSaleItem {
  id: string;
  name: string;
  quantity: number;
  price: number;
  total: number;
}

export interface CounterSale {
  id: string; // e.g. "CS-94821"
  customerName?: string;
  customerPhone?: string;
  items: CounterSaleItem[];
  totalAmount: number;
  paymentMethod: CounterSalePaymentMethod;
  createdAt: string; // ISO 8601 string
  note?: string;
  addedByUid?: string;
  addedByName?: string;
  updatedAt?: string;
}

export interface SalesSummary {
  onlineOrdersTotal: number;
  counterSalesTotal: number;
  combinedTotalSales: number;
  todayOnlineSales: number;
  todayCounterSales: number;
  todayTotalSales: number;
  totalCashCollection: number;
  totalUpiCollection: number;
  totalOtherCollection: number;
  todayCashCollection: number;
  todayUpiCollection: number;
  todayOtherCollection: number;
}
