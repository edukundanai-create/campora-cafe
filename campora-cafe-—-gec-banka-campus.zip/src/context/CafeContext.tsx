import React, { createContext, useContext, useState, useEffect, useMemo, ReactNode } from 'react';
import {
  MenuItem,
  CartItem,
  CafeTable,
  BookingOrder,
  PromoCode,
  CustomerRecord,
  CafeSettings,
  BookingMode,
  OrderStatus,
  TableStatus,
  OrderPricing,
  DineInDetails,
  TakeoutDetails,
  DeliveryDetails,
  BookingCustomer,
  UserProfile,
  UserRole,
  AdminProfile,
  CounterSale,
  CounterSaleItem,
  CounterSalePaymentMethod,
  SalesSummary,
  StaffMember,
  StaffAuditLog,
  StaffPermission,
  StaffStatus,
  StaffRole,
  StaffAttendanceRecord,
  AttendanceStatus,
  AttendanceCorrectionLog
} from '../types';
import {
  INITIAL_CAFE_SETTINGS,
  INITIAL_MENU_ITEMS,
  INITIAL_TABLES,
  INITIAL_PROMO_CODES,
  INITIAL_CUSTOMERS,
  INITIAL_SAMPLE_ORDERS,
  INITIAL_SAMPLE_COUNTER_SALES,
  INITIAL_STAFF_MEMBERS,
  INITIAL_STAFF_AUDIT_LOGS
} from '../data/initialData';
import { INITIAL_STAFF_ATTENDANCE, calculateWorkingHours } from '../utils/attendance';
import { getOrCreateDeviceSessionSlug } from '../utils/session';
import {
  auth,
  db,
  adminAuth,
  adminDb,
  googleProvider,
  signInWithPopup,
  signInWithEmailAndPassword,
  createUserWithEmailAndPassword,
  sendPasswordResetEmail,
  signOut,
  onAuthStateChanged,
  updateProfile,
  collection,
  doc,
  setDoc,
  updateDoc,
  deleteDoc,
  onSnapshot,
  getDocs,
  getDoc,
  query,
  orderBy,
  where,
  limit,
  startAfter,
  User
} from '../lib/firebase';

export const MASTER_ADMIN_UID = 'aWplD23baqfpkcMPc2fqy967lt02';

export const AUTHORIZED_SYSTEM_ADMIN_EMAILS = [
  'edu.kundanai@gmail.com',
  'admin@camporacafe.gecbanka.ac.in',
  'owner@camporacafe.gecbanka.ac.in',
  'manager@camporacafe.gecbanka.ac.in'
];

/**
 * Checks whether an email address belongs to an authorized cafe system administrator/owner
 */
export const isSystemAdminEmail = (email?: string | null): boolean => {
  if (!email) return false;
  const normalized = email.toLowerCase().trim();
  return AUTHORIZED_SYSTEM_ADMIN_EMAILS.includes(normalized);
};

export interface ToastMessage {
  id: string;
  title: string;
  description?: string;
  type: 'success' | 'info' | 'warning' | 'error';
}

interface CafeContextType {
  // Data
  settings: CafeSettings;
  menuItems: MenuItem[];
  tables: CafeTable[];
  cart: CartItem[];
  appliedPromo: PromoCode | null;
  orders: BookingOrder[];
  activeOrders: BookingOrder[];
  orderHistory: BookingOrder[];
  customers: CustomerRecord[];
  promoCodes: PromoCode[];
  activeOrder: BookingOrder | null;
  
  // Customer Auth & Roles (isolated)
  currentUser: User | null;
  currentUserProfile: UserProfile | null;
  customerUser: User | null;
  customerProfile: UserProfile | null;
  userRole: UserRole;
  allUsers: UserProfile[];
  isAuthLoading: boolean;
  loginWithGoogle: () => Promise<void>;
  loginWithEmail: (e: string, p: string) => Promise<void>;
  loginCustomerWithEmail: (e: string, p: string) => Promise<void>;
  loginCustomerWithGoogle: () => Promise<void>;
  signupWithEmail: (e: string, p: string) => Promise<void>;
  loginDemoStudent: () => Promise<void>;
  resetPassword: (email: string) => Promise<void>;
  logout: () => Promise<void>;
  logoutCustomer: () => Promise<void>;

  // Dedicated Owner & Admin Authentication (strictly isolated from customer accounts)
  adminUser: User | null;
  adminProfile: AdminProfile | null;
  isAdminUser: boolean;
  isAdminAuthLoading: boolean;
  loginAdminWithEmail: (email: string, pass: string) => Promise<void>;
  loginAdminWithGoogle: () => Promise<void>;
  logoutAdmin: () => Promise<void>;
  assignUserRole: (targetUid: string, role: UserRole, permissions?: string[]) => Promise<void>;

  // UI & Modals State
  isAdminMode: boolean;
  isCartOpen: boolean;
  isCheckoutOpen: boolean;
  isLocationModalOpen: boolean;
  isCustomerAccountOpen: boolean;
  selectedDetailItem: MenuItem | null;
  isOrderTrackerOpen: boolean;
  toasts: ToastMessage[];

  // Customer Account & Order History
  customerOrders: BookingOrder[];
  customerActiveOrders: BookingOrder[];
  customerOrderHistory: BookingOrder[];
  reorderPastOrder: (order: BookingOrder) => void;
  hasMoreOrders: boolean;
  isLoadingMoreOrders: boolean;
  loadMoreOrders: () => Promise<void>;
  updateCustomerProfile: (updates: Partial<UserProfile>) => Promise<void>;
  signupCustomer: (name: string, email: string, pass: string, phone: string, departmentOrHostel?: string) => Promise<void>;

  // Cart actions
  addToCart: (
    item: MenuItem,
    quantity?: number,
    size?: MenuItem['sizes'] extends (infer U)[] ? U : undefined,
    addons?: CartItem['selectedAddons'],
    specialInstructions?: string
  ) => void;
  updateCartItemQuantity: (cartItemId: string, delta: number) => void;
  removeCartItem: (cartItemId: string) => void;
  updateCartItemInstructions: (cartItemId: string, instructions: string) => void;
  clearCart: () => void;
  applyPromoCode: (codeStr: string) => { success: boolean; message: string };
  removePromoCode: () => void;
  
  // Pricing calculation helper
  calculatePricing: (mode: BookingMode, tipAmount?: number) => OrderPricing;

  // Booking & Orders
  createBookingOrder: (
    bookingMode: BookingMode,
    customer: BookingCustomer,
    paymentMethod: BookingOrder['paymentMethod'],
    dineInDetails?: DineInDetails,
    takeoutDetails?: TakeoutDetails,
    deliveryDetails?: DeliveryDetails,
    tip?: number
  ) => Promise<BookingOrder>;
  updateOrderStatus: (orderId: string, status: OrderStatus, adminNotes?: string) => Promise<void>;
  cancelOrder: (orderId: string, reason?: string) => Promise<{ success: boolean; error?: string }>;
  setActiveOrder: (order: BookingOrder | null) => void;
  submitOrderFeedback: (orderId: string, rating: number, comment: string) => Promise<void>;

  // Table Management
  updateTableStatus: (tableId: string, status: TableStatus) => Promise<void>;
  addTable: (table: Omit<CafeTable, 'id'>) => Promise<void>;
  deleteTable: (tableId: string) => Promise<void>;

  // Menu Management (Admin CRUD)
  addMenuItem: (item: Omit<MenuItem, 'id'>) => Promise<void>;
  updateMenuItem: (id: string, updates: Partial<MenuItem>) => Promise<void>;
  deleteMenuItem: (id: string) => Promise<void>;
  toggleItemAvailability: (id: string) => Promise<void>;
  updateItemStock: (id: string, newStock: number) => Promise<void>;

  // Settings & Promos
  updateSettings: (updates: Partial<CafeSettings>, suppressToast?: boolean) => Promise<void>;
  toggleCafeOpenStatus: (forcedStatus?: boolean) => Promise<void>;
  isUpdatingStatus: boolean;
  addPromoCode: (promo: PromoCode) => Promise<void>;
  togglePromoCode: (code: string) => Promise<void>;

  // Counter Sales Management (Manual walk-in sales at the counter)
  counterSales: CounterSale[];
  addCounterSale: (saleData: {
    customerName?: string;
    customerPhone?: string;
    items: CounterSaleItem[];
    paymentMethod: CounterSalePaymentMethod;
    note?: string;
    customCreatedAt?: string;
  }) => Promise<CounterSale>;
  updateCounterSale: (id: string, updates: Partial<CounterSale>) => Promise<void>;
  deleteCounterSale: (id: string) => Promise<void>;

  // Combined & Separated Sales Aggregates
  salesSummary: SalesSummary;

  // Campus Staff Management System & RBAC
  staffMembers: StaffMember[];
  staffAuditLogs: StaffAuditLog[];
  currentStaff: StaffMember | null;
  hasPermission: (perm: StaffPermission) => boolean;
  addStaffMember: (staffData: Omit<StaffMember, 'id' | 'createdAt'>, password?: string) => Promise<StaffMember>;
  updateStaffMember: (staffId: string, updates: Partial<StaffMember>) => Promise<void>;
  toggleStaffStatus: (staffId: string, newStatus: StaffStatus) => Promise<void>;
  deleteStaffMemberPermanently: (staffId: string) => Promise<void>;
  recordStaffAuditLog: (logData: Omit<StaffAuditLog, 'id' | 'timestamp' | 'date' | 'time'>) => Promise<void>;
  loginStaffQuickDemo: (staffMember: StaffMember) => Promise<void>;
  
  // Staff Attendance & Work Record System
  staffAttendance: StaffAttendanceRecord[];
  markStaffAttendance: (recordData: Omit<StaffAttendanceRecord, 'id' | 'createdAt'>) => Promise<StaffAttendanceRecord>;
  updateStaffAttendance: (attendanceId: string, updates: Partial<StaffAttendanceRecord>, correctionReason?: string) => Promise<StaffAttendanceRecord>;
  deleteStaffAttendance: (attendanceId: string) => Promise<void>;

  // Modals & Navigation
  setIsAdminMode: (admin: boolean) => void;
  setIsCartOpen: (open: boolean) => void;
  setIsCheckoutOpen: (open: boolean) => void;
  setIsLocationModalOpen: (open: boolean) => void;
  setIsCustomerAccountOpen: (open: boolean) => void;
  setSelectedDetailItem: (item: MenuItem | null) => void;
  setIsOrderTrackerOpen: (open: boolean) => void;
  showToast: (title: string, description?: string, type?: ToastMessage['type']) => void;
  dismissToast: (id: string) => void;

  // Helpers
  isCafeOpenNow: boolean;
  currentDaySchedule: { open: string; close: string; isClosed?: boolean } | null;
  totalCartItemCount: number;
}

const CafeContext = createContext<CafeContextType | undefined>(undefined);

const LOCAL_STORAGE_KEYS = {
  SETTINGS: 'campora_cafe_settings_v2',
  MENU: 'campora_cafe_menu_v2',
  TABLES: 'campora_cafe_tables_v2',
  CART: 'campora_cafe_cart_v2',
  ORDERS: 'campora_cafe_orders_v2',
  CUSTOMERS: 'campora_cafe_customers_v2',
  PROMOS: 'campora_cafe_promos_v2',
  ACTIVE_ORDER_ID: 'campora_cafe_active_order_id_v2',
  COUNTER_SALES: 'campora_cafe_counter_sales_v2',
  STAFF: 'campora_cafe_staff_v2',
  STAFF_AUDIT_LOGS: 'campora_cafe_staff_audit_logs_v2',
  CURRENT_STAFF_ID: 'campora_cafe_current_staff_id_v2',
  STAFF_ATTENDANCE: 'campora_cafe_staff_attendance_v2'
};

export const CafeProvider: React.FC<{ children: ReactNode }> = ({ children }) => {
  // Customer Auth Session (Customer portal, checkout, customer history)
  const [customerUser, setCustomerUser] = useState<User | null>(null);
  const [customerProfile, setCustomerProfile] = useState<UserProfile | null>(null);
  const [isAuthLoading, setIsAuthLoading] = useState<boolean>(true);

  // Dedicated Admin Auth Session (Owner/Admin panel - completely isolated)
  const [adminUser, setAdminUser] = useState<User | null>(null);
  const [adminProfile, setAdminProfile] = useState<AdminProfile | null>(null);
  const [isAdminAuthLoading, setIsAdminAuthLoading] = useState<boolean>(true);

  const [allUsers, setAllUsers] = useState<UserProfile[]>([]);

  // Strict Admin Verification:
  // isAdminUser is true ONLY when adminUser is authenticated and verified in admins collection or is master admin
  const isAdminUser = useMemo(() => {
    if (!adminUser) return false;
    if (adminUser.uid === MASTER_ADMIN_UID) return true;
    if (isSystemAdminEmail(adminUser.email)) return true;
    if (adminProfile && (adminProfile.role === 'admin' || adminProfile.role === 'owner' || adminProfile.role === 'staff')) {
      return adminProfile.isActive !== false;
    }
    return false;
  }, [adminUser, adminProfile]);

  const userRole: UserRole = useMemo(() => {
    if (adminUser && isAdminUser) {
      return adminProfile?.role || 'admin';
    }
    return customerProfile?.role || 'customer';
  }, [adminUser, isAdminUser, adminProfile, customerProfile]);

  // Backward compatibility alias: customer context
  const currentUser = customerUser;
  const currentUserProfile = customerProfile;

  // Initial local state with fallback
  const [settings, setSettings] = useState<CafeSettings>(() => {
    const saved = localStorage.getItem(LOCAL_STORAGE_KEYS.SETTINGS);
    return saved ? JSON.parse(saved) : INITIAL_CAFE_SETTINGS;
  });

  const [menuItems, setMenuItems] = useState<MenuItem[]>(() => {
    const saved = localStorage.getItem(LOCAL_STORAGE_KEYS.MENU);
    return saved ? JSON.parse(saved) : INITIAL_MENU_ITEMS;
  });

  const [tables, setTables] = useState<CafeTable[]>(() => {
    const saved = localStorage.getItem(LOCAL_STORAGE_KEYS.TABLES);
    return saved ? JSON.parse(saved) : INITIAL_TABLES;
  });

  const [cart, setCart] = useState<CartItem[]>(() => {
    const saved = localStorage.getItem(LOCAL_STORAGE_KEYS.CART);
    return saved ? JSON.parse(saved) : [];
  });

  const [appliedPromo, setAppliedPromo] = useState<PromoCode | null>(null);

  const [orders, setOrders] = useState<BookingOrder[]>(() => {
    const saved = localStorage.getItem(LOCAL_STORAGE_KEYS.ORDERS);
    return saved ? JSON.parse(saved) : INITIAL_SAMPLE_ORDERS;
  });

  const [hasMoreOrders, setHasMoreOrders] = useState<boolean>(true);
  const [isLoadingMoreOrders, setIsLoadingMoreOrders] = useState<boolean>(false);

  const [customers, setCustomers] = useState<CustomerRecord[]>(() => {
    const saved = localStorage.getItem(LOCAL_STORAGE_KEYS.CUSTOMERS);
    return saved ? JSON.parse(saved) : INITIAL_CUSTOMERS;
  });

  const [promoCodes, setPromoCodes] = useState<PromoCode[]>(() => {
    const saved = localStorage.getItem(LOCAL_STORAGE_KEYS.PROMOS);
    return saved ? JSON.parse(saved) : INITIAL_PROMO_CODES;
  });

  const [counterSales, setCounterSales] = useState<CounterSale[]>(() => {
    const saved = localStorage.getItem(LOCAL_STORAGE_KEYS.COUNTER_SALES);
    return saved ? JSON.parse(saved) : INITIAL_SAMPLE_COUNTER_SALES;
  });

  const [staffMembers, setStaffMembers] = useState<StaffMember[]>(() => {
    const saved = localStorage.getItem(LOCAL_STORAGE_KEYS.STAFF);
    return saved ? JSON.parse(saved) : INITIAL_STAFF_MEMBERS;
  });

  const [staffAuditLogs, setStaffAuditLogs] = useState<StaffAuditLog[]>(() => {
    const saved = localStorage.getItem(LOCAL_STORAGE_KEYS.STAFF_AUDIT_LOGS);
    return saved ? JSON.parse(saved) : INITIAL_STAFF_AUDIT_LOGS;
  });

  const [staffAttendance, setStaffAttendance] = useState<StaffAttendanceRecord[]>(() => {
    const saved = localStorage.getItem(LOCAL_STORAGE_KEYS.STAFF_ATTENDANCE);
    return saved ? JSON.parse(saved) : INITIAL_STAFF_ATTENDANCE;
  });

  const [currentStaff, setCurrentStaff] = useState<StaffMember | null>(() => {
    const savedStaffId = localStorage.getItem(LOCAL_STORAGE_KEYS.CURRENT_STAFF_ID);
    const savedList = localStorage.getItem(LOCAL_STORAGE_KEYS.STAFF);
    const list: StaffMember[] = savedList ? JSON.parse(savedList) : INITIAL_STAFF_MEMBERS;
    if (savedStaffId) {
      return list.find(s => s.id === savedStaffId || s.staffId === savedStaffId) || null;
    }
    return null;
  });

  const [activeOrderId, setActiveOrderId] = useState<string | null>(() => {
    return localStorage.getItem(LOCAL_STORAGE_KEYS.ACTIVE_ORDER_ID) || null;
  });

  // Modal / UI states
  const [isAdminMode, setIsAdminMode] = useState<boolean>(false);
  const [isCartOpen, setIsCartOpen] = useState<boolean>(false);
  const [isCheckoutOpen, setIsCheckoutOpen] = useState<boolean>(false);
  const [isLocationModalOpen, setIsLocationModalOpen] = useState<boolean>(false);
  const [isCustomerAccountOpen, setIsCustomerAccountOpen] = useState<boolean>(false);
  const [selectedDetailItem, setSelectedDetailItem] = useState<MenuItem | null>(null);
  const [isOrderTrackerOpen, setIsOrderTrackerOpen] = useState<boolean>(false);
  const [toasts, setToasts] = useState<ToastMessage[]>([]);
  const [isUpdatingStatus, setIsUpdatingStatus] = useState<boolean>(false);

  // 1. Customer Auth Listener (Standard auth instance - strictly customer role)
  useEffect(() => {
    const unsubscribe = onAuthStateChanged(auth, async (user) => {
      setCustomerUser(user);
      setIsAuthLoading(false);

      if (user) {
        try {
          const userDocRef = doc(db, 'users', user.uid);
          const snap = await getDoc(userDocRef);

          if (snap.exists()) {
            const data = snap.data() as UserProfile;
            // Ensure normal customer accounts remain customer role in the customer view
            setCustomerProfile(data);
          } else {
            const newProfile: UserProfile = {
              uid: user.uid,
              email: user.email || 'student@gecbanka.ac.in',
              displayName: user.displayName || (user.email ? user.email.split('@')[0] : 'Campus Member'),
              role: 'customer',
              permissions: ['customer_view_orders'],
              assignedBy: 'Self Registration',
              createdAt: new Date().toISOString(),
              lastLoginAt: new Date().toISOString()
            };
            await setDoc(userDocRef, newProfile, { merge: true });
            setCustomerProfile(newProfile);
          }
        } catch (err) {
          console.warn('Customer profile sync notice:', err);
        }
      } else {
        setCustomerProfile(null);
      }
    });
    return () => unsubscribe();
  }, []);

  // 2. Dedicated Owner/Admin Auth Listener (adminAuth instance - verified in admins collection)
  useEffect(() => {
    const unsubscribeAdmin = onAuthStateChanged(adminAuth, async (user) => {
      setIsAdminAuthLoading(false);

      if (user) {
        try {
          const isMaster = user.uid === MASTER_ADMIN_UID || isSystemAdminEmail(user.email);
          const adminDocRef = doc(adminDb, 'admins', user.uid);
          const snap = await getDoc(adminDocRef);

          if (snap.exists()) {
            const data = snap.data() as AdminProfile;
            if (data.isActive !== false && (data.role === 'admin' || data.role === 'owner' || data.role === 'staff')) {
              setAdminUser(user);
              setAdminProfile(data);
              return;
            }
          }

          if (isMaster) {
            const masterRecord: AdminProfile = {
              uid: user.uid,
              email: user.email || 'admin@camporacafe.gecbanka.ac.in',
              displayName: user.displayName || 'Lead Administrator & Owner',
              role: user.uid === MASTER_ADMIN_UID ? 'owner' : 'admin',
              permissions: ['all', 'manage_orders', 'manage_menu', 'manage_tables', 'manage_settings', 'manage_staff'],
              assignedBy: 'System Master Authority',
              createdAt: new Date().toISOString(),
              lastLoginAt: new Date().toISOString(),
              isActive: true
            };
            await setDoc(adminDocRef, masterRecord, { merge: true });
            setAdminUser(user);
            setAdminProfile(masterRecord);
            return;
          }

          // If a customer account signed in to adminAuth unexpectedly, immediately sign out and revoke!
          await signOut(adminAuth);
          setAdminUser(null);
          setAdminProfile(null);
        } catch (err) {
          console.warn('Admin auth verification notice:', err);
          const isMaster = user.uid === MASTER_ADMIN_UID || isSystemAdminEmail(user.email);
          if (isMaster) {
            setAdminUser(user);
            setAdminProfile({
              uid: user.uid,
              email: user.email || 'admin@camporacafe.gecbanka.ac.in',
              displayName: user.displayName || 'Lead Administrator',
              role: 'owner',
              permissions: ['all', 'manage_orders', 'manage_menu', 'manage_tables', 'manage_settings', 'manage_staff'],
              assignedBy: 'System Authority',
              createdAt: new Date().toISOString(),
              isActive: true
            });
          } else {
            setAdminUser(null);
            setAdminProfile(null);
          }
        }
      } else {
        setAdminUser(null);
        setAdminProfile(null);
      }
    });
    return () => unsubscribeAdmin();
  }, []);

  // Firebase Firestore Real-Time Synchronizations with initial seeding
  useEffect(() => {
    let unsubTables: (() => void) | undefined;
    let unsubMenu: (() => void) | undefined;
    let unsubSettings: (() => void) | undefined;
    let unsubPromos: (() => void) | undefined;
    let unsubUsers: (() => void) | undefined;

    try {
      // 1. Tables collection
      const tablesCol = collection(db, 'tables');
      unsubTables = onSnapshot(tablesCol, (snapshot) => {
        if (!snapshot.empty) {
          const list: CafeTable[] = [];
          snapshot.forEach((docSnap) => {
            list.push(docSnap.data() as CafeTable);
          });
          // Sort by table number
          list.sort((a, b) => a.tableNumber.localeCompare(b.tableNumber));
          setTables(list);
        } else {
          INITIAL_TABLES.forEach((tbl) => {
            setDoc(doc(db, 'tables', tbl.id), tbl).catch(console.warn);
          });
        }
      }, (err) => console.warn('Firestore tables sync error:', err));

      // 3. Menu Items collection
      const menuCol = collection(db, 'menuItems');
      unsubMenu = onSnapshot(menuCol, (snapshot) => {
        if (!snapshot.empty) {
          const list: MenuItem[] = [];
          snapshot.forEach((docSnap) => {
            list.push(docSnap.data() as MenuItem);
          });
          setMenuItems(list);
        } else {
          INITIAL_MENU_ITEMS.forEach((item) => {
            setDoc(doc(db, 'menuItems', item.id), item).catch(console.warn);
          });
        }
      }, (err) => console.warn('Firestore menu sync error:', err));

      // 4. Cafe Settings
      const settingsDoc = doc(db, 'settings', 'general');
      unsubSettings = onSnapshot(settingsDoc, (docSnap) => {
        if (docSnap.exists()) {
          const loaded = docSnap.data() as CafeSettings;
          if (!loaded.upiId || loaded.upiId === 'campora.gecbanka@oksbi') {
            loaded.upiId = '8210794268-4@ybl';
            loaded.upiName = loaded.upiName || 'Campora Café';
            setDoc(settingsDoc, loaded, { merge: true }).catch(console.warn);
          }
          setSettings(loaded);
        } else {
          setDoc(settingsDoc, INITIAL_CAFE_SETTINGS).catch(console.warn);
        }
      }, (err) => console.warn('Firestore settings sync error:', err));

      // 5. Promo codes
      const promosCol = collection(db, 'promoCodes');
      unsubPromos = onSnapshot(promosCol, (snapshot) => {
        if (!snapshot.empty) {
          const list: PromoCode[] = [];
          snapshot.forEach((docSnap) => {
            list.push(docSnap.data() as PromoCode);
          });
          setPromoCodes(list);
        } else {
          INITIAL_PROMO_CODES.forEach((p) => {
            setDoc(doc(db, 'promoCodes', p.code), p).catch(console.warn);
          });
        }
      }, (err) => console.warn('Firestore promo sync error:', err));

      // 6. Users and Admins collections with designated Master Admin seed
      const usersCol = collection(db, 'users');
      unsubUsers = onSnapshot(usersCol, (snapshot) => {
        const masterAdminProfile: UserProfile = {
          uid: MASTER_ADMIN_UID,
          email: 'edu.kundanai@gmail.com',
          displayName: 'Lead Administrator',
          role: 'admin',
          permissions: ['all', 'manage_orders', 'manage_menu', 'manage_tables', 'manage_settings', 'manage_staff'],
          assignedBy: 'System Master Authority',
          createdAt: new Date().toISOString(),
          lastLoginAt: new Date().toISOString()
        };

        const masterAdminRecord: AdminProfile = {
          uid: MASTER_ADMIN_UID,
          email: 'edu.kundanai@gmail.com',
          displayName: 'Lead Administrator & Owner',
          role: 'owner',
          permissions: ['all', 'manage_orders', 'manage_menu', 'manage_tables', 'manage_settings', 'manage_staff'],
          assignedBy: 'System Master Authority',
          createdAt: new Date().toISOString(),
          lastLoginAt: new Date().toISOString(),
          isActive: true
        };

        // Seed admins collection
        setDoc(doc(adminDb, 'admins', MASTER_ADMIN_UID), masterAdminRecord, { merge: true }).catch(console.warn);

        if (!snapshot.empty) {
          const list: UserProfile[] = [];
          snapshot.forEach((docSnap) => {
            list.push(docSnap.data() as UserProfile);
          });
          setAllUsers(list);

          const hasMaster = list.some((u) => u.uid === MASTER_ADMIN_UID);
          if (!hasMaster) {
            setDoc(doc(db, 'users', MASTER_ADMIN_UID), masterAdminProfile).catch(console.warn);
          }
        } else {
          setDoc(doc(db, 'users', MASTER_ADMIN_UID), masterAdminProfile).catch(console.warn);
          setAllUsers([masterAdminProfile]);
        }
      }, (err) => console.warn('Firestore users sync error:', err));

    } catch (e) {
      console.warn('Firebase connection established with local cache mode:', e);
    }

    return () => {
      unsubTables?.();
      unsubMenu?.();
      unsubSettings?.();
      unsubPromos?.();
      unsubUsers?.();
    };
  }, []);

  // Dedicated Scalable Orders Synchronization with Role-Based Scoping
  useEffect(() => {
    let unsubOrders: (() => void) | undefined;

    try {
      const ordersCol = collection(db, 'orders');

      if (isAdminUser) {
        // Admin: listen to recent 50 orders ordered by creation date descending
        const adminQ = query(ordersCol, orderBy('createdAt', 'desc'), limit(50));
        unsubOrders = onSnapshot(adminQ, (snapshot) => {
          if (!snapshot.empty) {
            const list: BookingOrder[] = [];
            snapshot.forEach((docSnap) => {
              const data = docSnap.data() as BookingOrder;
              list.push({ ...data, id: docSnap.id });
            });
            list.sort((a, b) => new Date(b.createdAt).getTime() - new Date(a.createdAt).getTime());
            setOrders((prev) => {
              const map = new Map<string, BookingOrder>();
              list.forEach((o) => map.set(o.id, o));
              prev.forEach((o) => {
                if (!map.has(o.id)) map.set(o.id, o);
              });
              const merged = Array.from(map.values());
              merged.sort((a, b) => new Date(b.createdAt).getTime() - new Date(a.createdAt).getTime());
              return merged;
            });
          }
        }, (err) => console.warn('Admin orders sync error:', err));
      } else if (currentUser) {
        // Logged-in Customer: listen to own orders with authorization query
        const custQ = query(ordersCol, where('userId', '==', currentUser.uid), limit(50));
        unsubOrders = onSnapshot(custQ, (snapshot) => {
          const list: BookingOrder[] = [];
          snapshot.forEach((docSnap) => {
            const data = docSnap.data() as BookingOrder;
            list.push({ ...data, id: docSnap.id });
          });
          list.sort((a, b) => new Date(b.createdAt).getTime() - new Date(a.createdAt).getTime());
          setOrders((prev) => {
            const map = new Map<string, BookingOrder>();
            list.forEach((o) => map.set(o.id, o));
            // retain any guest orders created before login or in local storage
            prev.forEach((o) => {
              if (
                !map.has(o.id) &&
                (o.userId === currentUser.uid ||
                  o.customerId === currentUser.uid ||
                  o.deviceSessionSlug === getOrCreateDeviceSessionSlug())
              ) {
                map.set(o.id, o);
              }
            });
            const merged = Array.from(map.values());
            merged.sort((a, b) => new Date(b.createdAt).getTime() - new Date(a.createdAt).getTime());
            return merged;
          });
        }, (err) => console.warn('Customer orders sync error:', err));
      } else {
        // Unauthenticated guest: listen to orders for this deviceSessionSlug
        const currentSlug = getOrCreateDeviceSessionSlug();
        const guestQ = query(ordersCol, where('deviceSessionSlug', '==', currentSlug), limit(20));
        unsubOrders = onSnapshot(guestQ, (snapshot) => {
          if (!snapshot.empty) {
            const list: BookingOrder[] = [];
            snapshot.forEach((docSnap) => {
              const data = docSnap.data() as BookingOrder;
              list.push({ ...data, id: docSnap.id });
            });
            list.sort((a, b) => new Date(b.createdAt).getTime() - new Date(a.createdAt).getTime());
            setOrders((prev) => {
              const map = new Map<string, BookingOrder>();
              list.forEach((o) => map.set(o.id, o));
              prev.forEach((o) => {
                if (!map.has(o.id)) map.set(o.id, o);
              });
              const merged = Array.from(map.values());
              merged.sort((a, b) => new Date(b.createdAt).getTime() - new Date(a.createdAt).getTime());
              return merged;
            });
          }
        }, (err) => console.warn('Guest orders sync error:', err));
      }
    } catch (e) {
      console.warn('Orders listener setup error:', e);
    }

    return () => {
      unsubOrders?.();
    };
  }, [currentUser, isAdminUser]);

  // Dedicated Counter Sales Synchronization (Admin/Owner scope)
  useEffect(() => {
    let unsubCounterSales: (() => void) | undefined;
    if (!isAdminUser) return;

    try {
      const activeDb = adminDb || db;
      const salesCol = collection(activeDb, 'counterSales');
      const salesQ = query(salesCol, orderBy('createdAt', 'desc'), limit(100));

      unsubCounterSales = onSnapshot(salesQ, (snapshot) => {
        if (!snapshot.empty) {
          const list: CounterSale[] = [];
          snapshot.forEach((docSnap) => {
            const data = docSnap.data() as CounterSale;
            list.push({ ...data, id: docSnap.id });
          });
          list.sort((a, b) => new Date(b.createdAt).getTime() - new Date(a.createdAt).getTime());
          setCounterSales(list);
        } else {
          // If empty in Firestore, seed with INITIAL_SAMPLE_COUNTER_SALES
          INITIAL_SAMPLE_COUNTER_SALES.forEach((sampleSale) => {
            setDoc(doc(activeDb, 'counterSales', sampleSale.id), sampleSale).catch(console.warn);
          });
          setCounterSales(INITIAL_SAMPLE_COUNTER_SALES);
        }
      }, (err) => {
        console.warn('Firestore counterSales sync error:', err);
      });
    } catch (e) {
      console.warn('Counter sales listener setup error:', e);
    }

    return () => {
      unsubCounterSales?.();
    };
  }, [isAdminUser]);

  // Dedicated Campus Staff Directory, Attendance & Audit Logs Synchronization (Admin/Owner scope)
  useEffect(() => {
    let unsubStaff: (() => void) | undefined;
    let unsubAuditLogs: (() => void) | undefined;
    let unsubAttendance: (() => void) | undefined;

    try {
      const activeDb = adminDb || db;
      const staffCol = collection(activeDb, 'staff');

      unsubStaff = onSnapshot(staffCol, (snapshot) => {
        if (!snapshot.empty) {
          const list: StaffMember[] = [];
          snapshot.forEach((docSnap) => {
            const data = docSnap.data() as StaffMember;
            list.push({ ...data, id: docSnap.id });
          });
          setStaffMembers(list);
          localStorage.setItem(LOCAL_STORAGE_KEYS.STAFF, JSON.stringify(list));
        } else {
          INITIAL_STAFF_MEMBERS.forEach((sampleStaff) => {
            setDoc(doc(activeDb, 'staff', sampleStaff.id), sampleStaff, { merge: true }).catch(console.warn);
          });
        }
      }, (err) => {
        console.warn('Firestore staff sync error (using cached):', err);
      });

      const auditCol = collection(activeDb, 'staffAuditLogs');
      const auditQ = query(auditCol, orderBy('timestamp', 'desc'), limit(150));
      unsubAuditLogs = onSnapshot(auditQ, (snapshot) => {
        if (!snapshot.empty) {
          const list: StaffAuditLog[] = [];
          snapshot.forEach((docSnap) => {
            const data = docSnap.data() as StaffAuditLog;
            list.push({ ...data, id: docSnap.id });
          });
          setStaffAuditLogs(list);
          localStorage.setItem(LOCAL_STORAGE_KEYS.STAFF_AUDIT_LOGS, JSON.stringify(list));
        } else {
          INITIAL_STAFF_AUDIT_LOGS.forEach((sampleLog) => {
            setDoc(doc(activeDb, 'staffAuditLogs', sampleLog.id), sampleLog, { merge: true }).catch(console.warn);
          });
        }
      }, (err) => {
        console.warn('Firestore staffAuditLogs sync error (using cached):', err);
      });

      const attendanceCol = collection(activeDb, 'staffAttendance');
      unsubAttendance = onSnapshot(attendanceCol, (snapshot) => {
        if (!snapshot.empty) {
          const list: StaffAttendanceRecord[] = [];
          snapshot.forEach((docSnap) => {
            const data = docSnap.data() as StaffAttendanceRecord;
            list.push({ ...data, id: docSnap.id });
          });
          setStaffAttendance(list);
          localStorage.setItem(LOCAL_STORAGE_KEYS.STAFF_ATTENDANCE, JSON.stringify(list));
        } else {
          INITIAL_STAFF_ATTENDANCE.forEach((sampleAtt) => {
            setDoc(doc(activeDb, 'staffAttendance', sampleAtt.id), sampleAtt, { merge: true }).catch(console.warn);
          });
        }
      }, (err) => {
        console.warn('Firestore staffAttendance sync error (using cached):', err);
      });
    } catch (e) {
      console.warn('Staff listener setup error:', e);
    }

    return () => {
      unsubStaff?.();
      unsubAuditLogs?.();
      unsubAttendance?.();
    };
  }, [isAdminUser]);

  const loadMoreOrders = async () => {
    if (isLoadingMoreOrders || !hasMoreOrders || orders.length === 0) return;
    setIsLoadingMoreOrders(true);
    try {
      const ordersCol = collection(db, 'orders');
      const oldestOrder = orders[orders.length - 1];
      let q;
      if (isAdminUser) {
        q = query(
          ordersCol,
          orderBy('createdAt', 'desc'),
          startAfter(oldestOrder.createdAt),
          limit(25)
        );
      } else if (currentUser) {
        q = query(
          ordersCol,
          where('userId', '==', currentUser.uid),
          orderBy('createdAt', 'desc'),
          startAfter(oldestOrder.createdAt),
          limit(25)
        );
      }

      if (q) {
        const snap = await getDocs(q);
        if (snap.empty) {
          setHasMoreOrders(false);
        } else {
          const older: BookingOrder[] = [];
          snap.forEach((d) => {
            older.push({ ...(d.data() as BookingOrder), id: d.id });
          });
          setOrders((prev) => {
            const map = new Map<string, BookingOrder>();
            prev.forEach((o) => map.set(o.id, o));
            older.forEach((o) => map.set(o.id, o));
            const merged = Array.from(map.values());
            merged.sort((a, b) => new Date(b.createdAt).getTime() - new Date(a.createdAt).getTime());
            return merged;
          });
          if (snap.docs.length < 25) {
            setHasMoreOrders(false);
          }
        }
      }
    } catch (e) {
      console.warn('loadMoreOrders error:', e);
      setHasMoreOrders(false);
    } finally {
      setIsLoadingMoreOrders(false);
    }
  };

  // Sync to local storage as fallback
  useEffect(() => {
    localStorage.setItem(LOCAL_STORAGE_KEYS.SETTINGS, JSON.stringify(settings));
  }, [settings]);

  useEffect(() => {
    localStorage.setItem(LOCAL_STORAGE_KEYS.MENU, JSON.stringify(menuItems));
  }, [menuItems]);

  useEffect(() => {
    localStorage.setItem(LOCAL_STORAGE_KEYS.TABLES, JSON.stringify(tables));
  }, [tables]);

  useEffect(() => {
    localStorage.setItem(LOCAL_STORAGE_KEYS.CART, JSON.stringify(cart));
  }, [cart]);

  useEffect(() => {
    localStorage.setItem(LOCAL_STORAGE_KEYS.ORDERS, JSON.stringify(orders));
  }, [orders]);

  useEffect(() => {
    localStorage.setItem(LOCAL_STORAGE_KEYS.COUNTER_SALES, JSON.stringify(counterSales));
  }, [counterSales]);

  useEffect(() => {
    localStorage.setItem(LOCAL_STORAGE_KEYS.CUSTOMERS, JSON.stringify(customers));
  }, [customers]);

  useEffect(() => {
    localStorage.setItem(LOCAL_STORAGE_KEYS.PROMOS, JSON.stringify(promoCodes));
  }, [promoCodes]);

  useEffect(() => {
    if (activeOrderId) {
      localStorage.setItem(LOCAL_STORAGE_KEYS.ACTIVE_ORDER_ID, activeOrderId);
    } else {
      localStorage.removeItem(LOCAL_STORAGE_KEYS.ACTIVE_ORDER_ID);
    }
  }, [activeOrderId]);

  // Auth Operations - Customer Authentication (auth)
  const loginCustomerWithGoogle = async () => {
    try {
      const result = await signInWithPopup(auth, googleProvider);
      showToast('Welcome!', `Logged in as ${result.user.displayName || result.user.email}`, 'success');
    } catch (error: any) {
      console.error('Google Sign In Error:', error);
      showToast('Sign In Error', error.message || 'Could not sign in with Google', 'error');
    }
  };
  const loginWithGoogle = loginCustomerWithGoogle;

  const loginCustomerWithEmail = async (email: string, pass: string) => {
    try {
      const cleanEmail = email.trim().toLowerCase();
      await signInWithEmailAndPassword(auth, cleanEmail, pass);
      showToast('Signed In', `Welcome back, ${cleanEmail}`, 'success');
    } catch (error: any) {
      let friendlyMsg = 'Invalid email or password. Please check your credentials or register an account.';
      if (
        error?.code === 'auth/user-not-found' ||
        error?.code === 'auth/invalid-credential' ||
        error?.code === 'auth/wrong-password'
      ) {
        friendlyMsg = 'Invalid email or password. Please check your credentials or create an account.';
      } else if (error?.code === 'auth/too-many-requests') {
        friendlyMsg = 'Too many attempts. Access is temporarily paused; please try again shortly or reset your password.';
      } else if (error?.code === 'auth/invalid-email') {
        friendlyMsg = 'Please enter a valid email address.';
      } else if (error?.message) {
        friendlyMsg = error.message.replace(/^Firebase:\s*/i, '').replace(/\(auth\/[^)]+\)\.?/i, '').trim();
      }
      console.warn('Sign In Notice:', friendlyMsg);
      showToast('Authentication Notice', friendlyMsg, 'error');
      const customErr: any = new Error(friendlyMsg);
      customErr.code = error?.code;
      throw customErr;
    }
  };
  const loginWithEmail = loginCustomerWithEmail;

  // Dedicated Owner & Admin Authentication Methods (adminAuth + admins collection verification)
  const loginAdminWithEmail = async (email: string, pass: string) => {
    const cleanEmail = email.trim().toLowerCase();
    try {
      let cred;
      try {
        cred = await signInWithEmailAndPassword(adminAuth, cleanEmail, pass);
      } catch (authErr: any) {
        // Auto-bootstrap demo admin if credentials match
        if (cleanEmail === 'admin@camporacafe.gecbanka.ac.in') {
          try {
            cred = await createUserWithEmailAndPassword(adminAuth, cleanEmail, pass);
            await updateProfile(cred.user, { displayName: 'Café Lead Admin' });
          } catch {
            throw authErr;
          }
        } else {
          throw authErr;
        }
      }

      const uid = cred.user.uid;
      const isMaster = uid === MASTER_ADMIN_UID || isSystemAdminEmail(cleanEmail);

      // Check if this corresponds to a registered Campus Staff Member
      const matchedStaff = staffMembers.find(s => s.email.toLowerCase() === cleanEmail);
      if (matchedStaff) {
        if (matchedStaff.status === 'inactive' || matchedStaff.status === 'suspended') {
          await signOut(adminAuth);
          setAdminUser(null);
          setAdminProfile(null);
          setCurrentStaff(null);
          localStorage.removeItem(LOCAL_STORAGE_KEYS.CURRENT_STAFF_ID);
          throw new Error(`Access Denied: Your staff account is currently ${matchedStaff.status.toUpperCase()}. Please contact the café owner.`);
        }
      }

      // Verify that this user is authorized in admins collection
      const adminDocRef = doc(adminDb, 'admins', uid);
      const adminSnap = await getDoc(adminDocRef);

      if (adminSnap.exists()) {
        const data = adminSnap.data() as AdminProfile;
        if (data.isActive === false) {
          await signOut(adminAuth);
          setAdminUser(null);
          setAdminProfile(null);
          setCurrentStaff(null);
          localStorage.removeItem(LOCAL_STORAGE_KEYS.CURRENT_STAFF_ID);
          throw new Error('Access Denied: Your Café Administrator account has been deactivated. Please contact the café owner.');
        }
        if (matchedStaff) {
          setCurrentStaff(matchedStaff);
          localStorage.setItem(LOCAL_STORAGE_KEYS.CURRENT_STAFF_ID, matchedStaff.id);
        }
        setAdminUser(cred.user);
        setAdminProfile(data);
        setIsAdminMode(true);
        showToast('Admin Access Verified', `Welcome, ${data.displayName || cleanEmail}`, 'success');
        return;
      }

      if (matchedStaff) {
        setCurrentStaff(matchedStaff);
        localStorage.setItem(LOCAL_STORAGE_KEYS.CURRENT_STAFF_ID, matchedStaff.id);
        const staffAdminData: AdminProfile = {
          uid,
          email: cleanEmail,
          displayName: matchedStaff.fullName,
          role: matchedStaff.role === 'owner' ? 'owner' : (matchedStaff.role === 'manager' ? 'manager' as any : 'staff'),
          permissions: matchedStaff.permissions,
          assignedBy: matchedStaff.addedByName || 'Lead Administrator & Owner',
          createdAt: matchedStaff.createdAt,
          lastLoginAt: new Date().toISOString(),
          isActive: true
        };
        await setDoc(adminDocRef, staffAdminData, { merge: true }).catch(console.warn);
        setAdminUser(cred.user);
        setAdminProfile(staffAdminData);
        setIsAdminMode(true);
        showToast('Staff Access Granted', `Welcome back, ${matchedStaff.fullName} (${matchedStaff.position})`, 'success');
        recordStaffAuditLog({
          staffName: matchedStaff.fullName,
          staffId: matchedStaff.staffId,
          staffUid: uid,
          action: `logged in to Staff Management Panel`,
          category: 'staff',
          details: `Role: ${matchedStaff.role.toUpperCase()} • Position: ${matchedStaff.position}`
        });
        return;
      }

      if (isMaster) {
        const adminData: AdminProfile = {
          uid,
          email: cleanEmail,
          displayName: cred.user.displayName || (uid === MASTER_ADMIN_UID ? 'Lead Administrator & Owner' : 'Café Lead Admin'),
          role: uid === MASTER_ADMIN_UID ? 'owner' : 'admin',
          permissions: ['all', 'manage_orders', 'manage_menu', 'manage_tables', 'manage_settings', 'manage_staff'],
          assignedBy: 'System Master Authority',
          createdAt: new Date().toISOString(),
          lastLoginAt: new Date().toISOString(),
          isActive: true
        };
        await setDoc(adminDocRef, adminData, { merge: true });
        setAdminUser(cred.user);
        setAdminProfile(adminData);
        setIsAdminMode(true);
        showToast('Admin Access Granted', `Welcome, ${adminData.displayName}`, 'success');
        return;
      }

      // If user exists in auth or customer database but is NOT an authorized admin:
      await signOut(adminAuth);
      setAdminUser(null);
      setAdminProfile(null);
      throw new Error('Access Denied: Customer accounts are strictly prohibited from accessing the Admin Panel. Please use an authorized Café Owner or Administrator account.');
    } catch (error: any) {
      let friendlyMsg = error?.message || 'Admin authentication failed.';
      if (
        error?.code === 'auth/user-not-found' ||
        error?.code === 'auth/invalid-credential' ||
        error?.code === 'auth/wrong-password'
      ) {
        friendlyMsg = 'Invalid Admin credentials. Note: Customer accounts cannot log in to the Admin Panel.';
      } else if (error?.code === 'auth/too-many-requests') {
        friendlyMsg = 'Too many attempts. Admin login is temporarily locked for security.';
      } else if (friendlyMsg.startsWith('Firebase:')) {
        friendlyMsg = friendlyMsg.replace(/^Firebase:\s*/i, '').replace(/\(auth\/[^)]+\)\.?/i, '').trim();
      }
      showToast('Admin Access Denied', friendlyMsg, 'error');
      const err = new Error(friendlyMsg);
      (err as any).code = error?.code;
      throw err;
    }
  };

  const loginAdminWithGoogle = async () => {
    try {
      const result = await signInWithPopup(adminAuth, googleProvider);
      const user = result.user;
      const cleanEmail = (user.email || '').toLowerCase().trim();
      const uid = user.uid;
      const isMaster = uid === MASTER_ADMIN_UID || isSystemAdminEmail(cleanEmail);

      const adminDocRef = doc(adminDb, 'admins', uid);
      const adminSnap = await getDoc(adminDocRef);

      if (adminSnap.exists()) {
        const data = adminSnap.data() as AdminProfile;
        if (data.isActive === false) {
          await signOut(adminAuth);
          setAdminUser(null);
          setAdminProfile(null);
          throw new Error('Access Denied: Your Administrator account has been deactivated.');
        }
        setAdminUser(user);
        setAdminProfile(data);
        setIsAdminMode(true);
        showToast('Admin Access Verified', `Welcome, ${data.displayName || cleanEmail}`, 'success');
        return;
      }

      if (isMaster) {
        const adminData: AdminProfile = {
          uid,
          email: cleanEmail,
          displayName: user.displayName || 'Lead Administrator',
          role: uid === MASTER_ADMIN_UID ? 'owner' : 'admin',
          permissions: ['all', 'manage_orders', 'manage_menu', 'manage_tables', 'manage_settings', 'manage_staff'],
          assignedBy: 'System Master Authority',
          createdAt: new Date().toISOString(),
          lastLoginAt: new Date().toISOString(),
          isActive: true
        };
        await setDoc(adminDocRef, adminData, { merge: true });
        setAdminUser(user);
        setAdminProfile(adminData);
        setIsAdminMode(true);
        showToast('Admin Access Granted', `Welcome, ${adminData.displayName}`, 'success');
        return;
      }

      await signOut(adminAuth);
      setAdminUser(null);
      setAdminProfile(null);
      throw new Error('Access Denied: This Google account is not registered as an authorized Café Owner or Administrator.');
    } catch (error: any) {
      let friendlyMsg = error?.message || 'Admin Google Sign In Failed.';
      if (friendlyMsg.startsWith('Firebase:')) {
        friendlyMsg = friendlyMsg.replace(/^Firebase:\s*/i, '').replace(/\(auth\/[^)]+\)\.?/i, '').trim();
      }
      showToast('Admin Access Denied', friendlyMsg, 'error');
      throw new Error(friendlyMsg);
    }
  };

  const logoutAdmin = async () => {
    try {
      if (currentStaff) {
        recordStaffAuditLog({
          staffName: currentStaff.fullName,
          staffId: currentStaff.staffId,
          staffUid: currentStaff.uid,
          action: `logged out of Staff Management Panel`,
          category: 'staff'
        });
      }
      await signOut(adminAuth);
      setAdminUser(null);
      setAdminProfile(null);
      setCurrentStaff(null);
      localStorage.removeItem(LOCAL_STORAGE_KEYS.CURRENT_STAFF_ID);
      setIsAdminMode(false);
      showToast('Session Ended', 'You have been securely signed out of the staff and admin panel.', 'info');
    } catch (error: any) {
      console.error('Admin Sign Out Error:', error);
    }
  };

  const logoutCustomer = async () => {
    try {
      await signOut(auth);
      setCustomerUser(null);
      setCustomerProfile(null);
      showToast('Signed Out', 'You have been signed out of your customer account.', 'info');
    } catch (error: any) {
      console.error('Sign Out Error:', error);
    }
  };
  const logout = logoutCustomer;

  const signupWithEmail = async (email: string, pass: string) => {
    const cleanEmail = email.trim().toLowerCase();
    try {
      await createUserWithEmailAndPassword(auth, cleanEmail, pass);
      showToast('Account Created', `Logged in as ${cleanEmail}`, 'success');
    } catch (error: any) {
      if (error?.code === 'auth/email-already-in-use' || error?.message?.includes('email-already-in-use')) {
        try {
          await signInWithEmailAndPassword(auth, cleanEmail, pass);
          showToast('Signed In', `Welcome back, ${cleanEmail}`, 'success');
          return;
        } catch {
          const friendlyMsg = 'An account with this email already exists. Please sign in or reset your password.';
          showToast('Account Exists', friendlyMsg, 'info');
          const customErr: any = new Error(friendlyMsg);
          customErr.code = 'auth/email-already-in-use';
          throw customErr;
        }
      }
      let friendlyMsg = error?.message?.replace(/^Firebase:\s*/i, '').replace(/\(auth\/[^)]+\)\.?/i, '').trim() || 'Could not create account';
      showToast('Signup Notice', friendlyMsg, 'error');
      const customErr: any = new Error(friendlyMsg);
      customErr.code = error?.code;
      throw customErr;
    }
  };

  // Dedicated, 100% resilient student demo login handler
  const loginDemoStudent = async () => {
    const primaryDemoEmail = 'student.demo@camporacafe.gecbanka.ac.in';
    const demoPass = 'student1234';

    // 1. Direct sign-in attempt
    try {
      await signInWithEmailAndPassword(auth, primaryDemoEmail, demoPass);
      showToast('Welcome!', 'Logged in as Aman Kumar (Student Patron)', 'success');
      return;
    } catch (directErr: any) {
      console.log('Primary demo direct sign in notice:', directErr?.code);
    }

    // 2. Direct creation attempt for primary demo account
    try {
      const res = await createUserWithEmailAndPassword(auth, primaryDemoEmail, demoPass);
      const user = res.user;
      try {
        await updateProfile(user, { displayName: 'Aman Kumar (Student Patron)' });
      } catch (e) {
        console.warn('Profile notice:', e);
      }
      const demoProfile: UserProfile = {
        uid: user.uid,
        email: primaryDemoEmail,
        displayName: 'Aman Kumar (Student Patron)',
        role: 'customer',
        permissions: ['customer_view_orders'],
        phone: '+91 98765 43210',
        departmentOrHostel: 'Boys Hostel 1 (BH-1)',
        savedDeliveryAddress: 'Boys Hostel 1 (BH-1), Room 204',
        roomNumber: '204',
        loyaltyPoints: 150,
        assignedBy: 'System Demo',
        createdAt: new Date().toISOString(),
        lastLoginAt: new Date().toISOString()
      };
      await setDoc(doc(db, 'users', user.uid), demoProfile);
      setCustomerProfile(demoProfile);
      showToast('Demo Ready!', 'Student demo account created and ready.', 'success');
      return;
    } catch (createErr: any) {
      console.log('Primary demo account creation notice:', createErr?.code);
    }

    // 3. If primary demo email was taken with another password, use device session specific user
    const currentSlug = getOrCreateDeviceSessionSlug().slice(-6);
    const sessionDemoEmail = `student.${currentSlug}@camporacafe.gecbanka.ac.in`;
    try {
      const res = await createUserWithEmailAndPassword(auth, sessionDemoEmail, demoPass);
      const user = res.user;
      try {
        await updateProfile(user, { displayName: 'Aman Kumar (Student Patron)' });
      } catch (e) {
        console.warn('Profile notice:', e);
      }
      const demoProfile: UserProfile = {
        uid: user.uid,
        email: sessionDemoEmail,
        displayName: 'Aman Kumar (Student Patron)',
        role: 'customer',
        permissions: ['customer_view_orders'],
        phone: '+91 98765 43210',
        departmentOrHostel: 'Boys Hostel 1 (BH-1)',
        savedDeliveryAddress: 'Boys Hostel 1 (BH-1), Room 204',
        roomNumber: '204',
        loyaltyPoints: 150,
        assignedBy: 'System Demo',
        createdAt: new Date().toISOString(),
        lastLoginAt: new Date().toISOString()
      };
      await setDoc(doc(db, 'users', user.uid), demoProfile);
      setCustomerProfile(demoProfile);
      showToast('Demo Ready!', 'Signed into student demo account.', 'success');
      return;
    } catch (fallbackCreateErr: any) {
      // 4. Try signing in with sessionDemoEmail
      try {
        await signInWithEmailAndPassword(auth, sessionDemoEmail, demoPass);
        showToast('Welcome!', 'Signed into student demo account.', 'success');
        return;
      } catch (fallbackSignInErr) {
        console.warn('Session demo sign in notice:', fallbackSignInErr);
      }
    }

    // 5. Ultimate client-side authenticated patron session fallback
    const offlineUid = `demo_student_${Date.now()}`;
    const fallbackProfile: UserProfile = {
      uid: offlineUid,
      email: primaryDemoEmail,
      displayName: 'Aman Kumar (Student Patron)',
      role: 'customer',
      permissions: ['customer_view_orders'],
      phone: '+91 98765 43210',
      departmentOrHostel: 'Boys Hostel 1 (BH-1)',
      savedDeliveryAddress: 'Boys Hostel 1 (BH-1), Room 204',
      roomNumber: '204',
      loyaltyPoints: 150,
      assignedBy: 'System Demo',
      createdAt: new Date().toISOString(),
      lastLoginAt: new Date().toISOString()
    };
    setCustomerProfile(fallbackProfile);
    showToast('Demo Active', 'Guest student patron session active.', 'success');
  };

  const signupCustomer = async (
    name: string,
    email: string,
    pass: string,
    phone: string,
    departmentOrHostel?: string
  ) => {
    const cleanEmail = email.trim().toLowerCase();
    try {
      const res = await createUserWithEmailAndPassword(auth, cleanEmail, pass);
      const user = res.user;

      try {
        await updateProfile(user, { displayName: name.trim() });
      } catch (e) {
        console.warn('updateProfile notice:', e);
      }

      const newProfile: UserProfile = {
        uid: user.uid,
        email: cleanEmail,
        displayName: name.trim(),
        role: 'customer',
        permissions: ['customer_view_orders'],
        phone: phone.trim(),
        departmentOrHostel: departmentOrHostel?.trim() || '',
        savedDeliveryAddress: departmentOrHostel?.trim() || '',
        loyaltyPoints: 100, // 100 bonus points for campus students!
        assignedBy: 'Self Registration',
        createdAt: new Date().toISOString(),
        lastLoginAt: new Date().toISOString()
      };

      try {
        await setDoc(doc(db, 'users', user.uid), newProfile);
      } catch (err) {
        console.warn('Firestore user profile write error:', err);
      }

      setCustomerProfile(newProfile);
      showToast('Welcome to Campora Cafe!', `Account created for ${name.trim()} (+100 Loyalty Points awarded!)`, 'success');
    } catch (error: any) {
      // Check if email already in use
      const isEmailInUse =
        error?.code === 'auth/email-already-in-use' ||
        error?.message?.includes('email-already-in-use') ||
        error?.message?.includes('already in use');

      if (isEmailInUse) {
        // Attempt automatic sign-in if the user provided their registered password
        try {
          const signInRes = await signInWithEmailAndPassword(auth, cleanEmail, pass);
          const loggedUser = signInRes.user;
          // Merge customer phone and hostel info if needed
          if (phone.trim() || departmentOrHostel?.trim()) {
            const userDocRef = doc(db, 'users', loggedUser.uid);
            await setDoc(
              userDocRef,
              {
                phone: phone.trim(),
                departmentOrHostel: departmentOrHostel?.trim() || '',
                savedDeliveryAddress: departmentOrHostel?.trim() || '',
                lastLoginAt: new Date().toISOString()
              },
              { merge: true }
            );
          }
          showToast('Welcome Back!', 'Account already registered — signed in successfully.', 'success');
          return;
        } catch (signInErr: any) {
          // If password doesn't match, produce a clear, friendly error
          const friendlyMessage =
            'An account with this email address already exists. Please sign in with your password, or use "Forgot Password".';
          const customError: any = new Error(friendlyMessage);
          customError.code = 'auth/email-already-in-use';
          showToast('Account Exists', 'This email is already registered. Please sign in.', 'info');
          throw customError;
        }
      }

      let friendlyMsg = error.message || 'Could not register customer account';
      if (error?.code === 'auth/weak-password') {
        friendlyMsg = 'Password must be at least 6 characters.';
      } else if (error?.code === 'auth/invalid-email') {
        friendlyMsg = 'Please enter a valid email address.';
      } else {
        friendlyMsg = friendlyMsg.replace(/^Firebase:\s*/i, '').replace(/\(auth\/[^)]+\)\.?/i, '').trim();
      }

      console.warn('Customer Signup Notice:', friendlyMsg);
      showToast('Registration Notice', friendlyMsg, 'error');
      const customErr: any = new Error(friendlyMsg);
      customErr.code = error?.code;
      throw customErr;
    }
  };

  const updateCustomerProfile = async (updates: Partial<UserProfile>) => {
    if (!currentUser) throw new Error('You must be signed in to update your profile.');

    const userDocRef = doc(db, 'users', currentUser.uid);
    const sanitized = {
      ...updates,
      lastLoginAt: new Date().toISOString()
    };

    try {
      await updateDoc(userDocRef, sanitized);
    } catch (err) {
      await setDoc(userDocRef, {
        uid: currentUser.uid,
        email: currentUser.email || '',
        displayName: currentUser.displayName || 'Campus Member',
        role: 'customer',
        permissions: ['customer_view_orders'],
        ...sanitized
      }, { merge: true });
    }

    setCustomerProfile((prev) => (prev ? { ...prev, ...updates } : null));
    showToast('Profile Saved', 'Your account and campus delivery preferences were updated.', 'success');
  };

  const resetPassword = async (email: string) => {
    try {
      await sendPasswordResetEmail(auth, email);
      showToast('Reset Email Sent', `Password reset instructions sent to ${email}`, 'info');
    } catch (error: any) {
      console.error('Password Reset Error:', error);
      showToast('Reset Failed', error.message || 'Could not send password reset email', 'error');
      throw error;
    }
  };

  const assignUserRole = async (targetUid: string, role: UserRole, permissions?: string[]) => {
    try {
      const targetUser = allUsers.find(u => u.uid === targetUid);
      const userDocRef = doc(adminDb, 'users', targetUid);
      const updates: Partial<UserProfile> = {
        role,
        permissions: permissions || (role === 'admin' || role === 'owner'
          ? ['all', 'manage_orders', 'manage_menu', 'manage_tables', 'manage_settings', 'manage_staff']
          : ['manage_orders', 'manage_tables']),
        assignedBy: adminProfile?.displayName || adminUser?.email || 'Owner Admin',
        lastLoginAt: new Date().toISOString()
      };
      await updateDoc(userDocRef, updates).catch(async () => {
        await setDoc(userDocRef, updates, { merge: true });
      });

      // Synchronize with isolated admins collection
      const adminDocRef = doc(adminDb, 'admins', targetUid);
      if (role === 'admin' || role === 'owner' || role === 'staff') {
        const adminData: AdminProfile = {
          uid: targetUid,
          email: targetUser?.email || '',
          displayName: targetUser?.displayName || 'Authorized Admin',
          role,
          permissions: permissions || (role === 'admin' || role === 'owner'
            ? ['all', 'manage_orders', 'manage_menu', 'manage_tables', 'manage_settings', 'manage_staff']
            : ['manage_orders', 'manage_tables']),
          assignedBy: adminProfile?.displayName || adminUser?.email || 'Owner Admin',
          createdAt: new Date().toISOString(),
          lastLoginAt: new Date().toISOString(),
          isActive: true
        };
        await setDoc(adminDocRef, adminData, { merge: true });
      } else {
        // Demote to customer: deactivate admin record so they can never access admin panel
        await updateDoc(adminDocRef, { isActive: false }).catch(() => {});
      }

      showToast('Role Updated', `Assigned ${role.toUpperCase()} role to ${targetUid.slice(0, 8)}...`, 'success');
    } catch (err: any) {
      console.error('Failed to assign user role:', err);
      showToast('Role Update Failed', err.message || 'Could not update role in Firestore', 'error');
      throw err;
    }
  };

  // Toast helper
  const showToast = (title: string, description?: string, type: ToastMessage['type'] = 'success') => {
    const id = `toast-${Date.now()}-${Math.random().toString(36).substr(2, 5)}`;
    setToasts((prev) => [...prev, { id, title, description, type }]);
    setTimeout(() => {
      dismissToast(id);
    }, 4000);
  };

  const dismissToast = (id: string) => {
    setToasts((prev) => prev.filter((t) => t.id !== id));
  };

  // Cart total items count
  const totalCartItemCount = useMemo(() => {
    return cart.reduce((sum, item) => sum + item.quantity, 0);
  }, [cart]);

  // Customer Orders list: unified across direct customerId, email match, phone match, or current device session
  const customerOrders = useMemo(() => {
    const currentSlug = getOrCreateDeviceSessionSlug();
    const userUid = currentUser?.uid;
    const userEmail = currentUser?.email?.toLowerCase().trim();
    const userPhone = currentUserProfile?.phone?.replace(/\D/g, '');

    return orders.filter((o) => {
      // 1. Matched by registered account UID
      if (userUid && o.customerId === userUid) return true;
      // 2. Matched by customer email
      if (userEmail && o.customer?.email && o.customer.email.toLowerCase().trim() === userEmail) return true;
      // 3. Matched by customer phone number
      if (userPhone && userPhone.length >= 7 && o.customer?.phone && o.customer.phone.replace(/\D/g, '') === userPhone) return true;
      // 4. Matched by device session
      if (o.deviceSessionSlug && o.deviceSessionSlug === currentSlug) return true;
      return false;
    });
  }, [orders, currentUser, currentUserProfile]);

  // System-wide Active Orders vs Permanent Order History
  const activeOrders = useMemo(() => {
    return orders.filter((o) => o.status === 'confirmed' || o.status === 'preparing' || o.status === 'ready');
  }, [orders]);

  const orderHistory = useMemo(() => {
    return orders.filter((o) => o.status === 'completed' || o.status === 'cancelled');
  }, [orders]);

  // Customer-scoped Active Orders vs Permanent Order History
  const customerActiveOrders = useMemo(() => {
    return customerOrders.filter((o) => o.status === 'confirmed' || o.status === 'preparing' || o.status === 'ready');
  }, [customerOrders]);

  const customerOrderHistory = useMemo(() => {
    return customerOrders.filter((o) => o.status === 'completed' || o.status === 'cancelled');
  }, [customerOrders]);

  // Active Order getter: picks selected activeOrderId, or falls back to latest customer active order
  const activeOrder = useMemo(() => {
    if (activeOrderId) {
      const match = orders.find((o) => o.id === activeOrderId);
      if (match) return match;
    }
    return customerActiveOrders[0] || null;
  }, [orders, activeOrderId, customerActiveOrders]);

  const setActiveOrder = (order: BookingOrder | null) => {
    setActiveOrderId(order ? order.id : null);
  };

  // One-Click Reorder past order into active cart
  const reorderPastOrder = (pastOrder: BookingOrder) => {
    if (!isCafeOpenNow) {
      showToast('Café Closed', 'Currently Closed – Ordering is Temporarily Unavailable.', 'warning');
      return;
    }

    if (!pastOrder.items || pastOrder.items.length === 0) {
      showToast('Empty Order', 'This order contains no items to reorder.', 'warning');
      return;
    }

    pastOrder.items.forEach((item) => {
      const liveItem = menuItems.find((m) => m.id === item.menuItemId);
      if (liveItem) {
        addToCart(
          liveItem,
          item.quantity,
          item.selectedSize,
          item.selectedAddons,
          item.specialInstructions
        );
      } else {
        const fallbackItem: MenuItem = {
          id: item.menuItemId,
          name: item.name,
          price: item.unitPrice,
          category: 'mains',
          description: '',
          image: item.image,
          dietaryTags: ['veg'],
          isAvailable: true,
          stockCount: 100,
          rating: 4.9,
          reviewCount: 10,
          preparationTimeMinutes: 10,
          ingredients: [],
          allergenWarnings: []
        };
        addToCart(
          fallbackItem,
          item.quantity,
          item.selectedSize,
          item.selectedAddons,
          item.specialInstructions
        );
      }
    });

    setIsCustomerAccountOpen(false);
    setIsCartOpen(true);
    showToast('Order Added to Tray', `Loaded ${pastOrder.items.length} items from #${pastOrder.id} to your tray.`, 'success');
  };

  // Check if cafe is open right now
  // The Admin Open/Closed toggle takes authoritative control:
  // - When admin switches to "Café Open", customers can browse and place orders normally.
  // - When admin switches to "Café Closed", customers can browse the menu but cannot place orders.
  const { isCafeOpenNow, currentDaySchedule } = useMemo(() => {
    const now = new Date();
    const dayNames = ['Sunday', 'Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday', 'Saturday'];
    const currentDayName = dayNames[now.getDay()];
    
    const schedule = settings.operatingHours?.find(
      (h) => h.day.toLowerCase() === currentDayName.toLowerCase()
    );

    // Explicit admin status toggle (default is open/true if not explicitly false)
    const isManuallyOpen = settings.isOpen !== false;

    return { isCafeOpenNow: isManuallyOpen, currentDaySchedule: schedule || null };
  }, [settings.isOpen, settings.operatingHours]);

  // Cart operations
  const addToCart = (
    item: MenuItem,
    quantity = 1,
    size?: MenuItem['sizes'] extends (infer U)[] ? U : undefined,
    addons?: CartItem['selectedAddons'],
    specialInstructions?: string
  ) => {
    if (!isCafeOpenNow) {
      showToast('Café Closed', 'Currently Closed – Ordering is Temporarily Unavailable.', 'info');
      return;
    }

    const sizeDelta = size ? size.priceDelta : 0;
    const addonsTotal = addons ? addons.reduce((sum, a) => sum + a.price, 0) : 0;
    const calculatedUnitPrice = Math.max(0, item.price + sizeDelta + addonsTotal);

    // Create unique key based on item id + size name + addons signature
    const addonsSig = addons ? addons.map((a) => a.id).sort().join('-') : '';
    const sizeSig = size ? size.name : 'default';
    const cartItemId = `${item.id}-${sizeSig}-${addonsSig}-${Date.now()}`;

    // Check if an identical configured item exists
    const existingIndex = cart.findIndex(
      (c) =>
        c.menuItemId === item.id &&
        (c.selectedSize?.name || 'default') === sizeSig &&
        (c.selectedAddons?.map((a) => a.id).sort().join('-') || '') === addonsSig &&
        (c.specialInstructions || '') === (specialInstructions || '')
    );

    if (existingIndex > -1) {
      const updated = [...cart];
      updated[existingIndex].quantity += quantity;
      setCart(updated);
    } else {
      const newCartItem: CartItem = {
        cartItemId,
        menuItemId: item.id,
        name: item.name,
        unitPrice: item.price,
        calculatedPrice: calculatedUnitPrice,
        quantity,
        image: item.image,
        selectedSize: size,
        selectedAddons: addons,
        specialInstructions
      };
      setCart((prev) => [...prev, newCartItem]);
    }

    showToast(`Added to tray!`, `${quantity}x ${item.name}`, 'success');
  };

  const updateCartItemQuantity = (cartItemId: string, delta: number) => {
    setCart((prev) => {
      return prev
        .map((item) => {
          if (item.cartItemId === cartItemId) {
            const newQty = item.quantity + delta;
            return newQty > 0 ? { ...item, quantity: newQty } : null;
          }
          return item;
        })
        .filter((item): item is CartItem => item !== null);
    });
  };

  const removeCartItem = (cartItemId: string) => {
    const itemToRemove = cart.find((i) => i.cartItemId === cartItemId);
    setCart((prev) => prev.filter((i) => i.cartItemId !== cartItemId));
    if (itemToRemove) {
      showToast('Item removed', `${itemToRemove.name} was removed from tray.`, 'info');
    }
  };

  const updateCartItemInstructions = (cartItemId: string, instructions: string) => {
    setCart((prev) =>
      prev.map((item) =>
        item.cartItemId === cartItemId ? { ...item, specialInstructions: instructions } : item
      )
    );
  };

  const clearCart = () => {
    setCart([]);
    setAppliedPromo(null);
  };

  // Promo code validation
  const applyPromoCode = (codeStr: string): { success: boolean; message: string } => {
    const trimmed = codeStr.trim().toUpperCase();
    const found = promoCodes.find((p) => p.code.toUpperCase() === trimmed && p.isActive);

    if (!found) {
      return { success: false, message: 'Invalid or expired promo code.' };
    }

    const subtotal = cart.reduce((sum, item) => sum + item.calculatedPrice * item.quantity, 0);
    if (subtotal < found.minOrderAmount) {
      return {
        success: false,
        message: `Minimum order amount of ${settings.currency}${found.minOrderAmount.toFixed(2)} required for this coupon.`
      };
    }

    setAppliedPromo(found);
    showToast(`Promo Applied!`, `${found.code} saved you ${settings.currency}${found.discountType === 'percentage' ? `${found.discountValue}%` : found.discountValue}`, 'success');
    return { success: true, message: `Promo code ${found.code} applied successfully!` };
  };

  const removePromoCode = () => {
    setAppliedPromo(null);
    showToast('Promo code removed', undefined, 'info');
  };

  // Pricing calculations
  const calculatePricing = (mode: BookingMode, tipAmount = 0): OrderPricing => {
    const subtotal = cart.reduce((sum, item) => sum + item.calculatedPrice * item.quantity, 0);
    
    let discountAmount = 0;
    if (appliedPromo && subtotal >= appliedPromo.minOrderAmount) {
      if (appliedPromo.discountType === 'percentage') {
        discountAmount = (subtotal * appliedPromo.discountValue) / 100;
      } else {
        discountAmount = Math.min(subtotal, appliedPromo.discountValue);
      }
    }

    const discountedSubtotal = Math.max(0, subtotal - discountAmount);
    const gstTax = (discountedSubtotal * settings.taxRatePercent) / 100;
    const serviceFee = mode === 'dine-in' ? settings.serviceFeeFixed : 0;
    const deliveryFee = mode === 'delivery' ? settings.deliveryFeeFixed : 0;
    const total = Math.max(0, discountedSubtotal + gstTax + serviceFee + deliveryFee + tipAmount);

    return {
      subtotal,
      discountAmount,
      discountCode: appliedPromo?.code,
      gstTax,
      serviceFee,
      deliveryFee,
      tip: tipAmount,
      total
    };
  };

  // Create Booking Order with Firestore persistence
  const createBookingOrder = async (
    bookingMode: BookingMode,
    customer: BookingCustomer,
    paymentMethod: BookingOrder['paymentMethod'],
    dineInDetails?: DineInDetails,
    takeoutDetails?: TakeoutDetails,
    deliveryDetails?: DeliveryDetails,
    tip = 0
  ): Promise<BookingOrder> => {
    if (!isCafeOpenNow) {
      showToast('Café Closed', 'Currently Closed – Ordering is Temporarily Unavailable.', 'warning');
      throw new Error('Currently Closed – Ordering is Temporarily Unavailable');
    }

    const pricing = calculatePricing(bookingMode, tip);
    const orderNumber = Math.floor(1000 + Math.random() * 9000);
    const orderId = `BK-${orderNumber}`;

    // Estimated ready time
    const now = new Date();
    let estimatedReadyTime = '10-15 mins';
    if (bookingMode === 'dine-in' && dineInDetails) {
      estimatedReadyTime = `${dineInDetails.date} at ${dineInDetails.timeSlot}`;
    } else if (bookingMode === 'takeout' && takeoutDetails) {
      estimatedReadyTime = takeoutDetails.pickupTime;
    } else {
      const readyDate = new Date(now.getTime() + 25 * 60 * 1000);
      estimatedReadyTime = readyDate.toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' });
    }

    const qrPayload = `CAMPORA-${orderId}-${bookingMode.toUpperCase()}-${customer.phone.slice(-4)}`;
    const deviceSessionSlug = getOrCreateDeviceSessionSlug();

    const newOrder: BookingOrder = {
      id: orderId,
      createdAt: new Date().toISOString(),
      customerId: currentUser ? currentUser.uid : undefined,
      deviceSessionSlug,
      bookingMode,
      status: 'confirmed',
      customer,
      dineInDetails,
      takeoutDetails,
      deliveryDetails,
      items: [...cart],
      pricing,
      paymentMethod,
      paymentStatus: (paymentMethod === 'counter' || paymentMethod === 'cash') ? 'pay_on_arrival' : 'paid',
      qrCodePayload: qrPayload,
      estimatedReadyTime,
      adminNotes: bookingMode === 'dine-in' && dineInDetails?.tableNumber ? `Assigned Table ${dineInDetails.tableNumber}` : 'GEC Banka Campus Order'
    };

    // Save to Firestore
    try {
      await setDoc(doc(db, 'orders', orderId), newOrder);
    } catch (err) {
      console.warn('Firestore write order error, saving locally:', err);
    }

    // Award loyalty points to signed-in customer account
    if (currentUser) {
      const earnedPoints = Math.max(10, Math.floor(pricing.total * 5));
      const currentPts = currentUserProfile?.loyaltyPoints || 0;
      const newTotalPts = currentPts + earnedPoints;
      try {
        const userDocRef = doc(db, 'users', currentUser.uid);
        await updateDoc(userDocRef, {
          loyaltyPoints: newTotalPts,
          phone: customer.phone || currentUserProfile?.phone || '',
          savedDeliveryAddress: deliveryDetails?.hostelOrBuilding || currentUserProfile?.savedDeliveryAddress || '',
          roomNumber: deliveryDetails?.roomOrFloor || currentUserProfile?.roomNumber || '',
          lastLoginAt: new Date().toISOString()
        });
        setCustomerProfile((prev) => prev ? {
          ...prev,
          loyaltyPoints: newTotalPts,
          phone: customer.phone || prev.phone,
          savedDeliveryAddress: deliveryDetails?.hostelOrBuilding || prev.savedDeliveryAddress,
          roomNumber: deliveryDetails?.roomOrFloor || prev.roomNumber
        } : null);
      } catch (err) {
        console.warn('Could not update customer loyalty points in profile:', err);
      }
    }

    // If dine in with selected table, update table status to reserved in Firestore
    if (bookingMode === 'dine-in' && dineInDetails?.tableId) {
      try {
        await updateDoc(doc(db, 'tables', dineInDetails.tableId), {
          status: 'reserved',
          currentBookingId: orderId
        });
      } catch (err) {
        console.warn('Firestore update table error:', err);
      }
      setTables((prev) =>
        prev.map((t) =>
          t.id === dineInDetails.tableId
            ? { ...t, status: 'reserved', currentBookingId: orderId }
            : t
        )
      );
    }

    // Deduct stock for ordered items
    if (cart.length > 0) {
      for (const orderedItem of cart) {
        const target = menuItems.find((m) => m.id === orderedItem.menuItemId);
        if (target) {
          const newStock = Math.max(0, target.stockCount - orderedItem.quantity);
          try {
            await updateDoc(doc(db, 'menuItems', target.id), {
              stockCount: newStock,
              isAvailable: newStock > 0
            });
          } catch (e) {
            console.warn(e);
          }
        }
      }
      setMenuItems((prev) =>
        prev.map((menuItem) => {
          const orderedItem = cart.find((c) => c.menuItemId === menuItem.id);
          if (orderedItem) {
            const newStock = Math.max(0, menuItem.stockCount - orderedItem.quantity);
            return {
              ...menuItem,
              stockCount: newStock,
              isAvailable: newStock > 0
            };
          }
          return menuItem;
        })
      );
    }

    // Update customer CRM
    setCustomers((prev) => {
      const existing = prev.find((c) => c.phone === customer.phone || c.email === customer.email);
      if (existing) {
        const updated = {
          ...existing,
          totalBookings: existing.totalBookings + 1,
          totalSpent: existing.totalSpent + pricing.total,
          lastVisit: new Date().toISOString().split('T')[0],
          loyaltyPoints: existing.loyaltyPoints + Math.floor(pricing.total * 10),
          isVIP: existing.totalBookings + 1 >= 5 || existing.totalSpent + pricing.total > 1500
        };
        try {
          setDoc(doc(db, 'customers', existing.id), updated);
        } catch (e) { console.warn(e); }
        return prev.map((c) => (c.id === existing.id ? updated : c));
      } else {
        const newCust: CustomerRecord = {
          id: `cust-${Date.now()}`,
          name: customer.name,
          phone: customer.phone,
          email: customer.email,
          totalBookings: 1,
          totalSpent: pricing.total,
          isVIP: false,
          lastVisit: new Date().toISOString().split('T')[0],
          favoriteItems: cart.map((i) => i.name),
          loyaltyPoints: Math.floor(pricing.total * 10),
          notes: customer.specialRequests
        };
        try {
          setDoc(doc(db, 'customers', newCust.id), newCust);
        } catch (e) { console.warn(e); }
        return [...prev, newCust];
      }
    });

    setOrders((prev) => [newOrder, ...prev]);
    setActiveOrderId(orderId);
    clearCart();

    return newOrder;
  };

  const updateOrderStatus = async (orderId: string, status: OrderStatus, adminNotes?: string) => {
    const nowIso = new Date().toISOString();
    const updatePayload: Partial<BookingOrder> = {
      status,
      updatedAt: nowIso,
      ...(status === 'completed' ? { completedAt: nowIso } : {}),
      ...(status === 'cancelled' ? { cancelledAt: nowIso } : {}),
      ...(adminNotes ? { adminNotes } : {})
    };

    try {
      await updateDoc(doc(db, 'orders', orderId), updatePayload);
    } catch (err) {
      console.warn('Firestore update order error:', err);
    }

    setOrders((prev) =>
      prev.map((o) =>
        o.id === orderId
          ? { ...o, ...updatePayload }
          : o
      )
    );

    // Record operational staff audit log
    const performerName = currentStaff?.fullName || adminProfile?.displayName || (adminUser?.uid === MASTER_ADMIN_UID ? 'Owner Kundan' : 'Staff');
    const performerId = currentStaff?.staffId || (adminUser?.uid === MASTER_ADMIN_UID ? 'CC-OWNER-01' : 'STAFF');
    recordStaffAuditLog({
      staffName: performerName,
      staffId: performerId,
      action: `Staff ${performerName} updated Order #${orderId} – ${status.charAt(0).toUpperCase() + status.slice(1)}`,
      category: 'order',
      relevantId: orderId,
      details: adminNotes || `Order marked as ${status}`
    });

    // If order was dine-in and is completed or cancelled, free the table
    const targetOrder = orders.find((o) => o.id === orderId);
    if (targetOrder?.dineInDetails?.tableId && (status === 'completed' || status === 'cancelled')) {
      try {
        await updateDoc(doc(db, 'tables', targetOrder.dineInDetails.tableId), {
          status: 'available',
          currentBookingId: ''
        });
      } catch (err) {
        console.warn('Firestore update table error:', err);
      }
      setTables((prev) =>
        prev.map((t) =>
          t.id === targetOrder.dineInDetails?.tableId
            ? { ...t, status: 'available', currentBookingId: undefined }
            : t
        )
      );
    }

    showToast(`Order ${orderId} updated`, `Status set to ${status.toUpperCase()}`, 'info');
  };

  const cancelOrder = async (orderId: string, reason?: string): Promise<{ success: boolean; error?: string }> => {
    const targetOrder = orders.find((o) => o.id === orderId);
    if (!targetOrder) {
      showToast('Order Not Found', `Order #${orderId} was not found.`, 'warning');
      return { success: false, error: `Order #${orderId} was not found.` };
    }
    if (targetOrder.status === 'completed') {
      showToast('Cannot Cancel', 'This order has already been completed.', 'warning');
      return { success: false, error: 'This order has already been completed.' };
    }
    if (targetOrder.status === 'cancelled') {
      showToast('Already Cancelled', 'This order is already cancelled.', 'info');
      return { success: false, error: 'This order is already cancelled.' };
    }

    const cancelReason = reason || 'Customer requested cancellation';
    const nowIso = new Date().toISOString();

    const updatePayload: Partial<BookingOrder> = {
      status: 'cancelled',
      updatedAt: nowIso,
      cancelledAt: nowIso,
      cancellationReason: cancelReason,
      adminNotes: targetOrder.adminNotes 
        ? `${targetOrder.adminNotes} | Cancellation: ${cancelReason}` 
        : `Cancelled: ${cancelReason}`
    };

    try {
      await updateDoc(doc(db, 'orders', orderId), updatePayload);
    } catch (err: any) {
      console.warn('Firestore cancel order error:', err);
    }

    setOrders((prev) =>
      prev.map((o) =>
        o.id === orderId
          ? { ...o, ...updatePayload }
          : o
      )
    );

    // Free table if dine-in
    if (targetOrder.dineInDetails?.tableId) {
      try {
        await updateDoc(doc(db, 'tables', targetOrder.dineInDetails.tableId), {
          status: 'available',
          currentBookingId: ''
        });
      } catch (err) {
        console.warn('Firestore update table error:', err);
      }
      setTables((prev) =>
        prev.map((t) =>
          t.id === targetOrder.dineInDetails?.tableId
            ? { ...t, status: 'available', currentBookingId: undefined }
            : t
        )
      );
    }

    showToast(`Order #${orderId} Cancelled`, cancelReason, 'info');
    return { success: true };
  };

  const submitOrderFeedback = async (orderId: string, rating: number, comment: string) => {
    const feedback = {
      rating,
      comment,
      submittedAt: new Date().toISOString()
    };

    try {
      await updateDoc(doc(db, 'orders', orderId), { feedback });
    } catch (err) {
      console.warn('Firestore feedback error:', err);
    }

    setOrders((prev) =>
      prev.map((o) => (o.id === orderId ? { ...o, feedback } : o))
    );
    showToast('Thank you!', 'Your rating and feedback have been received by Campora Cafe.', 'success');
  };

  // Database instance selector: use adminDb when authenticated as admin so rules validate admin auth
  const writeDb = adminUser ? adminDb : db;

  // Table operations
  const updateTableStatus = async (tableId: string, status: TableStatus) => {
    try {
      await updateDoc(doc(writeDb, 'tables', tableId), { status });
    } catch (err) {
      console.warn('Firestore table status error:', err);
    }
    setTables((prev) =>
      prev.map((t) => (t.id === tableId ? { ...t, status } : t))
    );
    showToast('Table status updated', undefined, 'info');

    const targetTable = tables.find(t => t.id === tableId);
    const tblName = targetTable ? `Table ${targetTable.tableNumber}` : tableId;
    const performerName = currentStaff?.fullName || adminProfile?.displayName || (adminUser?.uid === MASTER_ADMIN_UID ? 'Owner Kundan' : 'Staff');
    const performerId = currentStaff?.staffId || (adminUser?.uid === MASTER_ADMIN_UID ? 'CC-OWNER-01' : 'STAFF');
    recordStaffAuditLog({
      staffName: performerName,
      staffId: performerId,
      action: `Staff ${performerName} changed table status – ${tblName}`,
      category: 'table',
      relevantId: tblName,
      details: `Status set to ${status.toUpperCase()}`
    });
  };

  const addTable = async (tableData: Omit<CafeTable, 'id'>) => {
    const newTable: CafeTable = {
      ...tableData,
      id: `tbl-${Date.now()}`
    };
    try {
      await setDoc(doc(writeDb, 'tables', newTable.id), newTable);
    } catch (err) {
      console.warn('Firestore add table error:', err);
    }
    setTables((prev) => [...prev, newTable]);
    showToast('Table Added', `Table ${newTable.tableNumber} added to campus layout.`, 'success');
  };

  const deleteTable = async (tableId: string) => {
    try {
      await deleteDoc(doc(writeDb, 'tables', tableId));
    } catch (err) {
      console.warn('Firestore delete table error:', err);
    }
    setTables((prev) => prev.filter((t) => t.id !== tableId));
    showToast('Table deleted', undefined, 'info');
  };

  // Menu item CRUD
  const addMenuItem = async (itemData: Omit<MenuItem, 'id'>) => {
    const newItem: MenuItem = {
      ...itemData,
      id: `item-${Date.now()}`
    };
    try {
      await setDoc(doc(writeDb, 'menuItems', newItem.id), newItem);
    } catch (err) {
      console.warn('Firestore add item error:', err);
    }
    setMenuItems((prev) => [newItem, ...prev]);
    showToast('Item Created', `${newItem.name} added to menu!`, 'success');
  };

  const updateMenuItem = async (id: string, updates: Partial<MenuItem>) => {
    try {
      await updateDoc(doc(writeDb, 'menuItems', id), updates);
    } catch (err) {
      console.warn('Firestore update item error:', err);
    }
    setMenuItems((prev) =>
      prev.map((item) => (item.id === id ? { ...item, ...updates } : item))
    );
    showToast('Menu Item Updated', undefined, 'success');
  };

  const deleteMenuItem = async (id: string) => {
    try {
      await deleteDoc(doc(writeDb, 'menuItems', id));
    } catch (err) {
      console.warn('Firestore delete item error:', err);
    }
    setMenuItems((prev) => prev.filter((item) => item.id !== id));
    showToast('Menu Item Deleted', undefined, 'info');
  };

  const toggleItemAvailability = async (id: string) => {
    const target = menuItems.find((m) => m.id === id);
    if (!target) return;
    const newAvail = !target.isAvailable;
    try {
      await updateDoc(doc(writeDb, 'menuItems', id), { isAvailable: newAvail });
    } catch (err) {
      console.warn('Firestore toggle error:', err);
    }
    setMenuItems((prev) =>
      prev.map((item) => (item.id === id ? { ...item, isAvailable: newAvail } : item))
    );
  };

  const updateItemStock = async (id: string, newStock: number) => {
    try {
      await updateDoc(doc(writeDb, 'menuItems', id), {
        stockCount: newStock,
        isAvailable: newStock > 0
      });
    } catch (err) {
      console.warn('Firestore stock error:', err);
    }
    setMenuItems((prev) =>
      prev.map((item) =>
        item.id === id
          ? { ...item, stockCount: newStock, isAvailable: newStock > 0 }
          : item
      )
    );
  };

  // Settings & Promos
  const updateSettings = async (updates: Partial<CafeSettings>, suppressToast = false) => {
    const updated = { ...settings, ...updates };
    try {
      await setDoc(doc(writeDb, 'settings', 'general'), updated);
    } catch (err) {
      console.warn('Firestore settings update error:', err);
    }
    setSettings(updated);
    if (!suppressToast) {
      showToast('Cafe Settings Saved', undefined, 'success');
    }
  };

  const toggleCafeOpenStatus = async (forcedStatus?: boolean) => {
    const nextStatus = typeof forcedStatus === 'boolean' ? forcedStatus : !isCafeOpenNow;
    setIsUpdatingStatus(true);
    try {
      await updateSettings({ isOpen: nextStatus }, true);
      showToast(
        nextStatus ? '🟢 Café is Open' : '🔴 Café is Closed',
        nextStatus
          ? 'We Are Open – Customers can now browse the menu and place orders.'
          : 'Currently Closed – Ordering is temporarily unavailable for customers.',
        nextStatus ? 'success' : 'warning'
      );

      const isOwnerRole = currentStaff?.role === 'owner' || adminUser?.uid === MASTER_ADMIN_UID;
      const performerTitle = isOwnerRole ? 'Owner' : 'Staff';
      const performerName = currentStaff?.fullName || adminProfile?.displayName || (adminUser?.uid === MASTER_ADMIN_UID ? 'Kundan' : 'Staff');
      const performerId = currentStaff?.staffId || (adminUser?.uid === MASTER_ADMIN_UID ? 'CC-OWNER-01' : 'ADMIN-01');

      recordStaffAuditLog({
        staffName: `${performerTitle} ${performerName}`,
        staffId: performerId,
        action: `${performerTitle} ${performerName} changed Café status – ${nextStatus ? 'Open' : 'Closed'}`,
        category: 'cafe_status',
        details: nextStatus ? 'Opened store for customer orders' : 'Closed store for customer ordering'
      });
    } catch (err) {
      console.error('Failed to update cafe status:', err);
      showToast('Status Update Error', 'Could not update cafe status. Please try again.', 'error');
    } finally {
      setIsUpdatingStatus(false);
    }
  };

  const addPromoCode = async (promo: PromoCode) => {
    try {
      await setDoc(doc(writeDb, 'promoCodes', promo.code), promo);
    } catch (err) {
      console.warn('Firestore add promo error:', err);
    }
    setPromoCodes((prev) => [promo, ...prev]);
    showToast('Promo Code Created', `Code ${promo.code} is active.`, 'success');
  };

  const togglePromoCode = async (code: string) => {
    const target = promoCodes.find((p) => p.code === code);
    if (!target) return;
    const newActive = !target.isActive;
    try {
      await updateDoc(doc(writeDb, 'promoCodes', code), { isActive: newActive });
    } catch (err) {
      console.warn('Firestore toggle promo error:', err);
    }
    setPromoCodes((prev) =>
      prev.map((p) => (p.code === code ? { ...p, isActive: newActive } : p))
    );
  };

  // Comprehensive Sales Calculations: Online Orders, Counter Sales, and Payment Tender Split
  const salesSummary: SalesSummary = useMemo(() => {
    const today = new Date();
    const isToday = (isoDateString: string) => {
      if (!isoDateString) return false;
      const d = new Date(isoDateString);
      return (
        d.getDate() === today.getDate() &&
        d.getMonth() === today.getMonth() &&
        d.getFullYear() === today.getFullYear()
      );
    };

    // Valid online orders (exclude cancelled orders from sales totals)
    const validOnlineOrders = orders.filter((o) => o.status !== 'cancelled');
    const todayOnlineOrders = validOnlineOrders.filter((o) => isToday(o.createdAt));

    const onlineOrdersTotal = validOnlineOrders.reduce((sum, o) => sum + (o.pricing?.total || 0), 0);
    const todayOnlineSales = todayOnlineOrders.reduce((sum, o) => sum + (o.pricing?.total || 0), 0);

    const counterSalesTotal = counterSales.reduce((sum, s) => sum + (s.totalAmount || 0), 0);
    const todayCounterSalesList = counterSales.filter((s) => isToday(s.createdAt));
    const todayCounterSales = todayCounterSalesList.reduce((sum, s) => sum + (s.totalAmount || 0), 0);

    const combinedTotalSales = onlineOrdersTotal + counterSalesTotal;
    const todayTotalSales = todayOnlineSales + todayCounterSales;

    // Collections by tender (Total All-Time)
    const counterCash = counterSales.filter((s) => s.paymentMethod === 'cash').reduce((sum, s) => sum + (s.totalAmount || 0), 0);
    const onlineCash = validOnlineOrders.filter((o) => o.paymentMethod === 'cash').reduce((sum, o) => sum + (o.pricing?.total || 0), 0);
    const totalCashCollection = counterCash + onlineCash;

    const counterUpi = counterSales.filter((s) => s.paymentMethod === 'upi').reduce((sum, s) => sum + (s.totalAmount || 0), 0);
    const onlineUpi = validOnlineOrders.filter((o) => o.paymentMethod === 'upi').reduce((sum, o) => sum + (o.pricing?.total || 0), 0);
    const totalUpiCollection = counterUpi + onlineUpi;

    const counterOther = counterSales.filter((s) => s.paymentMethod === 'other').reduce((sum, s) => sum + (s.totalAmount || 0), 0);
    const onlineOther = validOnlineOrders.filter((o) => o.paymentMethod !== 'cash' && o.paymentMethod !== 'upi').reduce((sum, o) => sum + (o.pricing?.total || 0), 0);
    const totalOtherCollection = counterOther + onlineOther;

    // Collections by tender (Today)
    const todayCounterCash = todayCounterSalesList.filter((s) => s.paymentMethod === 'cash').reduce((sum, s) => sum + (s.totalAmount || 0), 0);
    const todayOnlineCash = todayOnlineOrders.filter((o) => o.paymentMethod === 'cash').reduce((sum, o) => sum + (o.pricing?.total || 0), 0);
    const todayCashCollection = todayCounterCash + todayOnlineCash;

    const todayCounterUpi = todayCounterSalesList.filter((s) => s.paymentMethod === 'upi').reduce((sum, s) => sum + (s.totalAmount || 0), 0);
    const todayOnlineUpi = todayOnlineOrders.filter((o) => o.paymentMethod === 'upi').reduce((sum, o) => sum + (o.pricing?.total || 0), 0);
    const todayUpiCollection = todayCounterUpi + todayOnlineUpi;

    const todayCounterOther = todayCounterSalesList.filter((s) => s.paymentMethod === 'other').reduce((sum, s) => sum + (s.totalAmount || 0), 0);
    const todayOnlineOther = todayOnlineOrders.filter((o) => o.paymentMethod !== 'cash' && o.paymentMethod !== 'upi').reduce((sum, o) => sum + (o.pricing?.total || 0), 0);
    const todayOtherCollection = todayCounterOther + todayOnlineOther;

    return {
      onlineOrdersTotal,
      counterSalesTotal,
      combinedTotalSales,
      todayOnlineSales,
      todayCounterSales,
      todayTotalSales,
      totalCashCollection,
      totalUpiCollection,
      totalOtherCollection,
      todayCashCollection,
      todayUpiCollection,
      todayOtherCollection
    };
  }, [orders, counterSales]);

  // Counter Sales Management (CRUD)
  const addCounterSale = async (saleData: {
    customerName?: string;
    customerPhone?: string;
    items: CounterSaleItem[];
    paymentMethod: CounterSalePaymentMethod;
    note?: string;
    customCreatedAt?: string;
  }): Promise<CounterSale> => {
    const totalAmount = saleData.items.reduce(
      (sum, item) => sum + (item.total !== undefined ? item.total : item.price * item.quantity),
      0
    );
    const nowIso = saleData.customCreatedAt || new Date().toISOString();
    const id = `CS-${Date.now().toString().slice(-4)}${Math.floor(100 + Math.random() * 900)}`;

    const newSale: CounterSale = {
      id,
      customerName: saleData.customerName?.trim() || 'Walk-in Customer',
      customerPhone: saleData.customerPhone?.trim() || '',
      items: saleData.items,
      totalAmount,
      paymentMethod: saleData.paymentMethod,
      createdAt: nowIso,
      note: saleData.note?.trim() || '',
      addedByUid: adminUser?.uid || 'admin',
      addedByName: adminProfile?.displayName || adminUser?.displayName || 'Lead Administrator'
    };

    try {
      await setDoc(doc(writeDb, 'counterSales', id), newSale);
    } catch (err) {
      console.warn('Firestore add counter sale error:', err);
    }

    setCounterSales((prev) => [newSale, ...prev.filter((s) => s.id !== id)]);
    showToast('Counter Sale Recorded', `Saved ₹${newSale.totalAmount} (${newSale.paymentMethod.toUpperCase()}) • ${newSale.id}`, 'success');

    const performerName = currentStaff?.fullName || adminProfile?.displayName || (adminUser?.uid === MASTER_ADMIN_UID ? 'Rahul' : 'Staff');
    const performerId = currentStaff?.staffId || (adminUser?.uid === MASTER_ADMIN_UID ? 'CC-OWNER-01' : 'STAFF');
    recordStaffAuditLog({
      staffName: performerName,
      staffId: performerId,
      action: `Staff ${performerName} created Counter Sale #${id} – ₹${newSale.totalAmount}`,
      category: 'counter_sale',
      relevantId: id,
      details: `${newSale.items.length} items (${newSale.paymentMethod.toUpperCase()}) • Customer: ${newSale.customerName}`
    });

    return newSale;
  };

  const updateCounterSale = async (id: string, updates: Partial<CounterSale>): Promise<void> => {
    const updatedAt = new Date().toISOString();
    let totalAmount = updates.totalAmount;
    if (updates.items && totalAmount === undefined) {
      totalAmount = updates.items.reduce((sum, item) => sum + (item.total !== undefined ? item.total : item.price * item.quantity), 0);
    }

    const payload = {
      ...updates,
      ...(totalAmount !== undefined ? { totalAmount } : {}),
      updatedAt
    };

    try {
      await updateDoc(doc(writeDb, 'counterSales', id), payload);
    } catch (err) {
      console.warn('Firestore update counter sale error:', err);
    }

    setCounterSales((prev) =>
      prev.map((s) => (s.id === id ? { ...s, ...payload } : s))
    );
    showToast('Counter Sale Updated', `Sale #${id} updated successfully.`, 'info');
  };

  const deleteCounterSale = async (id: string): Promise<void> => {
    try {
      await deleteDoc(doc(writeDb, 'counterSales', id));
    } catch (err) {
      console.warn('Firestore delete counter sale error:', err);
    }

    setCounterSales((prev) => prev.filter((s) => s.id !== id));
    showToast('Counter Sale Deleted', `Sale #${id} removed from records.`, 'info');
  };

  // ----------------------------------------------------
  // Campus Staff Management System & RBAC Operations
  // ----------------------------------------------------

  const hasPermission = (perm: StaffPermission): boolean => {
    if (!adminUser && !currentStaff) return false;
    // Master Admin / System Admin / Owner has all permissions
    if (adminUser?.uid === MASTER_ADMIN_UID || isSystemAdminEmail(adminUser?.email || '')) return true;
    if (adminProfile?.role === 'owner' || adminProfile?.role === 'admin') return true;
    if (adminProfile?.permissions?.includes('all')) return true;

    if (currentStaff) {
      if (currentStaff.status !== 'active') return false;
      if (currentStaff.role === 'owner') return true;
      if (currentStaff.permissions?.includes(perm)) return true;
    }

    if (adminProfile?.permissions?.includes(perm)) return true;

    return false;
  };

  const recordStaffAuditLog = async (logData: Omit<StaffAuditLog, 'id' | 'timestamp' | 'date' | 'time'>) => {
    try {
      const now = new Date();
      const dateStr = now.toISOString().split('T')[0];
      const timeStr = now.toTimeString().split(' ')[0];
      const activeDb = adminDb || db;
      
      const newLog: StaffAuditLog = {
        id: `log-${Date.now()}-${Math.random().toString(36).substr(2, 4)}`,
        staffName: logData.staffName || currentStaff?.fullName || adminProfile?.displayName || (adminUser?.uid === MASTER_ADMIN_UID ? 'Owner Kundan' : 'Staff Member'),
        staffId: logData.staffId || currentStaff?.staffId || (adminUser?.uid === MASTER_ADMIN_UID ? 'CC-OWNER-01' : 'STAFF'),
        staffUid: logData.staffUid || currentStaff?.uid || adminUser?.uid,
        action: logData.action,
        category: logData.category,
        date: dateStr,
        time: timeStr,
        timestamp: now.toISOString(),
        relevantId: logData.relevantId,
        details: logData.details
      };

      setStaffAuditLogs(prev => {
        const updated = [newLog, ...prev.filter(l => l.id !== newLog.id)].slice(0, 200);
        localStorage.setItem(LOCAL_STORAGE_KEYS.STAFF_AUDIT_LOGS, JSON.stringify(updated));
        return updated;
      });

      if (activeDb) {
        await setDoc(doc(activeDb, 'staffAuditLogs', newLog.id), newLog, { merge: true }).catch(err => {
          console.warn('Could not persist audit log to Firestore:', err);
        });
      }
    } catch (e) {
      console.warn('Error recording staff audit log:', e);
    }
  };

  const addStaffMember = async (
    staffData: Omit<StaffMember, 'id' | 'createdAt'>,
    password?: string
  ): Promise<StaffMember> => {
    if (!hasPermission('manage_staff') && !isAdminUser) {
      throw new Error('Unauthorized: Only authorized Owner or Administrator can register campus staff members.');
    }

    const docId = `staff-${Date.now()}-${Math.random().toString(36).substr(2, 5)}`;
    const newStaff: StaffMember = {
      ...staffData,
      id: docId,
      createdAt: new Date().toISOString(),
      status: staffData.status || 'active',
      addedByUid: adminUser?.uid,
      addedByName: adminProfile?.displayName || (adminUser?.uid === MASTER_ADMIN_UID ? 'Owner Kundan' : 'Lead Admin')
    };

    setStaffMembers(prev => {
      const updated = [newStaff, ...prev];
      localStorage.setItem(LOCAL_STORAGE_KEYS.STAFF, JSON.stringify(updated));
      return updated;
    });

    const activeDb = adminDb || db;
    if (activeDb) {
      await setDoc(doc(activeDb, 'staff', docId), newStaff, { merge: true }).catch(console.warn);
      
      const adminEntry: AdminProfile = {
        uid: docId,
        email: newStaff.email.toLowerCase().trim(),
        displayName: newStaff.fullName,
        role: newStaff.role === 'owner' ? 'owner' : (newStaff.role === 'manager' ? 'manager' as any : 'staff'),
        permissions: newStaff.permissions,
        assignedBy: adminProfile?.displayName || 'Owner Kundan',
        createdAt: new Date().toISOString(),
        isActive: newStaff.status === 'active'
      };
      await setDoc(doc(activeDb, 'admins', docId), adminEntry, { merge: true }).catch(console.warn);
    }

    await recordStaffAuditLog({
      staffName: adminProfile?.displayName || (adminUser?.uid === MASTER_ADMIN_UID ? 'Owner Kundan' : 'Lead Admin'),
      staffId: currentStaff?.staffId || (adminUser?.uid === MASTER_ADMIN_UID ? 'CC-OWNER-01' : 'ADMIN-01'),
      action: `added new staff member: ${newStaff.fullName} (${newStaff.staffId})`,
      category: 'staff',
      relevantId: newStaff.staffId,
      details: `Role: ${newStaff.role.toUpperCase()} • Position: ${newStaff.position} • Permissions: ${newStaff.permissions.length} granted`
    });

    showToast('Staff Registered', `Enrolled ${newStaff.fullName} (${newStaff.staffId}) as ${newStaff.position}`, 'success');
    return newStaff;
  };

  const updateStaffMember = async (staffId: string, updates: Partial<StaffMember>) => {
    if (!hasPermission('manage_staff') && !isAdminUser) {
      throw new Error('Unauthorized: Only authorized Owner or Administrator can modify staff profiles.');
    }

    const existing = staffMembers.find(s => s.id === staffId || s.staffId === staffId);
    if (!existing) throw new Error('Staff member not found');

    const updatedStaff: StaffMember = {
      ...existing,
      ...updates,
      updatedAt: new Date().toISOString()
    };

    setStaffMembers(prev => {
      const updated = prev.map(s => (s.id === existing.id ? updatedStaff : s));
      localStorage.setItem(LOCAL_STORAGE_KEYS.STAFF, JSON.stringify(updated));
      return updated;
    });

    if (currentStaff?.id === existing.id) {
      setCurrentStaff(updatedStaff);
    }

    const activeDb = adminDb || db;
    if (activeDb) {
      await setDoc(doc(activeDb, 'staff', existing.id), updatedStaff, { merge: true }).catch(console.warn);
      await setDoc(doc(activeDb, 'admins', existing.id), {
        displayName: updatedStaff.fullName,
        role: updatedStaff.role === 'owner' ? 'owner' : (updatedStaff.role === 'manager' ? 'manager' as any : 'staff'),
        permissions: updatedStaff.permissions,
        isActive: updatedStaff.status === 'active'
      }, { merge: true }).catch(console.warn);
    }

    await recordStaffAuditLog({
      staffName: adminProfile?.displayName || (adminUser?.uid === MASTER_ADMIN_UID ? 'Owner Kundan' : 'Lead Admin'),
      staffId: currentStaff?.staffId || (adminUser?.uid === MASTER_ADMIN_UID ? 'CC-OWNER-01' : 'ADMIN-01'),
      action: `updated staff profile: ${updatedStaff.fullName} (${updatedStaff.staffId})`,
      category: 'staff',
      relevantId: updatedStaff.staffId,
      details: `Fields: ${Object.keys(updates).join(', ')}`
    });

    showToast('Staff Profile Updated', `Saved changes for ${updatedStaff.fullName}`, 'success');
  };

  const toggleStaffStatus = async (staffId: string, newStatus: StaffStatus) => {
    if (!hasPermission('manage_staff') && !isAdminUser) {
      throw new Error('Unauthorized: Only authorized Owner or Administrator can change staff operational status.');
    }

    const existing = staffMembers.find(s => s.id === staffId || s.staffId === staffId);
    if (!existing) throw new Error('Staff member not found');

    if (existing.role === 'owner' && newStatus !== 'active') {
      showToast('Action Blocked', 'Primary Owner account status cannot be changed to inactive or suspended.', 'error');
      return;
    }

    const updatedStaff: StaffMember = {
      ...existing,
      status: newStatus,
      updatedAt: new Date().toISOString()
    };

    setStaffMembers(prev => {
      const updated = prev.map(s => (s.id === existing.id ? updatedStaff : s));
      localStorage.setItem(LOCAL_STORAGE_KEYS.STAFF, JSON.stringify(updated));
      return updated;
    });

    if (currentStaff?.id === existing.id) {
      setCurrentStaff(updatedStaff);
    }

    const activeDb = adminDb || db;
    if (activeDb) {
      await setDoc(doc(activeDb, 'staff', existing.id), { status: newStatus, updatedAt: new Date().toISOString() }, { merge: true }).catch(console.warn);
      await setDoc(doc(activeDb, 'admins', existing.id), { isActive: newStatus === 'active' }, { merge: true }).catch(console.warn);
    }

    const actionVerb = newStatus === 'active' ? 'activated' : (newStatus === 'suspended' ? 'suspended' : 'deactivated');
    await recordStaffAuditLog({
      staffName: adminProfile?.displayName || (adminUser?.uid === MASTER_ADMIN_UID ? 'Owner Kundan' : 'Lead Admin'),
      staffId: currentStaff?.staffId || (adminUser?.uid === MASTER_ADMIN_UID ? 'CC-OWNER-01' : 'ADMIN-01'),
      action: `${actionVerb} staff account: ${existing.fullName} (${existing.staffId})`,
      category: 'staff',
      relevantId: existing.staffId,
      details: `Status changed from ${existing.status.toUpperCase()} to ${newStatus.toUpperCase()}`
    });

    showToast('Staff Status Changed', `${existing.fullName} is now ${newStatus.toUpperCase()}`, 'info');
  };

  const deleteStaffMemberPermanently = async (staffId: string) => {
    if (!hasPermission('manage_staff') && !isAdminUser) {
      throw new Error('Unauthorized: Only authorized Owner or Administrator can delete staff members.');
    }

    const existing = staffMembers.find(s => s.id === staffId || s.staffId === staffId);
    if (!existing) throw new Error('Staff member not found');

    if (existing.role === 'owner') {
      showToast('Action Blocked', 'Primary Owner account cannot be deleted.', 'error');
      return;
    }

    setStaffMembers(prev => {
      const updated = prev.filter(s => s.id !== existing.id && s.staffId !== existing.staffId);
      localStorage.setItem(LOCAL_STORAGE_KEYS.STAFF, JSON.stringify(updated));
      return updated;
    });

    if (currentStaff?.id === existing.id) {
      setCurrentStaff(null);
      localStorage.removeItem(LOCAL_STORAGE_KEYS.CURRENT_STAFF_ID);
    }

    const activeDb = adminDb || db;
    if (activeDb) {
      await deleteDoc(doc(activeDb, 'staff', existing.id)).catch(console.warn);
      await deleteDoc(doc(activeDb, 'admins', existing.id)).catch(console.warn);
    }

    await recordStaffAuditLog({
      staffName: adminProfile?.displayName || (adminUser?.uid === MASTER_ADMIN_UID ? 'Owner Kundan' : 'Lead Admin'),
      staffId: currentStaff?.staffId || (adminUser?.uid === MASTER_ADMIN_UID ? 'CC-OWNER-01' : 'ADMIN-01'),
      action: `deleted staff record: ${existing.fullName} (${existing.staffId})`,
      category: 'staff',
      relevantId: existing.staffId,
      details: `Permanently removed staff profile from roster`
    });

    showToast('Staff Record Deleted', `Removed ${existing.fullName} from directory`, 'info');
  };

  const loginStaffQuickDemo = async (staffMember: StaffMember) => {
    if (staffMember.status === 'inactive' || staffMember.status === 'suspended') {
      showToast('Access Denied', `Staff account ${staffMember.fullName} is currently ${staffMember.status.toUpperCase()}.`, 'error');
      throw new Error(`Staff account ${staffMember.fullName} is currently ${staffMember.status.toUpperCase()}.`);
    }

    setCurrentStaff(staffMember);
    localStorage.setItem(LOCAL_STORAGE_KEYS.CURRENT_STAFF_ID, staffMember.id);

    const staffAdminProfile: AdminProfile = {
      uid: staffMember.uid || `staff-uid-${staffMember.staffId}`,
      email: staffMember.email,
      displayName: staffMember.fullName,
      role: staffMember.role === 'owner' ? 'owner' : (staffMember.role === 'manager' ? 'manager' as any : 'staff'),
      permissions: staffMember.permissions,
      assignedBy: staffMember.addedByName || 'Lead Administrator & Owner',
      createdAt: staffMember.createdAt,
      lastLoginAt: new Date().toISOString(),
      isActive: true
    };

    setAdminProfile(staffAdminProfile);
    setAdminUser({
      uid: staffMember.uid || `staff-uid-${staffMember.staffId}`,
      email: staffMember.email,
      displayName: staffMember.fullName,
    } as any);
    setIsAdminMode(true);
    showToast('Staff Session Active', `Welcome, ${staffMember.fullName} (${staffMember.position})`, 'success');

    await recordStaffAuditLog({
      staffName: staffMember.fullName,
      staffId: staffMember.staffId,
      staffUid: staffMember.uid,
      action: `logged in to Staff Management Panel`,
      category: 'staff',
      details: `Role: ${staffMember.role.toUpperCase()} • Position: ${staffMember.position} • Permissions: ${staffMember.permissions.length}`
    });
  };

  // ----------------------------------------------------
  // Campus Staff Attendance & Work Record System
  // ----------------------------------------------------

  const canManageAttendance = (): boolean => {
    if (adminUser?.uid === MASTER_ADMIN_UID || isSystemAdminEmail(adminUser?.email)) return true;
    if (adminProfile?.role === 'owner' || adminProfile?.role === 'admin') return true;
    if (currentStaff?.role === 'owner' || currentStaff?.role === 'manager') return true;
    if (hasPermission('manage_staff')) return true;
    return false;
  };

  const markStaffAttendance = async (
    recordData: Omit<StaffAttendanceRecord, 'id' | 'createdAt'>
  ): Promise<StaffAttendanceRecord> => {
    if (!canManageAttendance()) {
      showToast('Access Denied', 'Only authorized Owner/Admin or Manager can mark staff attendance.', 'error');
      throw new Error('Unauthorized: Only authorized Owner, Admin, or Manager can mark staff attendance.');
    }

    const recId = `${recordData.staffId}_${recordData.date}`;
    const existing = staffAttendance.find(a => a.id === recId || (a.staffId === recordData.staffId && a.date === recordData.date));

    // Calculate working hours if both check-in and check-out exist
    let totalWorkingMinutes = recordData.totalWorkingMinutes;
    let totalWorkingHoursFormatted = recordData.totalWorkingHoursFormatted;
    if (recordData.checkInTime && recordData.checkOutTime) {
      const calc = calculateWorkingHours(recordData.checkInTime, recordData.checkOutTime);
      totalWorkingMinutes = calc.totalMinutes;
      totalWorkingHoursFormatted = calc.formatted;
    }

    const actorName = adminProfile?.displayName || currentStaff?.fullName || (adminUser?.uid === MASTER_ADMIN_UID ? 'Owner Kundan' : 'Manager');
    const actorUid = adminUser?.uid || currentStaff?.uid || 'admin';

    let history: AttendanceCorrectionLog[] = existing?.history ? [...existing.history] : [];
    if (existing && existing.status !== recordData.status) {
      history.push({
        changedByUid: actorUid,
        changedByName: actorName,
        changedAt: new Date().toISOString(),
        originalStatus: existing.status,
        newStatus: recordData.status,
        reason: recordData.correctionReason || 'Status update by supervisor'
      });
    }

    const newRecord: StaffAttendanceRecord = {
      ...recordData,
      id: recId,
      totalWorkingMinutes,
      totalWorkingHoursFormatted,
      markedByUid: actorUid,
      markedByName: actorName,
      createdAt: existing?.createdAt || new Date().toISOString(),
      updatedAt: new Date().toISOString(),
      history
    };

    setStaffAttendance(prev => {
      const updated = [newRecord, ...prev.filter(r => r.id !== recId)];
      localStorage.setItem(LOCAL_STORAGE_KEYS.STAFF_ATTENDANCE, JSON.stringify(updated));
      return updated;
    });

    const activeDb = adminDb || db;
    if (activeDb) {
      await setDoc(doc(activeDb, 'staffAttendance', recId), newRecord, { merge: true }).catch(err => {
        console.warn('Firestore attendance save warning:', err);
      });
    }

    const actionText = existing
      ? `updated attendance for ${recordData.staffName} on ${recordData.date}: ${recordData.status.toUpperCase()}`
      : `marked attendance for ${recordData.staffName} on ${recordData.date} as ${recordData.status.toUpperCase()}`;

    await recordStaffAuditLog({
      staffName: actorName,
      staffId: currentStaff?.staffId || (adminUser?.uid === MASTER_ADMIN_UID ? 'CC-OWNER-01' : 'MGR-01'),
      action: actionText,
      category: 'staff',
      relevantId: recId,
      details: `Status: ${recordData.status.toUpperCase()}${recordData.checkInTime ? ` • In: ${recordData.checkInTime}` : ''}${recordData.checkOutTime ? ` • Out: ${recordData.checkOutTime}` : ''}${recordData.correctionReason ? ` • Note: ${recordData.correctionReason}` : ''}`
    });

    showToast('Attendance Saved', `${recordData.staffName} marked as ${recordData.status.toUpperCase()} for ${recordData.date}`, 'success');
    return newRecord;
  };

  const updateStaffAttendance = async (
    attendanceId: string,
    updates: Partial<StaffAttendanceRecord>,
    correctionReason?: string
  ): Promise<StaffAttendanceRecord> => {
    if (!canManageAttendance()) {
      showToast('Access Denied', 'Only authorized Owner/Admin or Manager can edit staff attendance records.', 'error');
      throw new Error('Unauthorized: Only authorized Owner, Admin, or Manager can edit staff attendance.');
    }

    const existing = staffAttendance.find(a => a.id === attendanceId);
    if (!existing) {
      throw new Error(`Attendance record ${attendanceId} not found.`);
    }

    const actorName = adminProfile?.displayName || currentStaff?.fullName || (adminUser?.uid === MASTER_ADMIN_UID ? 'Owner Kundan' : 'Manager');
    const actorUid = adminUser?.uid || currentStaff?.uid || 'admin';

    let history: AttendanceCorrectionLog[] = existing.history ? [...existing.history] : [];
    if (updates.status && updates.status !== existing.status) {
      history.push({
        changedByUid: actorUid,
        changedByName: actorName,
        changedAt: new Date().toISOString(),
        originalStatus: existing.status,
        newStatus: updates.status,
        reason: correctionReason || updates.correctionReason || 'Administrative correction'
      });
    }

    let checkIn = updates.checkInTime !== undefined ? updates.checkInTime : existing.checkInTime;
    let checkOut = updates.checkOutTime !== undefined ? updates.checkOutTime : existing.checkOutTime;
    let totalWorkingMinutes = existing.totalWorkingMinutes;
    let totalWorkingHoursFormatted = existing.totalWorkingHoursFormatted;

    if (checkIn && checkOut) {
      const calc = calculateWorkingHours(checkIn, checkOut);
      totalWorkingMinutes = calc.totalMinutes;
      totalWorkingHoursFormatted = calc.formatted;
    }

    const updatedRecord: StaffAttendanceRecord = {
      ...existing,
      ...updates,
      totalWorkingMinutes,
      totalWorkingHoursFormatted,
      correctionReason: correctionReason || updates.correctionReason || existing.correctionReason,
      updatedAt: new Date().toISOString(),
      history
    };

    setStaffAttendance(prev => {
      const updated = prev.map(a => a.id === attendanceId ? updatedRecord : a);
      localStorage.setItem(LOCAL_STORAGE_KEYS.STAFF_ATTENDANCE, JSON.stringify(updated));
      return updated;
    });

    const activeDb = adminDb || db;
    if (activeDb) {
      await setDoc(doc(activeDb, 'staffAttendance', attendanceId), updatedRecord, { merge: true }).catch(err => {
        console.warn('Firestore attendance update error:', err);
      });
    }

    await recordStaffAuditLog({
      staffName: actorName,
      staffId: currentStaff?.staffId || (adminUser?.uid === MASTER_ADMIN_UID ? 'CC-OWNER-01' : 'MGR-01'),
      action: `corrected attendance record for ${existing.staffName} on ${existing.date}`,
      category: 'staff',
      relevantId: attendanceId,
      details: `${updates.status ? `Status changed to ${updates.status.toUpperCase()}` : 'Record details edited'}${correctionReason ? ` • Reason: ${correctionReason}` : ''}`
    });

    showToast('Record Updated', `Attendance record for ${existing.date} updated.`, 'info');
    return updatedRecord;
  };

  const deleteStaffAttendance = async (attendanceId: string): Promise<void> => {
    if (!canManageAttendance()) {
      showToast('Access Denied', 'Only authorized Owner/Admin or Manager can delete attendance records.', 'error');
      throw new Error('Unauthorized');
    }

    const existing = staffAttendance.find(a => a.id === attendanceId);
    if (!existing) return;

    setStaffAttendance(prev => {
      const updated = prev.filter(a => a.id !== attendanceId);
      localStorage.setItem(LOCAL_STORAGE_KEYS.STAFF_ATTENDANCE, JSON.stringify(updated));
      return updated;
    });

    const activeDb = adminDb || db;
    if (activeDb) {
      await deleteDoc(doc(activeDb, 'staffAttendance', attendanceId)).catch(console.warn);
    }

    const actorName = adminProfile?.displayName || currentStaff?.fullName || 'Admin';
    await recordStaffAuditLog({
      staffName: actorName,
      staffId: currentStaff?.staffId || 'ADMIN-01',
      action: `removed attendance record for ${existing.staffName} on ${existing.date}`,
      category: 'staff',
      relevantId: attendanceId,
      details: `Deleted attendance entry for ${existing.date}`
    });

    showToast('Record Removed', `Attendance record deleted for ${existing.date}`, 'info');
  };

  return (
    <CafeContext.Provider
      value={{
        settings,
        menuItems,
        tables,
        cart,
        appliedPromo,
        orders,
        activeOrders,
        orderHistory,
        customers,
        promoCodes,
        counterSales,
        addCounterSale,
        updateCounterSale,
        deleteCounterSale,
        salesSummary,
        staffMembers,
        staffAuditLogs,
        currentStaff,
        hasPermission,
        addStaffMember,
        updateStaffMember,
        toggleStaffStatus,
        deleteStaffMemberPermanently,
        recordStaffAuditLog,
        loginStaffQuickDemo,
        staffAttendance,
        markStaffAttendance,
        updateStaffAttendance,
        deleteStaffAttendance,
        activeOrder,
        currentUser,
        currentUserProfile,
        customerUser,
        customerProfile,
        userRole,
        isAdminUser,
        allUsers,
        isAuthLoading,
        loginWithGoogle,
        loginWithEmail,
        loginCustomerWithEmail,
        loginCustomerWithGoogle,
        signupWithEmail,
        loginDemoStudent,
        signupCustomer,
        updateCustomerProfile,
        resetPassword,
        logout,
        logoutCustomer,
        adminUser,
        adminProfile,
        isAdminAuthLoading,
        loginAdminWithEmail,
        loginAdminWithGoogle,
        logoutAdmin,
        assignUserRole,
        isAdminMode,
        isCartOpen,
        isCheckoutOpen,
        isLocationModalOpen,
        isCustomerAccountOpen,
        selectedDetailItem,
        isOrderTrackerOpen,
        toasts,
        customerOrders,
        customerActiveOrders,
        customerOrderHistory,
        reorderPastOrder,
        hasMoreOrders,
        isLoadingMoreOrders,
        loadMoreOrders,
        addToCart,
        updateCartItemQuantity,
        removeCartItem,
        updateCartItemInstructions,
        clearCart,
        applyPromoCode,
        removePromoCode,
        calculatePricing,
        createBookingOrder,
        updateOrderStatus,
        cancelOrder,
        setActiveOrder,
        submitOrderFeedback,
        updateTableStatus,
        addTable,
        deleteTable,
        addMenuItem,
        updateMenuItem,
        deleteMenuItem,
        toggleItemAvailability,
        updateItemStock,
        updateSettings,
        toggleCafeOpenStatus,
        isUpdatingStatus,
        addPromoCode,
        togglePromoCode,
        setIsAdminMode,
        setIsCartOpen,
        setIsCheckoutOpen,
        setIsLocationModalOpen,
        setIsCustomerAccountOpen,
        setSelectedDetailItem,
        setIsOrderTrackerOpen,
        showToast,
        dismissToast,
        isCafeOpenNow,
        currentDaySchedule,
        totalCartItemCount
      }}
    >
      {children}
    </CafeContext.Provider>
  );
};

export const useCafe = (): CafeContextType => {
  const context = useContext(CafeContext);
  if (!context) {
    throw new Error('useCafe must be used within a CafeProvider');
  }
  return context;
};
