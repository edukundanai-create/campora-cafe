import { AttendanceStatus, StaffAttendanceRecord, MonthlyAttendanceSummary, StaffMember } from '../types';

/**
 * Parses time string (e.g. "09:30", "9:30 AM", "18:00", "6:00 PM") to minutes from 00:00
 */
export function parseTimeToMinutes(timeStr?: string): number | null {
  if (!timeStr || !timeStr.trim()) return null;
  const clean = timeStr.trim().toUpperCase();

  // Check 12-hour AM/PM format (e.g., "09:30 AM" or "6:00 PM")
  const ampmMatch = clean.match(/^(\d{1,2}):(\d{2})\s*(AM|PM)?$/);
  if (ampmMatch) {
    let hours = parseInt(ampmMatch[1], 10);
    const minutes = parseInt(ampmMatch[2], 10);
    const period = ampmMatch[3];

    if (period === 'PM' && hours < 12) hours += 12;
    if (period === 'AM' && hours === 12) hours = 0;

    return hours * 60 + minutes;
  }

  // 24-hour HH:MM
  const match24 = clean.match(/^(\d{1,2}):(\d{2})$/);
  if (match24) {
    const hours = parseInt(match24[1], 10);
    const minutes = parseInt(match24[2], 10);
    return hours * 60 + minutes;
  }

  return null;
}

/**
 * Formats minutes from midnight to 12-hour format with AM/PM (e.g. 570 -> "9:30 AM")
 */
export function formatMinutesToTime(minutes: number): string {
  const norm = ((minutes % (24 * 60)) + (24 * 60)) % (24 * 60);
  const hours24 = Math.floor(norm / 60);
  const mins = norm % 60;
  const period = hours24 >= 12 ? 'PM' : 'AM';
  const hours12 = hours24 % 12 === 0 ? 12 : hours24 % 12;
  const minsPadded = mins < 10 ? `0${mins}` : `${mins}`;
  return `${hours12}:${minsPadded} ${period}`;
}

/**
 * Formats minutes duration into human-readable hours and minutes (e.g. 510 -> "8h 30m")
 */
export function formatDurationHoursMinutes(totalMinutes: number): string {
  if (totalMinutes <= 0) return '0h 0m';
  const h = Math.floor(totalMinutes / 60);
  const m = Math.round(totalMinutes % 60);
  return `${h}h ${m}m`;
}

/**
 * Calculates total working hours between check-in and check-out
 */
export function calculateWorkingHours(
  checkIn?: string,
  checkOut?: string
): { totalMinutes: number; formatted: string } {
  const inMin = parseTimeToMinutes(checkIn);
  const outMin = parseTimeToMinutes(checkOut);

  if (inMin === null || outMin === null) {
    return { totalMinutes: 0, formatted: '' };
  }

  let diff = outMin - inMin;
  // If check-out is on the next day (overnight shift)
  if (diff < 0) {
    diff += 24 * 60;
  }

  return {
    totalMinutes: diff,
    formatted: formatDurationHoursMinutes(diff)
  };
}

/**
 * Returns human-readable label and styling classes for AttendanceStatus
 */
export function getAttendanceStatusConfig(status: AttendanceStatus): {
  label: string;
  shortLabel: string;
  emoji: string;
  badgeBg: string;
  textColor: string;
  borderColor: string;
  dotColor: string;
} {
  switch (status) {
    case 'present':
      return {
        label: 'Present',
        shortLabel: 'P',
        emoji: '🟢',
        badgeBg: 'bg-emerald-50 text-emerald-800',
        textColor: 'text-emerald-700',
        borderColor: 'border-emerald-300',
        dotColor: 'bg-emerald-500'
      };
    case 'absent':
      return {
        label: 'Absent',
        shortLabel: 'A',
        emoji: '🔴',
        badgeBg: 'bg-rose-50 text-rose-800',
        textColor: 'text-rose-700',
        borderColor: 'border-rose-300',
        dotColor: 'bg-rose-500'
      };
    case 'weekly_off':
      return {
        label: 'Weekly Off',
        shortLabel: 'WO',
        emoji: '🔵',
        badgeBg: 'bg-blue-50 text-blue-800',
        textColor: 'text-blue-700',
        borderColor: 'border-blue-300',
        dotColor: 'bg-blue-500'
      };
    case 'leave':
      return {
        label: 'Leave',
        shortLabel: 'L',
        emoji: '🟡',
        badgeBg: 'bg-amber-50 text-amber-800',
        textColor: 'text-amber-700',
        borderColor: 'border-amber-300',
        dotColor: 'bg-amber-500'
      };
    case 'holiday':
      return {
        label: 'Holiday',
        shortLabel: 'H',
        emoji: '⚪',
        badgeBg: 'bg-purple-50 text-purple-800',
        textColor: 'text-purple-700',
        borderColor: 'border-purple-300',
        dotColor: 'bg-purple-500'
      };
  }
}

const MONTH_NAMES = [
  'January',
  'February',
  'March',
  'April',
  'May',
  'June',
  'July',
  'August',
  'September',
  'October',
  'November',
  'December'
];

export function getMonthName(month: number): string {
  return MONTH_NAMES[month - 1] || '';
}

/**
 * Calculates monthly attendance summary for a staff member
 */
export function calculateMonthlyAttendanceSummary(
  records: StaffAttendanceRecord[],
  staffId: string,
  year: number,
  month: number // 1-12
): MonthlyAttendanceSummary {
  const monthStr = month < 10 ? `0${month}` : `${month}`;
  const prefix = `${year}-${monthStr}`;

  // Days in this month
  const totalDaysInMonth = new Date(year, month, 0).getDate();

  // Filter records for this staff and this year-month
  const monthlyRecords = records.filter(
    (r) => r.staffId === staffId && r.date.startsWith(prefix)
  );

  let presentDays = 0;
  let absentDays = 0;
  let weeklyOffDays = 0;
  let leaveDays = 0;
  let holidayDays = 0;
  let totalWorkingMinutes = 0;

  monthlyRecords.forEach((r) => {
    switch (r.status) {
      case 'present':
        presentDays++;
        if (r.totalWorkingMinutes && r.totalWorkingMinutes > 0) {
          totalWorkingMinutes += r.totalWorkingMinutes;
        } else if (r.checkInTime && r.checkOutTime) {
          const { totalMinutes } = calculateWorkingHours(r.checkInTime, r.checkOutTime);
          totalWorkingMinutes += totalMinutes;
        }
        break;
      case 'absent':
        absentDays++;
        break;
      case 'weekly_off':
        weeklyOffDays++;
        break;
      case 'leave':
        leaveDays++;
        break;
      case 'holiday':
        holidayDays++;
        break;
    }
  });

  // Scheduled working days: Present + Absent + Leave
  const totalWorkingDays = presentDays + absentDays + leaveDays;

  // Attendance Percentage = (Present / (Present + Absent)) * 100
  // Note: Weekly Off and Holidays are strictly not counted as absent days.
  // When an excused leave occurs, prompt example has:
  // Present: 20 Days, Absent: 2 Days, Weekly Off: 4 Days, Leave: 1 Day => 20 / (20 + 2) = 90.9%
  const evaluatedDays = presentDays + absentDays;
  const attendancePercentage =
    evaluatedDays > 0
      ? Number(((presentDays / evaluatedDays) * 100).toFixed(1))
      : presentDays > 0
      ? 100
      : 0;

  return {
    year,
    month,
    monthName: `${MONTH_NAMES[month - 1]} ${year}`,
    totalDaysInMonth,
    totalWorkingDays,
    presentDays,
    absentDays,
    weeklyOffDays,
    leaveDays,
    holidayDays,
    attendancePercentage,
    totalWorkingMinutes,
    totalWorkingHoursFormatted: formatDurationHoursMinutes(totalWorkingMinutes)
  };
}

/**
 * Generates calendar grid information for a given month and year
 */
export interface CalendarDayInfo {
  dayNumber: number;
  dateString: string; // YYYY-MM-DD
  dayOfWeek: number; // 0 (Sun) to 6 (Sat)
  dayName: string; // "Sun", "Mon", ...
  isToday: boolean;
  isFuture: boolean;
  isWeekend: boolean;
  record?: StaffAttendanceRecord;
}

export function generateCalendarDays(
  year: number,
  month: number, // 1-12
  records: StaffAttendanceRecord[],
  staffId: string
): {
  paddingDays: number; // Days to offset for starting weekday (Monday-first)
  days: CalendarDayInfo[];
} {
  const daysInMonth = new Date(year, month, 0).getDate();
  const firstDayOfWeek = new Date(year, month - 1, 1).getDay(); // 0 = Sun, 1 = Mon ...
  // Convert to Monday-first: Monday = 0, Sunday = 6
  const mondayOffset = (firstDayOfWeek + 6) % 7;

  const todayStr = new Date().toISOString().split('T')[0];
  const days: CalendarDayInfo[] = [];

  const dayNames = ['Sun', 'Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat'];

  // Map existing records by date
  const recordsMap = new Map<string, StaffAttendanceRecord>();
  records
    .filter((r) => r.staffId === staffId)
    .forEach((r) => recordsMap.set(r.date, r));

  for (let d = 1; d <= daysInMonth; d++) {
    const dayStr = d < 10 ? `0${d}` : `${d}`;
    const monthStr = month < 10 ? `0${month}` : `${month}`;
    const dateString = `${year}-${monthStr}-${dayStr}`;

    const dateObj = new Date(year, month - 1, d);
    const dayOfWeek = dateObj.getDay();
    const isWeekend = dayOfWeek === 0 || dayOfWeek === 6; // Sunday or Saturday
    const isToday = dateString === todayStr;
    const isFuture = dateString > todayStr;

    days.push({
      dayNumber: d,
      dateString,
      dayOfWeek,
      dayName: dayNames[dayOfWeek],
      isToday,
      isFuture,
      isWeekend,
      record: recordsMap.get(dateString)
    });
  }

  return {
    paddingDays: mondayOffset,
    days
  };
}

/**
 * Exports single staff attendance records to CSV
 */
export function exportStaffAttendanceCSV(
  staff: StaffMember,
  records: StaffAttendanceRecord[],
  year: number,
  month: number
): void {
  const summary = calculateMonthlyAttendanceSummary(records, staff.staffId, year, month);
  const monthStr = month < 10 ? `0${month}` : `${month}`;
  const prefix = `${year}-${monthStr}`;

  const staffRecords = records
    .filter((r) => r.staffId === staff.staffId && r.date.startsWith(prefix))
    .sort((a, b) => a.date.localeCompare(b.date));

  const headers = [
    'Date',
    'Day',
    'Staff ID',
    'Staff Name',
    'Designation',
    'Attendance Status',
    'Check-in Time',
    'Check-out Time',
    'Total Working Hours',
    'Notes / Remarks',
    'Marked By',
    'Last Updated',
    'Correction Reason'
  ];

  const rows = staffRecords.map((r) => {
    const dateObj = new Date(r.date + 'T12:00:00Z');
    const dayName = dateObj.toLocaleDateString('en-US', { weekday: 'short' });
    const config = getAttendanceStatusConfig(r.status);
    return [
      r.date,
      dayName,
      `"${staff.staffId}"`,
      `"${staff.fullName}"`,
      `"${staff.position}"`,
      `"${config.label}"`,
      r.checkInTime || '-',
      r.checkOutTime || '-',
      r.totalWorkingHoursFormatted || '-',
      `"${(r.notes || '').replace(/"/g, '""')}"`,
      `"${(r.markedByName || '').replace(/"/g, '""')}"`,
      r.updatedAt ? new Date(r.updatedAt).toLocaleString() : new Date(r.createdAt).toLocaleString(),
      `"${(r.correctionReason || '').replace(/"/g, '""')}"`
    ];
  });

  // Add Summary Header Rows
  const metaRows = [
    ['CAMPORA CAFE - STAFF ATTENDANCE & WORK RECORD'],
    [`Staff Member: ${staff.fullName} (${staff.staffId}) - Position: ${staff.position}`],
    [`Period: ${summary.monthName}`],
    [
      `Total Working Days: ${summary.totalWorkingDays} | Present: ${summary.presentDays} | Absent: ${summary.absentDays} | Weekly Off: ${summary.weeklyOffDays} | Leave: ${summary.leaveDays} | Attendance: ${summary.attendancePercentage}% | Total Hours: ${summary.totalWorkingHoursFormatted}`
    ],
    []
  ];

  const csvContent =
    'data:text/csv;charset=utf-8,' +
    metaRows.map((e) => e.join(',')).join('\n') +
    [headers.join(','), ...rows.map((e) => e.join(','))].join('\n');

  const encodedUri = encodeURI(csvContent);
  const link = document.createElement('a');
  link.setAttribute('href', encodedUri);
  link.setAttribute(
    'download',
    `Campora_Attendance_${staff.staffId}_${summary.monthName.replace(/\s+/g, '_')}.csv`
  );
  document.body.appendChild(link);
  link.click();
  document.body.removeChild(link);
}

/**
 * Initial Sample Attendance Records for realistic demonstration
 * Seeds August 2026 and September 2026 (including the exact prompt sample:
 * September 2026 - Present: 20 Days, Absent: 2 Days, Weekly Off: 4 Days, Leave: 1 Day, Attendance: 90.9%)
 */
export const INITIAL_STAFF_ATTENDANCE: StaffAttendanceRecord[] = [
  // --- Rahul Kumar (CC-STF-101) - Cashier ---
  // September 2026 sample days
  {
    id: 'CC-STF-101_2026-09-01',
    staffId: 'CC-STF-101',
    staffName: 'Rahul Kumar',
    date: '2026-09-01',
    status: 'present',
    checkInTime: '09:30',
    checkOutTime: '18:00',
    totalWorkingMinutes: 510,
    totalWorkingHoursFormatted: '8h 30m',
    notes: 'Morning counter opening and UPI terminal sync',
    markedByUid: 'master-owner-kundan',
    markedByName: 'Kundan (Owner)',
    createdAt: '2026-09-01T09:30:00.000Z'
  },
  {
    id: 'CC-STF-101_2026-09-02',
    staffId: 'CC-STF-101',
    staffName: 'Rahul Kumar',
    date: '2026-09-02',
    status: 'present',
    checkInTime: '09:25',
    checkOutTime: '18:05',
    totalWorkingMinutes: 520,
    totalWorkingHoursFormatted: '8h 40m',
    notes: 'On-time cash register handover',
    markedByUid: 'master-owner-kundan',
    markedByName: 'Kundan (Owner)',
    createdAt: '2026-09-02T09:25:00.000Z'
  },
  {
    id: 'CC-STF-101_2026-09-03',
    staffId: 'CC-STF-101',
    staffName: 'Rahul Kumar',
    date: '2026-09-03',
    status: 'weekly_off',
    notes: 'Scheduled Thursday roster off',
    markedByUid: 'master-owner-kundan',
    markedByName: 'Kundan (Owner)',
    createdAt: '2026-09-03T08:00:00.000Z'
  },
  {
    id: 'CC-STF-101_2026-09-04',
    staffId: 'CC-STF-101',
    staffName: 'Rahul Kumar',
    date: '2026-09-04',
    status: 'present',
    checkInTime: '09:30',
    checkOutTime: '18:00',
    totalWorkingMinutes: 510,
    totalWorkingHoursFormatted: '8h 30m',
    markedByUid: 'master-owner-kundan',
    markedByName: 'Kundan (Owner)',
    createdAt: '2026-09-04T09:30:00.000Z'
  },
  {
    id: 'CC-STF-101_2026-09-05',
    staffId: 'CC-STF-101',
    staffName: 'Rahul Kumar',
    date: '2026-09-05',
    status: 'absent',
    notes: 'Informed sick in the morning',
    correctionReason: 'Verified with hostel warden',
    markedByUid: 'master-owner-kundan',
    markedByName: 'Kundan (Owner)',
    createdAt: '2026-09-05T10:00:00.000Z'
  },
  {
    id: 'CC-STF-101_2026-09-06',
    staffId: 'CC-STF-101',
    staffName: 'Rahul Kumar',
    date: '2026-09-06',
    status: 'leave',
    notes: 'Approved medical recovery leave',
    markedByUid: 'master-owner-kundan',
    markedByName: 'Kundan (Owner)',
    createdAt: '2026-09-06T09:00:00.000Z'
  },
  {
    id: 'CC-STF-101_2026-09-07',
    staffId: 'CC-STF-101',
    staffName: 'Rahul Kumar',
    date: '2026-09-07',
    status: 'present',
    checkInTime: '09:30',
    checkOutTime: '18:00',
    totalWorkingMinutes: 510,
    totalWorkingHoursFormatted: '8h 30m',
    markedByUid: 'master-owner-kundan',
    markedByName: 'Kundan (Owner)',
    createdAt: '2026-09-07T09:30:00.000Z'
  },
  {
    id: 'CC-STF-101_2026-09-08',
    staffId: 'CC-STF-101',
    staffName: 'Rahul Kumar',
    date: '2026-09-08',
    status: 'present',
    checkInTime: '09:30',
    checkOutTime: '18:30',
    totalWorkingMinutes: 540,
    totalWorkingHoursFormatted: '9h 0m',
    notes: 'Evening peak study session billing assistance',
    markedByUid: 'master-owner-kundan',
    markedByName: 'Kundan (Owner)',
    createdAt: '2026-09-08T09:30:00.000Z'
  },
  {
    id: 'CC-STF-101_2026-09-09',
    staffId: 'CC-STF-101',
    staffName: 'Rahul Kumar',
    date: '2026-09-09',
    status: 'present',
    checkInTime: '09:30',
    checkOutTime: '18:00',
    totalWorkingMinutes: 510,
    totalWorkingHoursFormatted: '8h 30m',
    markedByUid: 'master-owner-kundan',
    markedByName: 'Kundan (Owner)',
    createdAt: '2026-09-09T09:30:00.000Z'
  },
  {
    id: 'CC-STF-101_2026-09-10',
    staffId: 'CC-STF-101',
    staffName: 'Rahul Kumar',
    date: '2026-09-10',
    status: 'weekly_off',
    notes: 'Scheduled roster off',
    markedByUid: 'master-owner-kundan',
    markedByName: 'Kundan (Owner)',
    createdAt: '2026-09-10T08:00:00.000Z'
  },
  {
    id: 'CC-STF-101_2026-09-11',
    staffId: 'CC-STF-101',
    staffName: 'Rahul Kumar',
    date: '2026-09-11',
    status: 'present',
    checkInTime: '09:30',
    checkOutTime: '18:00',
    totalWorkingMinutes: 510,
    totalWorkingHoursFormatted: '8h 30m',
    markedByUid: 'master-owner-kundan',
    markedByName: 'Kundan (Owner)',
    createdAt: '2026-09-11T09:30:00.000Z'
  },
  {
    id: 'CC-STF-101_2026-09-12',
    staffId: 'CC-STF-101',
    staffName: 'Rahul Kumar',
    date: '2026-09-12',
    status: 'present',
    checkInTime: '09:15',
    checkOutTime: '18:15',
    totalWorkingMinutes: 540,
    totalWorkingHoursFormatted: '9h 0m',
    markedByUid: 'master-owner-kundan',
    markedByName: 'Kundan (Owner)',
    createdAt: '2026-09-12T09:15:00.000Z'
  },
  {
    id: 'CC-STF-101_2026-09-13',
    staffId: 'CC-STF-101',
    staffName: 'Rahul Kumar',
    date: '2026-09-13',
    status: 'absent',
    notes: 'Unplanned absence',
    markedByUid: 'master-owner-kundan',
    markedByName: 'Kundan (Owner)',
    createdAt: '2026-09-13T10:00:00.000Z'
  },
  {
    id: 'CC-STF-101_2026-09-14',
    staffId: 'CC-STF-101',
    staffName: 'Rahul Kumar',
    date: '2026-09-14',
    status: 'present',
    checkInTime: '09:30',
    checkOutTime: '18:00',
    totalWorkingMinutes: 510,
    totalWorkingHoursFormatted: '8h 30m',
    markedByUid: 'master-owner-kundan',
    markedByName: 'Kundan (Owner)',
    createdAt: '2026-09-14T09:30:00.000Z'
  },
  {
    id: 'CC-STF-101_2026-09-15',
    staffId: 'CC-STF-101',
    staffName: 'Rahul Kumar',
    date: '2026-09-15',
    status: 'present',
    checkInTime: '09:30',
    checkOutTime: '18:00',
    totalWorkingMinutes: 510,
    totalWorkingHoursFormatted: '8h 30m',
    notes: 'Today shift active on counter POS',
    markedByUid: 'master-owner-kundan',
    markedByName: 'Kundan (Owner)',
    createdAt: '2026-09-15T09:30:00.000Z'
  },
  // Upcoming / Sample rest of month entries for complete month view
  {
    id: 'CC-STF-101_2026-09-16',
    staffId: 'CC-STF-101',
    staffName: 'Rahul Kumar',
    date: '2026-09-16',
    status: 'present',
    checkInTime: '09:30',
    checkOutTime: '18:00',
    totalWorkingMinutes: 510,
    totalWorkingHoursFormatted: '8h 30m',
    markedByUid: 'master-owner-kundan',
    markedByName: 'Kundan (Owner)',
    createdAt: '2026-09-15T18:00:00.000Z'
  },
  {
    id: 'CC-STF-101_2026-09-17',
    staffId: 'CC-STF-101',
    staffName: 'Rahul Kumar',
    date: '2026-09-17',
    status: 'weekly_off',
    markedByUid: 'master-owner-kundan',
    markedByName: 'Kundan (Owner)',
    createdAt: '2026-09-15T18:00:00.000Z'
  },
  {
    id: 'CC-STF-101_2026-09-18',
    staffId: 'CC-STF-101',
    staffName: 'Rahul Kumar',
    date: '2026-09-18',
    status: 'present',
    checkInTime: '09:30',
    checkOutTime: '18:00',
    totalWorkingMinutes: 510,
    totalWorkingHoursFormatted: '8h 30m',
    markedByUid: 'master-owner-kundan',
    markedByName: 'Kundan (Owner)',
    createdAt: '2026-09-15T18:00:00.000Z'
  },
  {
    id: 'CC-STF-101_2026-09-19',
    staffId: 'CC-STF-101',
    staffName: 'Rahul Kumar',
    date: '2026-09-19',
    status: 'present',
    checkInTime: '09:30',
    checkOutTime: '18:00',
    totalWorkingMinutes: 510,
    totalWorkingHoursFormatted: '8h 30m',
    markedByUid: 'master-owner-kundan',
    markedByName: 'Kundan (Owner)',
    createdAt: '2026-09-15T18:00:00.000Z'
  },
  {
    id: 'CC-STF-101_2026-09-20',
    staffId: 'CC-STF-101',
    staffName: 'Rahul Kumar',
    date: '2026-09-20',
    status: 'present',
    checkInTime: '09:30',
    checkOutTime: '18:00',
    totalWorkingMinutes: 510,
    totalWorkingHoursFormatted: '8h 30m',
    markedByUid: 'master-owner-kundan',
    markedByName: 'Kundan (Owner)',
    createdAt: '2026-09-15T18:00:00.000Z'
  },
  {
    id: 'CC-STF-101_2026-09-21',
    staffId: 'CC-STF-101',
    staffName: 'Rahul Kumar',
    date: '2026-09-21',
    status: 'present',
    checkInTime: '09:30',
    checkOutTime: '18:00',
    totalWorkingMinutes: 510,
    totalWorkingHoursFormatted: '8h 30m',
    markedByUid: 'master-owner-kundan',
    markedByName: 'Kundan (Owner)',
    createdAt: '2026-09-15T18:00:00.000Z'
  },
  {
    id: 'CC-STF-101_2026-09-22',
    staffId: 'CC-STF-101',
    staffName: 'Rahul Kumar',
    date: '2026-09-22',
    status: 'present',
    checkInTime: '09:30',
    checkOutTime: '18:00',
    totalWorkingMinutes: 510,
    totalWorkingHoursFormatted: '8h 30m',
    markedByUid: 'master-owner-kundan',
    markedByName: 'Kundan (Owner)',
    createdAt: '2026-09-15T18:00:00.000Z'
  },
  {
    id: 'CC-STF-101_2026-09-23',
    staffId: 'CC-STF-101',
    staffName: 'Rahul Kumar',
    date: '2026-09-23',
    status: 'present',
    checkInTime: '09:30',
    checkOutTime: '18:00',
    totalWorkingMinutes: 510,
    totalWorkingHoursFormatted: '8h 30m',
    markedByUid: 'master-owner-kundan',
    markedByName: 'Kundan (Owner)',
    createdAt: '2026-09-15T18:00:00.000Z'
  },
  {
    id: 'CC-STF-101_2026-09-24',
    staffId: 'CC-STF-101',
    staffName: 'Rahul Kumar',
    date: '2026-09-24',
    status: 'weekly_off',
    markedByUid: 'master-owner-kundan',
    markedByName: 'Kundan (Owner)',
    createdAt: '2026-09-15T18:00:00.000Z'
  },
  {
    id: 'CC-STF-101_2026-09-25',
    staffId: 'CC-STF-101',
    staffName: 'Rahul Kumar',
    date: '2026-09-25',
    status: 'present',
    checkInTime: '09:30',
    checkOutTime: '18:00',
    totalWorkingMinutes: 510,
    totalWorkingHoursFormatted: '8h 30m',
    markedByUid: 'master-owner-kundan',
    markedByName: 'Kundan (Owner)',
    createdAt: '2026-09-15T18:00:00.000Z'
  },
  {
    id: 'CC-STF-101_2026-09-26',
    staffId: 'CC-STF-101',
    staffName: 'Rahul Kumar',
    date: '2026-09-26',
    status: 'present',
    checkInTime: '09:30',
    checkOutTime: '18:00',
    totalWorkingMinutes: 510,
    totalWorkingHoursFormatted: '8h 30m',
    markedByUid: 'master-owner-kundan',
    markedByName: 'Kundan (Owner)',
    createdAt: '2026-09-15T18:00:00.000Z'
  },
  {
    id: 'CC-STF-101_2026-09-27',
    staffId: 'CC-STF-101',
    staffName: 'Rahul Kumar',
    date: '2026-09-27',
    status: 'present',
    checkInTime: '09:30',
    checkOutTime: '18:00',
    totalWorkingMinutes: 510,
    totalWorkingHoursFormatted: '8h 30m',
    markedByUid: 'master-owner-kundan',
    markedByName: 'Kundan (Owner)',
    createdAt: '2026-09-15T18:00:00.000Z'
  },
  {
    id: 'CC-STF-101_2026-09-28',
    staffId: 'CC-STF-101',
    staffName: 'Rahul Kumar',
    date: '2026-09-28',
    status: 'present',
    checkInTime: '09:30',
    checkOutTime: '18:00',
    totalWorkingMinutes: 510,
    totalWorkingHoursFormatted: '8h 30m',
    markedByUid: 'master-owner-kundan',
    markedByName: 'Kundan (Owner)',
    createdAt: '2026-09-15T18:00:00.000Z'
  },
  {
    id: 'CC-STF-101_2026-09-29',
    staffId: 'CC-STF-101',
    staffName: 'Rahul Kumar',
    date: '2026-09-29',
    status: 'present',
    checkInTime: '09:30',
    checkOutTime: '18:00',
    totalWorkingMinutes: 510,
    totalWorkingHoursFormatted: '8h 30m',
    markedByUid: 'master-owner-kundan',
    markedByName: 'Kundan (Owner)',
    createdAt: '2026-09-15T18:00:00.000Z'
  },
  {
    id: 'CC-STF-101_2026-09-30',
    staffId: 'CC-STF-101',
    staffName: 'Rahul Kumar',
    date: '2026-09-30',
    status: 'present',
    checkInTime: '09:30',
    checkOutTime: '18:00',
    totalWorkingMinutes: 510,
    totalWorkingHoursFormatted: '8h 30m',
    markedByUid: 'master-owner-kundan',
    markedByName: 'Kundan (Owner)',
    createdAt: '2026-09-15T18:00:00.000Z'
  },

  // --- Priya Kumari (CC-MGR-101) - Manager ---
  {
    id: 'CC-MGR-101_2026-09-14',
    staffId: 'CC-MGR-101',
    staffName: 'Priya Kumari',
    date: '2026-09-14',
    status: 'present',
    checkInTime: '08:45',
    checkOutTime: '17:30',
    totalWorkingMinutes: 525,
    totalWorkingHoursFormatted: '8h 45m',
    markedByUid: 'master-owner-kundan',
    markedByName: 'Kundan (Owner)',
    createdAt: '2026-09-14T08:45:00.000Z'
  },
  {
    id: 'CC-MGR-101_2026-09-15',
    staffId: 'CC-MGR-101',
    staffName: 'Priya Kumari',
    date: '2026-09-15',
    status: 'present',
    checkInTime: '08:50',
    checkOutTime: '17:40',
    totalWorkingMinutes: 530,
    totalWorkingHoursFormatted: '8h 50m',
    notes: 'Floor inspection and morning staff briefing completed',
    markedByUid: 'master-owner-kundan',
    markedByName: 'Kundan (Owner)',
    createdAt: '2026-09-15T08:50:00.000Z'
  },

  // --- Amit Sharma (CC-STF-102) - Kitchen Staff ---
  {
    id: 'CC-STF-102_2026-09-14',
    staffId: 'CC-STF-102',
    staffName: 'Amit Sharma',
    date: '2026-09-14',
    status: 'present',
    checkInTime: '08:30',
    checkOutTime: '17:00',
    totalWorkingMinutes: 510,
    totalWorkingHoursFormatted: '8h 30m',
    markedByUid: 'master-owner-kundan',
    markedByName: 'Kundan (Owner)',
    createdAt: '2026-09-14T08:30:00.000Z'
  },
  {
    id: 'CC-STF-102_2026-09-15',
    staffId: 'CC-STF-102',
    staffName: 'Amit Sharma',
    date: '2026-09-15',
    status: 'present',
    checkInTime: '08:30',
    checkOutTime: '17:00',
    totalWorkingMinutes: 510,
    totalWorkingHoursFormatted: '8h 30m',
    notes: 'Chai prep station and kitchen stock check done',
    markedByUid: 'master-owner-kundan',
    markedByName: 'Kundan (Owner)',
    createdAt: '2026-09-15T08:30:00.000Z'
  }
];
