/**
 * Device Session Slug Management for Campora Cafe (GEC Banka)
 * Generates and stores a unique hardware/client session slug to link
 * orders and client requests securely across browser reloads.
 */

const STORAGE_KEY = 'campora_client_device_slug_v2';

export const getOrCreateDeviceSessionSlug = (): string => {
  try {
    const existing = localStorage.getItem(STORAGE_KEY);
    if (existing && existing.startsWith('gec-dev-')) {
      return existing;
    }
    
    // Generate fresh formatted slug: gec-dev-[randomHex]-[timestampBase36]
    const randPart1 = Math.random().toString(36).substring(2, 6);
    const randPart2 = Math.random().toString(36).substring(2, 6);
    const timePart = Date.now().toString(36).slice(-4);
    const newSlug = `gec-dev-${randPart1}-${randPart2}${timePart}`;
    
    localStorage.setItem(STORAGE_KEY, newSlug);
    return newSlug;
  } catch (e) {
    // Fallback if localStorage is unavailable
    return `gec-dev-${Math.random().toString(36).substring(2, 8)}`;
  }
};

export const formatBookingTimeElapsed = (createdAtStr: string): {
  minutesElapsed: number;
  secondsElapsed: number;
  isWithin10MinWindow: boolean;
  minutesRemainingInWindow: number;
  secondsRemainingInWindow: number;
  formattedCountdown: string;
} => {
  const createdTime = new Date(createdAtStr).getTime();
  const now = Date.now();
  const diffMs = Math.max(0, now - createdTime);
  const totalSeconds = Math.floor(diffMs / 1000);
  const minutesElapsed = Math.floor(totalSeconds / 60);
  const secondsElapsed = totalSeconds % 60;

  const TEN_MINUTES_SEC = 10 * 60;
  const remainingSec = Math.max(0, TEN_MINUTES_SEC - totalSeconds);
  const isWithin10MinWindow = remainingSec > 0;
  const minutesRemainingInWindow = Math.floor(remainingSec / 60);
  const secondsRemainingInWindow = remainingSec % 60;

  const formattedCountdown = `${String(minutesRemainingInWindow).padStart(2, '0')}:${String(
    secondsRemainingInWindow
  ).padStart(2, '0')}`;

  return {
    minutesElapsed,
    secondsElapsed,
    isWithin10MinWindow,
    minutesRemainingInWindow,
    secondsRemainingInWindow,
    formattedCountdown
  };
};
