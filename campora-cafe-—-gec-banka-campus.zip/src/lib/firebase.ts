import { initializeApp, getApps, getApp, FirebaseApp } from 'firebase/app';
import { getAuth, Auth, GoogleAuthProvider, signInWithPopup, signInWithEmailAndPassword, createUserWithEmailAndPassword, sendPasswordResetEmail, signOut, onAuthStateChanged, updateProfile, User } from 'firebase/auth';
import { getFirestore, Firestore, collection, doc, setDoc, getDocs, onSnapshot, updateDoc, deleteDoc, query, orderBy, getDoc, where, limit, startAfter } from 'firebase/firestore';
import firebaseConfigData from '../../firebase-applet-config.json';

const firebaseConfig = {
  apiKey: firebaseConfigData.apiKey,
  authDomain: firebaseConfigData.authDomain,
  projectId: firebaseConfigData.projectId,
  storageBucket: firebaseConfigData.storageBucket,
  messagingSenderId: firebaseConfigData.messagingSenderId,
  appId: firebaseConfigData.appId
};

let app: FirebaseApp;
let auth: Auth;
let db: Firestore;

let adminApp: FirebaseApp;
let adminAuth: Auth;
let adminDb: Firestore;

const dbId = firebaseConfigData.firestoreDatabaseId && firebaseConfigData.firestoreDatabaseId !== '(default)'
  ? firebaseConfigData.firestoreDatabaseId
  : undefined;

try {
  // Primary app for customer session
  app = getApps().find((a) => a.name === '[DEFAULT]') || initializeApp(firebaseConfig);
  auth = getAuth(app);
  db = dbId ? getFirestore(app, dbId) : getFirestore(app);

  // Dedicated secondary app for owner/admin session (strictly isolated session storage)
  adminApp = getApps().find((a) => a.name === 'camporaAdminApp') || initializeApp(firebaseConfig, 'camporaAdminApp');
  adminAuth = getAuth(adminApp);
  adminDb = dbId ? getFirestore(adminApp, dbId) : getFirestore(adminApp);
} catch (error) {
  console.warn('Firebase initialization warning:', error);
  app = getApps().find((a) => a.name === '[DEFAULT]') || initializeApp(firebaseConfig);
  auth = getAuth(app);
  db = getFirestore(app);

  adminApp = getApps().find((a) => a.name === 'camporaAdminApp') || initializeApp(firebaseConfig, 'camporaAdminApp');
  adminAuth = getAuth(adminApp);
  adminDb = getFirestore(adminApp);
}

const googleProvider = new GoogleAuthProvider();

export {
  app,
  auth,
  db,
  adminApp,
  adminAuth,
  adminDb,
  googleProvider,
  signInWithPopup,
  signInWithEmailAndPassword,
  createUserWithEmailAndPassword,
  sendPasswordResetEmail,
  signOut,
  onAuthStateChanged,
  updateProfile,
  collection,
  doc,
  setDoc,
  getDocs,
  getDoc,
  onSnapshot,
  updateDoc,
  deleteDoc,
  query,
  orderBy,
  where,
  limit,
  startAfter
};
export type { User };
