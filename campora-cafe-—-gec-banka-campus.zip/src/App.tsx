/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React from 'react';
import { CafeProvider, useCafe } from './context/CafeContext';
import { AnnouncementBanner } from './components/common/AnnouncementBanner';
import { Header } from './components/common/Header';
import { Footer } from './components/common/Footer';
import { MobileBottomBar } from './components/common/MobileBottomBar';
import { ToastContainer } from './components/common/ToastContainer';
import { CafeHero } from './components/public/CafeHero';
import { MenuSection } from './components/public/MenuSection';
import { ItemDetailModal } from './components/public/ItemDetailModal';
import { LocationHoursModal } from './components/public/LocationHoursModal';
import { CartDrawer } from './components/cart/CartDrawer';
import { CheckoutModal } from './components/checkout/CheckoutModal';
import { LiveOrderTracker } from './components/order/LiveOrderTracker';
import { CustomerAccountModal } from './components/customer/CustomerAccountModal';
import { AdminDashboard } from './components/admin/AdminDashboard';
import { AdminLoginPage } from './components/admin/AdminLoginPage';

const MainLayout: React.FC = () => {
  const { isAdminMode, adminUser, isAdminUser } = useCafe();

  if (isAdminMode) {
    if (!adminUser || !isAdminUser) {
      return (
        <div className="min-h-screen bg-stone-950 text-stone-100 font-sans antialiased">
          <AdminLoginPage />
          <ToastContainer />
        </div>
      );
    }

    return (
      <div className="min-h-screen bg-stone-100 text-stone-900 font-sans antialiased">
        <AdminDashboard />
        <ToastContainer />
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-stone-50 text-stone-900 font-sans antialiased flex flex-col selection:bg-amber-200 selection:text-amber-950">
      
      {/* Top Special Offer Announcement */}
      <AnnouncementBanner />

      {/* Main Header */}
      <Header />

      {/* Main Public Content */}
      <main className="flex-1 pb-20 sm:pb-8">
        <CafeHero />
        <MenuSection />
      </main>

      {/* Footer */}
      <Footer />

      {/* Mobile-First Sticky Bottom Nav / Quick Action Bar */}
      <MobileBottomBar />

      {/* Floating Modals & Drawers */}
      <ItemDetailModal />
      <LocationHoursModal />
      <CartDrawer />
      <CheckoutModal />
      <LiveOrderTracker />
      <CustomerAccountModal />
      
      {/* Global Interactive Notifications */}
      <ToastContainer />
    </div>
  );
};

export default function App() {
  return (
    <CafeProvider>
      <MainLayout />
    </CafeProvider>
  );
}
