import { MenuItem, CafeTable, PromoCode, CustomerRecord, CafeSettings, BookingOrder, CounterSale, StaffMember, StaffAuditLog } from '../types';

export const INITIAL_CAFE_SETTINGS: CafeSettings = {
  name: 'Campora Cafe',
  tagline: 'GEC Banka Campus Eatery • Kulhad Chai, Fresh Street Bites, Sizzling Meals & Student Hangout',
  campusName: 'Government Engineering College, Banka',
  address: 'GEC Banka Campus, Lakrikola, Manjira',
  city: 'Banka',
  state: 'Bihar',
  pincode: '813102',
  phone: '+91 94318 72050',
  whatsapp: '+919431872050',
  email: 'campora.cafe@gecbanka.ac.in',
  upiId: '8210794268-4@ybl',
  upiName: 'Campora Café',
  googleMapEmbedUrl: 'https://maps.google.com/maps?q=Government+Engineering+College+Banka+Bihar&t=&z=15&ie=UTF8&iwloc=&output=embed',
  googleMapsDirectionsUrl: 'https://maps.google.com/?q=Government+Engineering+College+Banka+Bihar+813102',
  currency: '₹',
  taxRatePercent: 5.0, // 5% GST
  serviceFeeFixed: 0,
  deliveryFeeFixed: 15.00,
  minimumOrderForDelivery: 100.00,
  operatingHours: [
    { day: 'Monday', open: '08:00', close: '22:30' },
    { day: 'Tuesday', open: '08:00', close: '22:30' },
    { day: 'Wednesday', open: '08:00', close: '22:30' },
    { day: 'Thursday', open: '08:00', close: '22:30' },
    { day: 'Friday', open: '08:00', close: '23:00' },
    { day: 'Saturday', open: '08:30', close: '23:00' },
    { day: 'Sunday', open: '09:00', close: '22:00' },
  ],
  isOpen: true,
  closedNotice: 'Ordering is temporarily unavailable. Online orders will resume shortly!',
  hygieneCertifications: [
    { title: 'FSSAI Certified Campus Kitchen', badge: 'FSSAI Lic. Verified', issuer: 'Food Safety and Standards Authority of India', verifiedYear: '2026' },
    { title: '100% Pure Milk & Fresh Ingredients', badge: 'Daily Sourced', issuer: 'Local Dairy & Farm Co-op', verifiedYear: '2026' },
    { title: 'Clean & Sanitized Prep Station', badge: '5-Star Campus Hygiene', issuer: 'GEC Health & Sanitation Board', verifiedYear: '2026' },
  ],
  announcements: [
    { id: '1', text: '🎓 GEC Banka Students: Get 20% OFF with promo code CAMPUS20 on your order!', type: 'promo', active: true },
    { id: '2', text: '☕ Hot Tandoori Kulhad Chai & Samosa Chaat ready fresh at the counter!', type: 'info', active: true },
    { id: '3', text: '⚡ Campus Hostel Delivery active across Boys & Girls Hostels + Faculty Quarters.', type: 'info', active: true },
  ],
};

export const INITIAL_MENU_ITEMS: MenuItem[] = [
  // --- BEVERAGES ---
  {
    id: 'bev-1',
    name: 'Special Tandoori Kulhad Masala Chai',
    tagline: 'Smoky clay cup steeped with crushed ginger, cardamom & cloves',
    category: 'beverages',
    subcategory: 'Campus Chai',
    description: 'Freshly brewed Assam CTC milk tea simmered with fresh adrak (ginger), green cardamom, cinnamon, and black pepper, poured piping hot into glowing red-hot earthen kulhads for an authentic rustic smoky flavor.',
    price: 25,
    originalPrice: 30,
    image: 'https://images.unsplash.com/photo-1576092768241-dec231879fc3?w=800&auto=format&fit=crop&q=80',
    galleryImages: [
      'https://images.unsplash.com/photo-1576092768241-dec231879fc3?w=800&auto=format&fit=crop&q=80',
      'https://images.unsplash.com/photo-1544787219-7f47ccb76574?w=800&auto=format&fit=crop&q=80'
    ],
    dietaryTags: ['veg', 'gluten-free', 'chef-special'],
    isAvailable: true,
    stockCount: 150,
    isPopular: true,
    isChefSpecial: true,
    rating: 4.9,
    reviewCount: 420,
    preparationTimeMinutes: 3,
    calories: 85,
    protein: 3,
    carbs: 14,
    fat: 3,
    ingredients: ['Fresh Cow Milk', 'Assam Tea Leaves', 'Fresh Ginger', 'Cardamom Pods', 'Sugar / Jaggery', 'Earthen Clay Kulhad'],
    allergenWarnings: ['Contains Dairy (Milk)'],
    sizes: [
      { name: 'Standard Kulhad', priceDelta: 0 },
      { name: 'Big Double Kulhad', priceDelta: 15 }
    ],
    addons: [
      { id: 'add-1', name: 'Extra Ginger Punch (Adrak Kadak)', price: 5, category: 'extra' },
      { id: 'add-2', name: 'Desi Gur (Jaggery) Swap', price: 5, category: 'topping' }
    ],
    reviews: [
      { id: 'r-1', userName: 'Aman Kumar (CSE 3rd Yr)', rating: 5, date: 'Today', comment: 'Best chai in all of Banka! The smoky kulhad aroma after back-to-back lab classes is sheer bliss.' },
      { id: 'r-2', userName: 'Pooja Singh (ECE)', rating: 5, date: 'Yesterday', comment: 'Kadak ginger taste just like home. Perfect for winter mornings.' }
    ]
  },
  {
    id: 'bev-2',
    name: 'Thick Cold Coffee with Vanilla Ice Cream',
    tagline: 'Blended roasted coffee topped with creamy ice cream & chocolate syrup',
    category: 'beverages',
    subcategory: 'Cold Brews & Shakes',
    description: 'Thick, creamy hand-blended chilled espresso shake made with full cream milk, Hershey chocolate drizzle, and topped with a generous scoop of Madagascar vanilla ice cream and choco chips.',
    price: 80,
    originalPrice: 95,
    image: 'https://images.unsplash.com/photo-1517701550927-30cf4ba1dba5?w=800&auto=format&fit=crop&q=80',
    galleryImages: [
      'https://images.unsplash.com/photo-1517701550927-30cf4ba1dba5?w=800&auto=format&fit=crop&q=80',
      'https://images.unsplash.com/photo-1572490122747-3968b75cc699?w=800&auto=format&fit=crop&q=80'
    ],
    dietaryTags: ['veg', 'chef-special'],
    isAvailable: true,
    stockCount: 45,
    isPopular: true,
    isChefSpecial: true,
    rating: 4.8,
    reviewCount: 310,
    preparationTimeMinutes: 4,
    calories: 240,
    protein: 6,
    carbs: 34,
    fat: 9,
    ingredients: ['Dark Roast Coffee', 'Chilled Full-Cream Milk', 'Vanilla Ice Cream Scoop', 'Chocolate Fudge Sauce', 'Choco Chips'],
    allergenWarnings: ['Contains Dairy (Milk)'],
    sizes: [
      { name: 'Regular Glass (300ml)', priceDelta: 0 },
      { name: 'Monster Mug (450ml)', priceDelta: 30 }
    ],
    addons: [
      { id: 'add-3', name: 'Extra Scoop Vanilla Ice Cream', price: 25, category: 'topping' },
      { id: 'add-4', name: 'Crushed Oreo Crumbs', price: 15, category: 'topping' },
      { id: 'add-5', name: 'Double Espresso Shot', price: 20, category: 'extra' }
    ]
  },
  {
    id: 'bev-3',
    name: 'South Indian Filter Kaapi',
    tagline: 'Traditional brass tumbler decoction with frothy frothed milk',
    category: 'beverages',
    subcategory: 'Hot Brews',
    description: 'Authentic 80:20 Arabica-Peaberry blend slow-dripped in stainless steel filters, aerated back and forth to create velvety golden froth. Served in traditional brass Davarah and Tumbler.',
    price: 45,
    image: 'https://images.unsplash.com/photo-1514432324607-a09d9b4aefdd?w=800&auto=format&fit=crop&q=80',
    dietaryTags: ['veg', 'gluten-free'],
    isAvailable: true,
    stockCount: 30,
    rating: 4.8,
    reviewCount: 145,
    preparationTimeMinutes: 3,
    calories: 90,
    protein: 4,
    carbs: 12,
    fat: 3,
    ingredients: ['Chikmagalur Filter Coffee Decoction', 'Steamed Whole Milk', 'Sugar'],
    allergenWarnings: ['Contains Dairy'],
    sizes: [
      { name: 'Standard Tumbler', priceDelta: 0 },
      { name: 'Large Mug', priceDelta: 20 }
    ]
  },
  {
    id: 'bev-4',
    name: 'Kesar Pista Badam Lassi in Clay Cup',
    tagline: 'Thick churned sweet yogurt with saffron strands & roasted pistachios',
    category: 'beverages',
    subcategory: 'Traditional Coolers',
    description: 'Slow-churned thick Punjabi dahi infused with pure Kashmiri saffron, crushed green cardamom, and garnished with roasted California almond and pistachio flakes with thick malai topping.',
    price: 70,
    image: 'https://images.unsplash.com/photo-1541167760496-1628856ab772?w=800&auto=format&fit=crop&q=80',
    dietaryTags: ['veg', 'gluten-free', 'contains-nuts'],
    isAvailable: true,
    stockCount: 25,
    rating: 4.9,
    reviewCount: 180,
    preparationTimeMinutes: 3,
    calories: 280,
    protein: 8,
    carbs: 42,
    fat: 10,
    ingredients: ['Fresh Thick Yogurt (Dahi)', 'Kashmiri Kesar', 'Pistachio Flakes', 'Sliced Almonds', 'Rose Essence', 'Sugar'],
    allergenWarnings: ['Contains Dairy, Tree Nuts (Almonds, Pistachios)'],
    sizes: [
      { name: 'Clay Matka (300ml)', priceDelta: 0 },
      { name: 'Jumbo Matka (500ml)', priceDelta: 35 }
    ]
  },
  {
    id: 'bev-5',
    name: 'Mint Lime Shikanji (Bihari Masala Cooler)',
    tagline: 'Sparkling lemon cooler with roasted cumin & rock salt',
    category: 'beverages',
    subcategory: 'Refreshers',
    description: 'Refreshing fizzy soda water with freshly squeezed kagzi lemons, crushed garden mint, roasted bhuna jeera, black salt (kala namak), and tangy spices. Instant energy booster after classes.',
    price: 40,
    image: 'https://images.unsplash.com/photo-1556881286-fc6915169721?w=800&auto=format&fit=crop&q=80',
    dietaryTags: ['vegan', 'gluten-free', 'dairy-free'],
    isAvailable: true,
    stockCount: 60,
    rating: 4.7,
    reviewCount: 95,
    preparationTimeMinutes: 2,
    calories: 45,
    protein: 0,
    carbs: 11,
    fat: 0,
    ingredients: ['Fresh Lemon Juice', 'Chilled Sparkling Soda / Water', 'Black Salt', 'Bhuna Jeera Powder', 'Fresh Mint Leaves', 'Sugar Syrup'],
    allergenWarnings: ['None']
  },

  // --- SNACKS & FAST FOOD ---
  {
    id: 'snk-1',
    name: 'Bihari Khasta Samosa Chaat (2 Pcs)',
    tagline: 'Crispy potato samosas crushed with spicy chana curry, sev & sweet-tangy chutney',
    category: 'pastries',
    subcategory: 'Street Food Bites',
    description: 'Two golden flaky samosas stuffed with spiced cumin potatoes and green peas, crushed into a piping hot bowl of slow-cooked ghugni (chana curry), topped with fresh onions, coriander, sweet tamarind chutney, mint-chili relish, and crispy nylon sev.',
    price: 50,
    originalPrice: 60,
    image: 'https://images.unsplash.com/photo-1601050690597-df0568f70950?w=800&auto=format&fit=crop&q=80',
    galleryImages: [
      'https://images.unsplash.com/photo-1601050690597-df0568f70950?w=800&auto=format&fit=crop&q=80',
      'https://images.unsplash.com/photo-1589301760014-d929f3979dbc?w=800&auto=format&fit=crop&q=80'
    ],
    dietaryTags: ['veg', 'chef-special', 'spicy-medium'],
    isAvailable: true,
    stockCount: 80,
    isPopular: true,
    isChefSpecial: true,
    rating: 4.9,
    reviewCount: 390,
    preparationTimeMinutes: 5,
    calories: 340,
    protein: 9,
    carbs: 48,
    fat: 14,
    ingredients: ['Flaky Pastry Samosa', 'Spiced Yellow Peas Ghugni', 'Tamarind Imli Chutney', 'Green Coriander Mint Sauce', 'Chopped Onions & Green Chilies', 'Nylon Sev'],
    allergenWarnings: ['Contains Gluten'],
    addons: [
      { id: 'add-6', name: 'Extra Curd (Dahi) Topping', price: 10, category: 'topping' },
      { id: 'add-7', name: 'Extra Samosa (1 Pc)', price: 15, category: 'extra' }
    ]
  },
  {
    id: 'snk-2',
    name: 'Butter Bun Maska with Chai Dip',
    tagline: 'Soft sweet bakery bun stuffed with whipped Amul butter & fruit tutti-frutti',
    category: 'pastries',
    subcategory: 'Bakery & Buns',
    description: 'Irani-cafe style pillowy soft sweet milk buns sliced and generously slathered with salted Amul butter. Best enjoyed dipped directly into a hot steaming cup of Kulhad Chai.',
    price: 35,
    image: 'https://images.unsplash.com/photo-1509440159596-0249088772ff?w=800&auto=format&fit=crop&q=80',
    dietaryTags: ['veg'],
    isAvailable: true,
    stockCount: 50,
    isPopular: true,
    rating: 4.8,
    reviewCount: 160,
    preparationTimeMinutes: 2,
    calories: 220,
    protein: 5,
    carbs: 32,
    fat: 9,
    ingredients: ['Soft Milk Bun', 'Pure Amul Butter', 'Tutti Frutti', 'Light Sugar Dust'],
    allergenWarnings: ['Contains Gluten, Dairy'],
    addons: [
      { id: 'add-8', name: 'Extra Amul Butter Layer', price: 10, category: 'topping' },
      { id: 'add-9', name: 'Mixed Fruit Jam Spread', price: 10, category: 'topping' }
    ]
  },
  {
    id: 'snk-3',
    name: 'Double Butter Cheese Masala Maggi',
    tagline: 'College favorite 2-minute noodles tossed with veggies & molten cheese',
    category: 'mains',
    subcategory: 'Hostel Favorites',
    description: 'The undisputed campus legend: 2 bricks of Maggi noodles cooked with golden butter, sautéed onions, tomatoes, sweet green peas, house magic masala, and buried under melted shredded mozzarella cheese.',
    price: 65,
    originalPrice: 75,
    image: 'https://images.unsplash.com/photo-1612927601601-6638404737ce?w=800&auto=format&fit=crop&q=80',
    dietaryTags: ['veg', 'chef-special', 'spicy-mild'],
    isAvailable: true,
    stockCount: 100,
    isPopular: true,
    isChefSpecial: true,
    rating: 4.9,
    reviewCount: 480,
    preparationTimeMinutes: 7,
    calories: 380,
    protein: 8,
    carbs: 52,
    fat: 16,
    ingredients: ['Maggi Noodles', 'Amul Butter', 'Mozzarella & Cheddar Cheese', 'Green Peas', 'Capsicum & Tomato', 'Magic Masala Blend'],
    allergenWarnings: ['Contains Gluten, Dairy'],
    addons: [
      { id: 'add-10', name: 'Extra Cheese Slice', price: 15, category: 'topping' },
      { id: 'add-11', name: 'Spicy Peri Peri Sprinkles', price: 5, category: 'extra' },
      { id: 'add-12', name: 'Fried Egg Topping (1 Egg)', price: 15, category: 'extra' }
    ]
  },
  {
    id: 'snk-4',
    name: 'Steamed Paneer & Veg Momos (8 Pcs)',
    tagline: 'Juicy Himalayan dumplings served with spicy garlic-red chili dip',
    category: 'mains',
    subcategory: 'Momos & Dumplings',
    description: 'Thin-wrapper steamed momos packed with grated malai paneer, cabbage, carrots, spring onions, and ginger. Served with flaming hot red chili garlic chutney and creamy mayonnaise.',
    price: 80,
    image: 'https://images.unsplash.com/photo-1534422298391-e4f8c172dddb?w=800&auto=format&fit=crop&q=80',
    dietaryTags: ['veg', 'spicy-hot'],
    isAvailable: true,
    stockCount: 40,
    isPopular: true,
    rating: 4.8,
    reviewCount: 220,
    preparationTimeMinutes: 8,
    calories: 260,
    protein: 9,
    carbs: 38,
    fat: 8,
    ingredients: ['Wheat Flour Dough', 'Fresh Malai Paneer', 'Shredded Cabbage & Carrots', 'Garlic & Chili Dip', 'Mayonnaise'],
    allergenWarnings: ['Contains Gluten, Dairy'],
    sizes: [
      { name: 'Steamed (8 Pcs)', priceDelta: 0 },
      { name: 'Crispy Fried (8 Pcs)', priceDelta: 15 },
      { name: 'Pan-Tossed Kurkure Momos', priceDelta: 25 }
    ]
  },
  {
    id: 'snk-5',
    name: 'Mumbai Style Butter Pav Bhaji',
    tagline: 'Spiced mashed vegetable curry with 2 butter-toasted pav buns',
    category: 'mains',
    subcategory: 'Street Food Bites',
    description: 'Rich, aromatic slow-cooked potato-tomato-pea mash simmered with special pav bhaji spices and a golden pool of melting Amul butter. Served with soft pav buns toasted on tawa, chopped onions, and lemon wedges.',
    price: 90,
    image: 'https://images.unsplash.com/photo-1606491956689-2ea866880c84?w=800&auto=format&fit=crop&q=80',
    dietaryTags: ['veg', 'spicy-medium'],
    isAvailable: true,
    stockCount: 35,
    rating: 4.8,
    reviewCount: 190,
    preparationTimeMinutes: 8,
    calories: 440,
    protein: 10,
    carbs: 62,
    fat: 18,
    ingredients: ['Potatoes', 'Green Peas', 'Cauliflower', 'Tomato Puree', 'Pav Bhaji Masala', 'Amul Butter', 'Bakery Pav'],
    allergenWarnings: ['Contains Gluten, Dairy'],
    addons: [
      { id: 'add-13', name: 'Extra Butter Pav (2 Pcs)', price: 20, category: 'extra' },
      { id: 'add-14', name: 'Shredded Cheese Topping', price: 20, category: 'topping' }
    ]
  },

  // --- MAINS & ROLLS ---
  {
    id: 'main-1',
    name: 'Kolkata Paneer Tikka Kathi Roll',
    tagline: 'Flaky paratha wrapped with tandoori paneer, onions, mint chutney & chatpata masala',
    category: 'mains',
    subcategory: 'Kathi Rolls',
    description: 'Crisp layered tawa paratha filled with smoky marinated paneer tikka chunks, crunchy onion rings, capsicum strips, fresh mint-coriander chutney, and a squeeze of fresh lime juice.',
    price: 110,
    originalPrice: 130,
    image: 'https://images.unsplash.com/photo-1626777552726-4a6b54c97e46?w=800&auto=format&fit=crop&q=80',
    galleryImages: [
      'https://images.unsplash.com/photo-1626777552726-4a6b54c97e46?w=800&auto=format&fit=crop&q=80',
      'https://images.unsplash.com/photo-1528735602780-2552fd46c7af?w=800&auto=format&fit=crop&q=80'
    ],
    dietaryTags: ['veg', 'chef-special', 'spicy-medium'],
    isAvailable: true,
    stockCount: 35,
    isPopular: true,
    isChefSpecial: true,
    rating: 4.9,
    reviewCount: 260,
    preparationTimeMinutes: 10,
    calories: 460,
    protein: 18,
    carbs: 48,
    fat: 22,
    ingredients: ['Layered Flaky Paratha', 'Marinated Cottage Cheese (Paneer)', 'Sliced Onions & Bell Peppers', 'Mint Sauce', 'Chaat Masala'],
    allergenWarnings: ['Contains Gluten, Dairy'],
    addons: [
      { id: 'add-15', name: 'Double Paneer Stuffing', price: 35, category: 'extra' },
      { id: 'add-16', name: 'Melted Mozzarella Cheese Add-on', price: 20, category: 'topping' }
    ]
  },
  {
    id: 'main-2',
    name: 'Triple Layer Bombay Grilled Sandwich',
    tagline: 'Toasted jumbo sandwich with spiced aloo, beetroot, cheese & green chutney',
    category: 'mains',
    subcategory: 'Grilled Sandwiches',
    description: 'Three slices of buttered bread packed with sliced boiled potatoes, cucumber, tomatoes, sweet beets, grated cheese, and spicy mint-coriander chutney, grilled crispy with grill marks.',
    price: 95,
    image: 'https://images.unsplash.com/photo-1528735602780-2552fd46c7af?w=800&auto=format&fit=crop&q=80',
    dietaryTags: ['veg'],
    isAvailable: true,
    stockCount: 30,
    rating: 4.7,
    reviewCount: 155,
    preparationTimeMinutes: 8,
    calories: 420,
    protein: 11,
    carbs: 58,
    fat: 16,
    ingredients: ['Jumbo White/Brown Bread', 'Spiced Potatoes', 'Beetroot & Cucumbers', 'Processed Cheese', 'Mint Chutney', 'Amul Butter'],
    allergenWarnings: ['Contains Gluten, Dairy'],
    addons: [
      { id: 'add-17', name: 'Side Crispy Peri Peri French Fries', price: 40, category: 'side' }
    ]
  },
  {
    id: 'main-3',
    name: 'Hyderabadi Veg Dum Biryani Box',
    tagline: 'Fragrant long-grain basmati with marinated veggies, saffron & mint raita',
    category: 'mains',
    subcategory: 'Rice & Meals',
    description: 'Slow dum-cooked royal basmati rice layered with garden vegetables, fried onions (birista), fresh mint, coriander, and authentic Mughlai spices. Served in an eco-friendly box with cool boondi raita and spicy salan.',
    price: 130,
    originalPrice: 150,
    image: 'https://images.unsplash.com/photo-1563379091339-03b21ab4a4f8?w=800&auto=format&fit=crop&q=80',
    dietaryTags: ['veg', 'gluten-free', 'chef-special'],
    isAvailable: true,
    stockCount: 25,
    isPopular: true,
    isChefSpecial: true,
    rating: 4.9,
    reviewCount: 290,
    preparationTimeMinutes: 10,
    calories: 520,
    protein: 12,
    carbs: 76,
    fat: 18,
    ingredients: ['Aged Basmati Rice', 'Paneer & Mixed Vegetables', 'Saffron Milk', 'Fried Onions', 'Ghee', 'Whole Spices'],
    allergenWarnings: ['Contains Dairy (Ghee, Paneer)'],
    addons: [
      { id: 'add-18', name: 'Extra Boondi Raita Bowl', price: 20, category: 'side' },
      { id: 'add-19', name: 'Roasted Masala Papad (2 Pcs)', price: 15, category: 'side' }
    ]
  },
  {
    id: 'main-4',
    name: 'Punjabi Chole Bhature Combo (2 Bhature)',
    tagline: 'Fluffy balloon bhaturas with dark tangy Amritsari chole & pickle',
    category: 'mains',
    subcategory: 'North Indian Specials',
    description: 'Two huge, golden deep-fried puffed bhaturas served with slow-simmered Amritsari chickpea curry cooked with pomegranate seeds and whole spices. Served with spicy green chili pickle and sirka onion salad.',
    price: 100,
    image: 'https://images.unsplash.com/photo-1626777552726-4a6b54c97e46?w=800&auto=format&fit=crop&q=80',
    dietaryTags: ['veg', 'spicy-medium'],
    isAvailable: true,
    stockCount: 28,
    rating: 4.8,
    reviewCount: 215,
    preparationTimeMinutes: 9,
    calories: 580,
    protein: 16,
    carbs: 74,
    fat: 26,
    ingredients: ['Fermented Bhatura Dough', 'Kabuli Chana (Chickpeas)', 'Amchur & Anardana', 'Pickled Onions', 'Fried Green Chili'],
    allergenWarnings: ['Contains Gluten']
  },

  // --- HEALTHY & COMBOS ---
  {
    id: 'hea-1',
    name: "Engineer's All-Nighter Study Combo",
    tagline: 'Monster Cold Coffee + Double Cheese Maggi + Peri Peri Fries',
    category: 'healthy',
    subcategory: 'Student Super Combos',
    description: 'The ultimate fuel for exam nights and hackathons at GEC Banka: 1 Large Cold Coffee with vanilla ice cream, 1 piping hot Double Cheese Masala Maggi bowl, and 1 basket of crispy Peri Peri seasoned French fries.',
    price: 160,
    originalPrice: 195,
    image: 'https://images.unsplash.com/photo-1554118811-1e0d58224f24?w=800&auto=format&fit=crop&q=80',
    dietaryTags: ['veg', 'chef-special'],
    isAvailable: true,
    stockCount: 40,
    isPopular: true,
    isChefSpecial: true,
    rating: 4.9,
    reviewCount: 380,
    preparationTimeMinutes: 10,
    calories: 720,
    protein: 16,
    carbs: 98,
    fat: 30,
    ingredients: ['Cold Coffee with Ice Cream', 'Cheese Maggi', 'Crispy Potato Fries', 'Peri Peri Spice'],
    allergenWarnings: ['Contains Gluten, Dairy']
  },
  {
    id: 'hea-2',
    name: 'Campus Chai & Samosa Duet Combo',
    tagline: '2 Special Kulhad Masala Chais + 2 Hot Samosas with Chutneys',
    category: 'healthy',
    subcategory: 'Student Super Combos',
    description: 'Perfect for sharing with your batchmate during break! 2 hot smoky kulhads of ginger-cardamom tea paired with 2 crispy potato-pea samosas and tangy sweet & spicy chutneys.',
    price: 70,
    originalPrice: 85,
    image: 'https://images.unsplash.com/photo-1576092768241-dec231879fc3?w=800&auto=format&fit=crop&q=80',
    dietaryTags: ['veg'],
    isAvailable: true,
    stockCount: 50,
    isPopular: true,
    rating: 4.9,
    reviewCount: 340,
    preparationTimeMinutes: 4,
    calories: 360,
    protein: 8,
    carbs: 52,
    fat: 14,
    ingredients: ['2x Masala Kulhad Chai', '2x Golden Samosas', 'Mint Chutney', 'Imli Chutney'],
    allergenWarnings: ['Contains Dairy, Gluten']
  },

  // --- DESSERTS ---
  {
    id: 'des-1',
    name: 'Warm Gulab Jamun with Creamy Rabdi (2 Pcs)',
    tagline: 'Soft khoya dumplings dipped in saffron syrup topped with thick condensed milk',
    category: 'desserts',
    subcategory: 'Indian Sweets',
    description: 'Freshly fried melt-in-mouth mawa gulab jamuns steeped in rose-cardamom sugar syrup, served warm in a clay dish topped with rich malai rabdi and sliced pistachios.',
    price: 60,
    image: 'https://images.unsplash.com/photo-1571877227200-a0d98ea607e9?w=800&auto=format&fit=crop&q=80',
    dietaryTags: ['veg', 'chef-special', 'contains-nuts'],
    isAvailable: true,
    stockCount: 30,
    isPopular: true,
    isChefSpecial: true,
    rating: 4.9,
    reviewCount: 230,
    preparationTimeMinutes: 3,
    calories: 310,
    protein: 6,
    carbs: 48,
    fat: 12,
    ingredients: ['Khoya / Mawa', 'Rose Cardamom Syrup', 'Thick Rabdi', 'Pistachio Flakes'],
    allergenWarnings: ['Contains Dairy, Tree Nuts (Pistachio)']
  },
  {
    id: 'des-2',
    name: 'Sizzling Chocolate Brownie with Vanilla Ice Cream',
    tagline: 'Fudgy hot brownie on a sizzling iron skillet with molten chocolate fudge',
    category: 'desserts',
    subcategory: 'Pastries & Cakes',
    description: 'Dense dark chocolate walnut brownie served warm on a sizzling platter, topped with cold vanilla ice cream and drizzled with bubbling hot dark chocolate fudge sauce.',
    price: 95,
    image: 'https://images.unsplash.com/photo-1533134242443-d4fd215305ad?w=800&auto=format&fit=crop&q=80',
    dietaryTags: ['veg', 'contains-nuts'],
    isAvailable: true,
    stockCount: 18,
    rating: 4.9,
    reviewCount: 180,
    preparationTimeMinutes: 5,
    calories: 420,
    protein: 6,
    carbs: 56,
    fat: 20,
    ingredients: ['Dark Belgian Cocoa', 'Walnuts', 'Butter', 'Vanilla Bean Ice Cream', 'Chocolate Ganache'],
    allergenWarnings: ['Contains Dairy, Gluten, Tree Nuts (Walnuts)']
  }
];

export const INITIAL_TABLES: CafeTable[] = [
  // Indoor Food Court Zone
  { id: 'tbl-1', tableNumber: 'T-01', name: 'Central Campus Food Court 1', capacity: 4, zone: 'indoor', status: 'available', coordinates: { x: 20, y: 25 } },
  { id: 'tbl-2', tableNumber: 'T-02', name: 'Central Campus Food Court 2', capacity: 4, zone: 'indoor', status: 'available', coordinates: { x: 20, y: 55 } },
  { id: 'tbl-3', tableNumber: 'T-03', name: 'Central Campus Food Court 3', capacity: 6, zone: 'indoor', status: 'reserved', coordinates: { x: 20, y: 85 } },
  
  // Quiet Study & Coding Corner (with power sockets & Wi-Fi)
  { id: 'tbl-4', tableNumber: 'T-04', name: 'Study & Coding Nook 4 (Power Plugs)', capacity: 2, zone: 'lounge', status: 'available', coordinates: { x: 48, y: 25 } },
  { id: 'tbl-5', tableNumber: 'T-05', name: 'Study & Coding Nook 5 (Power Plugs)', capacity: 2, zone: 'lounge', status: 'occupied', coordinates: { x: 48, y: 55 } },
  { id: 'tbl-6', tableNumber: 'T-06', name: 'Library Quiet Zone Table 6', capacity: 4, zone: 'lounge', status: 'available', coordinates: { x: 48, y: 85 } },

  // Open Campus Green Lawn & Terrace
  { id: 'tbl-7', tableNumber: 'T-07', name: 'Green Campus Lawn Umbrella 7', capacity: 4, zone: 'patio', status: 'available', coordinates: { x: 78, y: 25 } },
  { id: 'tbl-8', tableNumber: 'T-08', name: 'Terrace Sunset View 8', capacity: 4, zone: 'patio', status: 'available', coordinates: { x: 78, y: 55 } },
  { id: 'tbl-9', tableNumber: 'T-09', name: 'Pergola Garden Bench 9', capacity: 6, zone: 'patio', status: 'reserved', coordinates: { x: 78, y: 85 } },

  // Group Project & Club Discussion Booths
  { id: 'tbl-10', tableNumber: 'T-10', name: 'Project & Club Booth 10 (Whiteboard)', capacity: 6, zone: 'booth', status: 'available', coordinates: { x: 35, y: 92 } },
  { id: 'tbl-11', tableNumber: 'T-11', name: 'Hackathon War Room Booth 11', capacity: 8, zone: 'booth', status: 'available', coordinates: { x: 65, y: 92 } },

  // Express Bar Counter
  { id: 'tbl-12', tableNumber: 'T-12', name: 'Express Chai & Kaapi Bar 12', capacity: 3, zone: 'counter', status: 'available', coordinates: { x: 50, y: 10 } }
];

export const INITIAL_PROMO_CODES: PromoCode[] = [
  {
    code: 'CAMPUS20',
    discountType: 'percentage',
    discountValue: 20,
    minOrderAmount: 100,
    description: '20% off for all GEC Banka students & faculty',
    isActive: true
  },
  {
    code: 'CHAI10',
    discountType: 'fixed',
    discountValue: 15,
    minOrderAmount: 50,
    description: '₹15 instant off on tea & snack orders',
    isActive: true
  },
  {
    code: 'EXAMNIGHT',
    discountType: 'percentage',
    discountValue: 15,
    minOrderAmount: 150,
    description: '15% off late evening & exam prep orders',
    isActive: true
  },
  {
    code: 'HOSTEL30',
    discountType: 'fixed',
    discountValue: 30,
    minOrderAmount: 200,
    description: '₹30 off hostel group delivery orders above ₹200',
    isActive: true
  }
];

export const INITIAL_CUSTOMERS: CustomerRecord[] = [
  {
    id: 'cust-1',
    name: 'Aman Kumar',
    phone: '+91 98765 43210',
    email: 'aman.cse24@gecbanka.ac.in',
    totalBookings: 18,
    totalSpent: 3450,
    isVIP: true,
    lastVisit: '2026-08-31',
    favoriteItems: ['Special Tandoori Kulhad Masala Chai', "Engineer's All-Nighter Study Combo"],
    loyaltyPoints: 345,
    notes: 'CSE Department Secretary. Prefers Study Booth 10.'
  },
  {
    id: 'cust-2',
    name: 'Pooja Kumari',
    phone: '+91 98350 12345',
    email: 'pooja.ece@gmail.com',
    totalBookings: 12,
    totalSpent: 2180,
    isVIP: true,
    lastVisit: '2026-08-30',
    favoriteItems: ['Thick Cold Coffee with Vanilla Ice Cream', 'Kolkata Paneer Tikka Kathi Roll'],
    loyaltyPoints: 218,
    notes: 'Regular table reservation on Lawn Patio 7.'
  },
  {
    id: 'cust-3',
    name: 'Prof. Rajesh Sharma',
    phone: '+91 94312 88990',
    email: 'rsharma@gecbanka.ac.in',
    totalBookings: 8,
    totalSpent: 1600,
    isVIP: false,
    lastVisit: '2026-08-28',
    favoriteItems: ['South Indian Filter Kaapi', 'Mumbai Style Butter Pav Bhaji'],
    loyaltyPoints: 160,
    notes: 'Faculty member. Prefers sugar-free coffee.'
  }
];

export const INITIAL_SAMPLE_ORDERS: BookingOrder[] = [
  {
    id: 'BK-7801',
    createdAt: new Date(Date.now() - 30 * 60 * 1000).toISOString(),
    deviceSessionSlug: 'gec-dev-k82x-9a1b',
    bookingMode: 'dine-in',
    status: 'preparing',
    customer: {
      name: 'Aman Kumar (CSE 3rd Yr)',
      phone: '+91 98765 43210',
      email: 'aman.cse24@gecbanka.ac.in',
      specialRequests: 'Extra ginger in Kulhad Chai, keep Maggi extra cheesy',
      sendWhatsAppNotification: true
    },
    dineInDetails: {
      date: new Date().toISOString().split('T')[0],
      timeSlot: '04:30 PM',
      guestCount: 3,
      tableId: 'tbl-3',
      tableNumber: 'T-03',
      zone: 'indoor',
      occasion: 'casual'
    },
    items: [
      {
        cartItemId: 'item-demo-1',
        menuItemId: 'bev-1',
        name: 'Special Tandoori Kulhad Masala Chai',
        unitPrice: 25,
        calculatedPrice: 25,
        quantity: 3,
        image: 'https://images.unsplash.com/photo-1576092768241-dec231879fc3?w=800&auto=format&fit=crop&q=80',
        specialInstructions: 'Piping hot in earthen cups'
      },
      {
        cartItemId: 'item-demo-2',
        menuItemId: 'snk-3',
        name: 'Double Butter Cheese Masala Maggi',
        unitPrice: 65,
        calculatedPrice: 65,
        quantity: 2,
        image: 'https://images.unsplash.com/photo-1612927601601-6638404737ce?w=800&auto=format&fit=crop&q=80',
        specialInstructions: 'Extra cheese topping'
      }
    ],
    pricing: {
      subtotal: 205,
      discountAmount: 41,
      discountCode: 'CAMPUS20',
      gstTax: 8.20,
      serviceFee: 0,
      deliveryFee: 0,
      tip: 10,
      total: 182.20
    },
    paymentMethod: 'upi',
    paymentStatus: 'paid',
    qrCodePayload: 'CAMPORA-BK-7801-T03',
    estimatedReadyTime: '04:45 PM',
    adminNotes: 'Table T-03 assigned. Kitchen preparing order.'
  },
  {
    id: 'BK-7802',
    createdAt: new Date(Date.now() - 5 * 60 * 1000).toISOString(),
    deviceSessionSlug: 'gec-dev-p41q-3c78',
    bookingMode: 'takeout',
    status: 'confirmed',
    customer: {
      name: 'Pooja Kumari',
      phone: '+91 98350 12345',
      email: 'pooja.ece@gmail.com',
      specialRequests: 'Pack rolls tight for hostel take-away',
      sendWhatsAppNotification: true
    },
    takeoutDetails: {
      pickupTime: 'Ready in 10 mins',
      vehicleOrNote: 'Counter pickup after ECE lecture'
    },
    items: [
      {
        cartItemId: 'item-demo-3',
        menuItemId: 'main-1',
        name: 'Kolkata Paneer Tikka Kathi Roll',
        unitPrice: 110,
        calculatedPrice: 110,
        quantity: 1,
        image: 'https://images.unsplash.com/photo-1626777552726-4a6b54c97e46?w=800&auto=format&fit=crop&q=80',
        specialInstructions: 'Extra green chutney'
      },
      {
        cartItemId: 'item-demo-4',
        menuItemId: 'bev-2',
        name: 'Thick Cold Coffee with Vanilla Ice Cream',
        unitPrice: 80,
        calculatedPrice: 80,
        quantity: 1,
        image: 'https://images.unsplash.com/photo-1517701550927-30cf4ba1dba5?w=800&auto=format&fit=crop&q=80',
        specialInstructions: 'With straw and choco chips'
      }
    ],
    pricing: {
      subtotal: 190,
      discountAmount: 15,
      discountCode: 'CHAI10',
      gstTax: 8.75,
      serviceFee: 0,
      deliveryFee: 0,
      tip: 0,
      total: 183.75
    },
    paymentMethod: 'upi',
    paymentStatus: 'paid',
    qrCodePayload: 'CAMPORA-BK-7802-TAKEOUT',
    estimatedReadyTime: 'Ready at Counter',
    adminNotes: 'Packed in eco-friendly paper bag.'
  }
];

export const INITIAL_SAMPLE_COUNTER_SALES: CounterSale[] = [
  {
    id: 'CS-101',
    customerName: 'Prof. S. N. Verma',
    customerPhone: '+91 98351 23456',
    items: [
      { id: 'cs-i1', name: 'Veg Hakka Noodles', quantity: 1, price: 70, total: 70 },
      { id: 'cs-i2', name: 'Special Masala Chai', quantity: 2, price: 15, total: 30 },
      { id: 'cs-i3', name: 'Crispy Samosa (2 Pcs)', quantity: 1, price: 20, total: 20 }
    ],
    totalAmount: 120,
    paymentMethod: 'upi',
    createdAt: new Date(Date.now() - 35 * 60 * 1000).toISOString(),
    note: 'Paid via PhonePe QR at counter soundbox',
    addedByName: 'Lead Administrator & Owner'
  },
  {
    id: 'CS-102',
    customerName: 'Walk-in Student',
    customerPhone: '',
    items: [
      { id: 'cs-i4', name: 'Cold Coffee with Ice Cream', quantity: 2, price: 80, total: 160 },
      { id: 'cs-i5', name: 'Veg Grilled Sandwich', quantity: 1, price: 90, total: 90 }
    ],
    totalAmount: 250,
    paymentMethod: 'cash',
    createdAt: new Date(Date.now() - 95 * 60 * 1000).toISOString(),
    note: 'Cash handed at counter',
    addedByName: 'Lead Administrator & Owner'
  },
  {
    id: 'CS-103',
    customerName: 'Anjali Verma (Hostel-2)',
    customerPhone: '+91 94310 98765',
    items: [
      { id: 'cs-i6', name: 'Paneer Tikka Roll', quantity: 1, price: 110, total: 110 },
      { id: 'cs-i7', name: 'Hot Cappuccino', quantity: 1, price: 45, total: 45 }
    ],
    totalAmount: 155,
    paymentMethod: 'upi',
    createdAt: new Date(Date.now() - 180 * 60 * 1000).toISOString(),
    note: 'GPay payment verified',
    addedByName: 'Lead Administrator & Owner'
  },
  {
    id: 'CS-104',
    customerName: 'CSE Department Staff',
    customerPhone: '',
    items: [
      { id: 'cs-i8', name: 'Special Masala Chai', quantity: 6, price: 15, total: 90 },
      { id: 'cs-i9', name: 'Crispy Samosa (2 Pcs)', quantity: 3, price: 20, total: 60 }
    ],
    totalAmount: 150,
    paymentMethod: 'cash',
    createdAt: new Date(Date.now() - 22 * 60 * 60 * 1000).toISOString(),
    note: 'Counter pickup for faculty tea break',
    addedByName: 'Lead Administrator & Owner'
  }
];

export const INITIAL_STAFF_MEMBERS: StaffMember[] = [
  {
    id: 'staff-kundan-owner',
    uid: 'aWplD23baqfpkcMPc2fqy967lt02',
    staffId: 'CC-OWNER-01',
    fullName: 'Kundan Kumar',
    mobile: '+91 94318 72050',
    email: 'edu.kundanai@gmail.com',
    dateOfJoining: '2025-01-01',
    role: 'owner',
    position: 'Manager',
    status: 'active',
    address: 'Faculty Residence Block B, GEC Banka Campus',
    emergencyContact: '+91 94318 72050',
    idProofType: 'College ID',
    idProofNumber: 'GECB/ADMIN/2025/001',
    photoUrl: 'https://images.unsplash.com/photo-1534528741775-53994a69daeb?w=300&auto=format&fit=crop&q=80',
    notes: 'Campora Café Lead Administrator & Owner. Unrestricted full system authority.',
    permissions: [
      'view_orders',
      'update_order_status',
      'create_counter_sale',
      'view_counter_sales',
      'manage_menu',
      'manage_tables',
      'view_customer_info',
      'view_crm',
      'view_sales_reports',
      'manage_staff',
      'change_cafe_status',
      'manage_settings'
    ],
    createdAt: '2025-01-01T08:00:00.000Z',
    lastLoginAt: new Date().toISOString()
  },
  {
    id: 'staff-priya-manager',
    staffId: 'CC-MGR-101',
    fullName: 'Priya Singh',
    mobile: '+91 98765 43212',
    email: 'priya.manager@camporacafe.in',
    dateOfJoining: '2025-07-15',
    role: 'manager',
    position: 'Manager',
    status: 'active',
    address: 'Hostel 3 Staff Quarters, GEC Banka',
    emergencyContact: '+91 98765 11111',
    idProofType: 'PAN',
    idProofNumber: 'PXXXX1234F',
    photoUrl: 'https://images.unsplash.com/photo-1573496359142-b8d87734a5a2?w=300&auto=format&fit=crop&q=80',
    notes: 'Floor manager overseeing daily café operations, table turnover, inventory, and staff rosters.',
    permissions: [
      'view_orders',
      'update_order_status',
      'create_counter_sale',
      'view_counter_sales',
      'manage_menu',
      'manage_tables',
      'view_customer_info',
      'view_crm',
      'view_sales_reports',
      'change_cafe_status'
    ],
    createdAt: '2025-07-15T09:00:00.000Z',
    lastLoginAt: new Date(Date.now() - 40 * 60 * 1000).toISOString()
  },
  {
    id: 'staff-rahul-cashier',
    staffId: 'CC-STF-101',
    fullName: 'Rahul Kumar',
    mobile: '+91 98765 43210',
    email: 'rahul.cashier@camporacafe.in',
    dateOfJoining: '2025-08-10',
    role: 'staff',
    position: 'Cashier',
    status: 'active',
    address: 'Near GEC Banka Gate No. 2, Lakrikola',
    emergencyContact: '+91 98765 22222',
    idProofType: 'College ID',
    idProofNumber: 'GECB/2023/EE/042',
    photoUrl: 'https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?w=300&auto=format&fit=crop&q=80',
    notes: 'Front-desk point of sale cashier managing walk-ins, UPI settlements, and bill receipts.',
    permissions: [
      'view_orders',
      'create_counter_sale',
      'view_counter_sales',
      'manage_tables'
    ],
    createdAt: '2025-08-10T10:00:00.000Z',
    lastLoginAt: new Date(Date.now() - 15 * 60 * 1000).toISOString()
  },
  {
    id: 'staff-amit-kitchen',
    staffId: 'CC-STF-102',
    fullName: 'Amit Sharma',
    mobile: '+91 98765 43211',
    email: 'amit.kitchen@camporacafe.in',
    dateOfJoining: '2025-09-01',
    role: 'staff',
    position: 'Kitchen Staff',
    status: 'active',
    address: 'Main Market, Manjira, Banka',
    emergencyContact: '+91 98765 33333',
    idProofType: 'Aadhaar',
    idProofNumber: 'XXXX-XXXX-8921',
    photoUrl: 'https://images.unsplash.com/photo-1500648767791-00dcc994a43e?w=300&auto=format&fit=crop&q=80',
    notes: 'Kitchen production staff handling chai prep, grill station, and order fulfillment states.',
    permissions: [
      'view_orders',
      'update_order_status',
      'manage_tables'
    ],
    createdAt: '2025-09-01T08:30:00.000Z',
    lastLoginAt: new Date(Date.now() - 25 * 60 * 1000).toISOString()
  },
  {
    id: 'staff-suman-counter',
    staffId: 'CC-STF-103',
    fullName: 'Suman Mukherjee',
    mobile: '+91 98765 43214',
    email: 'suman.counter@camporacafe.in',
    dateOfJoining: '2025-11-20',
    role: 'staff',
    position: 'Counter Staff',
    status: 'inactive',
    address: 'Hostel 1 Annex, GEC Banka',
    emergencyContact: '+91 98765 44444',
    idProofType: 'College ID',
    idProofNumber: 'GECB/2024/ME/018',
    photoUrl: 'https://images.unsplash.com/photo-1517841905240-472988babdf9?w=300&auto=format&fit=crop&q=80',
    notes: 'Account temporarily inactive during exam revision leave.',
    permissions: [
      'view_orders',
      'create_counter_sale',
      'view_counter_sales'
    ],
    createdAt: '2025-11-20T11:00:00.000Z',
    lastLoginAt: '2026-03-01T14:30:00.000Z'
  }
];

export const INITIAL_STAFF_AUDIT_LOGS: StaffAuditLog[] = [
  {
    id: 'log-1',
    staffName: 'Staff Rahul',
    staffId: 'CC-STF-101',
    action: 'created Counter Sale #CS1025 – ₹250',
    category: 'counter_sale',
    date: new Date().toISOString().split('T')[0],
    time: '09:42:15',
    timestamp: new Date(Date.now() - 15 * 60 * 1000).toISOString(),
    relevantId: 'CS-1025',
    details: '2 items • Payment Method: UPI (GPay)'
  },
  {
    id: 'log-2',
    staffName: 'Staff Amit',
    staffId: 'CC-STF-102',
    action: 'updated Order #ORD104 – Ready',
    category: 'order',
    date: new Date().toISOString().split('T')[0],
    time: '09:25:00',
    timestamp: new Date(Date.now() - 32 * 60 * 1000).toISOString(),
    relevantId: 'BK-104',
    details: 'Order status transitioned from Preparing to Ready for pickup'
  },
  {
    id: 'log-3',
    staffName: 'Staff Priya',
    staffId: 'CC-MGR-101',
    action: 'changed table status – Table 4',
    category: 'table',
    date: new Date().toISOString().split('T')[0],
    time: '09:10:20',
    timestamp: new Date(Date.now() - 47 * 60 * 1000).toISOString(),
    relevantId: 'tbl-4',
    details: 'Marked Table 4 (Veranda Corner) as Available after sanitization'
  },
  {
    id: 'log-4',
    staffName: 'Owner Kundan',
    staffId: 'CC-OWNER-01',
    action: 'changed Café status – Open',
    category: 'cafe_status',
    date: new Date().toISOString().split('T')[0],
    time: '08:00:00',
    timestamp: new Date(Date.now() - 117 * 60 * 1000).toISOString(),
    details: 'Morning operations initiated with all kitchen and chai counters live'
  },
  {
    id: 'log-5',
    staffName: 'Owner Kundan',
    staffId: 'CC-OWNER-01',
    action: 'changed Café status – Closed',
    category: 'cafe_status',
    date: new Date(Date.now() - 24 * 60 * 60 * 1000).toISOString().split('T')[0],
    time: '23:05:12',
    timestamp: new Date(Date.now() - 24 * 60 * 60 * 1000).toISOString(),
    details: 'Night closing after final counter reconciliation'
  },
  {
    id: 'log-6',
    staffName: 'Staff Priya',
    staffId: 'CC-MGR-101',
    action: 'updated menu item – Special Tandoori Kulhad Masala Chai',
    category: 'menu',
    date: new Date().toISOString().split('T')[0],
    time: '08:15:30',
    timestamp: new Date(Date.now() - 102 * 60 * 1000).toISOString(),
    relevantId: 'bev-1',
    details: 'Stock inventory updated to 50 kulhads'
  }
];

