import React, { useState, useMemo } from 'react';
import {
  Coins,
  QrCode,
  CreditCard,
  Plus,
  Search,
  Filter,
  Calendar,
  Download,
  Trash2,
  Edit2,
  Eye,
  FileText,
  Clock,
  Printer,
  X,
  TrendingUp,
  Receipt,
  User,
  Phone,
  AlertCircle,
  ShoppingBag,
  ArrowUpDown,
  CheckCircle2,
  Sparkles
} from 'lucide-react';
import { useCafe } from '../../../context/CafeContext';
import { CounterSale, CounterSalePaymentMethod } from '../../../types';
import { CounterSaleModal } from './CounterSaleModal';

interface CounterSalesHistoryProps {
  onOpenNewSale?: () => void;
}

export const CounterSalesHistory: React.FC<CounterSalesHistoryProps> = ({ onOpenNewSale }) => {
  const { counterSales, deleteCounterSale, salesSummary, settings, showToast } = useCafe();

  // Search and Filter states
  const [searchQuery, setSearchQuery] = useState<string>('');
  const [dateFilter, setDateFilter] = useState<'all' | 'today' | 'yesterday' | '7days' | 'month' | 'custom'>('all');
  const [customDate, setCustomDate] = useState<string>('');
  const [methodFilter, setMethodFilter] = useState<'all' | CounterSalePaymentMethod>('all');
  const [sortBy, setSortBy] = useState<'newest' | 'oldest' | 'highest' | 'lowest'>('newest');

  // Modals state
  const [isNewModalOpen, setIsNewModalOpen] = useState<boolean>(false);
  const [editingSale, setEditingSale] = useState<CounterSale | null>(null);
  const [viewingReceiptSale, setViewingReceiptSale] = useState<CounterSale | null>(null);
  const [deletingSaleId, setDeletingSaleId] = useState<string | null>(null);

  // Helper date matchers
  const isDateToday = (isoDate: string) => {
    if (!isoDate) return false;
    const d = new Date(isoDate);
    const today = new Date();
    return (
      d.getDate() === today.getDate() &&
      d.getMonth() === today.getMonth() &&
      d.getFullYear() === today.getFullYear()
    );
  };

  const isDateYesterday = (isoDate: string) => {
    if (!isoDate) return false;
    const d = new Date(isoDate);
    const y = new Date();
    y.setDate(y.getDate() - 1);
    return (
      d.getDate() === y.getDate() &&
      d.getMonth() === y.getMonth() &&
      d.getFullYear() === y.getFullYear()
    );
  };

  const isDateWithinDays = (isoDate: string, days: number) => {
    if (!isoDate) return false;
    const time = new Date(isoDate).getTime();
    const threshold = Date.now() - days * 24 * 60 * 60 * 1000;
    return time >= threshold;
  };

  const isDateThisMonth = (isoDate: string) => {
    if (!isoDate) return false;
    const d = new Date(isoDate);
    const today = new Date();
    return d.getMonth() === today.getMonth() && d.getFullYear() === today.getFullYear();
  };

  // Filtered and sorted counter sales
  const filteredSales = useMemo(() => {
    return counterSales
      .filter((sale) => {
        // Search query
        if (searchQuery.trim()) {
          const q = searchQuery.toLowerCase().trim();
          const matchesId = sale.id.toLowerCase().includes(q);
          const matchesCustomer = sale.customerName?.toLowerCase().includes(q);
          const matchesPhone = sale.customerPhone?.toLowerCase().includes(q);
          const matchesNote = sale.note?.toLowerCase().includes(q);
          const matchesItems = sale.items?.some((it) => it.name.toLowerCase().includes(q));
          if (!matchesId && !matchesCustomer && !matchesPhone && !matchesNote && !matchesItems) {
            return false;
          }
        }

        // Method filter
        if (methodFilter !== 'all' && sale.paymentMethod !== methodFilter) {
          return false;
        }

        // Date filter
        if (dateFilter === 'today') {
          return isDateToday(sale.createdAt);
        }
        if (dateFilter === 'yesterday') {
          return isDateYesterday(sale.createdAt);
        }
        if (dateFilter === '7days') {
          return isDateWithinDays(sale.createdAt, 7);
        }
        if (dateFilter === 'month') {
          return isDateThisMonth(sale.createdAt);
        }
        if (dateFilter === 'custom' && customDate) {
          const saleDate = new Date(sale.createdAt).toISOString().slice(0, 10);
          return saleDate === customDate;
        }

        return true;
      })
      .sort((a, b) => {
        if (sortBy === 'newest') {
          return new Date(b.createdAt).getTime() - new Date(a.createdAt).getTime();
        }
        if (sortBy === 'oldest') {
          return new Date(a.createdAt).getTime() - new Date(b.createdAt).getTime();
        }
        if (sortBy === 'highest') {
          return b.totalAmount - a.totalAmount;
        }
        if (sortBy === 'lowest') {
          return a.totalAmount - b.totalAmount;
        }
        return 0;
      });
  }, [counterSales, searchQuery, methodFilter, dateFilter, customDate, sortBy]);

  // Aggregate stats of currently filtered selection
  const filteredTotals = useMemo(() => {
    const totalRevenue = filteredSales.reduce((sum, s) => sum + s.totalAmount, 0);
    const cashTotal = filteredSales.filter((s) => s.paymentMethod === 'cash').reduce((sum, s) => sum + s.totalAmount, 0);
    const upiTotal = filteredSales.filter((s) => s.paymentMethod === 'upi').reduce((sum, s) => sum + s.totalAmount, 0);
    const otherTotal = filteredSales.filter((s) => s.paymentMethod === 'other').reduce((sum, s) => sum + s.totalAmount, 0);
    return {
      count: filteredSales.length,
      totalRevenue,
      cashTotal,
      upiTotal,
      otherTotal
    };
  }, [filteredSales]);

  // Export filtered counter sales to CSV
  const handleExportCSV = () => {
    if (filteredSales.length === 0) {
      showToast('No Data', 'There are no counter sales matching current filters to export.', 'warning');
      return;
    }

    const headers = [
      'Sale ID',
      'Date & Time',
      'Customer Name',
      'Customer Phone',
      'Items Purchased',
      'Total Items Count',
      'Total Amount (INR)',
      'Payment Method',
      'Recorded By',
      'Note / Remark'
    ];

    const rows = filteredSales.map((sale) => {
      const itemsList = sale.items
        ? sale.items.map((i) => `${i.name} (${i.quantity}x @ Rs.${i.price})`).join('; ')
        : '';
      const totalUnits = sale.items ? sale.items.reduce((s, i) => s + i.quantity, 0) : 0;
      return [
        `"${sale.id}"`,
        `"${new Date(sale.createdAt).toLocaleString('en-IN')}"`,
        `"${(sale.customerName || 'Walk-in').replace(/"/g, '""')}"`,
        `"${(sale.customerPhone || '').replace(/"/g, '""')}"`,
        `"${itemsList.replace(/"/g, '""')}"`,
        totalUnits,
        sale.totalAmount.toFixed(2),
        `"${sale.paymentMethod.toUpperCase()}"`,
        `"${(sale.addedByName || 'Admin Staff').replace(/"/g, '""')}"`,
        `"${(sale.note || '').replace(/"/g, '""')}"`
      ];
    });

    const csvContent = 'data:text/csv;charset=utf-8,' + [headers.join(','), ...rows.map((r) => r.join(','))].join('\n');
    const encodedUri = encodeURI(csvContent);
    const link = document.createElement('a');
    link.setAttribute('href', encodedUri);
    link.setAttribute('download', `campora_counter_sales_${new Date().toISOString().slice(0, 10)}.csv`);
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);

    showToast('Export Successful', `Exported ${filteredSales.length} counter sales to CSV file.`, 'success');
  };

  // Delete handler
  const confirmDelete = async () => {
    if (!deletingSaleId) return;
    try {
      await deleteCounterSale(deletingSaleId);
      setDeletingSaleId(null);
    } catch (err) {
      console.error('Delete counter sale error:', err);
    }
  };

  return (
    <div className="space-y-6">
      
      {/* 1. TOP DUAL REVENUE KPI METRICS (Online Orders vs Counter Sales vs Combined Total) */}
      <div className="space-y-3">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2">
          <div>
            <h3 className="font-serif text-lg font-bold text-stone-900 flex items-center gap-2">
              <span>Counter Sales & Daily Sales Breakdown</span>
              <span className="text-[10px] px-2 py-0.5 rounded-full bg-amber-100 text-amber-900 font-bold uppercase tracking-wider">
                Audited Totals
              </span>
            </h3>
            <p className="text-xs text-stone-500">
              Complete café sales reporting separating counter walk-ins from online customer orders.
            </p>
          </div>

          <div className="flex items-center gap-2">
            <button
              onClick={() => setIsNewModalOpen(true)}
              className="px-4 py-2 rounded-xl bg-amber-500 hover:bg-amber-400 text-stone-950 font-bold text-xs flex items-center gap-1.5 shadow-sm transition-all cursor-pointer"
            >
              <Plus className="w-4 h-4" />
              <span>New Counter Sale</span>
            </button>
            <button
              onClick={handleExportCSV}
              className="px-3.5 py-2 rounded-xl bg-stone-900 hover:bg-stone-800 text-white font-bold text-xs flex items-center gap-1.5 transition-all cursor-pointer"
              title="Download CSV"
            >
              <Download className="w-3.5 h-3.5" />
              <span className="hidden sm:inline">Export CSV</span>
            </button>
          </div>
        </div>

        {/* Primary 3-Way Split Cards: Online Orders, Counter Sales, Combined Total */}
        <div className="grid grid-cols-1 sm:grid-cols-3 gap-3.5">
          
          {/* Card 1: Online Orders */}
          <div className="p-4 rounded-2xl bg-white border border-stone-200 shadow-2xs relative overflow-hidden">
            <div className="flex items-center justify-between text-stone-500 text-xs font-semibold">
              <span className="uppercase tracking-wider">Online Orders</span>
              <ShoppingBag className="w-4 h-4 text-blue-500" />
            </div>
            <div className="text-2xl sm:text-3xl font-bold font-serif text-stone-900 mt-2">
              {settings.currency}{salesSummary.onlineOrdersTotal.toFixed(2)}
            </div>
            <div className="flex items-center justify-between mt-2 pt-2 border-t border-stone-100 text-[11px]">
              <span className="text-stone-500">Today's Online:</span>
              <span className="font-bold text-blue-600 font-serif">
                {settings.currency}{salesSummary.todayOnlineSales.toFixed(2)}
              </span>
            </div>
          </div>

          {/* Card 2: Counter Sales */}
          <div className="p-4 rounded-2xl bg-white border border-amber-200 shadow-2xs relative overflow-hidden bg-gradient-to-br from-amber-50/40 via-white to-white">
            <div className="flex items-center justify-between text-amber-900 text-xs font-semibold">
              <span className="uppercase tracking-wider font-bold">Counter Sales (Walk-ins)</span>
              <Receipt className="w-4 h-4 text-amber-600" />
            </div>
            <div className="text-2xl sm:text-3xl font-bold font-serif text-amber-950 mt-2">
              {settings.currency}{salesSummary.counterSalesTotal.toFixed(2)}
            </div>
            <div className="flex items-center justify-between mt-2 pt-2 border-t border-amber-100 text-[11px]">
              <span className="text-amber-800">Today's Counter:</span>
              <span className="font-bold text-amber-700 font-serif">
                {settings.currency}{salesSummary.todayCounterSales.toFixed(2)}
              </span>
            </div>
          </div>

          {/* Card 3: Total Combined Sales */}
          <div className="p-4 rounded-2xl bg-stone-950 text-white shadow-sm relative overflow-hidden">
            <div className="flex items-center justify-between text-stone-400 text-xs font-semibold">
              <span className="uppercase tracking-wider text-amber-400 font-bold">Total Sales</span>
              <TrendingUp className="w-4 h-4 text-emerald-400" />
            </div>
            <div className="text-2xl sm:text-3xl font-bold font-serif text-white mt-2">
              {settings.currency}{salesSummary.combinedTotalSales.toFixed(2)}
            </div>
            <div className="flex items-center justify-between mt-2 pt-2 border-t border-stone-800 text-[11px]">
              <span className="text-stone-300">Today's Total Sales:</span>
              <span className="font-bold text-emerald-400 font-serif text-xs">
                {settings.currency}{salesSummary.todayTotalSales.toFixed(2)}
              </span>
            </div>
          </div>

        </div>

        {/* Secondary Tender Collection Strip: Cash Collection vs UPI Collection */}
        <div className="grid grid-cols-2 sm:grid-cols-4 gap-3">
          
          <div className="p-3 bg-emerald-50/80 rounded-xl border border-emerald-200 flex items-center gap-3">
            <div className="w-9 h-9 rounded-lg bg-emerald-600 text-white flex items-center justify-center font-bold shrink-0">
              <Coins className="w-4 h-4" />
            </div>
            <div>
              <span className="text-[10px] uppercase font-bold text-emerald-800 block tracking-wider">
                Cash Collection
              </span>
              <span className="text-sm sm:text-base font-bold font-serif text-emerald-950">
                {settings.currency}{salesSummary.totalCashCollection.toFixed(2)}
              </span>
              <span className="text-[10px] text-emerald-700 block">
                Today: {settings.currency}{salesSummary.todayCashCollection.toFixed(2)}
              </span>
            </div>
          </div>

          <div className="p-3 bg-blue-50/80 rounded-xl border border-blue-200 flex items-center gap-3">
            <div className="w-9 h-9 rounded-lg bg-blue-600 text-white flex items-center justify-center font-bold shrink-0">
              <QrCode className="w-4 h-4" />
            </div>
            <div>
              <span className="text-[10px] uppercase font-bold text-blue-800 block tracking-wider">
                UPI Collection
              </span>
              <span className="text-sm sm:text-base font-bold font-serif text-blue-950">
                {settings.currency}{salesSummary.totalUpiCollection.toFixed(2)}
              </span>
              <span className="text-[10px] text-blue-700 block">
                Today: {settings.currency}{salesSummary.todayUpiCollection.toFixed(2)}
              </span>
            </div>
          </div>

          <div className="p-3 bg-purple-50/80 rounded-xl border border-purple-200 flex items-center gap-3">
            <div className="w-9 h-9 rounded-lg bg-purple-600 text-white flex items-center justify-center font-bold shrink-0">
              <CreditCard className="w-4 h-4" />
            </div>
            <div>
              <span className="text-[10px] uppercase font-bold text-purple-800 block tracking-wider">
                Other / Card
              </span>
              <span className="text-sm sm:text-base font-bold font-serif text-purple-950">
                {settings.currency}{salesSummary.totalOtherCollection.toFixed(2)}
              </span>
              <span className="text-[10px] text-purple-700 block">
                Today: {settings.currency}{salesSummary.todayOtherCollection.toFixed(2)}
              </span>
            </div>
          </div>

          <div className="p-3 bg-stone-100 rounded-xl border border-stone-200 flex items-center gap-3">
            <div className="w-9 h-9 rounded-lg bg-stone-800 text-white flex items-center justify-center font-bold shrink-0">
              <Clock className="w-4 h-4" />
            </div>
            <div>
              <span className="text-[10px] uppercase font-bold text-stone-600 block tracking-wider">
                Counter Entries
              </span>
              <span className="text-sm sm:text-base font-bold text-stone-900">
                {counterSales.length} Total
              </span>
              <span className="text-[10px] text-stone-500 block">
                {counterSales.filter((s) => isDateToday(s.createdAt)).length} Today
              </span>
            </div>
          </div>

        </div>
      </div>

      {/* 2. SEARCH & FILTER CONTROLS BAR */}
      <div className="bg-white p-4 rounded-2xl border border-stone-200 shadow-2xs space-y-3">
        <div className="grid grid-cols-1 sm:grid-cols-12 gap-3">
          
          {/* Search Box */}
          <div className="sm:col-span-5 relative">
            <Search className="w-4 h-4 text-stone-400 absolute left-3 top-2.5" />
            <input
              type="text"
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              placeholder="Search by ID, customer name, mobile, item, or note..."
              className="w-full pl-9 pr-8 py-2 text-xs bg-stone-50 rounded-xl border border-stone-200 focus:outline-hidden focus:ring-2 focus:ring-amber-500 text-stone-900 placeholder:text-stone-400"
            />
            {searchQuery && (
              <button
                onClick={() => setSearchQuery('')}
                className="absolute right-2.5 top-2.5 text-stone-400 hover:text-stone-600"
              >
                <X className="w-3.5 h-3.5" />
              </button>
            )}
          </div>

          {/* Date Filter Tabs */}
          <div className="sm:col-span-4 flex items-center gap-1 bg-stone-100 p-1 rounded-xl overflow-x-auto text-xs font-semibold">
            {[
              { id: 'all', label: 'All' },
              { id: 'today', label: 'Today' },
              { id: 'yesterday', label: 'Yesterday' },
              { id: '7days', label: '7 Days' },
              { id: 'month', label: 'Month' },
              { id: 'custom', label: 'Custom' }
            ].map((f) => (
              <button
                key={f.id}
                onClick={() => setDateFilter(f.id as any)}
                className={`px-2.5 py-1 rounded-lg transition-all cursor-pointer whitespace-nowrap ${
                  dateFilter === f.id
                    ? 'bg-white text-stone-950 font-bold shadow-2xs'
                    : 'text-stone-600 hover:text-stone-900'
                }`}
              >
                {f.label}
              </button>
            ))}
          </div>

          {/* Payment Method Filter */}
          <div className="sm:col-span-3 flex items-center gap-2">
            <select
              value={methodFilter}
              onChange={(e) => setMethodFilter(e.target.value as any)}
              className="w-full px-3 py-2 text-xs bg-stone-50 rounded-xl border border-stone-200 text-stone-800 font-semibold focus:outline-hidden focus:ring-2 focus:ring-amber-500"
            >
              <option value="all">All Tender Methods</option>
              <option value="cash">💵 Cash Only</option>
              <option value="upi">📱 UPI / QR Only</option>
              <option value="other">💳 Other / Card Only</option>
            </select>
          </div>

        </div>

        {/* Custom date picker row when 'custom' is active */}
        {dateFilter === 'custom' && (
          <div className="pt-2 border-t border-stone-100 flex items-center gap-2 text-xs">
            <span className="text-stone-500 font-medium">Select Exact Date:</span>
            <input
              type="date"
              value={customDate}
              onChange={(e) => setCustomDate(e.target.value)}
              className="px-3 py-1.5 rounded-lg border border-stone-300 text-xs text-stone-800 focus:outline-hidden focus:ring-1 focus:ring-amber-500"
            />
            {customDate && (
              <button
                onClick={() => setCustomDate('')}
                className="text-stone-400 hover:text-stone-600"
              >
                Clear
              </button>
            )}
          </div>
        )}

        {/* Results summary filter tag bar */}
        <div className="flex flex-wrap items-center justify-between text-xs text-stone-500 pt-1 border-t border-stone-100">
          <div>
            Showing <span className="font-bold text-stone-900">{filteredSales.length}</span> counter sales
            {filteredSales.length !== counterSales.length && (
              <span> (filtered from {counterSales.length} total)</span>
            )}
            : <span className="font-bold text-amber-700 font-serif">{settings.currency}{filteredTotals.totalRevenue.toFixed(2)}</span>
          </div>

          <div className="flex items-center gap-2">
            <span className="text-[11px] text-stone-400">Sort by:</span>
            <select
              value={sortBy}
              onChange={(e) => setSortBy(e.target.value as any)}
              className="text-xs bg-transparent border-none text-stone-800 font-semibold focus:outline-hidden cursor-pointer"
            >
              <option value="newest">Newest First</option>
              <option value="oldest">Oldest First</option>
              <option value="highest">Highest Amount</option>
              <option value="lowest">Lowest Amount</option>
            </select>
          </div>
        </div>
      </div>

      {/* 3. COUNTER SALES HISTORY TABLE */}
      <div className="bg-white rounded-2xl border border-stone-200 shadow-2xs overflow-hidden">
        {filteredSales.length === 0 ? (
          <div className="py-12 px-4 text-center space-y-3">
            <div className="w-12 h-12 rounded-2xl bg-amber-100 text-amber-700 flex items-center justify-center mx-auto">
              <Receipt className="w-6 h-6" />
            </div>
            <div>
              <h4 className="font-bold text-stone-800 text-sm">No Counter Sales Found</h4>
              <p className="text-xs text-stone-500 max-w-sm mx-auto mt-0.5">
                {searchQuery || methodFilter !== 'all' || dateFilter !== 'all'
                  ? 'No counter sales match your search or filter criteria. Try clearing filters.'
                  : 'No counter sales recorded yet. Click "New Counter Sale" to add your first walk-in purchase.'}
              </p>
            </div>
            <button
              onClick={() => setIsNewModalOpen(true)}
              className="px-4 py-2 rounded-xl bg-amber-500 hover:bg-amber-400 text-stone-950 text-xs font-bold transition-all inline-flex items-center gap-1.5 cursor-pointer shadow-2xs"
            >
              <Plus className="w-4 h-4" />
              <span>Record Counter Sale</span>
            </button>
          </div>
        ) : (
          <div className="overflow-x-auto">
            <table className="w-full text-left text-xs">
              <thead className="bg-stone-50 text-stone-500 font-semibold text-[11px] border-b border-stone-200 uppercase tracking-wider">
                <tr>
                  <th className="py-3 px-4">Sale ID / Time</th>
                  <th className="py-3 px-4">Customer</th>
                  <th className="py-3 px-4">Purchased Items</th>
                  <th className="py-3 px-4 text-right">Amount</th>
                  <th className="py-3 px-4 text-center">Tender</th>
                  <th className="py-3 px-4">Staff / Note</th>
                  <th className="py-3 px-4 text-right">Actions</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-stone-100">
                {filteredSales.map((sale) => {
                  const isToday = isDateToday(sale.createdAt);
                  return (
                    <tr key={sale.id} className="hover:bg-stone-50/80 transition-colors">
                      
                      {/* Sale ID & Timestamp */}
                      <td className="py-3 px-4">
                        <div className="flex items-center gap-1.5">
                          <span className="font-mono font-bold text-stone-900 bg-stone-100 px-2 py-0.5 rounded-md text-[11px]">
                            {sale.id}
                          </span>
                          {isToday && (
                            <span className="w-2 h-2 rounded-full bg-emerald-500" title="Today's sale" />
                          )}
                        </div>
                        <div className="text-[11px] text-stone-500 mt-0.5 flex items-center gap-1">
                          <Clock className="w-3 h-3 text-stone-400" />
                          <span>
                            {new Date(sale.createdAt).toLocaleDateString('en-IN', {
                              day: 'numeric',
                              month: 'short'
                            })}{' '}
                            •{' '}
                            {new Date(sale.createdAt).toLocaleTimeString('en-IN', {
                              hour: '2-digit',
                              minute: '2-digit',
                              hour12: true
                            })}
                          </span>
                        </div>
                      </td>

                      {/* Customer */}
                      <td className="py-3 px-4">
                        <span className="font-bold text-stone-900 block">
                          {sale.customerName || 'Walk-in Customer'}
                        </span>
                        {sale.customerPhone ? (
                          <span className="text-[11px] text-stone-500 flex items-center gap-1 mt-0.5">
                            <Phone className="w-3 h-3 text-stone-400" />
                            <span>{sale.customerPhone}</span>
                          </span>
                        ) : (
                          <span className="text-[10px] text-stone-400 italic">Direct counter walk-in</span>
                        )}
                      </td>

                      {/* Items Summary */}
                      <td className="py-3 px-4 max-w-xs">
                        <div className="space-y-1">
                          {sale.items && sale.items.slice(0, 2).map((item, idx) => (
                            <div key={idx} className="text-[11px] text-stone-800 flex items-center justify-between gap-2">
                              <span className="truncate">{item.name}</span>
                              <span className="text-stone-500 font-mono text-[10px] shrink-0">
                                {item.quantity} × {settings.currency}{item.price}
                              </span>
                            </div>
                          ))}
                          {sale.items && sale.items.length > 2 && (
                            <span className="text-[10px] text-amber-700 font-semibold block">
                              +{sale.items.length - 2} more item{sale.items.length - 2 > 1 ? 's' : ''}
                            </span>
                          )}
                        </div>
                      </td>

                      {/* Amount */}
                      <td className="py-3 px-4 text-right">
                        <span className="text-base font-bold font-serif text-stone-950">
                          {settings.currency}{sale.totalAmount.toFixed(2)}
                        </span>
                        <span className="text-[10px] text-stone-400 block">
                          {sale.items?.reduce((s, i) => s + i.quantity, 0) || 0} unit(s)
                        </span>
                      </td>

                      {/* Payment Method */}
                      <td className="py-3 px-4 text-center">
                        <span
                          className={`inline-flex items-center gap-1 px-2.5 py-1 rounded-full text-[10px] font-bold uppercase tracking-wider ${
                            sale.paymentMethod === 'cash'
                              ? 'bg-emerald-100 text-emerald-800 border border-emerald-200'
                              : sale.paymentMethod === 'upi'
                              ? 'bg-blue-100 text-blue-800 border border-blue-200'
                              : 'bg-purple-100 text-purple-800 border border-purple-200'
                          }`}
                        >
                          {sale.paymentMethod === 'cash' && <Coins className="w-3 h-3" />}
                          {sale.paymentMethod === 'upi' && <QrCode className="w-3 h-3" />}
                          {sale.paymentMethod === 'other' && <CreditCard className="w-3 h-3" />}
                          <span>{sale.paymentMethod}</span>
                        </span>
                      </td>

                      {/* Staff & Note */}
                      <td className="py-3 px-4 max-w-xs">
                        <div className="text-[11px] text-stone-700 font-medium truncate">
                          {sale.addedByName || 'Admin Staff'}
                        </div>
                        {sale.note ? (
                          <div className="text-[10px] text-stone-500 italic truncate mt-0.5" title={sale.note}>
                            "{sale.note}"
                          </div>
                        ) : (
                          <span className="text-[10px] text-stone-300">—</span>
                        )}
                      </td>

                      {/* Actions */}
                      <td className="py-3 px-4 text-right whitespace-nowrap">
                        <div className="flex items-center justify-end gap-1">
                          
                          {/* View Receipt */}
                          <button
                            onClick={() => setViewingReceiptSale(sale)}
                            className="p-1.5 text-stone-500 hover:text-stone-900 hover:bg-stone-100 rounded-lg transition-colors cursor-pointer"
                            title="View Full Itemized Receipt"
                          >
                            <Eye className="w-3.5 h-3.5" />
                          </button>

                          {/* Edit Sale */}
                          <button
                            onClick={() => setEditingSale(sale)}
                            className="p-1.5 text-stone-500 hover:text-amber-700 hover:bg-amber-50 rounded-lg transition-colors cursor-pointer"
                            title="Edit Counter Sale"
                          >
                            <Edit2 className="w-3.5 h-3.5" />
                          </button>

                          {/* Delete Sale */}
                          <button
                            onClick={() => setDeletingSaleId(sale.id)}
                            className="p-1.5 text-stone-500 hover:text-rose-600 hover:bg-rose-50 rounded-lg transition-colors cursor-pointer"
                            title="Delete Entry"
                          >
                            <Trash2 className="w-3.5 h-3.5" />
                          </button>

                        </div>
                      </td>

                    </tr>
                  );
                })}
              </tbody>
            </table>
          </div>
        )}
      </div>

      {/* 4. NEW COUNTER SALE MODAL */}
      <CounterSaleModal
        isOpen={isNewModalOpen}
        onClose={() => setIsNewModalOpen(false)}
      />

      {/* 5. EDIT COUNTER SALE MODAL */}
      {editingSale && (
        <CounterSaleModal
          isOpen={true}
          saleToEdit={editingSale}
          onClose={() => setEditingSale(null)}
        />
      )}

      {/* 6. DELETE CONFIRMATION DIALOG */}
      {deletingSaleId && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-stone-950/70 backdrop-blur-xs">
          <div className="w-full max-w-md bg-white rounded-3xl p-6 shadow-2xl border border-stone-200 space-y-4">
            <div className="w-12 h-12 rounded-2xl bg-rose-100 text-rose-600 flex items-center justify-center">
              <AlertCircle className="w-6 h-6" />
            </div>

            <div className="space-y-1">
              <h4 className="font-serif text-lg font-bold text-stone-900">Delete Counter Sale Entry?</h4>
              <p className="text-xs text-stone-600">
                Are you sure you want to delete counter sale <span className="font-mono font-bold text-stone-900">{deletingSaleId}</span>? 
                This will remove the sale from the café's daily and overall revenue records.
              </p>
            </div>

            <div className="flex items-center justify-end gap-2.5 pt-2">
              <button
                type="button"
                onClick={() => setDeletingSaleId(null)}
                className="px-4 py-2 rounded-xl border border-stone-300 hover:bg-stone-100 text-stone-700 text-xs font-bold cursor-pointer"
              >
                Cancel
              </button>
              <button
                type="button"
                onClick={confirmDelete}
                className="px-5 py-2 rounded-xl bg-rose-600 hover:bg-rose-500 text-white text-xs font-bold cursor-pointer shadow-xs"
              >
                Yes, Delete Sale
              </button>
            </div>
          </div>
        </div>
      )}

      {/* 7. FULL ITEMIZED RECEIPT PREVIEW MODAL */}
      {viewingReceiptSale && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-stone-950/75 backdrop-blur-xs overflow-y-auto">
          <div className="w-full max-w-md bg-white rounded-3xl shadow-2xl border border-stone-200 overflow-hidden my-6">
            
            {/* Modal Header */}
            <div className="px-5 py-4 bg-stone-900 text-white flex items-center justify-between">
              <div className="flex items-center gap-2">
                <Receipt className="w-4 h-4 text-amber-400" />
                <span className="font-bold text-xs uppercase tracking-wider">Counter Sale Receipt</span>
              </div>
              <button
                onClick={() => setViewingReceiptSale(null)}
                className="p-1 rounded-lg text-stone-400 hover:text-white hover:bg-stone-800"
              >
                <X className="w-4 h-4" />
              </button>
            </div>

            {/* Printable Receipt Card */}
            <div id="counter-sale-printable-receipt" className="p-6 space-y-4 text-stone-800 bg-stone-50/50">
              
              {/* Cafe Branding */}
              <div className="text-center space-y-1 pb-3 border-b border-dashed border-stone-300">
                <h3 className="font-serif text-xl font-black text-stone-950 tracking-tight">
                  {settings.name}
                </h3>
                <p className="text-[11px] text-stone-500 font-medium">
                  {settings.campusName}
                </p>
                <p className="text-[10px] text-stone-400">
                  {settings.address}, {settings.city} • Ph: {settings.phone}
                </p>
                <div className="pt-1">
                  <span className="inline-block px-2.5 py-0.5 rounded-full bg-stone-200 text-stone-800 font-mono text-[10px] font-bold">
                    COUNTER WALK-IN SALE
                  </span>
                </div>
              </div>

              {/* Receipt Metadata */}
              <div className="grid grid-cols-2 gap-2 text-xs py-1 border-b border-dashed border-stone-300">
                <div>
                  <span className="text-[10px] text-stone-400 block">Sale Receipt No.</span>
                  <span className="font-mono font-bold text-stone-900">{viewingReceiptSale.id}</span>
                </div>
                <div className="text-right">
                  <span className="text-[10px] text-stone-400 block">Date & Time</span>
                  <span className="font-mono text-stone-800 text-[11px]">
                    {new Date(viewingReceiptSale.createdAt).toLocaleString('en-IN', {
                      dateStyle: 'medium',
                      timeStyle: 'short'
                    })}
                  </span>
                </div>
                <div>
                  <span className="text-[10px] text-stone-400 block">Customer</span>
                  <span className="font-semibold text-stone-800">
                    {viewingReceiptSale.customerName || 'Walk-in Customer'}
                  </span>
                </div>
                <div className="text-right">
                  <span className="text-[10px] text-stone-400 block">Payment Tender</span>
                  <span className="font-bold text-amber-700 uppercase">
                    {viewingReceiptSale.paymentMethod}
                  </span>
                </div>
              </div>

              {/* Itemized Table */}
              <div className="space-y-2">
                <div className="flex items-center justify-between text-[11px] font-bold text-stone-500 uppercase border-b border-stone-200 pb-1">
                  <span>Item</span>
                  <span>Qty × Price</span>
                  <span className="text-right">Amount</span>
                </div>

                <div className="space-y-1.5 text-xs">
                  {viewingReceiptSale.items.map((item, idx) => (
                    <div key={idx} className="flex items-center justify-between py-1 border-b border-stone-100">
                      <div className="max-w-[180px]">
                        <span className="font-semibold text-stone-900 block">{item.name}</span>
                      </div>
                      <div className="font-mono text-[11px] text-stone-500">
                        {item.quantity} × {settings.currency}{item.price.toFixed(2)}
                      </div>
                      <div className="font-bold text-stone-900 font-serif text-right">
                        {settings.currency}{item.total.toFixed(2)}
                      </div>
                    </div>
                  ))}
                </div>
              </div>

              {/* Total Amount */}
              <div className="pt-2 border-t-2 border-stone-900 space-y-1">
                <div className="flex items-center justify-between text-base font-bold text-stone-950">
                  <span>Total Amount Paid:</span>
                  <span className="text-xl font-serif text-amber-800">
                    {settings.currency}{viewingReceiptSale.totalAmount.toFixed(2)}
                  </span>
                </div>
                <div className="flex items-center justify-between text-[10px] text-stone-500">
                  <span>Payment Tender Method:</span>
                  <span className="font-bold uppercase text-stone-800">{viewingReceiptSale.paymentMethod}</span>
                </div>
              </div>

              {/* Notes if any */}
              {viewingReceiptSale.note && (
                <div className="p-2.5 bg-stone-100 rounded-xl text-xs text-stone-600">
                  <span className="font-bold text-[10px] text-stone-400 uppercase block">Remark</span>
                  <span>{viewingReceiptSale.note}</span>
                </div>
              )}

              {/* Staff Sign-off */}
              <div className="text-center text-[10px] text-stone-400 pt-2 border-t border-dashed border-stone-300">
                <p>Recorded by: {viewingReceiptSale.addedByName || 'Campora Cafe Counter Staff'}</p>
                <p className="mt-0.5">Thank you for visiting Campora Cafe GEC Banka!</p>
              </div>

            </div>

            {/* Modal Actions */}
            <div className="p-4 bg-stone-100 border-t border-stone-200 flex items-center justify-between">
              <button
                type="button"
                onClick={() => {
                  window.print();
                }}
                className="px-4 py-2 rounded-xl bg-stone-900 hover:bg-stone-800 text-white text-xs font-bold flex items-center gap-1.5 cursor-pointer"
              >
                <Printer className="w-3.5 h-3.5" />
                <span>Print Receipt</span>
              </button>

              <button
                type="button"
                onClick={() => setViewingReceiptSale(null)}
                className="px-4 py-2 rounded-xl bg-stone-200 hover:bg-stone-300 text-stone-800 text-xs font-bold cursor-pointer"
              >
                Close
              </button>
            </div>

          </div>
        </div>
      )}

    </div>
  );
};
