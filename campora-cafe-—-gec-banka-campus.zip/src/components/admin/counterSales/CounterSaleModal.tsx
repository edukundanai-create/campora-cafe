import React, { useState, useEffect, useMemo } from 'react';
import {
  X,
  Plus,
  Trash2,
  Receipt,
  Coins,
  QrCode,
  CreditCard,
  Calendar,
  Clock,
  User,
  Phone,
  FileText,
  AlertCircle,
  CheckCircle2,
  Sparkles,
  ShoppingBag
} from 'lucide-react';
import { useCafe } from '../../../context/CafeContext';
import { CounterSale, CounterSaleItem, CounterSalePaymentMethod } from '../../../types';
import { UpiPaymentBox } from '../../payment/UpiPaymentBox';

interface CounterSaleModalProps {
  isOpen: boolean;
  onClose: () => void;
  saleToEdit?: CounterSale | null;
}

export const CounterSaleModal: React.FC<CounterSaleModalProps> = ({
  isOpen,
  onClose,
  saleToEdit
}) => {
  const { menuItems, addCounterSale, updateCounterSale, settings, showToast } = useCafe();

  // Form fields
  const [customerName, setCustomerName] = useState<string>('');
  const [customerPhone, setCustomerPhone] = useState<string>('');
  const [paymentMethod, setPaymentMethod] = useState<CounterSalePaymentMethod>('cash');
  const [note, setNote] = useState<string>('');
  const [items, setItems] = useState<CounterSaleItem[]>([]);
  const [customDateTime, setCustomDateTime] = useState<string>('');
  const [useCustomDateTime, setUseCustomDateTime] = useState<boolean>(false);
  const [isSubmitting, setIsSubmitting] = useState<boolean>(false);

  // New item entry builder
  const [selectedMenuItemId, setSelectedMenuItemId] = useState<string>('');
  const [itemName, setItemName] = useState<string>('');
  const [itemQuantity, setItemQuantity] = useState<number>(1);
  const [itemPrice, setItemPrice] = useState<number | ''>('');
  const [itemSearchQuery, setItemSearchQuery] = useState<string>('');

  // Pre-fill form when editing or resetting
  useEffect(() => {
    if (saleToEdit) {
      setCustomerName(saleToEdit.customerName === 'Walk-in Customer' ? '' : (saleToEdit.customerName || ''));
      setCustomerPhone(saleToEdit.customerPhone || '');
      setPaymentMethod(saleToEdit.paymentMethod);
      setNote(saleToEdit.note || '');
      setItems(saleToEdit.items || []);
      setUseCustomDateTime(true);
      // format to datetime-local (YYYY-MM-DDTHH:mm)
      try {
        const d = new Date(saleToEdit.createdAt);
        const tzOffset = d.getTimezoneOffset() * 60000;
        const localISOTime = new Date(d.getTime() - tzOffset).toISOString().slice(0, 16);
        setCustomDateTime(localISOTime);
      } catch {
        setCustomDateTime('');
      }
    } else {
      setCustomerName('');
      setCustomerPhone('');
      setPaymentMethod('cash');
      setNote('');
      setItems([]);
      setUseCustomDateTime(false);
      setCustomDateTime('');
    }
    // reset item builder
    setSelectedMenuItemId('');
    setItemName('');
    setItemQuantity(1);
    setItemPrice('');
    setItemSearchQuery('');
  }, [saleToEdit, isOpen]);

  // Filtered menu items for quick picker
  const filteredMenuItems = useMemo(() => {
    if (!itemSearchQuery.trim()) return menuItems.slice(0, 12);
    const q = itemSearchQuery.toLowerCase();
    return menuItems.filter(
      (m) => m.name.toLowerCase().includes(q) || m.category.toLowerCase().includes(q)
    );
  }, [menuItems, itemSearchQuery]);

  // Quick popular items for 1-click counter addition
  const popularShortcuts = useMemo(() => {
    return menuItems.slice(0, 6);
  }, [menuItems]);

  // Calculate total amount automatically
  const totalAmount = useMemo(() => {
    return items.reduce((sum, i) => sum + (i.total !== undefined ? i.total : i.price * i.quantity), 0);
  }, [items]);

  // Handle selecting item from menu
  const handleSelectMenuItem = (menuItemId: string) => {
    setSelectedMenuItemId(menuItemId);
    const found = menuItems.find((m) => m.id === menuItemId);
    if (found) {
      setItemName(found.name);
      setItemPrice(found.price);
    }
  };

  // Quick 1-click add from shortcuts
  const handleQuickAddShortcut = (item: typeof menuItems[0]) => {
    const existingIndex = items.findIndex((i) => i.name.toLowerCase() === item.name.toLowerCase());
    if (existingIndex > -1) {
      // increase quantity
      setItems((prev) =>
        prev.map((it, idx) => {
          if (idx === existingIndex) {
            const newQty = it.quantity + 1;
            return {
              ...it,
              quantity: newQty,
              total: newQty * it.price
            };
          }
          return it;
        })
      );
    } else {
      const newItem: CounterSaleItem = {
        id: `item-${Date.now()}-${Math.random().toString(36).slice(2, 5)}`,
        name: item.name,
        quantity: 1,
        price: item.price,
        total: item.price
      };
      setItems((prev) => [...prev, newItem]);
    }
  };

  // Add item from input form
  const handleAddItem = (e?: React.FormEvent) => {
    if (e) e.preventDefault();
    if (!itemName.trim()) {
      showToast('Item Name Required', 'Please enter or select an item name.', 'warning');
      return;
    }
    const priceNum = typeof itemPrice === 'number' ? itemPrice : parseFloat(String(itemPrice));
    if (isNaN(priceNum) || priceNum < 0) {
      showToast('Invalid Price', 'Please enter a valid non-negative price.', 'warning');
      return;
    }
    if (itemQuantity < 1) {
      showToast('Invalid Quantity', 'Quantity must be at least 1.', 'warning');
      return;
    }

    const calculatedTotal = priceNum * itemQuantity;

    // Check if same item exists in current sale
    const existingIndex = items.findIndex((i) => i.name.toLowerCase().trim() === itemName.toLowerCase().trim());
    if (existingIndex > -1) {
      setItems((prev) =>
        prev.map((it, idx) => {
          if (idx === existingIndex) {
            const updatedQty = it.quantity + itemQuantity;
            return {
              ...it,
              quantity: updatedQty,
              price: priceNum,
              total: updatedQty * priceNum
            };
          }
          return it;
        })
      );
    } else {
      const newItem: CounterSaleItem = {
        id: `item-${Date.now()}-${Math.random().toString(36).slice(2, 5)}`,
        name: itemName.trim(),
        quantity: itemQuantity,
        price: priceNum,
        total: calculatedTotal
      };
      setItems((prev) => [...prev, newItem]);
    }

    // Reset item builder inputs for next entry
    setSelectedMenuItemId('');
    setItemName('');
    setItemQuantity(1);
    setItemPrice('');
    setItemSearchQuery('');
  };

  // Stepper controls in line item table
  const handleUpdateItemQuantity = (index: number, newQty: number) => {
    if (newQty <= 0) {
      handleRemoveItem(index);
      return;
    }
    setItems((prev) =>
      prev.map((it, idx) => {
        if (idx === index) {
          return {
            ...it,
            quantity: newQty,
            total: newQty * it.price
          };
        }
        return it;
      })
    );
  };

  const handleRemoveItem = (index: number) => {
    setItems((prev) => prev.filter((_, idx) => idx !== index));
  };

  // Submit sale entry
  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();

    if (items.length === 0) {
      showToast('No Items Added', 'Please add at least one item to this counter sale.', 'warning');
      return;
    }

    setIsSubmitting(true);
    try {
      let customCreatedAt: string | undefined;
      if (useCustomDateTime && customDateTime) {
        customCreatedAt = new Date(customDateTime).toISOString();
      }

      if (saleToEdit) {
        await updateCounterSale(saleToEdit.id, {
          customerName: customerName.trim() || 'Walk-in Customer',
          customerPhone: customerPhone.trim(),
          items,
          totalAmount,
          paymentMethod,
          note: note.trim(),
          ...(customCreatedAt ? { createdAt: customCreatedAt } : {})
        });
      } else {
        await addCounterSale({
          customerName: customerName.trim() || 'Walk-in Customer',
          customerPhone: customerPhone.trim(),
          items,
          paymentMethod,
          note: note.trim(),
          customCreatedAt
        });
      }

      onClose();
    } catch (err) {
      console.error('Save counter sale error:', err);
      showToast('Error', 'Could not save counter sale. Please try again.', 'error');
    } finally {
      setIsSubmitting(false);
    }
  };

  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-3 sm:p-4 overflow-y-auto">
      {/* Backdrop */}
      <div 
        className="fixed inset-0 bg-stone-950/75 backdrop-blur-xs transition-opacity"
        onClick={onClose}
      />

      {/* Modal Container */}
      <div className="relative w-full max-w-2xl bg-white rounded-3xl shadow-2xl border border-stone-200 overflow-hidden z-10 my-6 flex flex-col max-h-[92vh]">
        
        {/* Header */}
        <div className="px-6 py-4.5 bg-linear-to-r from-stone-900 via-stone-850 to-stone-900 text-white flex items-center justify-between border-b border-stone-800 shrink-0">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-2xl bg-amber-500/20 text-amber-400 border border-amber-500/30 flex items-center justify-center font-bold shadow-xs">
              <Receipt className="w-5 h-5" />
            </div>
            <div>
              <h3 className="font-serif text-lg font-bold text-white flex items-center gap-2">
                <span>{saleToEdit ? 'Edit Counter Sale' : 'Counter Sale / Walk-in Entry'}</span>
                <span className="text-[10px] font-mono px-2 py-0.5 rounded-full bg-emerald-950 text-emerald-300 border border-emerald-700/60 font-semibold uppercase">
                  {saleToEdit ? saleToEdit.id : 'Direct POS'}
                </span>
              </h3>
              <p className="text-xs text-stone-400">
                Record manual counter purchases directly into café daily sales records
              </p>
            </div>
          </div>

          <button
            onClick={onClose}
            className="p-2 rounded-xl text-stone-400 hover:text-white hover:bg-stone-800 transition-colors cursor-pointer"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Scrollable Form Content */}
        <form onSubmit={handleSubmit} className="overflow-y-auto flex-1 p-5 sm:p-6 space-y-5">
          
          {/* 1. Customer Information (Optional) */}
          <div className="bg-stone-50/70 p-4 rounded-2xl border border-stone-200/80 space-y-3">
            <div className="flex items-center justify-between">
              <span className="text-xs font-bold text-stone-800 flex items-center gap-1.5 uppercase tracking-wider">
                <User className="w-3.5 h-3.5 text-amber-700" />
                <span>Customer Information</span>
              </span>
              <span className="text-[11px] text-stone-400 font-medium italic">Optional for walk-ins</span>
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
              <div>
                <label className="block text-[11px] font-semibold text-stone-600 mb-1">
                  Customer Name
                </label>
                <div className="relative">
                  <User className="w-4 h-4 text-stone-400 absolute left-3 top-2.5" />
                  <input
                    type="text"
                    value={customerName}
                    onChange={(e) => setCustomerName(e.target.value)}
                    placeholder="e.g., Prof. Verma or Student"
                    className="w-full pl-9 pr-3 py-2 text-xs bg-white rounded-xl border border-stone-300 focus:outline-hidden focus:ring-2 focus:ring-amber-500 text-stone-900 placeholder:text-stone-400"
                  />
                </div>
              </div>

              <div>
                <label className="block text-[11px] font-semibold text-stone-600 mb-1">
                  Customer Mobile Number
                </label>
                <div className="relative">
                  <Phone className="w-4 h-4 text-stone-400 absolute left-3 top-2.5" />
                  <input
                    type="tel"
                    value={customerPhone}
                    onChange={(e) => setCustomerPhone(e.target.value)}
                    placeholder="e.g., +91 98350 12345"
                    className="w-full pl-9 pr-3 py-2 text-xs bg-white rounded-xl border border-stone-300 focus:outline-hidden focus:ring-2 focus:ring-amber-500 text-stone-900 placeholder:text-stone-400"
                  />
                </div>
              </div>
            </div>
          </div>

          {/* 2. Quick 1-Click Menu Item Shortcuts */}
          {popularShortcuts.length > 0 && (
            <div className="space-y-1.5">
              <div className="flex items-center justify-between text-[11px] font-semibold text-stone-500">
                <span className="flex items-center gap-1">
                  <Sparkles className="w-3.5 h-3.5 text-amber-500" />
                  <span>Quick 1-Click Popular Items</span>
                </span>
                <span className="text-[10px] text-stone-400">Tap to add directly</span>
              </div>
              <div className="flex flex-wrap gap-1.5">
                {popularShortcuts.map((shortcut) => (
                  <button
                    key={shortcut.id}
                    type="button"
                    onClick={() => handleQuickAddShortcut(shortcut)}
                    className="px-2.5 py-1.5 bg-stone-100 hover:bg-amber-100 border border-stone-200 hover:border-amber-300 text-stone-800 hover:text-stone-950 rounded-xl text-xs font-semibold flex items-center gap-1.5 transition-all cursor-pointer shadow-2xs active:scale-95"
                  >
                    <Plus className="w-3 h-3 text-amber-600" />
                    <span>{shortcut.name}</span>
                    <span className="text-stone-500 font-normal">({settings.currency}{shortcut.price})</span>
                  </button>
                ))}
              </div>
            </div>
          )}

          {/* 3. Item Entry Builder Form */}
          <div className="p-4 bg-amber-50/40 rounded-2xl border border-amber-200/80 space-y-3">
            <div className="flex items-center justify-between">
              <span className="text-xs font-bold text-stone-900 flex items-center gap-1.5 uppercase tracking-wider">
                <ShoppingBag className="w-3.5 h-3.5 text-amber-700" />
                <span>Add Item to Sale</span>
              </span>
              <span className="text-[11px] text-amber-800 font-medium">Supports multiple items</span>
            </div>

            {/* Selector or custom typing */}
            <div className="grid grid-cols-1 sm:grid-cols-12 gap-2.5">
              
              {/* Item Name / Menu Picker */}
              <div className="sm:col-span-6 space-y-1">
                <label className="block text-[11px] font-semibold text-stone-700">
                  Item / Product Name *
                </label>
                <div className="space-y-1">
                  <input
                    type="text"
                    value={itemName}
                    onChange={(e) => {
                      setItemName(e.target.value);
                      setSelectedMenuItemId('');
                    }}
                    placeholder="Enter item name or select below"
                    className="w-full px-3 py-2 text-xs bg-white rounded-xl border border-stone-300 focus:outline-hidden focus:ring-2 focus:ring-amber-500 text-stone-900 placeholder:text-stone-400"
                  />
                  {/* Menu items dropdown picker */}
                  <select
                    value={selectedMenuItemId}
                    onChange={(e) => handleSelectMenuItem(e.target.value)}
                    className="w-full px-3 py-1.5 text-[11px] bg-white rounded-lg border border-stone-200 text-stone-700 focus:outline-hidden focus:ring-1 focus:ring-amber-500"
                  >
                    <option value="">-- Quick Select from Cafe Menu --</option>
                    {filteredMenuItems.map((m) => (
                      <option key={m.id} value={m.id}>
                        {m.name} — {settings.currency}{m.price} ({m.category})
                      </option>
                    ))}
                  </select>
                </div>
              </div>

              {/* Quantity */}
              <div className="sm:col-span-3 space-y-1">
                <label className="block text-[11px] font-semibold text-stone-700">
                  Quantity *
                </label>
                <div className="flex items-center bg-white rounded-xl border border-stone-300 overflow-hidden">
                  <button
                    type="button"
                    onClick={() => setItemQuantity(Math.max(1, itemQuantity - 1))}
                    className="px-2.5 py-2 text-stone-600 hover:bg-stone-100 font-bold text-sm cursor-pointer"
                  >
                    -
                  </button>
                  <input
                    type="number"
                    min="1"
                    value={itemQuantity}
                    onChange={(e) => setItemQuantity(Math.max(1, parseInt(e.target.value) || 1))}
                    className="w-full text-center py-2 text-xs font-bold text-stone-900 focus:outline-hidden"
                  />
                  <button
                    type="button"
                    onClick={() => setItemQuantity(itemQuantity + 1)}
                    className="px-2.5 py-2 text-stone-600 hover:bg-stone-100 font-bold text-sm cursor-pointer"
                  >
                    +
                  </button>
                </div>
              </div>

              {/* Price */}
              <div className="sm:col-span-3 space-y-1">
                <label className="block text-[11px] font-semibold text-stone-700">
                  Item Price ({settings.currency}) *
                </label>
                <input
                  type="number"
                  min="0"
                  step="any"
                  value={itemPrice}
                  onChange={(e) => setItemPrice(e.target.value === '' ? '' : parseFloat(e.target.value))}
                  placeholder="Price"
                  className="w-full px-3 py-2 text-xs bg-white rounded-xl border border-stone-300 focus:outline-hidden focus:ring-2 focus:ring-amber-500 text-stone-900 placeholder:text-stone-400 font-semibold"
                />
              </div>

            </div>

            {/* Calculated line item preview & Add Button */}
            <div className="flex items-center justify-between pt-1 border-t border-amber-200/50">
              <div className="text-xs text-amber-900 font-medium">
                {itemName.trim() && itemPrice !== '' ? (
                  <span>
                    Calculation: <span className="font-bold">{itemName}</span> × {itemQuantity} = <span className="font-bold font-serif">{settings.currency}{((Number(itemPrice) || 0) * itemQuantity).toFixed(2)}</span>
                  </span>
                ) : (
                  <span className="text-stone-400">Fill item name & price to calculate line total</span>
                )}
              </div>

              <button
                type="button"
                onClick={() => handleAddItem()}
                className="px-4 py-1.5 bg-amber-600 hover:bg-amber-500 text-stone-950 font-bold text-xs rounded-xl flex items-center gap-1.5 cursor-pointer shadow-xs transition-all active:scale-95"
              >
                <Plus className="w-4 h-4" />
                <span>Add Item</span>
              </button>
            </div>
          </div>

          {/* 4. Added Items Table (Multiple items display with calculations) */}
          <div className="space-y-2">
            <div className="flex items-center justify-between">
              <span className="text-xs font-bold text-stone-800 uppercase tracking-wider">
                Sale Items Breakdown ({items.length})
              </span>
              {items.length > 0 && (
                <button
                  type="button"
                  onClick={() => setItems([])}
                  className="text-[11px] text-rose-600 hover:text-rose-700 font-semibold cursor-pointer"
                >
                  Clear All
                </button>
              )}
            </div>

            {items.length === 0 ? (
              <div className="p-6 text-center rounded-2xl border-2 border-dashed border-stone-200 text-stone-400 text-xs">
                <ShoppingBag className="w-6 h-6 mx-auto mb-1.5 opacity-40" />
                <p>No items added yet. Add items above or tap popular item chips.</p>
              </div>
            ) : (
              <div className="rounded-2xl border border-stone-200 overflow-hidden bg-white shadow-2xs">
                <table className="w-full text-left text-xs">
                  <thead className="bg-stone-50 border-b border-stone-200 text-stone-500 font-semibold text-[11px]">
                    <tr>
                      <th className="py-2.5 px-3">Item / Product</th>
                      <th className="py-2.5 px-3 text-center">Qty</th>
                      <th className="py-2.5 px-3 text-right">Price</th>
                      <th className="py-2.5 px-3 text-right">Total</th>
                      <th className="py-2.5 px-2 text-center w-10"></th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-stone-100">
                    {items.map((item, idx) => (
                      <tr key={item.id || idx} className="hover:bg-stone-50/60">
                        <td className="py-2.5 px-3">
                          <span className="font-semibold text-stone-900 block">{item.name}</span>
                          <span className="text-[10px] text-stone-400">
                            {item.name} × {item.quantity} = {settings.currency}{item.total.toFixed(2)}
                          </span>
                        </td>
                        <td className="py-2.5 px-3 text-center">
                          <div className="inline-flex items-center gap-1 bg-stone-100 rounded-lg p-0.5">
                            <button
                              type="button"
                              onClick={() => handleUpdateItemQuantity(idx, item.quantity - 1)}
                              className="w-5 h-5 flex items-center justify-center text-stone-600 hover:bg-white rounded-md font-bold cursor-pointer"
                            >
                              -
                            </button>
                            <span className="w-6 text-center font-bold text-stone-900">
                              {item.quantity}
                            </span>
                            <button
                              type="button"
                              onClick={() => handleUpdateItemQuantity(idx, item.quantity + 1)}
                              className="w-5 h-5 flex items-center justify-center text-stone-600 hover:bg-white rounded-md font-bold cursor-pointer"
                            >
                              +
                            </button>
                          </div>
                        </td>
                        <td className="py-2.5 px-3 text-right font-medium text-stone-700">
                          {settings.currency}{item.price.toFixed(2)}
                        </td>
                        <td className="py-2.5 px-3 text-right font-bold text-stone-900 font-serif">
                          {settings.currency}{item.total.toFixed(2)}
                        </td>
                        <td className="py-2.5 px-2 text-center">
                          <button
                            type="button"
                            onClick={() => handleRemoveItem(idx)}
                            className="p-1 rounded-md text-stone-400 hover:text-rose-600 hover:bg-rose-50 transition-colors cursor-pointer"
                            title="Remove item"
                          >
                            <Trash2 className="w-3.5 h-3.5" />
                          </button>
                        </td>
                      </tr>
                    ))}
                  </tbody>
                  {/* Total calculation bar */}
                  <tfoot className="bg-amber-50/50 border-t border-stone-200 font-bold">
                    <tr>
                      <td colSpan={3} className="py-3 px-3 text-stone-900 text-right">
                        Total Amount:
                      </td>
                      <td className="py-3 px-3 text-right text-base text-amber-700 font-serif">
                        {settings.currency}{totalAmount.toFixed(2)}
                      </td>
                      <td></td>
                    </tr>
                  </tfoot>
                </table>
              </div>
            )}
          </div>

          {/* 5. Payment Method Selector */}
          <div className="space-y-2">
            <label className="block text-xs font-bold text-stone-800 uppercase tracking-wider">
              Payment Method *
            </label>
            <div className="grid grid-cols-3 gap-2.5">
              {[
                { id: 'cash' as const, label: 'Cash', icon: Coins, desc: 'Cash at counter' },
                { id: 'upi' as const, label: 'UPI / QR', icon: QrCode, desc: 'PhonePe / GPay' },
                { id: 'other' as const, label: 'Other', icon: CreditCard, desc: 'Card / NetBanking' }
              ].map((method) => {
                const Icon = method.icon;
                const isSelected = paymentMethod === method.id;
                return (
                  <button
                    key={method.id}
                    type="button"
                    onClick={() => setPaymentMethod(method.id)}
                    className={`p-3 rounded-2xl border text-left transition-all cursor-pointer flex flex-col items-center sm:items-start text-center sm:text-left ${
                      isSelected
                        ? 'bg-amber-500 text-stone-950 border-amber-500 shadow-xs font-bold'
                        : 'bg-white text-stone-700 border-stone-200 hover:border-amber-300'
                    }`}
                  >
                    <div className="flex items-center gap-2">
                      <Icon className={`w-4 h-4 ${isSelected ? 'text-stone-950' : 'text-amber-700'}`} />
                      <span className="text-xs font-bold">{method.label}</span>
                    </div>
                    <span className={`text-[10px] mt-0.5 hidden sm:block ${isSelected ? 'text-stone-900' : 'text-stone-400'}`}>
                      {method.desc}
                    </span>
                  </button>
                );
              })}
            </div>

            {/* When UPI is selected: show Campora Café UPI QR Code & UPI ID so customer can scan & pay */}
            {paymentMethod === 'upi' && (
              <div className="pt-2 animate-in fade-in duration-200">
                <UpiPaymentBox
                  upiId={settings.upiId || '8210794268-4@ybl'}
                  payeeName={settings.name || 'Campora Café'}
                  amount={totalAmount}
                  note="Campora Cafe Counter Walk-in"
                  title="Campora Café Counter QR"
                  subtitle="Scan & Pay with Google Pay, PhonePe, Paytm, BHIM at the counter"
                  variant="counter"
                  size={140}
                  showPayButton={false}
                />
              </div>
            )}
          </div>

          {/* 6. Date and Time (Automatically recorded + optional override) */}
          <div className="p-3 bg-stone-50 rounded-2xl border border-stone-200/80 space-y-2">
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-1.5 text-xs font-bold text-stone-700">
                <Clock className="w-3.5 h-3.5 text-stone-500" />
                <span>Date and Time</span>
              </div>
              <button
                type="button"
                onClick={() => setUseCustomDateTime(!useCustomDateTime)}
                className="text-[11px] text-amber-700 hover:text-amber-800 font-semibold cursor-pointer"
              >
                {useCustomDateTime ? 'Use Current Time' : 'Adjust Date/Time'}
              </button>
            </div>

            {useCustomDateTime ? (
              <input
                type="datetime-local"
                value={customDateTime}
                onChange={(e) => setCustomDateTime(e.target.value)}
                className="w-full px-3 py-1.5 text-xs bg-white rounded-xl border border-stone-300 text-stone-800 focus:outline-hidden focus:ring-2 focus:ring-amber-500"
              />
            ) : (
              <div className="text-xs text-stone-600 font-mono bg-white px-3 py-2 rounded-xl border border-stone-200 flex items-center justify-between">
                <span>{new Date().toLocaleString('en-IN', { dateStyle: 'medium', timeStyle: 'short' })}</span>
                <span className="text-[10px] text-emerald-600 font-bold uppercase tracking-wider">
                  Automatically Recorded
                </span>
              </div>
            )}
          </div>

          {/* 7. Note / Remark (Optional) */}
          <div>
            <label className="block text-[11px] font-semibold text-stone-600 mb-1">
              Note / Remark (Optional)
            </label>
            <div className="relative">
              <FileText className="w-4 h-4 text-stone-400 absolute left-3 top-2.5" />
              <input
                type="text"
                value={note}
                onChange={(e) => setNote(e.target.value)}
                placeholder="e.g., Soundbox confirmed, Faculty tea break, etc."
                className="w-full pl-9 pr-3 py-2 text-xs bg-white rounded-xl border border-stone-300 focus:outline-hidden focus:ring-2 focus:ring-amber-500 text-stone-900 placeholder:text-stone-400"
              />
            </div>
          </div>

        </form>

        {/* Footer Summary & Action Buttons */}
        <div className="px-6 py-4 bg-stone-50 border-t border-stone-200 flex flex-col sm:flex-row items-center justify-between gap-3 shrink-0">
          <div>
            <span className="text-xs text-stone-500 font-medium">Total Payable:</span>
            <div className="text-2xl font-bold font-serif text-stone-950">
              {settings.currency}{totalAmount.toFixed(2)}
            </div>
            <span className="text-[10px] text-stone-400 block">
              Payment via <span className="font-bold uppercase text-stone-700">{paymentMethod}</span>
            </span>
          </div>

          <div className="flex items-center gap-2.5 w-full sm:w-auto">
            <button
              type="button"
              onClick={onClose}
              className="flex-1 sm:flex-none px-4 py-2.5 rounded-xl border border-stone-300 hover:bg-stone-200 text-stone-700 text-xs font-bold transition-all cursor-pointer"
            >
              Cancel
            </button>
            <button
              type="button"
              onClick={handleSubmit}
              disabled={isSubmitting || items.length === 0}
              className="flex-1 sm:flex-none px-6 py-2.5 rounded-xl bg-amber-500 hover:bg-amber-400 text-stone-950 text-xs font-extrabold shadow-sm transition-all disabled:opacity-50 disabled:cursor-not-allowed flex items-center justify-center gap-1.5 cursor-pointer"
            >
              {isSubmitting ? (
                <span>Saving...</span>
              ) : (
                <>
                  <CheckCircle2 className="w-4 h-4" />
                  <span>{saleToEdit ? 'Update Sale' : 'Add Sale / Save Entry'}</span>
                </>
              )}
            </button>
          </div>
        </div>

      </div>
    </div>
  );
};
