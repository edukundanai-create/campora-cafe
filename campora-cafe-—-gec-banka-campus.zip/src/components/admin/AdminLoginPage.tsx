import React, { useState } from 'react';
import { useCafe } from '../../context/CafeContext';
import {
  ShieldCheck,
  Lock,
  Mail,
  Eye,
  EyeOff,
  LogIn,
  Sparkles,
  ArrowLeft,
  AlertCircle,
  CheckCircle2
} from 'lucide-react';
import { motion } from 'motion/react';

export const AdminLoginPage: React.FC = () => {
  const {
    loginAdminWithEmail,
    loginAdminWithGoogle,
    resetPassword,
    setIsAdminMode,
    settings
  } = useCafe();

  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [showPassword, setShowPassword] = useState(false);
  const [isLoading, setIsLoading] = useState(false);
  const [isResetting, setIsResetting] = useState(false);
  const [resetSuccessMessage, setResetSuccessMessage] = useState<string | null>(null);
  const [errorMessage, setErrorMessage] = useState<string | null>(null);

  const getFriendlyAuthErrorMessage = (err: any): string => {
    if (err?.message?.includes('Access Denied')) {
      return err.message;
    }
    const code = err?.code || '';
    switch (code) {
      case 'auth/invalid-credential':
        return 'Invalid admin email or password. Customer accounts cannot log in to this portal.';
      case 'auth/user-not-found':
        return 'No administrator account found with this email. Customer accounts cannot access the Admin Panel.';
      case 'auth/wrong-password':
        return 'Incorrect password entered. Please check your credentials or reset your admin password.';
      case 'auth/invalid-email':
        return 'Please enter a valid administrator email address format.';
      case 'auth/user-disabled':
        return 'This administrative account has been deactivated. Please contact the café owner.';
      case 'auth/too-many-requests':
        return 'Access is temporarily restricted due to repeated unsuccessful attempts. Please wait a few moments.';
      case 'auth/network-request-failed':
        return 'Network connection issue. Please check your internet connectivity and try again.';
      default:
        return err?.message || 'Authentication failed. Please verify your administrator credentials.';
    }
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setErrorMessage(null);
    setResetSuccessMessage(null);

    if (!email.trim()) {
      setErrorMessage('Please enter your authorized admin email address.');
      return;
    }

    if (!password) {
      setErrorMessage('Please enter your password.');
      return;
    }

    setIsLoading(true);
    try {
      await loginAdminWithEmail(email.trim(), password);
    } catch (err: any) {
      setErrorMessage(getFriendlyAuthErrorMessage(err));
    } finally {
      setIsLoading(false);
    }
  };

  const handleForgotPassword = async () => {
    setErrorMessage(null);
    setResetSuccessMessage(null);
    if (!email.trim()) {
      setErrorMessage('Please enter your administrator email above to receive password reset instructions.');
      return;
    }

    setIsResetting(true);
    try {
      await resetPassword(email.trim());
      setResetSuccessMessage(`Password reset link has been dispatched to ${email.trim()}. Please inspect your inbox and spam folders.`);
    } catch (err: any) {
      setErrorMessage(getFriendlyAuthErrorMessage(err));
    } finally {
      setIsResetting(false);
    }
  };

  const handleQuickDemoAdmin = async () => {
    setIsLoading(true);
    setErrorMessage(null);
    setResetSuccessMessage(null);
    const demoEmail = 'admin@camporacafe.gecbanka.ac.in';
    const demoPass = 'BankaGecCafe2026!';
    setEmail(demoEmail);
    setPassword(demoPass);

    try {
      await loginAdminWithEmail(demoEmail, demoPass);
    } catch (loginErr: any) {
      setErrorMessage(getFriendlyAuthErrorMessage(loginErr));
    } finally {
      setIsLoading(false);
    }
  };

  const handleGoogleAdminLogin = async () => {
    setIsLoading(true);
    setErrorMessage(null);
    setResetSuccessMessage(null);
    try {
      await loginAdminWithGoogle();
    } catch (err: any) {
      setErrorMessage(getFriendlyAuthErrorMessage(err));
    } finally {
      setIsLoading(false);
    }
  };

  return (
    <div className="min-h-screen bg-stone-950 text-stone-100 flex flex-col justify-center items-center px-4 py-10 relative overflow-hidden selection:bg-amber-500 selection:text-stone-950">
      {/* Ambient background accents */}
      <div className="absolute top-1/4 left-1/2 -translate-x-1/2 -translate-y-1/2 w-96 h-96 bg-amber-600/10 rounded-full blur-3xl pointer-events-none" />
      <div className="absolute bottom-10 right-10 w-72 h-72 bg-amber-800/10 rounded-full blur-2xl pointer-events-none" />

      {/* Top back navigation */}
      <div className="w-full max-w-md mb-6 flex items-center justify-between">
        <button
          onClick={() => setIsAdminMode(false)}
          className="flex items-center gap-2 text-xs font-semibold text-stone-400 hover:text-stone-100 transition-colors py-1.5 px-3 rounded-xl bg-stone-900 border border-stone-800 cursor-pointer"
        >
          <ArrowLeft className="w-4 h-4" />
          <span>Back to Customer View</span>
        </button>

        <span className="text-[11px] font-mono text-amber-400/80 bg-amber-950/60 px-2.5 py-1 rounded-full border border-amber-800/50">
          Admin Portal
        </span>
      </div>

      {/* Main Login Card */}
      <motion.div
        initial={{ opacity: 0, y: 20, scale: 0.98 }}
        animate={{ opacity: 1, y: 0, scale: 1 }}
        transition={{ duration: 0.25 }}
        className="w-full max-w-md bg-stone-900/90 border border-stone-800 rounded-3xl p-6 sm:p-8 shadow-2xl backdrop-blur-xl relative z-10"
      >
        {/* Header Branding */}
        <div className="text-center space-y-2 mb-6">
          <div className="mx-auto w-14 h-14 rounded-2xl bg-amber-500 text-stone-950 flex items-center justify-center shadow-lg shadow-amber-500/20 mb-3">
            <ShieldCheck className="w-7 h-7" />
          </div>
          <div className="inline-block px-2.5 py-0.5 rounded-full text-[10px] font-mono font-bold uppercase tracking-wider bg-stone-800 text-amber-300 border border-stone-700">
            Administrative Access
          </div>
          <h1 className="font-serif text-2xl sm:text-3xl font-bold text-stone-100">
            {settings.name}
          </h1>
          <p className="text-xs text-stone-400">
            Government Engineering College (GEC) Banka
          </p>
        </div>

        {/* Password Reset Confirmation Notification */}
        {resetSuccessMessage && (
          <div className="mb-5 p-3.5 rounded-2xl bg-emerald-950/80 border border-emerald-800 text-emerald-200 text-xs flex items-start gap-2.5">
            <CheckCircle2 className="w-4 h-4 text-emerald-400 shrink-0 mt-0.5" />
            <p className="flex-1 text-[11px] leading-relaxed">{resetSuccessMessage}</p>
          </div>
        )}

        {/* Error Notification */}
        {errorMessage && (
          <div className="mb-5 p-3.5 rounded-2xl bg-rose-950/80 border border-rose-800 text-rose-200 text-xs flex items-start gap-2.5">
            <AlertCircle className="w-4 h-4 text-rose-400 shrink-0 mt-0.5" />
            <p className="flex-1 text-[11px] leading-relaxed">{errorMessage}</p>
          </div>
        )}

        {/* Form Fields */}
        <form onSubmit={handleSubmit} className="space-y-4">
          <div className="space-y-1.5">
            <label className="text-xs font-semibold text-stone-300 flex items-center gap-1.5">
              <Mail className="w-3.5 h-3.5 text-amber-400" />
              <span>Admin / Campus Email</span>
            </label>
            <input
              type="email"
              required
              value={email}
              onChange={(e) => setEmail(e.target.value)}
              placeholder="e.g. admin@camporacafe.gecbanka.ac.in"
              className="w-full bg-stone-950 border border-stone-700 text-stone-100 placeholder-stone-600 rounded-xl px-3.5 py-2.5 text-xs focus:outline-none focus:ring-2 focus:ring-amber-500/50 focus:border-amber-500 transition-colors"
            />
          </div>

          <div className="space-y-1.5">
            <div className="flex items-center justify-between">
              <label className="text-xs font-semibold text-stone-300 flex items-center gap-1.5">
                <Lock className="w-3.5 h-3.5 text-amber-400" />
                <span>Password</span>
              </label>
              <button
                type="button"
                onClick={handleForgotPassword}
                disabled={isResetting || isLoading}
                className="text-[11px] text-amber-400/90 hover:text-amber-300 transition-colors cursor-pointer disabled:opacity-50"
              >
                {isResetting ? 'Sending link...' : 'Forgot password?'}
              </button>
            </div>
            <div className="relative">
              <input
                type={showPassword ? 'text' : 'password'}
                required
                value={password}
                onChange={(e) => setPassword(e.target.value)}
                placeholder="••••••••"
                className="w-full bg-stone-950 border border-stone-700 text-stone-100 placeholder-stone-600 rounded-xl pl-3.5 pr-10 py-2.5 text-xs focus:outline-none focus:ring-2 focus:ring-amber-500/50 focus:border-amber-500 transition-colors"
              />
              <button
                type="button"
                onClick={() => setShowPassword(!showPassword)}
                className="absolute right-3 top-1/2 -translate-y-1/2 text-stone-500 hover:text-stone-300 cursor-pointer"
              >
                {showPassword ? <EyeOff className="w-4 h-4" /> : <Eye className="w-4 h-4" />}
              </button>
            </div>
          </div>

          {/* Primary Sign-In Action Button */}
          <button
            type="submit"
            disabled={isLoading}
            className="w-full py-3 bg-gradient-to-r from-amber-500 to-amber-600 hover:from-amber-400 hover:to-amber-500 text-stone-950 font-bold text-xs rounded-xl shadow-lg shadow-amber-500/25 transition-all flex items-center justify-center gap-2 disabled:opacity-50 active:scale-[0.99] cursor-pointer"
          >
            {isLoading ? (
              <div className="w-4 h-4 border-2 border-stone-950 border-t-transparent rounded-full animate-spin" />
            ) : (
              <>
                <LogIn className="w-4 h-4" />
                <span>Sign In to Admin Dashboard</span>
              </>
            )}
          </button>
        </form>

        {/* Divider */}
        <div className="my-5 flex items-center gap-3">
          <div className="flex-1 h-px bg-stone-800" />
          <span className="text-[10px] font-mono uppercase text-stone-500">Authorized Single Sign-On</span>
          <div className="flex-1 h-px bg-stone-800" />
        </div>

        {/* Google OAuth & Quick Demo Buttons */}
        <div className="space-y-2.5">
          {/* Google Sign In */}
          <button
            type="button"
            onClick={handleGoogleAdminLogin}
            disabled={isLoading}
            className="w-full py-2.5 bg-stone-950 hover:bg-stone-800 border border-stone-700 text-stone-200 font-semibold text-xs rounded-xl transition-colors flex items-center justify-center gap-2.5 disabled:opacity-50 cursor-pointer"
          >
            <svg className="w-4 h-4" viewBox="0 0 24 24">
              <path
                fill="#4285F4"
                d="M22.56 12.25c0-.78-.07-1.53-.2-2.25H12v4.26h5.92c-.26 1.37-1.04 2.53-2.21 3.31v2.77h3.57c2.08-1.92 3.28-4.74 3.28-8.09z"
              />
              <path
                fill="#34A853"
                d="M12 23c2.97 0 5.46-.98 7.28-2.66l-3.57-2.77c-.98.66-2.23 1.06-3.71 1.06-2.86 0-5.29-1.93-6.16-4.53H2.18v2.84C3.99 20.53 7.7 23 12 23z"
              />
              <path
                fill="#FBBC05"
                d="M5.84 14.09c-.22-.66-.35-1.36-.35-2.09s.13-1.43.35-2.09V7.06H2.18C1.43 8.55 1 10.22 1 12s.43 3.45 1.18 4.94l2.85-2.22.81-.63z"
              />
              <path
                fill="#EA4335"
                d="M12 5.38c1.62 0 3.06.56 4.21 1.64l3.15-3.15C17.45 2.09 14.97 1 12 1 7.7 1 3.99 3.47 2.18 7.06l3.66 2.84c.87-2.6 3.3-4.52 6.16-4.52z"
              />
            </svg>
            <span>Continue with Google Account</span>
          </button>

          {/* Quick Demo Credentials Autofill & Login */}
          <div className="space-y-1.5">
            <button
              type="button"
              onClick={handleQuickDemoAdmin}
              disabled={isLoading}
              className="w-full py-2.5 bg-amber-950/40 hover:bg-amber-900/50 border border-amber-700/60 text-amber-200 font-semibold text-xs rounded-xl transition-all flex items-center justify-center gap-2 group cursor-pointer"
            >
              <Sparkles className="w-3.5 h-3.5 text-amber-400 group-hover:rotate-12 transition-transform" />
              <span>1-Click Quick Demo Admin Sign In</span>
            </button>
            <div className="flex items-center justify-between px-1.5 text-[10px] text-stone-500 font-mono">
              <span className="truncate">admin@camporacafe.gecbanka.ac.in</span>
              <span className="shrink-0 ml-2">BankaGecCafe2026!</span>
            </div>
          </div>
        </div>

        {/* Security / System Footer Note */}
        <div className="mt-6 pt-4 border-t border-stone-800/80 text-center">
          <p className="text-[10px] text-stone-500 leading-relaxed">
            Protected administrative portal. For credential recovery or new staff onboarding, contact the Lead Master Administrator.
          </p>
        </div>
      </motion.div>
    </div>
  );
};
