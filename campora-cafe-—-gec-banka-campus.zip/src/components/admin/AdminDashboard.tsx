import React, { useState, useMemo } from 'react';
import { useCafe, MASTER_ADMIN_UID, isSystemAdminEmail } from '../../context/CafeContext';
import { formatBookingTimeElapsed } from '../../utils/session';
import { OrderReceiptModal } from '../customer/OrderReceiptModal';
import {
  BookingOrder,
  OrderStatus,
  TableStatus,
  MenuItem,
  PromoCode,
  TableZone,
  UserRole
} from '../../types';
import {
  ShieldCheck,
  ClipboardList,
  LayoutGrid,
  UtensilsCrossed,
  Users,
  TrendingUp,
  Settings,
  Plus,
  Search,
  Filter,
  CheckCircle2,
  Clock,
  Coffee,
  CalendarCheck,
  ShoppingBag,
  Truck,
  Edit2,
  Trash2,
  Download,
  Printer,
  Sparkles,
  DollarSign,
  UserCheck,
  Tag,
  AlertTriangle,
  AlertCircle,
  X,
  Volume2,
  VolumeX,
  Save,
  Flame,
  ChevronRight,
  LogOut,
  User as UserIcon,
  Smartphone,
  PhoneCall,
  Ban,
  Crown,
  Key,
  ShieldAlert,
  Receipt,
  FileText,
  MessageCircle,
  RotateCcw,
  Calendar,
  Check,
  CheckCheck,
  Eye,
  Coins,
  QrCode,
  Copy
} from 'lucide-react';
import { CounterSaleModal } from './counterSales/CounterSaleModal';
import { CounterSalesHistory } from './counterSales/CounterSalesHistory';
import { StaffManagementSection } from './staff/StaffManagementSection';
import { UpiPaymentBox } from '../payment/UpiPaymentBox';
import {
  BarChart,
  Bar,
  XAxis,
  YAxis,
  Tooltip,
  ResponsiveContainer,
  PieChart,
  Pie,
  Cell,
  CartesianGrid
} from 'recharts';

type AdminTab = 'orders' | 'counter-sales' | 'tables' | 'menu' | 'crm' | 'staff' | 'analytics' | 'settings';

export const AdminDashboard: React.FC = () => {
  const {
    orders,
    activeOrders,
    orderHistory,
    hasMoreOrders,
    isLoadingMoreOrders,
    loadMoreOrders,
    updateOrderStatus,
    cancelOrder,
    tables,
    updateTableStatus,
    addTable,
    deleteTable,
    menuItems,
    addMenuItem,
    updateMenuItem,
    deleteMenuItem,
    toggleItemAvailability,
    updateItemStock,
    customers,
    promoCodes,
    addPromoCode,
    togglePromoCode,
    counterSales,
    salesSummary,
    staffMembers,
    staffAuditLogs,
    currentStaff,
    hasPermission,
    addStaffMember,
    updateStaffMember,
    toggleStaffStatus,
    deleteStaffMemberPermanently,
    recordStaffAuditLog,
    loginStaffQuickDemo,
    settings,
    updateSettings,
    isCafeOpenNow,
    toggleCafeOpenStatus,
    isUpdatingStatus,
    setIsAdminMode,
    currentUser,
    currentUserProfile,
    adminUser,
    adminProfile,
    userRole,
    isAdminUser,
    allUsers,
    assignUserRole,
    logout,
    logoutAdmin,
    showToast
  } = useCafe();

  const [activeTab, setActiveTab] = useState<AdminTab>('orders');
  const [isCounterSaleModalOpen, setIsCounterSaleModalOpen] = useState(false);
  const [orderViewMode, setOrderViewMode] = useState<'active' | 'history'>('active');
  const [orderFilter, setOrderFilter] = useState<'all' | 'dine-in' | 'takeout' | 'delivery'>('all');
  const [orderSearch, setOrderSearch] = useState('');
  const [historyStatusFilter, setHistoryStatusFilter] = useState<'all' | 'completed' | 'cancelled'>('all');
  const [historyDateFilter, setHistoryDateFilter] = useState<'all' | 'today' | 'yesterday' | '7days' | 'month'>('all');
  const [soundAlerts, setSoundAlerts] = useState(true);

  // UPI Payment Configuration State (Owner / Admin)
  const [paymentUpiId, setPaymentUpiId] = useState(settings.upiId || '8210794268-4@ybl');
  const [paymentUpiName, setPaymentUpiName] = useState(settings.upiName || 'Campora Café');
  const [isSavingPaymentSettings, setIsSavingPaymentSettings] = useState(false);
  const [testQrAmount, setTestQrAmount] = useState<number>(120);

  // Synchronize local edit fields when global settings change
  React.useEffect(() => {
    if (settings.upiId) {
      setPaymentUpiId(settings.upiId);
    }
    if (settings.upiName) {
      setPaymentUpiName(settings.upiName);
    }
  }, [settings.upiId, settings.upiName]);

  // Receipt, Cancellation & Detailed View Modals
  const [selectedReceiptOrder, setSelectedReceiptOrder] = useState<BookingOrder | null>(null);
  const [selectedDetailOrder, setSelectedDetailOrder] = useState<BookingOrder | null>(null);
  const [cancelModalOrder, setCancelModalOrder] = useState<BookingOrder | null>(null);
  const [cancelReasonInput, setCancelReasonInput] = useState('Customer requested within 10-minute cancellation grace window');
  const [isSubmittingCancel, setIsSubmittingCancel] = useState(false);

  // New Table Modal
  const [isAddTableOpen, setIsAddTableOpen] = useState(false);
  const [newTableNumber, setNewTableNumber] = useState('');
  const [newTableName, setNewTableName] = useState('');
  const [newTableCapacity, setNewTableCapacity] = useState(4);
  const [newTableZone, setNewTableZone] = useState<TableZone>('indoor');

  // New Menu Item Modal
  const [isAddMenuOpen, setIsAddMenuOpen] = useState(false);
  const [editingItem, setEditingItem] = useState<MenuItem | null>(null);
  const [menuForm, setMenuForm] = useState({
    name: '',
    tagline: '',
    category: 'beverages' as MenuItem['category'],
    subcategory: '',
    description: '',
    price: 6.50,
    stockCount: 20,
    image: 'https://images.unsplash.com/photo-1514432324607-a09d9b4aefdd?w=800&auto=format&fit=crop&q=80',
    dietaryTags: ['veg'] as any[],
    ingredients: 'Coffee, Milk, Sugar',
    allergenWarnings: 'None',
    calories: 120,
    preparationTimeMinutes: 5,
  });

  // New Promo Code Modal
  const [isAddPromoOpen, setIsAddPromoOpen] = useState(false);
  const [newPromoCode, setNewPromoCode] = useState('');
  const [newPromoValue, setNewPromoValue] = useState(15);
  const [newPromoType, setNewPromoType] = useState<'percentage' | 'fixed'>('percentage');
  const [newPromoMin, setNewPromoMin] = useState(10);
  const [newPromoDesc, setNewPromoDesc] = useState('');

  // Filtered Active Orders (Kitchen & Dispatch)
  const filteredActiveOrders = useMemo(() => {
    return activeOrders.filter((o) => {
      if (orderFilter !== 'all' && o.bookingMode !== orderFilter) return false;
      if (orderSearch.trim()) {
        const query = orderSearch.toLowerCase();
        return (
          o.id.toLowerCase().includes(query) ||
          o.customer.name.toLowerCase().includes(query) ||
          o.customer.phone.includes(query) ||
          o.items.some((i) => i.name.toLowerCase().includes(query))
        );
      }
      return true;
    });
  }, [activeOrders, orderFilter, orderSearch]);

  // Filtered History Orders (Permanent Archive)
  const filteredHistoryOrders = useMemo(() => {
    return orderHistory.filter((o) => {
      if (historyStatusFilter !== 'all' && o.status !== historyStatusFilter) return false;
      if (orderFilter !== 'all' && o.bookingMode !== orderFilter) return false;

      // Date filtering
      if (historyDateFilter !== 'all') {
        const orderTime = new Date(o.createdAt).getTime();
        const now = new Date();
        const startOfToday = new Date(now.getFullYear(), now.getMonth(), now.getDate()).getTime();
        const startOfYesterday = startOfToday - 24 * 60 * 60 * 1000;
        const sevenDaysAgo = Date.now() - 7 * 24 * 60 * 60 * 1000;
        const thirtyDaysAgo = Date.now() - 30 * 24 * 60 * 60 * 1000;

        if (historyDateFilter === 'today' && orderTime < startOfToday) return false;
        if (historyDateFilter === 'yesterday' && (orderTime < startOfYesterday || orderTime >= startOfToday)) return false;
        if (historyDateFilter === '7days' && orderTime < sevenDaysAgo) return false;
        if (historyDateFilter === 'month' && orderTime < thirtyDaysAgo) return false;
      }

      if (orderSearch.trim()) {
        const query = orderSearch.toLowerCase();
        return (
          o.id.toLowerCase().includes(query) ||
          o.customer.name.toLowerCase().includes(query) ||
          o.customer.phone.includes(query) ||
          o.items.some((i) => i.name.toLowerCase().includes(query))
        );
      }
      return true;
    });
  }, [orderHistory, historyStatusFilter, historyDateFilter, orderFilter, orderSearch]);

  // History Summary KPI Stats
  const historyStats = useMemo(() => {
    const totalCount = filteredHistoryOrders.length;
    const completedList = filteredHistoryOrders.filter((o) => o.status === 'completed');
    const cancelledList = filteredHistoryOrders.filter((o) => o.status === 'cancelled');
    const totalCompletedRevenue = completedList.reduce((sum, o) => sum + o.pricing.total, 0);
    const avgOrderValue = completedList.length > 0 ? totalCompletedRevenue / completedList.length : 0;
    const cancellationRate = totalCount > 0 ? (cancelledList.length / totalCount) * 100 : 0;

    return {
      totalCount,
      completedCount: completedList.length,
      cancelledCount: cancelledList.length,
      totalCompletedRevenue,
      avgOrderValue,
      cancellationRate
    };
  }, [filteredHistoryOrders]);

  // Export Permanent Order History to CSV
  const handleExportOrderHistory = () => {
    const headers = 'Order ID,Date,Time,Mode,Status,Customer Name,Customer Phone,Customer Email,Items,Subtotal,Discount,GST Tax,Total,Payment Method,Payment Status,Completed At,Cancelled At,Cancellation Reason\n';
    const rows = filteredHistoryOrders
      .map((o) => {
        const dateStr = new Date(o.createdAt).toLocaleDateString('en-IN');
        const timeStr = new Date(o.createdAt).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' });
        const itemsStr = o.items.map((i) => `${i.quantity}x ${i.name.replace(/"/g, '""')}`).join('; ');
        return `"${o.id}","${dateStr}","${timeStr}","${o.bookingMode}","${o.status}","${(o.customer?.name || '').replace(/"/g, '""')}","${o.customer?.phone || ''}","${o.customer?.email || ''}","${itemsStr}",${o.pricing.subtotal.toFixed(2)},${o.pricing.discountAmount.toFixed(2)},${o.pricing.gstTax.toFixed(2)},${o.pricing.total.toFixed(2)},"${o.paymentMethod}","${o.paymentStatus}","${o.completedAt || ''}","${o.cancelledAt || ''}","${(o.cancellationReason || '').replace(/"/g, '""')}"`;
      })
      .join('\n');
    const blob = new Blob([headers + rows], { type: 'text/csv;charset=utf-8;' });
    const url = URL.createObjectURL(blob);
    const link = document.createElement('a');
    link.href = url;
    link.download = `Campora_Order_History_${new Date().toISOString().split('T')[0]}.csv`;
    link.click();
    showToast('Export Completed', `Exported ${filteredHistoryOrders.length} order records to CSV.`, 'success');
  };

  // Confirm and Execute Cancellation
  const handleConfirmCancelOrder = async () => {
    if (!cancelModalOrder) return;
    setIsSubmittingCancel(true);
    try {
      const res = await cancelOrder(cancelModalOrder.id, cancelReasonInput);
      if (res.success) {
        showToast('Order Cancelled', `Order #${cancelModalOrder.id} has been cancelled and moved to permanent history.`, 'info');
        setCancelModalOrder(null);
      } else {
        showToast('Error', res.error || 'Failed to cancel order.', 'error');
      }
    } finally {
      setIsSubmittingCancel(false);
    }
  };

  // Analytics Metrics
  const metrics = useMemo(() => {
    const totalRevenue = orders.reduce((sum, o) => sum + (o.status !== 'cancelled' ? o.pricing.total : 0), 0);
    const completedOrders = orders.filter((o) => o.status === 'completed').length;
    const activeOrders = orders.filter((o) => o.status === 'confirmed' || o.status === 'preparing' || o.status === 'ready').length;
    const totalReservations = orders.filter((o) => o.bookingMode === 'dine-in').length;

    // Peak hours calculation
    const hourlyDistribution: Record<string, number> = {
      '08:00': 4,
      '10:00': 7,
      '12:00': 16,
      '14:00': 11,
      '16:00': 9,
      '18:00': 14,
      '20:00': 6
    };

    const chartData = Object.entries(hourlyDistribution).map(([time, count]) => ({
      time,
      bookings: count
    }));

    // Category distribution
    const categoryData = [
      { name: 'Coffee & Brews', value: 45, color: '#78350f' },
      { name: 'Bakery & Pastries', value: 25, color: '#d97706' },
      { name: 'Brunch & Mains', value: 20, color: '#15803d' },
      { name: 'Healthy & Vegan', value: 10, color: '#0284c7' },
    ];

    return { totalRevenue, completedOrders, activeOrders, totalReservations, chartData, categoryData };
  }, [orders]);

  // Section 11: Real-Time Admin Dashboard Summary Statistics
  const dashboardStats = useMemo(() => {
    const now = new Date();
    const startOfToday = new Date(now.getFullYear(), now.getMonth(), now.getDate()).getTime();

    const todayOrders = orders.filter((o) => new Date(o.createdAt).getTime() >= startOfToday);
    const todayRevenue = todayOrders
      .filter((o) => o.status !== 'cancelled')
      .reduce((sum, o) => sum + (o.pricing?.total || 0), 0);

    const pendingCount = orders.filter((o) => o.status === 'confirmed').length;
    const preparingCount = orders.filter((o) => o.status === 'preparing').length;
    const readyCount = orders.filter((o) => o.status === 'ready').length;
    const completedCount = orders.filter((o) => o.status === 'completed').length;
    const cancelledCount = orders.filter((o) => o.status === 'cancelled').length;

    return {
      todayOrdersCount: todayOrders.length,
      todayRevenue,
      pendingCount,
      preparingCount,
      readyCount,
      completedCount,
      cancelledCount,
      totalOrdersCount: orders.length
    };
  }, [orders]);

  // CSV Export for Customers
  const handleExportCustomers = () => {
    const headers = 'ID,Name,Phone,Email,TotalBookings,TotalSpent,VIP,LastVisit\n';
    const rows = customers
      .map(
        (c) =>
          `"${c.id}","${c.name}","${c.phone}","${c.email}",${c.totalBookings},${c.totalSpent.toFixed(2)},${c.isVIP},"${c.lastVisit}"`
      )
      .join('\n');
    const blob = new Blob([headers + rows], { type: 'text/csv' });
    const url = URL.createObjectURL(blob);
    const link = document.createElement('a');
    link.href = url;
    link.download = `Cafe_CRM_Customers_${new Date().toISOString().split('T')[0]}.csv`;
    link.click();
    showToast('Export Completed', 'Customer database downloaded as CSV.', 'success');
  };

  const handleSaveMenu = (e: React.FormEvent) => {
    e.preventDefault();
    if (!menuForm.name.trim()) return;

    if (editingItem) {
      updateMenuItem(editingItem.id, {
        ...menuForm,
        ingredients: menuForm.ingredients.split(',').map((s) => s.trim()),
        allergenWarnings: menuForm.allergenWarnings.split(',').map((s) => s.trim())
      });
      setEditingItem(null);
    } else {
      addMenuItem({
        ...menuForm,
        ingredients: menuForm.ingredients.split(',').map((s) => s.trim()),
        allergenWarnings: menuForm.allergenWarnings.split(',').map((s) => s.trim()),
        isAvailable: true,
        rating: 5.0,
        reviewCount: 1
      });
    }
    setIsAddMenuOpen(false);
  };

  const handleSavePromo = (e: React.FormEvent) => {
    e.preventDefault();
    if (!newPromoCode.trim()) return;

    const promo: PromoCode = {
      code: newPromoCode.trim().toUpperCase(),
      discountType: newPromoType,
      discountValue: Number(newPromoValue),
      minOrderAmount: Number(newPromoMin),
      description: newPromoDesc.trim() || `${newPromoValue}% discount`,
      isActive: true
    };
    addPromoCode(promo);
    setIsAddPromoOpen(false);
    setNewPromoCode('');
  };

  const handleSaveTable = (e: React.FormEvent) => {
    e.preventDefault();
    if (!newTableNumber.trim()) return;

    addTable({
      tableNumber: newTableNumber.trim().toUpperCase(),
      name: newTableName.trim() || `Table ${newTableNumber}`,
      capacity: Number(newTableCapacity),
      zone: newTableZone,
      status: 'available'
    });
    setIsAddTableOpen(false);
    setNewTableNumber('');
    setNewTableName('');
  };

  return (
    <div id="admin-dashboard-root" className="min-h-screen bg-stone-100 text-stone-900 pb-20">
      
      {/* Admin Top Navigation Bar */}
      <div className="bg-stone-900 text-stone-100 border-b border-stone-800 sticky top-0 z-30 shadow-md">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex items-center justify-between h-16">
            
            {/* Left Brand */}
            <div className="flex items-center gap-3">
              <div className="w-8 h-8 rounded-lg bg-amber-500 text-stone-950 flex items-center justify-center font-bold shrink-0">
                <ShieldCheck className="w-5 h-5" />
              </div>
              <div>
                <div className="flex items-center gap-2.5 flex-wrap">
                  <h1 className="font-serif text-base sm:text-lg font-bold text-white tracking-tight">
                    Cafe Management & POS
                  </h1>

                  {/* Open / Closed Toggle Button with real-time sync */}
                  <button
                    id="admin-status-toggle-badge"
                    type="button"
                    onClick={() => toggleCafeOpenStatus()}
                    disabled={isUpdatingStatus}
                    className={`flex items-center gap-1.5 px-2.5 py-1 rounded-full text-xs font-bold border transition-all cursor-pointer shadow-xs active:scale-95 ${
                      isCafeOpenNow
                        ? 'bg-emerald-950/90 text-emerald-300 border-emerald-500/50 hover:bg-emerald-900 ring-1 ring-emerald-500/20'
                        : 'bg-rose-950/90 text-rose-300 border-rose-500/50 hover:bg-rose-900 ring-1 ring-rose-500/20'
                    } ${isUpdatingStatus ? 'opacity-50 cursor-wait' : ''}`}
                    title={isCafeOpenNow ? 'Café is OPEN. Click to switch to Café Closed.' : 'Café is CLOSED. Click to switch to Café Open.'}
                  >
                    <span className="relative flex h-2 w-2">
                      <span
                        className={`animate-ping absolute inline-flex h-full w-full rounded-full opacity-75 ${
                          isCafeOpenNow ? 'bg-emerald-400' : 'bg-rose-400'
                        }`}
                      />
                      <span
                        className={`relative inline-flex rounded-full h-2 w-2 ${
                          isCafeOpenNow ? 'bg-emerald-500' : 'bg-rose-500'
                        }`}
                      />
                    </span>
                    <span>{isCafeOpenNow ? '🟢 Café Open' : '🔴 Café Closed'}</span>
                    <span className="text-[10px] text-stone-400 border-l border-stone-700 pl-1.5 ml-0.5 hidden xs:inline font-normal">
                      Click to toggle
                    </span>
                  </button>
                </div>
                <p className="text-xs text-stone-400">{settings.name}</p>
              </div>
            </div>

            {/* Right Controls */}
            <div className="flex items-center gap-2">
              {(adminUser || currentUser || currentStaff) && (
                <div className="hidden sm:flex items-center gap-2 px-2.5 py-1 rounded-xl bg-stone-800 border border-stone-700 text-xs text-stone-300">
                  <div className="w-6 h-6 rounded-full bg-amber-500 text-stone-950 flex items-center justify-center font-bold text-[10px] overflow-hidden">
                    {currentStaff?.photoUrl ? (
                      <img src={currentStaff.photoUrl} alt="" className="w-full h-full object-cover" />
                    ) : (
                      (currentStaff?.fullName || adminProfile?.displayName || adminUser?.displayName || adminUser?.email || currentUser?.displayName || currentUser?.email || 'A')[0].toUpperCase()
                    )}
                  </div>
                  <div className="flex flex-col">
                    <div className="flex items-center gap-1.5">
                      <span className="max-w-[130px] truncate text-[11px] font-semibold text-white">
                        {currentStaff?.fullName || adminProfile?.displayName || adminUser?.displayName || adminUser?.email || currentUser?.displayName || currentUser?.email}
                      </span>
                      {currentStaff ? (
                        <span className="inline-flex items-center gap-0.5 px-1.5 py-0.2 rounded bg-amber-500/20 text-amber-300 border border-amber-500/40 text-[9px] font-bold">
                          {currentStaff.role === 'owner' && <Crown className="w-2.5 h-2.5 text-amber-400" />}
                          {currentStaff.position}
                        </span>
                      ) : isAdminUser ? (
                        <span className="inline-flex items-center gap-0.5 px-1.5 py-0.2 rounded bg-amber-500/20 text-amber-300 border border-amber-500/40 text-[9px] font-bold">
                          <Crown className="w-2.5 h-2.5 text-amber-400" />
                          ADMIN
                        </span>
                      ) : (
                        <span className="inline-flex items-center px-1.5 py-0.2 rounded bg-stone-700 text-stone-300 text-[9px] font-semibold">
                          STAFF
                        </span>
                      )}
                    </div>
                    <span className="text-[9px] text-stone-400 font-mono">
                      {currentStaff ? `Staff ID: ${currentStaff.staffId}` : `UID: ${(adminUser?.uid || currentUser?.uid || '').slice(0, 10)}...`}
                    </span>
                  </div>
                  <button
                    onClick={logoutAdmin}
                    className="p-1 text-stone-400 hover:text-rose-400 transition-colors ml-1 cursor-pointer"
                    title="Sign Out of Admin Portal"
                  >
                    <LogOut className="w-3.5 h-3.5" />
                  </button>
                </div>
              )}

              <button
                onClick={() => setSoundAlerts(!soundAlerts)}
                className={`p-2 rounded-lg text-xs font-semibold flex items-center gap-1.5 transition-colors ${
                  soundAlerts ? 'bg-stone-800 text-amber-400' : 'bg-stone-800 text-stone-500'
                }`}
                title={soundAlerts ? 'Audio alert chime ON' : 'Audio alert chime OFF'}
              >
                {soundAlerts ? <Volume2 className="w-4 h-4" /> : <VolumeX className="w-4 h-4" />}
                <span className="hidden md:inline">Alerts</span>
              </button>

              <button
                onClick={() => setIsCounterSaleModalOpen(true)}
                className="px-3 py-1.5 rounded-lg bg-emerald-600 hover:bg-emerald-500 text-white font-bold text-xs transition-all flex items-center gap-1.5 cursor-pointer shadow-xs"
                title="Record new Counter / Walk-in Sale"
              >
                <Coins className="w-3.5 h-3.5" />
                <span>+ Counter Sale</span>
              </button>

              <button
                onClick={() => setIsAdminMode(false)}
                className="px-3.5 py-1.5 rounded-lg bg-amber-500 hover:bg-amber-400 text-stone-950 font-bold text-xs transition-colors flex items-center gap-1.5 cursor-pointer"
              >
                <span>Customer Portal</span>
                <ChevronRight className="w-3.5 h-3.5" />
              </button>
            </div>

          </div>

          {/* Admin Navigation Tabs */}
          <div className="flex items-center gap-1 overflow-x-auto no-scrollbar border-t border-stone-800/80 pt-1">
            {[
              { id: 'orders', label: 'Live Orders & Bookings', icon: ClipboardList, badge: metrics.activeOrders },
              { id: 'counter-sales', label: 'Counter Sales / Walk-ins', icon: Coins, badge: counterSales.length > 0 ? counterSales.length : undefined },
              { id: 'tables', label: 'Floor Plan & Tables', icon: LayoutGrid },
              { id: 'menu', label: 'Menu & Stock Manager', icon: UtensilsCrossed },
              { id: 'crm', label: 'Customer CRM', icon: Users },
              { id: 'staff', label: 'Campus Staff & RBAC', icon: ShieldCheck, badge: staffMembers.length },
              { id: 'analytics', label: 'Analytics & Insights', icon: TrendingUp },
              { id: 'settings', label: 'Cafe Settings & Promos', icon: Settings },
            ].map((tab) => {
              const Icon = tab.icon;
              const isActive = activeTab === tab.id;
              return (
                <button
                  key={tab.id}
                  onClick={() => setActiveTab(tab.id as AdminTab)}
                  className={`flex items-center gap-2 px-3.5 py-2.5 text-xs font-bold whitespace-nowrap border-b-2 transition-all cursor-pointer ${
                    isActive
                      ? 'border-amber-400 text-amber-400 bg-stone-800/40'
                      : 'border-transparent text-stone-400 hover:text-stone-200'
                  }`}
                >
                  <Icon className="w-4 h-4" />
                  <span>{tab.label}</span>
                  {tab.badge !== undefined && tab.badge > 0 && (
                    <span className="w-4 h-4 rounded-full bg-amber-500 text-stone-950 text-[10px] font-extrabold flex items-center justify-center">
                      {tab.badge}
                    </span>
                  )}
                </button>
              );
            })}
          </div>

        </div>
      </div>

      {/* Main Tab Content */}
      <main className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 pt-6 space-y-6">
        
        {/* TAB 1: LIVE ORDERS & BOOKING BOARD */}
        {activeTab === 'orders' && (
          <div className="space-y-4">

            {/* Closed Status Operational Banner */}
            {!isCafeOpenNow && (
              <div className="p-4 rounded-2xl bg-rose-50 border border-rose-200 flex flex-col sm:flex-row sm:items-center justify-between gap-3 text-rose-950 shadow-xs">
                <div className="flex items-center gap-3">
                  <div className="w-9 h-9 rounded-xl bg-rose-600 text-white flex items-center justify-center font-bold shrink-0 shadow-xs">
                    <AlertCircle className="w-5 h-5" />
                  </div>
                  <div>
                    <h4 className="font-bold text-sm text-rose-900 flex items-center gap-2">
                      <span>🔴 Café is Currently Closed</span>
                      <span className="text-[10px] px-2 py-0.5 rounded-full bg-rose-200 text-rose-800 font-bold uppercase tracking-wider">
                        Online Ordering Paused
                      </span>
                    </h4>
                    <p className="text-xs text-rose-700 mt-0.5">
                      Customers can still browse the menu and pricing on the website, but new orders and table reservations are blocked.
                    </p>
                  </div>
                </div>
                <button
                  type="button"
                  onClick={() => toggleCafeOpenStatus(true)}
                  disabled={isUpdatingStatus}
                  className="px-4 py-2 rounded-xl bg-emerald-600 hover:bg-emerald-500 text-white text-xs font-bold transition-all shadow-xs shrink-0 cursor-pointer flex items-center justify-center gap-1.5"
                >
                  <Check className="w-4 h-4" />
                  <span>Reopen Café Now</span>
                </button>
              </div>
            )}

            {/* Sales Reporting: Online Orders vs Counter Sales vs Combined Total */}
            <div className="bg-stone-900 text-white p-3.5 sm:p-4 rounded-2xl shadow-xs border border-stone-800">
              <div className="flex flex-col md:flex-row md:items-center justify-between gap-3">
                <div className="flex items-center gap-2.5">
                  <div className="w-8 h-8 rounded-xl bg-amber-500/20 text-amber-400 border border-amber-500/30 flex items-center justify-center font-bold">
                    <TrendingUp className="w-4 h-4" />
                  </div>
                  <div>
                    <h4 className="text-xs font-bold uppercase tracking-wider text-stone-200">
                      Consolidated Café Sales Overview
                    </h4>
                    <span className="text-[11px] text-stone-400">
                      Live audit of Online Customer Bookings + In-Person Counter Walk-ins
                    </span>
                  </div>
                </div>

                <div className="grid grid-cols-3 gap-2 sm:gap-4 divide-x divide-stone-800 text-center sm:text-right">
                  <div className="px-2">
                    <span className="text-[10px] text-stone-400 block font-semibold uppercase">Online Orders</span>
                    <span className="text-sm sm:text-base font-bold font-serif text-blue-400">
                      {settings.currency}{salesSummary.onlineOrdersTotal.toFixed(0)}
                    </span>
                    <span className="text-[10px] text-stone-500 block">Today: {settings.currency}{salesSummary.todayOnlineSales.toFixed(0)}</span>
                  </div>

                  <div className="px-2">
                    <span className="text-[10px] text-amber-400 block font-semibold uppercase">Counter Sales</span>
                    <span className="text-sm sm:text-base font-bold font-serif text-amber-400">
                      {settings.currency}{salesSummary.counterSalesTotal.toFixed(0)}
                    </span>
                    <span className="text-[10px] text-stone-500 block">Today: {settings.currency}{salesSummary.todayCounterSales.toFixed(0)}</span>
                  </div>

                  <div className="px-2">
                    <span className="text-[10px] text-emerald-400 block font-semibold uppercase">Total Sales</span>
                    <span className="text-sm sm:text-base font-bold font-serif text-emerald-400">
                      {settings.currency}{salesSummary.combinedTotalSales.toFixed(0)}
                    </span>
                    <span className="text-[10px] text-emerald-400/80 block font-semibold">Today: {settings.currency}{salesSummary.todayTotalSales.toFixed(0)}</span>
                  </div>
                </div>
              </div>
            </div>

            {/* 7-Point Admin Dashboard Summary Statistics (Section 11) */}
            <div className="grid grid-cols-2 sm:grid-cols-4 lg:grid-cols-7 gap-2.5 sm:gap-3">
              <div 
                id="kpi-card-today-orders"
                onClick={() => { setOrderViewMode('active'); setOrderFilter('all'); }}
                className="bg-white p-3 rounded-2xl border border-stone-200 shadow-xs cursor-pointer hover:border-amber-400 transition-all"
              >
                <div className="flex items-center justify-between text-stone-500 text-[11px] font-semibold">
                  <span>Today's Orders</span>
                  <Calendar className="w-3.5 h-3.5 text-stone-400" />
                </div>
                <div className="text-xl font-bold font-serif text-stone-900 mt-1">
                  {dashboardStats.todayOrdersCount}
                </div>
                <div className="text-[10px] text-stone-400 mt-0.5">Placed today</div>
              </div>

              <div 
                id="kpi-card-pending-orders"
                onClick={() => { setOrderViewMode('active'); }}
                className="bg-white p-3 rounded-2xl border border-stone-200 shadow-xs cursor-pointer hover:border-amber-400 transition-all"
              >
                <div className="flex items-center justify-between text-stone-500 text-[11px] font-semibold">
                  <span>Pending</span>
                  <Clock className="w-3.5 h-3.5 text-amber-500" />
                </div>
                <div className="text-xl font-bold font-serif text-amber-600 mt-1">
                  {dashboardStats.pendingCount}
                </div>
                <div className="text-[10px] text-stone-400 mt-0.5">Awaiting prep</div>
              </div>

              <div 
                id="kpi-card-preparing-orders"
                onClick={() => { setOrderViewMode('active'); }}
                className="bg-white p-3 rounded-2xl border border-stone-200 shadow-xs cursor-pointer hover:border-amber-400 transition-all"
              >
                <div className="flex items-center justify-between text-stone-500 text-[11px] font-semibold">
                  <span>Preparing</span>
                  <Flame className="w-3.5 h-3.5 text-orange-500" />
                </div>
                <div className="text-xl font-bold font-serif text-orange-600 mt-1">
                  {dashboardStats.preparingCount}
                </div>
                <div className="text-[10px] text-stone-400 mt-0.5">In kitchen</div>
              </div>

              <div 
                id="kpi-card-ready-orders"
                onClick={() => { setOrderViewMode('active'); }}
                className="bg-white p-3 rounded-2xl border border-stone-200 shadow-xs cursor-pointer hover:border-amber-400 transition-all"
              >
                <div className="flex items-center justify-between text-stone-500 text-[11px] font-semibold">
                  <span>Ready</span>
                  <CheckCircle2 className="w-3.5 h-3.5 text-blue-500" />
                </div>
                <div className="text-xl font-bold font-serif text-blue-600 mt-1">
                  {dashboardStats.readyCount}
                </div>
                <div className="text-[10px] text-stone-400 mt-0.5">Ready for pickup</div>
              </div>

              <div 
                id="kpi-card-completed-orders"
                onClick={() => { setOrderViewMode('history'); setHistoryStatusFilter('completed'); }}
                className="bg-white p-3 rounded-2xl border border-stone-200 shadow-xs cursor-pointer hover:border-amber-400 transition-all"
              >
                <div className="flex items-center justify-between text-stone-500 text-[11px] font-semibold">
                  <span>Completed</span>
                  <CheckCheck className="w-3.5 h-3.5 text-emerald-500" />
                </div>
                <div className="text-xl font-bold font-serif text-emerald-600 mt-1">
                  {dashboardStats.completedCount}
                </div>
                <div className="text-[10px] text-stone-400 mt-0.5">Archived fulfilled</div>
              </div>

              <div 
                id="kpi-card-cancelled-orders"
                onClick={() => { setOrderViewMode('history'); setHistoryStatusFilter('cancelled'); }}
                className="bg-white p-3 rounded-2xl border border-stone-200 shadow-xs cursor-pointer hover:border-amber-400 transition-all"
              >
                <div className="flex items-center justify-between text-stone-500 text-[11px] font-semibold">
                  <span>Cancelled</span>
                  <Ban className="w-3.5 h-3.5 text-rose-500" />
                </div>
                <div className="text-xl font-bold font-serif text-rose-600 mt-1">
                  {dashboardStats.cancelledCount}
                </div>
                <div className="text-[10px] text-stone-400 mt-0.5">Grace/voided</div>
              </div>

              <div 
                id="kpi-card-today-revenue"
                className="col-span-2 sm:col-span-2 lg:col-span-1 bg-gradient-to-br from-amber-500 to-amber-600 text-stone-950 p-3 rounded-2xl shadow-xs"
              >
                <div className="flex items-center justify-between text-stone-900/80 text-[11px] font-bold">
                  <span>Today's Revenue</span>
                  <DollarSign className="w-3.5 h-3.5 text-stone-950" />
                </div>
                <div className="text-xl font-bold font-serif text-stone-950 mt-1">
                  {settings.currency}{dashboardStats.todayRevenue.toFixed(0)}
                </div>
                <div className="text-[10px] text-stone-900/80 font-medium mt-0.5">Active gross total</div>
              </div>
            </div>
            
            {/* Sub-Navigation: Live Active Kitchen vs Permanent History */}
            <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 bg-white p-2.5 sm:p-3 rounded-2xl border border-stone-200 shadow-xs">
              <div className="flex items-center gap-2 p-1 bg-stone-100 rounded-xl">
                <button
                  type="button"
                  id="btn-admin-mode-active"
                  onClick={() => setOrderViewMode('active')}
                  className={`flex items-center gap-2 px-4 py-2 rounded-lg text-xs font-bold transition-all cursor-pointer ${
                    orderViewMode === 'active'
                      ? 'bg-stone-900 text-white shadow-xs'
                      : 'text-stone-600 hover:text-stone-900'
                  }`}
                >
                  <Flame className={`w-3.5 h-3.5 ${orderViewMode === 'active' ? 'text-amber-400' : 'text-stone-400'}`} />
                  <span>Live Kitchen & Dispatch</span>
                  <span className={`px-1.5 py-0.5 rounded-full text-[10px] font-extrabold ${
                    orderViewMode === 'active' ? 'bg-amber-500 text-stone-950' : 'bg-stone-200 text-stone-700'
                  }`}>
                    {activeOrders.length}
                  </span>
                </button>

                <button
                  type="button"
                  id="btn-admin-mode-history"
                  onClick={() => setOrderViewMode('history')}
                  className={`flex items-center gap-2 px-4 py-2 rounded-lg text-xs font-bold transition-all cursor-pointer ${
                    orderViewMode === 'history'
                      ? 'bg-stone-900 text-white shadow-xs'
                      : 'text-stone-600 hover:text-stone-900'
                  }`}
                >
                  <RotateCcw className="w-3.5 h-3.5" />
                  <span>Permanent Order History</span>
                  <span className={`px-1.5 py-0.5 rounded-full text-[10px] font-bold ${
                    orderViewMode === 'history' ? 'bg-amber-500 text-stone-950' : 'bg-stone-200 text-stone-700'
                  }`}>
                    {orderHistory.length}
                  </span>
                </button>
              </div>

              {orderViewMode === 'history' ? (
                <button
                  type="button"
                  id="btn-admin-export-csv"
                  onClick={handleExportOrderHistory}
                  className="flex items-center justify-center gap-1.5 px-4 py-2 bg-stone-900 hover:bg-stone-800 text-white text-xs font-bold rounded-xl transition-all shadow-xs cursor-pointer"
                >
                  <Download className="w-3.5 h-3.5 text-amber-400" />
                  <span>Export History (CSV)</span>
                </button>
              ) : (
                <div className="flex items-center gap-2 text-xs text-stone-500 px-2">
                  <span className="inline-block w-2 h-2 rounded-full bg-emerald-500 animate-ping"></span>
                  <span className="font-semibold text-stone-700">Real-Time Kitchen Sync Active</span>
                </div>
              )}
            </div>

            {/* VIEW 1: LIVE ACTIVE ORDERS BOARD */}
            {orderViewMode === 'active' && (
              <div className="space-y-4">
                {/* Filter & Search Toolbar */}
                <div className="flex flex-col sm:flex-row items-stretch sm:items-center justify-between gap-3 bg-white p-3 rounded-2xl border border-stone-200 shadow-xs">
                  <div className="flex items-center gap-1.5 overflow-x-auto no-scrollbar">
                    {[
                      { id: 'all', label: `All Active (${activeOrders.length})` },
                      { id: 'dine-in', label: 'Dine-In Bookings' },
                      { id: 'takeout', label: 'Express Takeout' },
                      { id: 'delivery', label: 'Deliveries' },
                    ].map((f) => (
                      <button
                        key={f.id}
                        type="button"
                        onClick={() => setOrderFilter(f.id as any)}
                        className={`px-3 py-1.5 rounded-xl text-xs font-bold transition-all whitespace-nowrap cursor-pointer ${
                          orderFilter === f.id
                            ? 'bg-stone-900 text-stone-50 shadow-xs'
                            : 'bg-stone-100 text-stone-600 hover:bg-stone-200'
                        }`}
                      >
                        {f.label}
                      </button>
                    ))}
                  </div>

                  <div className="relative">
                    <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-3.5 h-3.5 text-stone-400" />
                    <input
                      type="text"
                      id="input-search-active-orders"
                      value={orderSearch}
                      onChange={(e) => setOrderSearch(e.target.value)}
                      placeholder="Search active orders, items, phone..."
                      className="pl-8 pr-3 py-1.5 bg-stone-50 border border-stone-200 rounded-xl text-xs text-stone-800 w-full sm:w-64 focus:outline-none focus:ring-1 focus:ring-amber-800"
                    />
                  </div>
                </div>

                {/* Active Orders Grid */}
                {filteredActiveOrders.length === 0 ? (
                  <div className="bg-white rounded-3xl border border-stone-200 p-12 text-center space-y-3 shadow-xs">
                    <div className="w-12 h-12 rounded-2xl bg-emerald-50 text-emerald-600 mx-auto flex items-center justify-center">
                      <CheckCheck className="w-6 h-6" />
                    </div>
                    <h4 className="font-serif font-bold text-stone-800 text-lg">Kitchen & Counter All Caught Up</h4>
                    <p className="text-xs text-stone-500 max-w-md mx-auto">
                      No live active orders currently waiting in the preparation or dispatch pipeline. All placed orders have either been completed and logged into permanent history, or are awaiting customer checkout.
                    </p>
                    <button
                      type="button"
                      onClick={() => setOrderViewMode('history')}
                      className="px-4 py-2 rounded-xl bg-stone-100 hover:bg-stone-200 text-stone-700 text-xs font-bold transition-colors inline-flex items-center gap-1.5"
                    >
                      <RotateCcw className="w-3.5 h-3.5" />
                      <span>View Permanent Order Archive</span>
                    </button>
                  </div>
                ) : (
                  <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
                    {filteredActiveOrders.map((order) => {
                      let statusBadgeBg = 'bg-amber-100 text-amber-900 border-amber-300';
                      if (order.status === 'preparing') statusBadgeBg = 'bg-sky-100 text-sky-900 border-sky-300';
                      if (order.status === 'ready') statusBadgeBg = 'bg-emerald-100 text-emerald-900 border-emerald-300';

                      const timeElapsedInfo = formatBookingTimeElapsed(order.createdAt);
                      const cleanPhone = order.customer.phone.replace(/[^0-9]/g, '');

                      return (
                        <div
                          key={order.id}
                          className="bg-white rounded-2xl border border-stone-200 p-4 shadow-xs flex flex-col justify-between space-y-3 hover:border-stone-300 transition-colors"
                        >
                          {/* Header Row */}
                          <div className="flex items-start justify-between gap-2 border-b border-stone-100 pb-2.5">
                            <div>
                              <div className="flex items-center gap-2">
                                <span className="font-mono font-bold text-sm text-stone-900">
                                  #{order.id}
                                </span>
                                <span className={`px-2 py-0.5 rounded-md text-[10px] font-bold border uppercase ${statusBadgeBg}`}>
                                  {order.status}
                                </span>
                              </div>
                              <div className="flex items-center gap-1.5 text-xs text-stone-500 mt-0.5">
                                <span>{new Date(order.createdAt).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}</span>
                                <span>•</span>
                                <span className="text-amber-800 font-mono text-[10px] font-semibold bg-amber-50 px-1.5 py-0.5 rounded border border-amber-200/60">
                                  {order.deviceSessionSlug || 'campus-client'}
                                </span>
                              </div>
                            </div>

                            <div className="text-right">
                              <span className="text-xs font-bold text-stone-900 font-serif">
                                {settings.currency}{order.pricing.total.toFixed(2)}
                              </span>
                              <span className="text-[10px] text-stone-500 block uppercase font-medium">
                                {order.bookingMode}
                              </span>
                            </div>
                          </div>

                          {/* Cancellation Policy Window Badge */}
                          <div className={`p-2 rounded-xl text-[11px] flex items-center justify-between ${
                            timeElapsedInfo.isWithin10MinWindow
                              ? 'bg-emerald-50 text-emerald-800 border border-emerald-200'
                              : 'bg-stone-50 text-stone-600 border border-stone-200'
                          }`}>
                            <div className="flex items-center gap-1.5">
                              <Clock className={`w-3.5 h-3.5 ${timeElapsedInfo.isWithin10MinWindow ? 'text-emerald-600 animate-pulse' : 'text-stone-400'}`} />
                              <span className="font-medium">
                                {timeElapsedInfo.isWithin10MinWindow
                                  ? `Grace Window: ${timeElapsedInfo.formattedCountdown} left (Zero Fee)`
                                  : `Grace Expired (${timeElapsedInfo.minutesElapsed}m elapsed)`}
                              </span>
                            </div>
                            <span className="text-[10px] font-bold uppercase tracking-wider">
                              {timeElapsedInfo.isWithin10MinWindow ? 'Eligible' : 'Full Charge'}
                            </span>
                          </div>

                          {/* Customer Details Strip */}
                          <div className="bg-stone-50 p-3 rounded-xl text-xs space-y-1.5 border border-stone-100">
                            <div className="flex items-center justify-between">
                              <p className="font-bold text-stone-900">{order.customer.name}</p>
                              <div className="flex items-center gap-2">
                                <a
                                  href={`tel:${cleanPhone}`}
                                  className="p-1 rounded-md bg-stone-200 hover:bg-amber-100 text-stone-700 hover:text-amber-900 transition-colors"
                                  title="Direct Call"
                                >
                                  <PhoneCall className="w-3 h-3" />
                                </a>
                                {cleanPhone && (
                                  <a
                                    href={`https://wa.me/91${cleanPhone}?text=${encodeURIComponent(`Hello ${order.customer.name}, this is Campora Cafe regarding your Order #${order.id}.`)}`}
                                    target="_blank"
                                    rel="noopener noreferrer"
                                    className="p-1 rounded-md bg-emerald-100 hover:bg-emerald-200 text-emerald-800 transition-colors"
                                    title="WhatsApp Customer"
                                  >
                                    <MessageCircle className="w-3 h-3" />
                                  </a>
                                )}
                              </div>
                            </div>

                            {order.dineInDetails && (
                              <p className="text-amber-900 font-semibold text-[11px]">
                                🪑 Table {order.dineInDetails.tableNumber || 'Assigned on arrival'} • {order.dineInDetails.guestCount} Guests • {order.dineInDetails.timeSlot}
                              </p>
                            )}

                            {order.takeoutDetails && (
                              <p className="text-stone-700 font-medium text-[11px]">
                                🛍️ Express Pickup: {order.takeoutDetails.pickupTime}
                              </p>
                            )}

                            {order.deliveryDetails && (
                              <p className="text-stone-700 font-medium text-[11px]">
                                🛵 Delivery: {order.deliveryDetails.deliveryAddress}
                              </p>
                            )}

                            {order.customer.specialRequests && (
                              <p className="text-[11px] text-amber-800 italic bg-amber-50 p-1.5 rounded border border-amber-200/50">
                                Note: "{order.customer.specialRequests}"
                              </p>
                            )}
                          </div>

                          {/* Ordered Items Preview */}
                          <div className="space-y-1 text-xs max-h-32 overflow-y-auto pr-1">
                            {order.items.map((i) => (
                              <div key={i.cartItemId} className="flex justify-between text-stone-700 py-0.5">
                                <span className="font-medium">
                                  {i.quantity}× {i.name}
                                  {i.selectedSize && <span className="text-[10px] text-stone-400 ml-1">({i.selectedSize.name})</span>}
                                </span>
                                <span className="text-stone-500 font-mono">
                                  {settings.currency}{(i.calculatedPrice * i.quantity).toFixed(2)}
                                </span>
                              </div>
                            ))}
                          </div>

                          {/* Action Status Changers & Receipt */}
                          <div className="pt-2 border-t border-stone-100 flex flex-col gap-1.5">
                            <div className="flex items-center gap-1.5">
                              {order.status === 'confirmed' && (
                                <button
                                  type="button"
                                  id={`btn-craft-${order.id}`}
                                  onClick={() => updateOrderStatus(order.id, 'preparing')}
                                  className="flex-1 py-2 bg-sky-600 hover:bg-sky-700 text-white rounded-xl text-xs font-bold transition-colors cursor-pointer shadow-xs"
                                >
                                  ☕ Start Crafting
                                </button>
                              )}

                              {order.status === 'preparing' && (
                                <button
                                  type="button"
                                  id={`btn-ready-${order.id}`}
                                  onClick={() => updateOrderStatus(order.id, 'ready')}
                                  className="flex-1 py-2 bg-emerald-600 hover:bg-emerald-700 text-white rounded-xl text-xs font-bold transition-colors cursor-pointer shadow-xs"
                                >
                                  ✅ Mark Ready
                                </button>
                              )}

                              {order.status === 'ready' && (
                                <button
                                  type="button"
                                  id={`btn-complete-${order.id}`}
                                  onClick={() => updateOrderStatus(order.id, 'completed')}
                                  className="flex-1 py-2 bg-stone-900 hover:bg-stone-800 text-white rounded-xl text-xs font-bold transition-colors cursor-pointer shadow-xs"
                                >
                                  🎉 Complete Order
                                </button>
                              )}

                              <button
                                type="button"
                                id={`btn-detail-${order.id}`}
                                onClick={() => setSelectedDetailOrder(order)}
                                className="px-2.5 py-2 bg-stone-100 hover:bg-stone-200 text-stone-700 rounded-xl text-xs font-bold transition-colors cursor-pointer flex items-center gap-1"
                                title="Detailed Order View"
                              >
                                <Eye className="w-3.5 h-3.5 text-stone-600" />
                                <span className="hidden sm:inline">Details</span>
                              </button>

                              <button
                                type="button"
                                id={`btn-receipt-${order.id}`}
                                onClick={() => setSelectedReceiptOrder(order)}
                                className="px-3 py-2 bg-stone-100 hover:bg-stone-200 text-stone-700 rounded-xl text-xs font-bold transition-colors cursor-pointer flex items-center gap-1"
                                title="Print / View Receipt"
                              >
                                <Receipt className="w-3.5 h-3.5" />
                                <span className="hidden sm:inline">Receipt</span>
                              </button>

                              <button
                                type="button"
                                id={`btn-cancel-${order.id}`}
                                onClick={() => {
                                  setCancelModalOrder(order);
                                  setCancelReasonInput('Customer requested cancellation within 10-minute grace window');
                                }}
                                className="p-2 text-stone-400 hover:text-rose-600 hover:bg-rose-50 rounded-xl transition-colors text-xs font-medium"
                                title="Cancel Order"
                              >
                                <Ban className="w-3.5 h-3.5" />
                              </button>
                            </div>
                          </div>

                        </div>
                      );
                    })}
                  </div>
                )}
              </div>
            )}

            {/* VIEW 2: PERMANENT ORDER HISTORY & AUDIT ARCHIVE */}
            {orderViewMode === 'history' && (
              <div className="space-y-4">
                
                {/* History Analytics KPI Banner */}
                <div className="grid grid-cols-2 lg:grid-cols-4 gap-3">
                  <div className="bg-white p-3.5 rounded-2xl border border-stone-200 shadow-xs">
                    <p className="text-[11px] font-bold text-stone-400 uppercase tracking-wider">Archived Orders</p>
                    <p className="text-xl font-bold font-serif text-stone-900 mt-1">{historyStats.totalCount}</p>
                    <p className="text-[10px] text-stone-500 mt-0.5">Permanent records stored</p>
                  </div>

                  <div className="bg-white p-3.5 rounded-2xl border border-stone-200 shadow-xs">
                    <p className="text-[11px] font-bold text-stone-400 uppercase tracking-wider">Completed Revenue</p>
                    <p className="text-xl font-bold font-serif text-emerald-700 mt-1">
                      {settings.currency}{historyStats.totalCompletedRevenue.toFixed(2)}
                    </p>
                    <p className="text-[10px] text-stone-500 mt-0.5">{historyStats.completedCount} fulfilled orders</p>
                  </div>

                  <div className="bg-white p-3.5 rounded-2xl border border-stone-200 shadow-xs">
                    <p className="text-[11px] font-bold text-stone-400 uppercase tracking-wider">Avg Order Value</p>
                    <p className="text-xl font-bold font-serif text-stone-900 mt-1">
                      {settings.currency}{historyStats.avgOrderValue.toFixed(2)}
                    </p>
                    <p className="text-[10px] text-stone-500 mt-0.5">Per completed transaction</p>
                  </div>

                  <div className="bg-white p-3.5 rounded-2xl border border-stone-200 shadow-xs">
                    <p className="text-[11px] font-bold text-stone-400 uppercase tracking-wider">Cancellations</p>
                    <p className="text-xl font-bold font-serif text-rose-600 mt-1">{historyStats.cancelledCount}</p>
                    <p className="text-[10px] text-stone-500 mt-0.5">{historyStats.cancellationRate.toFixed(1)}% cancellation rate</p>
                  </div>
                </div>

                {/* History Filters & Search Toolbar */}
                <div className="bg-white p-3.5 rounded-2xl border border-stone-200 shadow-xs space-y-3">
                  <div className="flex flex-col md:flex-row gap-3 items-stretch md:items-center justify-between">
                    
                    {/* Status Filter Chips */}
                    <div className="flex items-center gap-1.5 overflow-x-auto no-scrollbar">
                      {[
                        { id: 'all', label: `All History (${orderHistory.length})` },
                        { id: 'completed', label: `Completed (${orderHistory.filter(o => o.status === 'completed').length})` },
                        { id: 'cancelled', label: `Cancelled (${orderHistory.filter(o => o.status === 'cancelled').length})` },
                      ].map((st) => (
                        <button
                          key={st.id}
                          type="button"
                          onClick={() => setHistoryStatusFilter(st.id as any)}
                          className={`px-3 py-1.5 rounded-xl text-xs font-bold transition-all whitespace-nowrap cursor-pointer ${
                            historyStatusFilter === st.id
                              ? 'bg-stone-900 text-stone-50 shadow-xs'
                              : 'bg-stone-100 text-stone-600 hover:bg-stone-200'
                          }`}
                        >
                          {st.label}
                        </button>
                      ))}
                    </div>

                    {/* Search Input */}
                    <div className="relative">
                      <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-3.5 h-3.5 text-stone-400" />
                      <input
                        type="text"
                        id="input-search-history"
                        value={orderSearch}
                        onChange={(e) => setOrderSearch(e.target.value)}
                        placeholder="Search token, customer, items..."
                        className="pl-8 pr-3 py-1.5 bg-stone-50 border border-stone-200 rounded-xl text-xs text-stone-800 w-full md:w-64 focus:outline-none focus:ring-1 focus:ring-amber-800"
                      />
                    </div>
                  </div>

                  {/* Secondary Filters: Date Range & Mode */}
                  <div className="flex flex-wrap items-center justify-between gap-2 pt-2 border-t border-stone-100 text-xs">
                    <div className="flex flex-wrap items-center gap-2">
                      <span className="text-stone-400 font-medium">Date Range:</span>
                      {[
                        { id: 'all', label: 'All Time' },
                        { id: 'today', label: 'Today' },
                        { id: 'yesterday', label: 'Yesterday' },
                        { id: '7days', label: 'Last 7 Days' },
                        { id: 'month', label: 'This Month' },
                      ].map((df) => (
                        <button
                          key={df.id}
                          type="button"
                          onClick={() => setHistoryDateFilter(df.id as any)}
                          className={`px-2.5 py-1 rounded-lg text-[11px] font-semibold transition-colors cursor-pointer ${
                            historyDateFilter === df.id
                              ? 'bg-amber-100 text-amber-900 border border-amber-300 font-bold'
                              : 'text-stone-500 hover:bg-stone-100'
                          }`}
                        >
                          {df.label}
                        </button>
                      ))}
                    </div>

                    <div className="flex items-center gap-2">
                      <span className="text-stone-400 font-medium">Mode:</span>
                      <select
                        value={orderFilter}
                        onChange={(e) => setOrderFilter(e.target.value as any)}
                        className="bg-stone-50 border border-stone-200 rounded-lg px-2 py-1 text-xs text-stone-700 outline-none"
                      >
                        <option value="all">All Modes</option>
                        <option value="dine-in">Dine-In</option>
                        <option value="takeout">Takeout</option>
                        <option value="delivery">Delivery</option>
                      </select>
                    </div>
                  </div>
                </div>

                {/* History Orders List */}
                {filteredHistoryOrders.length === 0 ? (
                  <div className="bg-white rounded-3xl border border-stone-200 p-10 text-center space-y-2 shadow-xs">
                    <RotateCcw className="w-10 h-10 text-stone-300 mx-auto" />
                    <h4 className="font-serif font-bold text-stone-800 text-base">No Historical Records Found</h4>
                    <p className="text-xs text-stone-500 max-w-sm mx-auto">
                      No past orders match the selected status, date, or search filter.
                    </p>
                  </div>
                ) : (
                  <div className="space-y-3">
                    {filteredHistoryOrders.map((order) => {
                      const isCompleted = order.status === 'completed';
                      const isCancelled = order.status === 'cancelled';
                      const createdDate = new Date(order.createdAt);
                      
                      // Calculate duration if completed
                      let prepDurationText = '';
                      if (order.completedAt) {
                        const durationMins = Math.max(1, Math.round((new Date(order.completedAt).getTime() - createdDate.getTime()) / 60000));
                        prepDurationText = `Fulfilled in ${durationMins} mins`;
                      }

                      return (
                        <div
                          key={order.id}
                          className="bg-white rounded-2xl border border-stone-200 p-4 sm:p-5 shadow-xs hover:border-stone-300 transition-colors space-y-3"
                        >
                          {/* Row 1: Token, Date & Status */}
                          <div className="flex flex-wrap items-center justify-between gap-2 border-b border-stone-100 pb-3">
                            <div className="flex items-center gap-2">
                              <span className="font-mono font-bold text-sm text-stone-900">
                                #{order.id}
                              </span>
                              <span className="text-xs text-stone-400">
                                {createdDate.toLocaleDateString('en-IN', {
                                  day: 'numeric',
                                  month: 'short',
                                  year: 'numeric',
                                  hour: '2-digit',
                                  minute: '2-digit'
                                })}
                              </span>
                              <span className="text-[10px] uppercase font-bold px-2 py-0.5 rounded bg-stone-100 text-stone-600 border border-stone-200">
                                {order.bookingMode}
                              </span>
                            </div>

                            <div className="flex items-center gap-2">
                              {isCompleted && (
                                <span className="flex items-center gap-1 px-2.5 py-1 rounded-full text-xs font-bold bg-emerald-100 text-emerald-800 border border-emerald-300">
                                  <CheckCircle2 className="w-3.5 h-3.5" />
                                  <span>Completed</span>
                                </span>
                              )}
                              {isCancelled && (
                                <span className="flex items-center gap-1 px-2.5 py-1 rounded-full text-xs font-bold bg-rose-100 text-rose-800 border border-rose-300">
                                  <Ban className="w-3.5 h-3.5" />
                                  <span>Cancelled</span>
                                </span>
                              )}
                            </div>
                          </div>

                          {/* Row 2: Customer & Cancellation Details */}
                          <div className="grid grid-cols-1 md:grid-cols-2 gap-3 text-xs">
                            <div className="space-y-1">
                              <div className="flex items-center gap-2">
                                <span className="font-bold text-stone-900">{order.customer.name}</span>
                                <span className="text-stone-400">•</span>
                                <span className="text-stone-600 font-mono">{order.customer.phone}</span>
                              </div>
                              <p className="text-stone-500">
                                {order.bookingMode === 'dine-in' ? `Table ${order.dineInDetails?.tableNumber || 'Assigned'} (${order.dineInDetails?.guestCount || 2} Guests)` :
                                 order.bookingMode === 'delivery' ? `Delivery to: ${order.deliveryDetails?.deliveryAddress || 'Campus'}` : 'Express Takeout Counter'}
                              </p>
                            </div>

                            <div className="space-y-1 md:text-right">
                              {isCompleted && (
                                <p className="text-emerald-700 font-medium">
                                  ✅ {prepDurationText || 'Completed & Archived'}
                                  {order.completedAt && (
                                    <span className="text-stone-400 block text-[11px]">
                                      Completed at {new Date(order.completedAt).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}
                                    </span>
                                  )}
                                </p>
                              )}
                              {isCancelled && (
                                <div className="bg-rose-50 p-2 rounded-xl border border-rose-200 text-left md:text-right space-y-0.5">
                                  <p className="text-rose-800 font-bold text-[11px]">
                                    Cancellation Reason:
                                  </p>
                                  <p className="text-rose-700 text-[11px] italic">
                                    "{order.cancellationReason || 'Cancelled within policy'}"
                                  </p>
                                  {order.cancelledAt && (
                                    <p className="text-[10px] text-stone-400">
                                      Cancelled at {new Date(order.cancelledAt).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}
                                    </p>
                                  )}
                                </div>
                              )}
                            </div>
                          </div>

                          {/* Row 3: Items Ordered & Financial Breakdown */}
                          <div className="p-3 bg-stone-50 rounded-xl border border-stone-100 flex flex-col sm:flex-row sm:items-center justify-between gap-3 text-xs">
                            <div className="space-y-1">
                              <p className="text-stone-700 font-medium">
                                {order.items.map(i => `${i.quantity}x ${i.name}`).join(', ')}
                              </p>
                              <p className="text-[11px] text-stone-400">
                                Payment: <span className="font-semibold text-stone-600 uppercase">{order.paymentMethod}</span> ({order.paymentStatus === 'paid' ? 'Paid' : 'Unpaid/Arrival'})
                              </p>
                            </div>

                            <div className="flex items-center gap-3 self-end sm:self-center">
                              <div className="text-right">
                                <span className="text-stone-400 text-[11px]">Total: </span>
                                <span className="font-serif font-bold text-stone-900 text-sm">
                                  {settings.currency}{order.pricing.total.toFixed(2)}
                                </span>
                              </div>

                              <button
                                type="button"
                                id={`btn-history-detail-${order.id}`}
                                onClick={() => setSelectedDetailOrder(order)}
                                className="px-3 py-1.5 rounded-xl bg-white border border-stone-300 hover:bg-stone-50 text-stone-700 font-bold text-xs transition-colors flex items-center gap-1 shadow-2xs cursor-pointer"
                                title="Detailed Order View"
                              >
                                <Eye className="w-3.5 h-3.5 text-stone-600" />
                                <span>Details</span>
                              </button>

                              <button
                                type="button"
                                id={`btn-history-receipt-${order.id}`}
                                onClick={() => setSelectedReceiptOrder(order)}
                                className="px-3 py-1.5 rounded-xl bg-white border border-stone-300 hover:bg-stone-50 text-stone-700 font-bold text-xs transition-colors flex items-center gap-1 shadow-2xs"
                              >
                                <Receipt className="w-3.5 h-3.5 text-amber-700" />
                                <span>Receipt</span>
                              </button>
                            </div>
                          </div>

                          {/* Customer Star Rating & Feedback (if submitted) */}
                          {order.feedback && (
                            <div className="p-2.5 bg-amber-50/60 rounded-xl border border-amber-200/60 text-xs flex items-center gap-2">
                              <span className="text-amber-500 font-bold">
                                {'★'.repeat(order.feedback.rating)}{'☆'.repeat(5 - order.feedback.rating)}
                              </span>
                              <span className="text-stone-700 italic">"{order.feedback.comment}"</span>
                            </div>
                          )}

                        </div>
                      );
                    })}
                  </div>
                )}

                {/* Load More Historical Orders Pagination */}
                {hasMoreOrders && (
                  <div className="pt-2 text-center">
                    <button
                      type="button"
                      id="btn-admin-load-more-orders"
                      onClick={() => loadMoreOrders()}
                      disabled={isLoadingMoreOrders}
                      className="px-6 py-2.5 bg-white border border-stone-300 hover:bg-stone-50 text-stone-700 font-bold text-xs rounded-xl shadow-xs transition-all disabled:opacity-50 cursor-pointer inline-flex items-center gap-2"
                    >
                      {isLoadingMoreOrders ? (
                        <>
                          <span className="w-3.5 h-3.5 border-2 border-stone-400 border-t-stone-800 rounded-full animate-spin"></span>
                          <span>Loading More Orders...</span>
                        </>
                      ) : (
                        <>
                          <RotateCcw className="w-3.5 h-3.5 text-stone-500" />
                          <span>Load Earlier Orders</span>
                        </>
                      )}
                    </button>
                  </div>
                )}
              </div>
            )}

          </div>
        )}

        {/* TAB: COUNTER SALES & WALK-IN POS */}
        {activeTab === 'counter-sales' && (
          <CounterSalesHistory onOpenNewSale={() => setIsCounterSaleModalOpen(true)} />
        )}

        {/* TAB 2: FLOOR PLAN & TABLE MANAGEMENT */}
        {activeTab === 'tables' && (
          <div className="space-y-4">
            
            <div className="flex justify-between items-center bg-white p-4 rounded-2xl border border-stone-200">
              <div>
                <h3 className="font-serif text-lg font-bold text-stone-900">
                  Cafe Floor Plan & Seating Status
                </h3>
                <p className="text-xs text-stone-500">
                  Click any table card to toggle status between Available, Reserved, Occupied, or Cleaning.
                </p>
              </div>

              <button
                onClick={() => setIsAddTableOpen(true)}
                className="px-3.5 py-2 bg-stone-900 hover:bg-stone-800 text-white text-xs font-bold rounded-xl flex items-center gap-1.5 cursor-pointer shadow-xs"
              >
                <Plus className="w-3.5 h-3.5" />
                <span>Add Table</span>
              </button>
            </div>

            {/* Tables Grid */}
            <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-4 gap-4">
              {tables.map((table) => {
                let borderBg = 'border-emerald-300 bg-emerald-50/50';
                let statusLabel = 'Available';
                let statusColor = 'text-emerald-800 bg-emerald-100';

                if (table.status === 'reserved') {
                  borderBg = 'border-amber-300 bg-amber-50/60';
                  statusLabel = 'Reserved';
                  statusColor = 'text-amber-900 bg-amber-200';
                } else if (table.status === 'occupied') {
                  borderBg = 'border-purple-300 bg-purple-50/60';
                  statusLabel = 'Occupied';
                  statusColor = 'text-purple-900 bg-purple-200';
                } else if (table.status === 'cleaning') {
                  borderBg = 'border-sky-300 bg-sky-50/60';
                  statusLabel = 'Cleaning';
                  statusColor = 'text-sky-900 bg-sky-200';
                }

                return (
                  <div
                    key={table.id}
                    className={`rounded-2xl border-2 p-4 flex flex-col justify-between space-y-3 transition-all ${borderBg}`}
                  >
                    <div>
                      <div className="flex items-center justify-between">
                        <span className="text-lg font-bold font-serif text-stone-900">
                          {table.tableNumber}
                        </span>
                        <span className={`px-2 py-0.5 rounded-full text-[10px] font-bold ${statusColor}`}>
                          {statusLabel}
                        </span>
                      </div>
                      <p className="text-xs font-medium text-stone-700 mt-1">{table.name}</p>
                      <p className="text-[11px] text-stone-500 capitalize">
                        Area: {table.zone} • Max {table.capacity} Seats
                      </p>
                    </div>

                    {/* Quick Status Toggles */}
                    <div className="pt-2 border-t border-stone-200/60 grid grid-cols-2 gap-1 text-[10px] font-bold">
                      <button
                        onClick={() => updateTableStatus(table.id, 'available')}
                        className={`p-1.5 rounded-lg border text-center ${
                          table.status === 'available'
                            ? 'bg-emerald-700 text-white border-emerald-700'
                            : 'bg-white text-stone-700 hover:bg-stone-50'
                        }`}
                      >
                        Available
                      </button>

                      <button
                        onClick={() => updateTableStatus(table.id, 'occupied')}
                        className={`p-1.5 rounded-lg border text-center ${
                          table.status === 'occupied'
                            ? 'bg-purple-700 text-white border-purple-700'
                            : 'bg-white text-stone-700 hover:bg-stone-50'
                        }`}
                      >
                        Occupied
                      </button>

                      <button
                        onClick={() => updateTableStatus(table.id, 'reserved')}
                        className={`p-1.5 rounded-lg border text-center ${
                          table.status === 'reserved'
                            ? 'bg-amber-700 text-white border-amber-700'
                            : 'bg-white text-stone-700 hover:bg-stone-50'
                        }`}
                      >
                        Reserved
                      </button>

                      <button
                        onClick={() => updateTableStatus(table.id, 'cleaning')}
                        className={`p-1.5 rounded-lg border text-center ${
                          table.status === 'cleaning'
                            ? 'bg-sky-700 text-white border-sky-700'
                            : 'bg-white text-stone-700 hover:bg-stone-50'
                        }`}
                      >
                        Cleaning
                      </button>
                    </div>

                    {/* Delete option */}
                    <div className="flex justify-end pt-1">
                      <button
                        onClick={() => deleteTable(table.id)}
                        className="text-[10px] text-rose-500 hover:text-rose-700 font-medium"
                      >
                        Remove Table
                      </button>
                    </div>

                  </div>
                );
              })}
            </div>

          </div>
        )}

        {/* TAB 3: MENU CRUD & STOCK MANAGEMENT */}
        {activeTab === 'menu' && (
          <div className="space-y-4">
            
            <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 bg-white p-4 rounded-2xl border border-stone-200 shadow-xs">
              <div>
                <h3 className="font-serif text-lg font-bold text-stone-900">
                  Menu Items & Real-Time Stock Control
                </h3>
                <p className="text-xs text-stone-500">
                  Modify pricing, mark dishes out of stock, or add seasonal specialties.
                </p>
              </div>

              <button
                onClick={() => {
                  setEditingItem(null);
                  setMenuForm({
                    name: '',
                    tagline: '',
                    category: 'beverages',
                    subcategory: '',
                    description: '',
                    price: 6.50,
                    stockCount: 20,
                    image: 'https://images.unsplash.com/photo-1514432324607-a09d9b4aefdd?w=800&auto=format&fit=crop&q=80',
                    dietaryTags: ['veg'],
                    ingredients: 'Single origin beans, filtered spring water',
                    allergenWarnings: 'None',
                    calories: 10,
                    preparationTimeMinutes: 5,
                  });
                  setIsAddMenuOpen(true);
                }}
                className="px-4 py-2 bg-stone-900 hover:bg-stone-800 text-white text-xs font-bold rounded-xl flex items-center justify-center gap-1.5 cursor-pointer shadow-xs"
              >
                <Plus className="w-3.5 h-3.5" />
                <span>Add New Menu Item</span>
              </button>
            </div>

            {/* Menu Table */}
            <div className="bg-white rounded-2xl border border-stone-200 overflow-hidden shadow-xs">
              <div className="overflow-x-auto">
                <table className="w-full text-left text-xs text-stone-700">
                  <thead className="bg-stone-50 border-b border-stone-200 text-stone-500 uppercase tracking-wider font-bold text-[10px]">
                    <tr>
                      <th className="p-3.5">Item</th>
                      <th className="p-3.5">Category</th>
                      <th className="p-3.5">Price</th>
                      <th className="p-3.5">Stock</th>
                      <th className="p-3.5">Availability</th>
                      <th className="p-3.5 text-right">Actions</th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-stone-100">
                    {menuItems.map((item) => (
                      <tr key={item.id} className="hover:bg-stone-50/70">
                        <td className="p-3.5 flex items-center gap-3">
                          <img
                            src={item.image}
                            alt={item.name}
                            className="w-10 h-10 rounded-lg object-cover bg-stone-200"
                          />
                          <div>
                            <p className="font-bold text-stone-900">{item.name}</p>
                            <p className="text-[10px] text-stone-400 line-clamp-1">{item.description}</p>
                          </div>
                        </td>

                        <td className="p-3.5 capitalize font-medium">
                          {item.category}
                        </td>

                        <td className="p-3.5 font-bold text-stone-900 font-serif">
                          {settings.currency}{item.price.toFixed(2)}
                        </td>

                        <td className="p-3.5">
                          <div className="flex items-center gap-1">
                            <input
                              type="number"
                              min="0"
                              value={item.stockCount}
                              onChange={(e) => updateItemStock(item.id, Number(e.target.value))}
                              className="w-14 p-1 rounded-lg border border-stone-300 text-center font-bold text-xs"
                            />
                            <span className="text-[10px] text-stone-400">units</span>
                          </div>
                        </td>

                        <td className="p-3.5">
                          <button
                            onClick={() => toggleItemAvailability(item.id)}
                            className={`px-2.5 py-1 rounded-full text-[10px] font-bold ${
                              item.isAvailable && item.stockCount > 0
                                ? 'bg-emerald-100 text-emerald-800'
                                : 'bg-rose-100 text-rose-800'
                            }`}
                          >
                            {item.isAvailable && item.stockCount > 0 ? 'In Stock' : 'Out of Stock'}
                          </button>
                        </td>

                        <td className="p-3.5 text-right space-x-2">
                          <button
                            onClick={() => {
                              setEditingItem(item);
                              setMenuForm({
                                name: item.name,
                                tagline: item.tagline || '',
                                category: item.category,
                                subcategory: item.subcategory || '',
                                description: item.description,
                                price: item.price,
                                stockCount: item.stockCount,
                                image: item.image,
                                dietaryTags: item.dietaryTags,
                                ingredients: item.ingredients.join(', '),
                                allergenWarnings: item.allergenWarnings.join(', '),
                                calories: item.calories || 100,
                                preparationTimeMinutes: item.preparationTimeMinutes,
                              });
                              setIsAddMenuOpen(true);
                            }}
                            className="p-1.5 rounded-lg text-stone-500 hover:text-stone-900 hover:bg-stone-100"
                            title="Edit Item"
                          >
                            <Edit2 className="w-3.5 h-3.5" />
                          </button>

                          <button
                            onClick={() => deleteMenuItem(item.id)}
                            className="p-1.5 rounded-lg text-stone-500 hover:text-rose-600 hover:bg-rose-50"
                            title="Delete Item"
                          >
                            <Trash2 className="w-3.5 h-3.5" />
                          </button>
                        </td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            </div>

          </div>
        )}

        {/* TAB 4: CUSTOMER CRM & LOYALTY */}
        {activeTab === 'crm' && (
          <div className="space-y-4">
            
            <div className="flex justify-between items-center bg-white p-4 rounded-2xl border border-stone-200 shadow-xs">
              <div>
                <h3 className="font-serif text-lg font-bold text-stone-900">
                  Customer Directory & Relationship Management
                </h3>
                <p className="text-xs text-stone-500">
                  Track loyal cafe patrons, VIP table guests, and spending history.
                </p>
              </div>

              <button
                onClick={handleExportCustomers}
                className="px-3.5 py-2 bg-stone-900 hover:bg-stone-800 text-white text-xs font-bold rounded-xl flex items-center gap-1.5 cursor-pointer"
              >
                <Download className="w-3.5 h-3.5" />
                <span>Export CSV</span>
              </button>
            </div>

            {/* Customers Grid */}
            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4">
              {customers.map((c) => (
                <div
                  key={c.id}
                  className="p-4 rounded-2xl bg-white border border-stone-200 shadow-xs space-y-3"
                >
                  <div className="flex items-start justify-between">
                    <div>
                      <div className="flex items-center gap-2">
                        <span className="font-bold text-sm text-stone-900">{c.name}</span>
                        {c.isVIP && (
                          <span className="px-2 py-0.5 rounded-full text-[9px] font-extrabold bg-amber-500 text-stone-950">
                            VIP Patron
                          </span>
                        )}
                      </div>
                      <p className="text-xs text-stone-500">{c.phone}</p>
                      <p className="text-xs text-stone-400">{c.email}</p>
                    </div>

                    <div className="text-right">
                      <span className="text-sm font-bold text-stone-900 font-serif">
                        {settings.currency}{c.totalSpent.toFixed(2)}
                      </span>
                      <p className="text-[10px] text-stone-400">Total Spent</p>
                    </div>
                  </div>

                  <div className="grid grid-cols-2 gap-2 pt-2 border-t border-stone-100 text-xs">
                    <div>
                      <span className="text-stone-400 text-[10px] block">Total Visits</span>
                      <span className="font-bold text-stone-800">{c.totalBookings} Bookings</span>
                    </div>
                    <div>
                      <span className="text-stone-400 text-[10px] block">Loyalty Points</span>
                      <span className="font-bold text-amber-800">{c.loyaltyPoints} pts</span>
                    </div>
                  </div>

                  {c.favoriteItems && c.favoriteItems.length > 0 && (
                    <div className="text-[11px] text-stone-500">
                      <span className="font-semibold text-stone-700">Favorites: </span>
                      <span>{c.favoriteItems.slice(0, 2).join(', ')}</span>
                    </div>
                  )}
                </div>
              ))}
            </div>

          </div>
        )}

        {/* TAB: CAMPUS STAFF MANAGEMENT & RBAC */}
        {activeTab === 'staff' && (
          <div className="space-y-4">
            <StaffManagementSection
              staffMembers={staffMembers}
              auditLogs={staffAuditLogs}
              onAddStaff={addStaffMember}
              onUpdateStaff={updateStaffMember}
              onToggleStatus={toggleStaffStatus}
              onDeleteStaff={deleteStaffMemberPermanently}
              onSimulateStaffLogin={loginStaffQuickDemo}
              currentStaff={currentStaff}
              hasPermission={hasPermission}
              isAdminUser={isAdminUser}
            />
          </div>
        )}

        {/* TAB 5: ANALYTICS & INSIGHTS */}
        {activeTab === 'analytics' && (
          <div className="space-y-6">
            
            {/* KPI Metric Cards */}
            <div className="grid grid-cols-2 lg:grid-cols-4 gap-4">
              <div className="p-4 rounded-2xl bg-white border border-stone-200 shadow-xs">
                <span className="text-xs font-bold uppercase text-stone-400">Total Combined Sales</span>
                <p className="text-2xl font-bold font-serif text-stone-900 mt-1">
                  {settings.currency}{salesSummary.combinedTotalSales.toFixed(2)}
                </p>
                <div className="flex items-center justify-between text-[11px] text-emerald-600 font-semibold mt-1">
                  <span>Today: {settings.currency}{salesSummary.todayTotalSales.toFixed(2)}</span>
                </div>
              </div>

              <div className="p-4 rounded-2xl bg-white border border-stone-200 shadow-xs">
                <span className="text-xs font-bold uppercase text-stone-400">Online Customer Orders</span>
                <p className="text-2xl font-bold font-serif text-blue-600 mt-1">
                  {settings.currency}{salesSummary.onlineOrdersTotal.toFixed(2)}
                </p>
                <span className="text-[11px] text-stone-500 font-semibold">{orders.length} total orders ({metrics.activeOrders} active)</span>
              </div>

              <div className="p-4 rounded-2xl bg-white border border-stone-200 shadow-xs">
                <span className="text-xs font-bold uppercase text-amber-700">Counter Sales (Walk-ins)</span>
                <p className="text-2xl font-bold font-serif text-amber-800 mt-1">
                  {settings.currency}{salesSummary.counterSalesTotal.toFixed(2)}
                </p>
                <span className="text-[11px] text-amber-700 font-medium">{counterSales.length} walk-in purchases recorded</span>
              </div>

              <div className="p-4 rounded-2xl bg-white border border-stone-200 shadow-xs">
                <span className="text-xs font-bold uppercase text-stone-400">Tender: Cash vs UPI</span>
                <div className="flex items-baseline gap-2 mt-1">
                  <span className="text-lg font-bold font-serif text-emerald-700">{settings.currency}{salesSummary.totalCashCollection.toFixed(0)}</span>
                  <span className="text-xs text-stone-400">/</span>
                  <span className="text-lg font-bold font-serif text-blue-700">{settings.currency}{salesSummary.totalUpiCollection.toFixed(0)}</span>
                </div>
                <span className="text-[11px] text-stone-500 font-semibold">Cash / UPI Gross Audit</span>
              </div>
            </div>

            {/* Charts Row */}
            <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
              
              {/* Peak Booking Hours */}
              <div className="p-5 rounded-2xl bg-white border border-stone-200 shadow-xs space-y-4">
                <div>
                  <h4 className="font-serif text-base font-bold text-stone-900">
                    Peak Cafe Hours & Booking Traffic
                  </h4>
                  <p className="text-xs text-stone-500">Distribution of customer visits across time of day</p>
                </div>
                <div className="h-64 w-full">
                  <ResponsiveContainer width="100%" height="100%">
                    <BarChart data={metrics.chartData}>
                      <CartesianGrid strokeDasharray="3 3" vertical={false} stroke="#f1f5f9" />
                      <XAxis dataKey="time" tick={{ fontSize: 11 }} />
                      <YAxis tick={{ fontSize: 11 }} />
                      <Tooltip />
                      <Bar dataKey="bookings" fill="#78350f" radius={[6, 6, 0, 0]} />
                    </BarChart>
                  </ResponsiveContainer>
                </div>
              </div>

              {/* Category Share */}
              <div className="p-5 rounded-2xl bg-white border border-stone-200 shadow-xs space-y-4">
                <div>
                  <h4 className="font-serif text-base font-bold text-stone-900">
                    Sales Distribution by Menu Category
                  </h4>
                  <p className="text-xs text-stone-500">Breakdown of orders across beverage & food groups</p>
                </div>
                <div className="h-64 w-full flex items-center justify-center">
                  <ResponsiveContainer width="100%" height="100%">
                    <PieChart>
                      <Pie
                        data={metrics.categoryData}
                        dataKey="value"
                        nameKey="name"
                        cx="50%"
                        cy="50%"
                        outerRadius={80}
                        label={({ name, percent }) => `${name} ${(percent * 100).toFixed(0)}%`}
                      >
                        {metrics.categoryData.map((entry, index) => (
                          <Cell key={`cell-${index}`} fill={entry.color} />
                        ))}
                      </Pie>
                      <Tooltip />
                    </PieChart>
                  </ResponsiveContainer>
                </div>
              </div>

            </div>

          </div>
        )}

        {/* TAB 6: CAFE SETTINGS & PROMO CODES */}
        {activeTab === 'settings' && (
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
            
            {/* Store Open / Closed Status Management Card */}
            <div className="lg:col-span-2 p-5 rounded-2xl bg-white border border-stone-200 shadow-xs space-y-4">
              <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 border-b border-stone-100 pb-3">
                <div>
                  <div className="flex items-center gap-2">
                    <h3 className="font-serif text-base font-bold text-stone-900">
                      Live Store Status & Ordering Control
                    </h3>
                    <span
                      className={`text-xs font-bold px-2.5 py-0.5 rounded-full border ${
                        isCafeOpenNow
                          ? 'bg-emerald-50 text-emerald-700 border-emerald-300'
                          : 'bg-rose-50 text-rose-700 border-rose-300'
                      }`}
                    >
                      {isCafeOpenNow ? '🟢 Currently Open' : '🔴 Currently Closed'}
                    </span>
                  </div>
                  <p className="text-xs text-stone-500 mt-0.5">
                    Controls customer ordering and table bookings in real time. Changes sync instantly and persist in the database.
                  </p>
                </div>

                <div className="flex items-center gap-2 shrink-0">
                  <button
                    type="button"
                    onClick={() => toggleCafeOpenStatus(true)}
                    disabled={isUpdatingStatus || isCafeOpenNow}
                    className={`px-4 py-2 rounded-xl text-xs font-bold transition-all flex items-center gap-1.5 cursor-pointer ${
                      isCafeOpenNow
                        ? 'bg-emerald-600 text-white shadow-xs ring-2 ring-emerald-500/30'
                        : 'bg-stone-100 text-stone-700 hover:bg-emerald-50 hover:text-emerald-700 border border-stone-200'
                    }`}
                  >
                    <Check className="w-3.5 h-3.5" />
                    <span>🟢 Café Open</span>
                  </button>

                  <button
                    type="button"
                    onClick={() => toggleCafeOpenStatus(false)}
                    disabled={isUpdatingStatus || !isCafeOpenNow}
                    className={`px-4 py-2 rounded-xl text-xs font-bold transition-all flex items-center gap-1.5 cursor-pointer ${
                      !isCafeOpenNow
                        ? 'bg-rose-600 text-white shadow-xs ring-2 ring-rose-500/30'
                        : 'bg-stone-100 text-stone-700 hover:bg-rose-50 hover:text-rose-700 border border-stone-200'
                    }`}
                  >
                    <Ban className="w-3.5 h-3.5" />
                    <span>🔴 Café Closed</span>
                  </button>
                </div>
              </div>

              {/* Status Details Grid */}
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4 text-xs">
                <div
                  className={`p-3.5 rounded-xl border transition-all ${
                    isCafeOpenNow
                      ? 'border-emerald-300 bg-emerald-50/50 text-emerald-950 ring-1 ring-emerald-500/20'
                      : 'border-stone-200 bg-stone-50 text-stone-600 opacity-60'
                  }`}
                >
                  <div className="font-bold flex items-center gap-1.5 text-emerald-900 mb-1">
                    <span>🟢 Café Open Behavior:</span>
                  </div>
                  <ul className="list-disc list-inside space-y-0.5 text-stone-700">
                    <li>Customers can browse all food & beverage menus</li>
                    <li>Tray additions, customization, and checkout active</li>
                    <li>Dine-in table booking & hostel delivery enabled</li>
                    <li>Status displays: <strong>"🟢 We Are Open – Order Now"</strong></li>
                  </ul>
                </div>

                <div
                  className={`p-3.5 rounded-xl border transition-all ${
                    !isCafeOpenNow
                      ? 'border-rose-300 bg-rose-50/50 text-rose-950 ring-1 ring-rose-500/20'
                      : 'border-stone-200 bg-stone-50 text-stone-600 opacity-60'
                  }`}
                >
                  <div className="font-bold flex items-center gap-1.5 text-rose-900 mb-1">
                    <span>🔴 Café Closed Behavior:</span>
                  </div>
                  <ul className="list-disc list-inside space-y-0.5 text-stone-700">
                    <li>Customers can view full menu, photos, prices & tags</li>
                    <li>New cart adds, checkout & bookings are locked</li>
                    <li>Existing orders & active preparation continue normally</li>
                    <li>Status displays: <strong>"🔴 Currently Closed – Ordering is Temporarily Unavailable"</strong></li>
                  </ul>
                </div>
              </div>

              {/* Custom Closed Message Notice */}
              <div className="pt-1">
                <label className="block font-semibold text-stone-700 text-xs mb-1">
                  Customer Closed Notice Message (displayed on website when closed)
                </label>
                <div className="flex gap-2">
                  <input
                    type="text"
                    value={settings.closedNotice || ''}
                    placeholder="e.g. Kitchen is taking a prep break. Online ordering reopens at 4:30 PM!"
                    onChange={(e) => updateSettings({ closedNotice: e.target.value }, true)}
                    className="flex-1 p-2.5 rounded-xl border border-stone-200 bg-stone-50 focus:bg-white text-xs"
                  />
                  <button
                    type="button"
                    onClick={() => showToast('Notice Saved', 'Customer closed banner message updated.', 'success')}
                    className="px-3.5 py-2 bg-stone-900 hover:bg-stone-800 text-white rounded-xl text-xs font-semibold shrink-0 cursor-pointer"
                  >
                    Save Notice
                  </button>
                </div>
              </div>
            </div>

            {/* Cafe Core Settings */}
            <div className="p-5 rounded-2xl bg-white border border-stone-200 shadow-xs space-y-4 text-xs">
              <h3 className="font-serif text-base font-bold text-stone-900">
                Cafe Store Configuration
              </h3>

              <div className="space-y-3">
                <div>
                  <label className="block font-semibold text-stone-700 mb-1">Cafe Name</label>
                  <input
                    type="text"
                    value={settings.name}
                    onChange={(e) => updateSettings({ name: e.target.value })}
                    className="w-full p-2.5 rounded-xl border border-stone-200 bg-stone-50 focus:bg-white"
                  />
                </div>

                <div>
                  <label className="block font-semibold text-stone-700 mb-1">Tagline</label>
                  <input
                    type="text"
                    value={settings.tagline}
                    onChange={(e) => updateSettings({ tagline: e.target.value })}
                    className="w-full p-2.5 rounded-xl border border-stone-200 bg-stone-50 focus:bg-white"
                  />
                </div>

                <div className="grid grid-cols-2 gap-3">
                  <div>
                    <label className="block font-semibold text-stone-700 mb-1">Tax Rate (GST %)</label>
                    <input
                      type="number"
                      step="0.1"
                      value={settings.taxRatePercent}
                      onChange={(e) => updateSettings({ taxRatePercent: Number(e.target.value) })}
                      className="w-full p-2.5 rounded-xl border border-stone-200 bg-stone-50 focus:bg-white"
                    />
                  </div>

                  <div>
                    <label className="block font-semibold text-stone-700 mb-1">Service Fee ($)</label>
                    <input
                      type="number"
                      step="0.25"
                      value={settings.serviceFeeFixed}
                      onChange={(e) => updateSettings({ serviceFeeFixed: Number(e.target.value) })}
                      className="w-full p-2.5 rounded-xl border border-stone-200 bg-stone-50 focus:bg-white"
                    />
                  </div>
                </div>

                <div>
                  <label className="block font-semibold text-stone-700 mb-1">Street Address</label>
                  <input
                    type="text"
                    value={settings.address}
                    onChange={(e) => updateSettings({ address: e.target.value })}
                    className="w-full p-2.5 rounded-xl border border-stone-200 bg-stone-50 focus:bg-white"
                  />
                </div>

                <div className="grid grid-cols-2 gap-3">
                  <div>
                    <label className="block font-semibold text-stone-700 mb-1">Phone Number</label>
                    <input
                      type="text"
                      value={settings.phone}
                      onChange={(e) => updateSettings({ phone: e.target.value })}
                      className="w-full p-2.5 rounded-xl border border-stone-200 bg-stone-50 focus:bg-white"
                    />
                  </div>

                  <div>
                    <label className="block font-semibold text-stone-700 mb-1">WhatsApp Contact</label>
                    <input
                      type="text"
                      value={settings.whatsapp}
                      onChange={(e) => updateSettings({ whatsapp: e.target.value })}
                      className="w-full p-2.5 rounded-xl border border-stone-200 bg-stone-50 focus:bg-white"
                    />
                  </div>
                </div>
              </div>
            </div>

            {/* UPI Payment & Dynamic Merchant QR Settings */}
            <div id="admin-upi-payment-settings" className="p-5 sm:p-6 rounded-2xl bg-white border border-stone-200 shadow-xs space-y-5 text-xs lg:col-span-2">
              <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2 pb-3 border-b border-stone-100">
                <div>
                  <div className="flex items-center gap-2">
                    <div className="w-7 h-7 rounded-lg bg-amber-500/20 text-amber-900 flex items-center justify-center font-bold">
                      <QrCode className="w-4 h-4 text-amber-700" />
                    </div>
                    <h3 className="font-serif text-base font-bold text-stone-900">
                      UPI Payment Gateway & Dynamic QR Configuration
                    </h3>
                  </div>
                  <p className="text-stone-500 mt-1">
                    Manage the café's official UPI ID, merchant display name, and live scannable QR codes for online checkout and walk-in counter sales.
                  </p>
                </div>

                <div className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full bg-emerald-50 text-emerald-800 border border-emerald-200 font-semibold text-[11px] self-start sm:self-auto">
                  <CheckCircle2 className="w-3.5 h-3.5 text-emerald-600" />
                  <span>Configured & Active</span>
                </div>
              </div>

              <div className="grid grid-cols-1 lg:grid-cols-12 gap-6 items-start">
                {/* Left: Input Controls & Management */}
                <div className="lg:col-span-7 space-y-4">
                  {/* Current Active UPI ID Card */}
                  <div className="p-3.5 rounded-xl bg-amber-50/60 border border-amber-200/80 flex items-center justify-between gap-3">
                    <div className="space-y-0.5">
                      <span className="text-[10px] uppercase font-bold text-amber-900/70 tracking-wider">
                        Active Cafe UPI ID
                      </span>
                      <div className="font-mono font-bold text-sm text-stone-950 flex items-center gap-1.5">
                        <Smartphone className="w-4 h-4 text-amber-600" />
                        <span>{settings.upiId || '8210794268-4@ybl'}</span>
                      </div>
                    </div>

                    <button
                      type="button"
                      onClick={() => {
                        navigator.clipboard?.writeText(settings.upiId || '8210794268-4@ybl');
                        showToast('UPI ID Copied', settings.upiId || '8210794268-4@ybl', 'success');
                      }}
                      className="px-2.5 py-1.5 rounded-lg bg-white hover:bg-amber-100 border border-amber-300 text-amber-900 font-bold text-[11px] flex items-center gap-1 transition-colors cursor-pointer shadow-2xs"
                    >
                      <Copy className="w-3 h-3" />
                      <span>Copy</span>
                    </button>
                  </div>

                  {/* Form to update UPI ID */}
                  <div className="space-y-3 pt-1">
                    <div>
                      <label className="block font-semibold text-stone-700 mb-1">
                        Merchant UPI ID (VPA) *
                      </label>
                      <input
                        type="text"
                        value={paymentUpiId}
                        onChange={(e) => setPaymentUpiId(e.target.value)}
                        placeholder="e.g. 8210794268-4@ybl"
                        className="w-full p-2.5 rounded-xl border border-stone-200 bg-stone-50 focus:bg-white font-mono text-xs focus:ring-2 focus:ring-amber-500/20 focus:border-amber-500 transition-all"
                      />
                      <span className="text-[10px] text-stone-400 mt-1 block">
                        Compatible with Google Pay, PhonePe, Paytm, BHIM, Cred, and all bank UPI apps.
                      </span>
                    </div>

                    <div>
                      <label className="block font-semibold text-stone-700 mb-1">
                        Payee Display Name
                      </label>
                      <input
                        type="text"
                        value={paymentUpiName}
                        onChange={(e) => setPaymentUpiName(e.target.value)}
                        placeholder="e.g. Campora Café"
                        className="w-full p-2.5 rounded-xl border border-stone-200 bg-stone-50 focus:bg-white text-xs focus:ring-2 focus:ring-amber-500/20 focus:border-amber-500 transition-all"
                      />
                      <span className="text-[10px] text-stone-400 mt-1 block">
                        Displayed to customers in their UPI app when confirming payment.
                      </span>
                    </div>

                    {/* Test Amount Simulator for Admin Preview */}
                    <div>
                      <label className="block font-semibold text-stone-700 mb-1">
                        Test Preview Bill Amount ({settings.currency})
                      </label>
                      <div className="flex items-center gap-2">
                        <input
                          type="number"
                          min="0"
                          step="5"
                          value={testQrAmount}
                          onChange={(e) => setTestQrAmount(Math.max(0, Number(e.target.value)))}
                          className="w-32 p-2.5 rounded-xl border border-stone-200 bg-stone-50 focus:bg-white text-xs font-mono"
                        />
                        <div className="flex gap-1.5">
                          {[50, 100, 120, 250].map((amt) => (
                            <button
                              key={amt}
                              type="button"
                              onClick={() => setTestQrAmount(amt)}
                              className={`px-2 py-1 rounded-lg border text-[11px] font-semibold transition-colors cursor-pointer ${
                                testQrAmount === amt
                                  ? 'bg-amber-100 text-amber-900 border-amber-300'
                                  : 'bg-stone-50 hover:bg-stone-100 text-stone-600 border-stone-200'
                              }`}
                            >
                              ₹{amt}
                            </button>
                          ))}
                        </div>
                      </div>
                    </div>
                  </div>

                  {/* Actions: Save, Reset */}
                  <div className="flex flex-wrap items-center gap-2 pt-2 border-t border-stone-100">
                    <button
                      type="button"
                      id="btn-save-upi-settings"
                      disabled={isSavingPaymentSettings || !paymentUpiId.trim()}
                      onClick={async () => {
                        setIsSavingPaymentSettings(true);
                        try {
                          await updateSettings({
                            upiId: paymentUpiId.trim(),
                            upiName: paymentUpiName.trim()
                          });
                          showToast('UPI Settings Saved', `Merchant UPI set to ${paymentUpiId.trim()}`, 'success');
                        } catch {
                          showToast('Error', 'Failed to update payment settings', 'error');
                        } finally {
                          setIsSavingPaymentSettings(false);
                        }
                      }}
                      className="px-4 py-2 bg-stone-900 hover:bg-stone-800 disabled:opacity-50 text-white rounded-xl font-bold flex items-center gap-1.5 transition-colors cursor-pointer shadow-xs"
                    >
                      <Save className="w-3.5 h-3.5" />
                      <span>{isSavingPaymentSettings ? 'Saving...' : 'Save UPI Settings'}</span>
                    </button>

                    <button
                      type="button"
                      id="btn-reset-default-upi"
                      onClick={async () => {
                        setPaymentUpiId('8210794268-4@ybl');
                        setPaymentUpiName('Campora Café');
                        try {
                          await updateSettings({
                            upiId: '8210794268-4@ybl',
                            upiName: 'Campora Café'
                          });
                          showToast('Reset to Default', 'UPI ID set to 8210794268-4@ybl', 'info');
                        } catch {
                          showToast('Error', 'Failed to reset UPI settings', 'error');
                        }
                      }}
                      className="px-3.5 py-2 bg-stone-100 hover:bg-stone-200 text-stone-700 rounded-xl font-semibold flex items-center gap-1.5 transition-colors cursor-pointer"
                    >
                      <RotateCcw className="w-3.5 h-3.5" />
                      <span>Reset to 8210794268-4@ybl</span>
                    </button>
                  </div>
                </div>

                {/* Right: Real-time Live Dynamic QR Preview */}
                <div className="lg:col-span-5 flex flex-col items-center">
                  <div className="w-full">
                    <div className="flex items-center justify-between mb-2">
                      <span className="text-[11px] font-bold uppercase tracking-wider text-stone-500">
                        Live Dynamic QR Preview
                      </span>
                      <span className="text-[10px] text-emerald-700 font-semibold flex items-center gap-1">
                        <span className="w-2 h-2 rounded-full bg-emerald-500 animate-pulse" />
                        Dynamic Render
                      </span>
                    </div>

                    {/* Dynamic QR Box using UpiPaymentBox */}
                    <UpiPaymentBox
                      upiId={paymentUpiId || '8210794268-4@ybl'}
                      payeeName={paymentUpiName || 'Campora Café'}
                      amount={testQrAmount}
                      note="Campora Cafe Order"
                      title={paymentUpiName || 'Campora Café'}
                      subtitle="Live Scannable QR Code"
                      variant="admin-preview"
                      size={150}
                      showPayButton={false}
                      showCopyButton={true}
                    />

                    <div className="mt-3 p-3 bg-stone-50 rounded-xl border border-stone-200 text-stone-500 text-[11px] space-y-1">
                      <p className="font-semibold text-stone-700">QR Code Verification:</p>
                      <p>
                        Scan this QR with your mobile camera or Google Pay / PhonePe app to verify the payee details (<span className="font-mono text-stone-800">{paymentUpiId || '8210794268-4@ybl'}</span>) and the test amount of {settings.currency}{testQrAmount}.
                      </p>
                    </div>
                  </div>
                </div>
              </div>
            </div>

            {/* Promo Codes Manager */}
            <div className="p-5 rounded-2xl bg-white border border-stone-200 shadow-xs space-y-4 text-xs">
              <div className="flex items-center justify-between">
                <div>
                  <h3 className="font-serif text-base font-bold text-stone-900">
                    Discount Coupon & Promo Codes
                  </h3>
                  <p className="text-stone-500">Configure incentives for table bookings and online orders</p>
                </div>
                <button
                  onClick={() => setIsAddPromoOpen(true)}
                  className="px-3 py-1.5 bg-stone-900 hover:bg-stone-800 text-white rounded-xl font-bold flex items-center gap-1"
                >
                  <Plus className="w-3.5 h-3.5" />
                  <span>Create Promo</span>
                </button>
              </div>

              <div className="space-y-2.5">
                {promoCodes.map((p) => (
                  <div
                    key={p.code}
                    className="p-3 rounded-xl border border-stone-200 flex items-center justify-between bg-stone-50"
                  >
                    <div>
                      <div className="flex items-center gap-2">
                        <span className="font-mono font-bold text-sm text-stone-900">{p.code}</span>
                        <span className="px-2 py-0.5 rounded-full text-[10px] font-bold bg-amber-100 text-amber-900">
                          {p.discountType === 'percentage' ? `${p.discountValue}% OFF` : `${settings.currency}${p.discountValue} OFF`}
                        </span>
                      </div>
                      <p className="text-stone-500 mt-0.5">{p.description}</p>
                    </div>

                    <button
                      onClick={() => togglePromoCode(p.code)}
                      className={`px-3 py-1 rounded-xl font-bold text-[10px] ${
                        p.isActive ? 'bg-emerald-600 text-white' : 'bg-stone-200 text-stone-600'
                      }`}
                    >
                      {p.isActive ? 'Active' : 'Disabled'}
                    </button>
                  </div>
                ))}
              </div>
            </div>

            {/* Role-Based Access Control (RBAC) & Staff Authority */}
            <div className="p-5 rounded-2xl bg-white border border-stone-200 shadow-xs space-y-4 text-xs">
              <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2">
                <div>
                  <div className="flex items-center gap-2">
                    <ShieldCheck className="w-5 h-5 text-amber-600" />
                    <h3 className="font-serif text-base font-bold text-stone-900">
                      Campus Staff & Admin User Roles (RBAC)
                    </h3>
                  </div>
                  <p className="text-stone-500 mt-0.5">
                    Live Firestore synchronization of admin roles, staff assignments, and permissions.
                  </p>
                </div>
                <div className="flex items-center gap-2">
                  <span className="px-2.5 py-1 rounded-lg bg-amber-50 text-amber-900 border border-amber-200 font-mono font-semibold text-[11px]">
                    Master UID: {MASTER_ADMIN_UID.slice(0, 10)}...
                  </span>
                </div>
              </div>

              {/* Master Root Admin Banner */}
              <div className="p-3.5 rounded-xl bg-gradient-to-r from-amber-500/10 via-amber-400/5 to-transparent border border-amber-400/30 flex items-start gap-3">
                <div className="p-2 rounded-lg bg-amber-500 text-stone-950 mt-0.5">
                  <Crown className="w-4 h-4" />
                </div>
                <div className="space-y-1">
                  <div className="flex items-center gap-2 flex-wrap">
                    <span className="font-bold text-stone-900 text-xs">Lead Master Administrator</span>
                    <span className="px-2 py-0.5 rounded-md bg-amber-500 text-stone-950 font-bold text-[10px]">
                      PRIMARY ADMIN ROLE
                    </span>
                    <span className="px-2 py-0.5 rounded-md bg-emerald-100 text-emerald-800 font-bold text-[10px]">
                      FULL ACCESS
                    </span>
                  </div>
                  <p className="text-[11px] text-stone-600 font-mono">
                    UID: <span className="font-bold text-stone-900 select-all">{MASTER_ADMIN_UID}</span>
                  </p>
                  <p className="text-[11px] text-stone-500">
                    Designated primary root administrator for Campora Cafe @ GEC Banka. Configured in security rules with full read/write authority across orders, menu items, table floor plans, and system parameters.
                  </p>
                </div>
              </div>

              {/* Users Directory Table */}
              <div className="space-y-2">
                <h4 className="font-semibold text-stone-800 text-xs flex items-center justify-between">
                  <span>Registered Staff & Admin Directory ({allUsers.length})</span>
                  <span className="text-[10px] text-stone-400 font-normal">Auto-synced with Firestore `users` collection</span>
                </h4>

                <div className="space-y-2">
                  {allUsers.map((usr) => {
                    const isMaster = usr.uid === MASTER_ADMIN_UID || isSystemAdminEmail(usr.email);
                    const isCurrent = (adminUser?.uid === usr.uid) || (currentUser?.uid === usr.uid);

                    return (
                      <div
                        key={usr.uid}
                        className={`p-3 rounded-xl border flex flex-col md:flex-row md:items-center justify-between gap-3 ${
                          isMaster
                            ? 'bg-amber-50/60 border-amber-300 shadow-xs'
                            : 'bg-stone-50 border-stone-200'
                        }`}
                      >
                        <div className="space-y-1">
                          <div className="flex items-center gap-2 flex-wrap">
                            <span className="font-bold text-stone-900 text-xs">
                              {usr.displayName || usr.email || 'Cafe Staff Member'}
                            </span>
                            {isMaster && (
                              <span className="px-1.5 py-0.5 rounded bg-amber-500 text-stone-950 font-black text-[9px] flex items-center gap-1">
                                <Crown className="w-2.5 h-2.5" /> MASTER ADMIN
                              </span>
                            )}
                            {isCurrent && (
                              <span className="px-1.5 py-0.5 rounded bg-emerald-500 text-white font-bold text-[9px]">
                                YOU
                              </span>
                            )}
                            <span
                              className={`px-2 py-0.5 rounded-full text-[10px] font-bold ${
                                usr.role === 'admin'
                                  ? 'bg-amber-200 text-amber-900 border border-amber-300'
                                  : usr.role === 'staff'
                                  ? 'bg-blue-100 text-blue-800'
                                  : 'bg-stone-200 text-stone-700'
                              }`}
                            >
                              {usr.role.toUpperCase()} ROLE
                            </span>
                          </div>

                          <div className="flex items-center gap-3 text-[11px] text-stone-500 font-mono flex-wrap">
                            <span>UID: <span className="font-semibold text-stone-700">{usr.uid}</span></span>
                            {usr.email && <span>Email: {usr.email}</span>}
                            {usr.createdAt && <span>Created: {new Date(usr.createdAt).toLocaleDateString()}</span>}
                          </div>

                          <div className="flex items-center gap-1.5 flex-wrap pt-0.5">
                            <span className="text-[10px] text-stone-400 font-semibold">Permissions:</span>
                            {usr.permissions?.map((perm) => (
                              <span key={perm} className="px-1.5 py-0.2 rounded bg-stone-200/80 text-stone-700 text-[9px] font-mono">
                                {perm}
                              </span>
                            ))}
                          </div>
                        </div>

                        {/* Action buttons (only if current user is admin) */}
                        {isAdminUser && !isMaster && (
                          <div className="flex items-center gap-1.5 self-start md:self-center">
                            <button
                              onClick={() => assignUserRole(usr.uid, usr.role === 'admin' ? 'staff' : 'admin')}
                              className={`px-2.5 py-1 rounded-lg text-[10px] font-bold transition-colors cursor-pointer ${
                                usr.role === 'admin'
                                  ? 'bg-stone-200 hover:bg-stone-300 text-stone-800'
                                  : 'bg-amber-500 hover:bg-amber-400 text-stone-950'
                              }`}
                            >
                              {usr.role === 'admin' ? 'Set as Staff' : 'Promote to Admin'}
                            </button>
                          </div>
                        )}
                      </div>
                    );
                  })}
                </div>
              </div>

              {/* Campus Staff Management System (Directory, Registration & Audit Trail) */}
              <div className="pt-6 border-t border-stone-200 space-y-4">
                <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 pb-2 border-b border-stone-100">
                  <div>
                    <h4 className="font-serif text-base font-bold text-stone-900 flex items-center gap-2">
                      <Users className="w-4 h-4 text-amber-600" />
                      <span>Campus Staff Management System</span>
                    </h4>
                    <p className="text-[11px] text-stone-500 mt-0.5">
                      Register café staff, assign granular role-based access control (RBAC), inspect documents, and audit operational activity logs.
                    </p>
                  </div>
                  <button
                    type="button"
                    onClick={() => setActiveTab('staff')}
                    className="px-3 py-1.5 rounded-xl bg-stone-900 hover:bg-stone-800 text-white font-bold text-xs flex items-center gap-1.5 transition-colors cursor-pointer self-start sm:self-auto"
                  >
                    <span>Open Standalone Staff View</span>
                    <ChevronRight className="w-3.5 h-3.5" />
                  </button>
                </div>

                <StaffManagementSection
                  staffMembers={staffMembers}
                  auditLogs={staffAuditLogs}
                  onAddStaff={addStaffMember}
                  onUpdateStaff={updateStaffMember}
                  onToggleStatus={toggleStaffStatus}
                  onDeleteStaff={deleteStaffMemberPermanently}
                  onSimulateStaffLogin={loginStaffQuickDemo}
                  currentStaff={currentStaff}
                  hasPermission={hasPermission}
                  isAdminUser={isAdminUser}
                />
              </div>
            </div>

          </div>
        )}

      </main>

      {/* Modal: Add/Edit Menu Item */}
      {isAddMenuOpen && (
        <div className="fixed inset-0 z-50 bg-black/60 backdrop-blur-xs flex items-center justify-center p-4">
          <div className="bg-white rounded-3xl max-w-lg w-full p-6 space-y-4 max-h-[90vh] overflow-y-auto">
            <div className="flex justify-between items-center">
              <h3 className="font-serif text-lg font-bold text-stone-900">
                {editingItem ? 'Edit Menu Item' : 'Add New Seasonal Menu Item'}
              </h3>
              <button onClick={() => setIsAddMenuOpen(false)} className="p-1 rounded-lg hover:bg-stone-100">
                <X className="w-5 h-5" />
              </button>
            </div>

            <form onSubmit={handleSaveMenu} className="space-y-3 text-xs">
              <div>
                <label className="block font-semibold mb-1">Item Title *</label>
                <input
                  type="text"
                  required
                  value={menuForm.name}
                  onChange={(e) => setMenuForm({ ...menuForm, name: e.target.value })}
                  className="w-full p-2.5 rounded-xl border border-stone-200 bg-stone-50"
                />
              </div>

              <div className="grid grid-cols-2 gap-2">
                <div>
                  <label className="block font-semibold mb-1">Category</label>
                  <select
                    value={menuForm.category}
                    onChange={(e) => setMenuForm({ ...menuForm, category: e.target.value as any })}
                    className="w-full p-2.5 rounded-xl border border-stone-200 bg-stone-50"
                  >
                    <option value="beverages">Beverages & Coffee</option>
                    <option value="pastries">Pastries & Bakery</option>
                    <option value="mains">Brunch & Mains</option>
                    <option value="healthy">Healthy Bowls</option>
                    <option value="desserts">Desserts</option>
                  </select>
                </div>

                <div>
                  <label className="block font-semibold mb-1">Price ($)</label>
                  <input
                    type="number"
                    step="0.25"
                    required
                    value={menuForm.price}
                    onChange={(e) => setMenuForm({ ...menuForm, price: Number(e.target.value) })}
                    className="w-full p-2.5 rounded-xl border border-stone-200 bg-stone-50"
                  />
                </div>
              </div>

              <div>
                <label className="block font-semibold mb-1">Description</label>
                <textarea
                  value={menuForm.description}
                  onChange={(e) => setMenuForm({ ...menuForm, description: e.target.value })}
                  rows={2}
                  className="w-full p-2.5 rounded-xl border border-stone-200 bg-stone-50"
                />
              </div>

              <div className="grid grid-cols-2 gap-2">
                <div>
                  <label className="block font-semibold mb-1">Initial Stock Count</label>
                  <input
                    type="number"
                    value={menuForm.stockCount}
                    onChange={(e) => setMenuForm({ ...menuForm, stockCount: Number(e.target.value) })}
                    className="w-full p-2.5 rounded-xl border border-stone-200 bg-stone-50"
                  />
                </div>

                <div>
                  <label className="block font-semibold mb-1">Prep Time (mins)</label>
                  <input
                    type="number"
                    value={menuForm.preparationTimeMinutes}
                    onChange={(e) => setMenuForm({ ...menuForm, preparationTimeMinutes: Number(e.target.value) })}
                    className="w-full p-2.5 rounded-xl border border-stone-200 bg-stone-50"
                  />
                </div>
              </div>

              <div>
                <label className="block font-semibold mb-1">Photo Image URL</label>
                <input
                  type="url"
                  value={menuForm.image}
                  onChange={(e) => setMenuForm({ ...menuForm, image: e.target.value })}
                  className="w-full p-2.5 rounded-xl border border-stone-200 bg-stone-50"
                />
              </div>

              <div className="flex justify-end gap-2 pt-2">
                <button
                  type="button"
                  onClick={() => setIsAddMenuOpen(false)}
                  className="px-4 py-2 rounded-xl bg-stone-100 text-stone-700 font-semibold"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  className="px-5 py-2 rounded-xl bg-stone-900 text-white font-bold"
                >
                  Save Item
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* Modal: Add Table */}
      {isAddTableOpen && (
        <div className="fixed inset-0 z-50 bg-black/60 backdrop-blur-xs flex items-center justify-center p-4">
          <div className="bg-white rounded-3xl max-w-sm w-full p-6 space-y-4">
            <div className="flex justify-between items-center">
              <h3 className="font-serif text-lg font-bold text-stone-900">Add Floor Table</h3>
              <button onClick={() => setIsAddTableOpen(false)} className="p-1 rounded-lg hover:bg-stone-100">
                <X className="w-5 h-5" />
              </button>
            </div>

            <form onSubmit={handleSaveTable} className="space-y-3 text-xs">
              <div>
                <label className="block font-semibold mb-1">Table Number (e.g. T-14) *</label>
                <input
                  type="text"
                  required
                  value={newTableNumber}
                  onChange={(e) => setNewTableNumber(e.target.value)}
                  className="w-full p-2.5 rounded-xl border border-stone-200 bg-stone-50 uppercase font-mono"
                />
              </div>

              <div>
                <label className="block font-semibold mb-1">Table Name</label>
                <input
                  type="text"
                  value={newTableName}
                  onChange={(e) => setNewTableName(e.target.value)}
                  placeholder="e.g. Garden Pergola 14"
                  className="w-full p-2.5 rounded-xl border border-stone-200 bg-stone-50"
                />
              </div>

              <div className="grid grid-cols-2 gap-2">
                <div>
                  <label className="block font-semibold mb-1">Seating Capacity</label>
                  <input
                    type="number"
                    min="1"
                    max="20"
                    value={newTableCapacity}
                    onChange={(e) => setNewTableCapacity(Number(e.target.value))}
                    className="w-full p-2.5 rounded-xl border border-stone-200 bg-stone-50"
                  />
                </div>

                <div>
                  <label className="block font-semibold mb-1">Zone Area</label>
                  <select
                    value={newTableZone}
                    onChange={(e) => setNewTableZone(e.target.value as any)}
                    className="w-full p-2.5 rounded-xl border border-stone-200 bg-stone-50"
                  >
                    <option value="indoor">Indoor</option>
                    <option value="patio">Terrace Patio</option>
                    <option value="booth">Booth</option>
                    <option value="lounge">Lounge</option>
                    <option value="counter">Barista Counter</option>
                  </select>
                </div>
              </div>

              <div className="flex justify-end gap-2 pt-2">
                <button
                  type="button"
                  onClick={() => setIsAddTableOpen(false)}
                  className="px-4 py-2 rounded-xl bg-stone-100 text-stone-700 font-semibold"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  className="px-5 py-2 rounded-xl bg-stone-900 text-white font-bold"
                >
                  Add Table
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* Modal: Add Promo Code */}
      {isAddPromoOpen && (
        <div className="fixed inset-0 z-50 bg-black/60 backdrop-blur-xs flex items-center justify-center p-4">
          <div className="bg-white rounded-3xl max-w-sm w-full p-6 space-y-4">
            <div className="flex justify-between items-center">
              <h3 className="font-serif text-lg font-bold text-stone-900">Create Promo Code</h3>
              <button onClick={() => setIsAddPromoOpen(false)} className="p-1 rounded-lg hover:bg-stone-100">
                <X className="w-5 h-5" />
              </button>
            </div>

            <form onSubmit={handleSavePromo} className="space-y-3 text-xs">
              <div>
                <label className="block font-semibold mb-1">Promo Code Name *</label>
                <input
                  type="text"
                  required
                  placeholder="e.g. WEEKEND25"
                  value={newPromoCode}
                  onChange={(e) => setNewPromoCode(e.target.value)}
                  className="w-full p-2.5 rounded-xl border border-stone-200 bg-stone-50 uppercase font-mono"
                />
              </div>

              <div className="grid grid-cols-2 gap-2">
                <div>
                  <label className="block font-semibold mb-1">Discount Type</label>
                  <select
                    value={newPromoType}
                    onChange={(e) => setNewPromoType(e.target.value as any)}
                    className="w-full p-2.5 rounded-xl border border-stone-200 bg-stone-50"
                  >
                    <option value="percentage">Percentage (%)</option>
                    <option value="fixed">Fixed Amount ($)</option>
                  </select>
                </div>

                <div>
                  <label className="block font-semibold mb-1">Discount Value</label>
                  <input
                    type="number"
                    value={newPromoValue}
                    onChange={(e) => setNewPromoValue(Number(e.target.value))}
                    className="w-full p-2.5 rounded-xl border border-stone-200 bg-stone-50"
                  />
                </div>
              </div>

              <div>
                <label className="block font-semibold mb-1">Min Order Amount ($)</label>
                <input
                  type="number"
                  value={newPromoMin}
                  onChange={(e) => setNewPromoMin(Number(e.target.value))}
                  className="w-full p-2.5 rounded-xl border border-stone-200 bg-stone-50"
                />
              </div>

              <div>
                <label className="block font-semibold mb-1">Short Description</label>
                <input
                  type="text"
                  placeholder="e.g. 20% off all brunch items"
                  value={newPromoDesc}
                  onChange={(e) => setNewPromoDesc(e.target.value)}
                  className="w-full p-2.5 rounded-xl border border-stone-200 bg-stone-50"
                />
              </div>

              <div className="flex justify-end gap-2 pt-2">
                <button
                  type="button"
                  onClick={() => setIsAddPromoOpen(false)}
                  className="px-4 py-2 rounded-xl bg-stone-100 text-stone-700 font-semibold"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  className="px-5 py-2 rounded-xl bg-stone-900 text-white font-bold"
                >
                  Create Code
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* Cancellation Reason Modal */}
      {cancelModalOrder && (
        <div className="fixed inset-0 z-50 bg-black/60 backdrop-blur-xs flex items-center justify-center p-4">
          <div className="bg-white rounded-3xl max-w-md w-full p-6 space-y-4 shadow-xl border border-stone-200">
            <div className="flex justify-between items-center border-b border-stone-100 pb-3">
              <div className="flex items-center gap-2">
                <div className="w-8 h-8 rounded-xl bg-rose-50 text-rose-600 flex items-center justify-center">
                  <Ban className="w-4 h-4" />
                </div>
                <div>
                  <h3 className="font-serif font-bold text-stone-900 text-base">Cancel Order #{cancelModalOrder.id}</h3>
                  <p className="text-xs text-stone-500">Customer: {cancelModalOrder.customer.name}</p>
                </div>
              </div>
              <button
                type="button"
                onClick={() => setCancelModalOrder(null)}
                className="p-1 rounded-lg text-stone-400 hover:text-stone-700 hover:bg-stone-100 cursor-pointer"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            <div className="space-y-3 text-xs">
              <p className="text-stone-600">
                Cancelling this order will release any reserved table or items and archive it to permanent order history with full audit tracking.
              </p>

              <div>
                <label className="block font-bold text-stone-700 mb-1">Cancellation Reason *</label>
                <textarea
                  rows={3}
                  value={cancelReasonInput}
                  onChange={(e) => setCancelReasonInput(e.target.value)}
                  placeholder="e.g. Customer requested cancellation within grace window / Item unavailable"
                  className="w-full p-3 rounded-xl border border-stone-200 bg-stone-50 text-stone-800 text-xs focus:ring-1 focus:ring-amber-800 outline-none"
                />
              </div>

              <div className="flex flex-wrap gap-1.5 pt-1">
                {[
                  'Customer requested (Within Grace)',
                  'Out of stock ingredients',
                  'Customer unreachable',
                  'Duplicate booking entry',
                ].map((reason) => (
                  <button
                    key={reason}
                    type="button"
                    onClick={() => setCancelReasonInput(reason)}
                    className="px-2 py-1 bg-stone-100 hover:bg-stone-200 text-stone-600 text-[11px] rounded-lg font-medium cursor-pointer"
                  >
                    {reason}
                  </button>
                ))}
              </div>

              <div className="flex justify-end gap-2 pt-3 border-t border-stone-100">
                <button
                  type="button"
                  onClick={() => setCancelModalOrder(null)}
                  className="px-4 py-2 rounded-xl bg-stone-100 hover:bg-stone-200 text-stone-700 font-semibold cursor-pointer"
                >
                  Dismiss
                </button>
                <button
                  type="button"
                  onClick={async () => {
                    if (cancelModalOrder) {
                      await cancelOrder(cancelModalOrder.id, cancelReasonInput.trim() || 'Cancelled by manager');
                      setCancelModalOrder(null);
                    }
                  }}
                  className="px-5 py-2 rounded-xl bg-rose-600 hover:bg-rose-700 text-white font-bold cursor-pointer shadow-xs"
                >
                  Confirm Cancellation
                </button>
              </div>
            </div>
          </div>
        </div>
      )}

      {/* Detailed Order View Modal (Section 3) */}
      {selectedDetailOrder && (
        <div className="fixed inset-0 z-50 bg-black/60 backdrop-blur-xs flex items-center justify-center p-4 overflow-y-auto">
          <div className="bg-white rounded-3xl max-w-2xl w-full p-5 sm:p-6 space-y-4 shadow-2xl border border-stone-200 my-8 max-h-[90vh] overflow-y-auto">
            {/* Header */}
            <div className="flex items-center justify-between border-b border-stone-100 pb-3">
              <div className="flex items-center gap-2">
                <div className="w-9 h-9 rounded-2xl bg-amber-500/10 text-amber-800 flex items-center justify-center font-bold text-sm">
                  #{selectedDetailOrder.id.slice(-4)}
                </div>
                <div>
                  <div className="flex items-center gap-2">
                    <h3 className="font-serif font-bold text-stone-900 text-lg">Order #{selectedDetailOrder.id}</h3>
                    <span className={`text-[10px] uppercase font-bold px-2 py-0.5 rounded-full ${
                      selectedDetailOrder.status === 'completed' ? 'bg-emerald-100 text-emerald-800 border border-emerald-300' :
                      selectedDetailOrder.status === 'cancelled' ? 'bg-rose-100 text-rose-800 border border-rose-300' :
                      selectedDetailOrder.status === 'ready' ? 'bg-blue-100 text-blue-800 border border-blue-300' :
                      selectedDetailOrder.status === 'preparing' ? 'bg-sky-100 text-sky-800 border border-sky-300' :
                      'bg-amber-100 text-amber-800 border border-amber-300'
                    }`}>
                      {selectedDetailOrder.status}
                    </span>
                  </div>
                  <p className="text-xs text-stone-400">
                    Placed on {new Date(selectedDetailOrder.createdAt).toLocaleDateString('en-IN', {
                      day: 'numeric',
                      month: 'short',
                      year: 'numeric',
                      hour: '2-digit',
                      minute: '2-digit'
                    })} • Mode: <span className="font-semibold text-stone-700 uppercase">{selectedDetailOrder.bookingMode}</span>
                  </p>
                </div>
              </div>
              <button
                type="button"
                onClick={() => setSelectedDetailOrder(null)}
                className="p-1.5 rounded-xl text-stone-400 hover:text-stone-700 hover:bg-stone-100 cursor-pointer"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            {/* Customer & Location Cards */}
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 text-xs">
              <div className="p-3.5 bg-stone-50 rounded-2xl border border-stone-200/80 space-y-1.5">
                <div className="flex items-center justify-between">
                  <span className="font-bold text-stone-800 flex items-center gap-1.5">
                    <UserIcon className="w-3.5 h-3.5 text-stone-500" />
                    Customer Information
                  </span>
                </div>
                <p className="text-stone-900 font-semibold">{selectedDetailOrder.customer.name}</p>
                <p className="text-stone-600 font-mono flex items-center gap-1">
                  <Smartphone className="w-3 h-3 text-stone-400" />
                  {selectedDetailOrder.customer.phone}
                </p>
                <p className="text-stone-500">{selectedDetailOrder.customer.email}</p>
                {selectedDetailOrder.userId && (
                  <p className="text-[10px] text-stone-400 font-mono pt-1 border-t border-stone-200/60">
                    User UID: {selectedDetailOrder.userId}
                  </p>
                )}
                {selectedDetailOrder.customer.specialRequests && (
                  <div className="mt-1.5 p-2 bg-amber-50/80 rounded-xl border border-amber-200 text-stone-700 italic">
                    Note: "{selectedDetailOrder.customer.specialRequests}"
                  </div>
                )}
                <div className="pt-2 flex items-center gap-2">
                  <a
                    href={`tel:${selectedDetailOrder.customer.phone}`}
                    className="flex-1 py-1.5 px-2 bg-stone-900 hover:bg-stone-800 text-white rounded-lg text-center font-bold flex items-center justify-center gap-1"
                  >
                    <PhoneCall className="w-3 h-3" />
                    Call
                  </a>
                  <a
                    href={`https://wa.me/91${selectedDetailOrder.customer.phone.replace(/\D/g, '').slice(-10)}?text=Hello%20${encodeURIComponent(selectedDetailOrder.customer.name)},%20regarding%20your%20order%20%23${selectedDetailOrder.id}%20at%20Campora%20Cafe`}
                    target="_blank"
                    rel="noopener noreferrer"
                    className="flex-1 py-1.5 px-2 bg-emerald-600 hover:bg-emerald-700 text-white rounded-lg text-center font-bold flex items-center justify-center gap-1"
                  >
                    <MessageCircle className="w-3 h-3" />
                    WhatsApp
                  </a>
                </div>
              </div>

              <div className="p-3.5 bg-stone-50 rounded-2xl border border-stone-200/80 space-y-2">
                <span className="font-bold text-stone-800 flex items-center gap-1.5">
                  {selectedDetailOrder.bookingMode === 'delivery' ? <Truck className="w-3.5 h-3.5 text-blue-600" /> :
                   selectedDetailOrder.bookingMode === 'dine-in' ? <Coffee className="w-3.5 h-3.5 text-amber-700" /> :
                   <ShoppingBag className="w-3.5 h-3.5 text-stone-600" />}
                  Fulfillment & Location Details
                </span>
                
                {selectedDetailOrder.bookingMode === 'delivery' && (
                  <div className="space-y-1 text-stone-700">
                    <p className="font-semibold text-stone-900">Campus Delivery</p>
                    <p>Hostel/Dept: <span className="font-medium text-stone-900">{selectedDetailOrder.deliveryDetails?.hostelOrBuilding || 'Campus'}</span></p>
                    <p>Room/Floor: <span className="font-medium text-stone-900">{selectedDetailOrder.deliveryDetails?.roomOrFloor || 'N/A'}</span></p>
                    <p className="text-stone-500 text-[11px]">{selectedDetailOrder.deliveryDetails?.deliveryAddress}</p>
                  </div>
                )}

                {selectedDetailOrder.bookingMode === 'dine-in' && (
                  <div className="space-y-1 text-stone-700">
                    <p className="font-semibold text-stone-900">Dine-In Reservation</p>
                    <p>Assigned Table: <span className="font-bold text-amber-900 font-mono">Table {selectedDetailOrder.dineInDetails?.tableNumber || 'Assigned'}</span></p>
                    <p>Guest Count: <span className="font-medium">{selectedDetailOrder.dineInDetails?.guestCount || 2} Guests</span></p>
                    <p>Time Slot: <span className="font-medium">{selectedDetailOrder.dineInDetails?.date} at {selectedDetailOrder.dineInDetails?.timeSlot}</span></p>
                  </div>
                )}

                {selectedDetailOrder.bookingMode === 'takeout' && (
                  <div className="space-y-1 text-stone-700">
                    <p className="font-semibold text-stone-900">Express Takeout</p>
                    <p>Ready Time: <span className="font-bold text-stone-900">{selectedDetailOrder.takeoutDetails?.pickupTime || selectedDetailOrder.estimatedReadyTime}</span></p>
                    <p className="text-stone-500">Pick up directly from Campora Cafe Counter</p>
                  </div>
                )}

                <div className="pt-2 border-t border-stone-200/60 space-y-1">
                  <div className="flex justify-between text-stone-600">
                    <span>Payment Method:</span>
                    <span className="font-bold uppercase text-stone-900">{selectedDetailOrder.paymentMethod}</span>
                  </div>
                  <div className="flex justify-between text-stone-600">
                    <span>Payment Status:</span>
                    <span className={`font-bold ${selectedDetailOrder.paymentStatus === 'paid' ? 'text-emerald-700' : 'text-amber-700'}`}>
                      {selectedDetailOrder.paymentStatus === 'paid' ? 'Paid Online/Confirmed' : 'Pay on Arrival / Counter'}
                    </span>
                  </div>
                </div>
              </div>
            </div>

            {/* Audit Timestamps & Cancellation details */}
            <div className="p-3 bg-stone-100/70 rounded-2xl text-[11px] text-stone-600 space-y-1">
              <div className="flex flex-wrap items-center justify-between gap-2">
                <span>Created: {new Date(selectedDetailOrder.createdAt).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit', second: '2-digit' })}</span>
                {selectedDetailOrder.updatedAt && (
                  <span>Updated: {new Date(selectedDetailOrder.updatedAt).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit', second: '2-digit' })}</span>
                )}
                {selectedDetailOrder.completedAt && (
                  <span className="text-emerald-700 font-semibold">Completed: {new Date(selectedDetailOrder.completedAt).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}</span>
                )}
              </div>
              {selectedDetailOrder.status === 'cancelled' && (
                <div className="p-2 bg-rose-50 rounded-xl border border-rose-200 text-rose-800 space-y-0.5 mt-1">
                  <p className="font-bold">Cancelled by: {selectedDetailOrder.cancelledBy || 'System'}</p>
                  <p className="italic">Reason: "{selectedDetailOrder.cancellationReason || 'No reason specified'}"</p>
                  {selectedDetailOrder.cancelledAt && (
                    <p className="text-[10px] text-stone-500">Cancelled at: {new Date(selectedDetailOrder.cancelledAt).toLocaleString('en-IN')}</p>
                  )}
                </div>
              )}
            </div>

            {/* Ordered Items Table with Snapshot Prices */}
            <div className="border border-stone-200 rounded-2xl overflow-hidden">
              <div className="bg-stone-50 px-4 py-2.5 border-b border-stone-200 font-bold text-xs text-stone-700 flex justify-between">
                <span>Ordered Item</span>
                <div className="flex items-center gap-6">
                  <span>Price</span>
                  <span>Qty</span>
                  <span>Subtotal</span>
                </div>
              </div>
              <div className="divide-y divide-stone-100 max-h-48 overflow-y-auto">
                {selectedDetailOrder.items.map((item) => (
                  <div key={item.cartItemId} className="px-4 py-2 text-xs flex items-center justify-between">
                    <div>
                      <span className="font-semibold text-stone-900">{item.name}</span>
                      {item.selectedSize && (
                        <span className="text-[10px] text-stone-500 ml-1.5 font-medium">
                          ({item.selectedSize.name})
                        </span>
                      )}
                      {item.selectedAddons && item.selectedAddons.length > 0 && (
                        <p className="text-[10px] text-stone-400">
                          Addons: {item.selectedAddons.map(a => a.name).join(', ')}
                        </p>
                      )}
                      {item.specialInstructions && (
                        <p className="text-[10px] text-amber-700 italic">"{item.specialInstructions}"</p>
                      )}
                    </div>
                    <div className="flex items-center gap-6 text-stone-700">
                      <span className="font-mono text-stone-500">{settings.currency}{item.calculatedPrice.toFixed(2)}</span>
                      <span className="font-bold w-6 text-center">{item.quantity}</span>
                      <span className="font-mono font-bold text-stone-900 w-16 text-right">
                        {settings.currency}{(item.calculatedPrice * item.quantity).toFixed(2)}
                      </span>
                    </div>
                  </div>
                ))}
              </div>
            </div>

            {/* Financial Summary */}
            <div className="p-3.5 bg-stone-50 rounded-2xl border border-stone-200 text-xs space-y-1.5">
              <div className="flex justify-between text-stone-600">
                <span>Subtotal ({selectedDetailOrder.items.reduce((s, i) => s + i.quantity, 0)} items):</span>
                <span className="font-mono">{settings.currency}{selectedDetailOrder.pricing.subtotal.toFixed(2)}</span>
              </div>
              {selectedDetailOrder.pricing.discountAmount > 0 && (
                <div className="flex justify-between text-emerald-700 font-medium">
                  <span>Discount ({selectedDetailOrder.pricing.discountCode || 'Promo'}):</span>
                  <span className="font-mono">-{settings.currency}{selectedDetailOrder.pricing.discountAmount.toFixed(2)}</span>
                </div>
              )}
              {selectedDetailOrder.pricing.gstTax > 0 && (
                <div className="flex justify-between text-stone-500">
                  <span>GST Tax ({settings.taxRatePercent}%):</span>
                  <span className="font-mono">{settings.currency}{selectedDetailOrder.pricing.gstTax.toFixed(2)}</span>
                </div>
              )}
              {selectedDetailOrder.pricing.deliveryFee > 0 && (
                <div className="flex justify-between text-stone-500">
                  <span>Campus Delivery Fee:</span>
                  <span className="font-mono">{settings.currency}{selectedDetailOrder.pricing.deliveryFee.toFixed(2)}</span>
                </div>
              )}
              {selectedDetailOrder.pricing.serviceFee > 0 && (
                <div className="flex justify-between text-stone-500">
                  <span>Service & Table Fee:</span>
                  <span className="font-mono">{settings.currency}{selectedDetailOrder.pricing.serviceFee.toFixed(2)}</span>
                </div>
              )}
              <div className="pt-2 border-t border-stone-200 flex justify-between font-bold text-sm text-stone-900">
                <span>Total Amount:</span>
                <span className="font-serif text-base text-stone-950">{settings.currency}{selectedDetailOrder.pricing.total.toFixed(2)}</span>
              </div>
            </div>

            {/* Admin Order Status Changer & Modal Actions */}
            <div className="pt-3 border-t border-stone-200 flex flex-wrap items-center justify-between gap-2.5">
              <div className="flex items-center gap-2">
                <span className="text-xs font-bold text-stone-700">Update Status:</span>
                <select
                  value={selectedDetailOrder.status}
                  onChange={(e) => {
                    const newStatus = e.target.value as OrderStatus;
                    updateOrderStatus(selectedDetailOrder.id, newStatus);
                    setSelectedDetailOrder((prev) => prev ? { ...prev, status: newStatus } : null);
                  }}
                  className="px-3 py-1.5 rounded-xl border border-stone-300 bg-white text-xs font-bold text-stone-800 shadow-2xs outline-none"
                >
                  <option value="confirmed">Confirmed / Pending</option>
                  <option value="preparing">Preparing in Kitchen</option>
                  <option value="ready">Ready for Pickup / Dispatch</option>
                  <option value="completed">Completed & Fulfilled</option>
                  <option value="cancelled">Cancelled</option>
                </select>
              </div>

              <div className="flex items-center gap-2">
                {selectedDetailOrder.status !== 'completed' && selectedDetailOrder.status !== 'cancelled' && (
                  <button
                    type="button"
                    onClick={() => {
                      setCancelModalOrder(selectedDetailOrder);
                      setCancelReasonInput('Cancelled by manager / staff');
                    }}
                    className="px-3 py-2 bg-rose-50 hover:bg-rose-100 text-rose-700 border border-rose-200 rounded-xl text-xs font-bold transition-colors cursor-pointer"
                  >
                    Cancel Order
                  </button>
                )}

                <button
                  type="button"
                  onClick={() => setSelectedReceiptOrder(selectedDetailOrder)}
                  className="px-4 py-2 bg-stone-900 hover:bg-stone-800 text-white rounded-xl text-xs font-bold transition-colors cursor-pointer flex items-center gap-1.5 shadow-xs"
                >
                  <Receipt className="w-3.5 h-3.5 text-amber-400" />
                  <span>Print Receipt</span>
                </button>

                <button
                  type="button"
                  onClick={() => setSelectedDetailOrder(null)}
                  className="px-4 py-2 bg-stone-100 hover:bg-stone-200 text-stone-700 rounded-xl text-xs font-semibold cursor-pointer"
                >
                  Close
                </button>
              </div>
            </div>

          </div>
        </div>
      )}

      {/* Order Receipt Modal */}
      {selectedReceiptOrder && (
        <OrderReceiptModal
          order={selectedReceiptOrder}
          isOpen={!!selectedReceiptOrder}
          onClose={() => setSelectedReceiptOrder(null)}
          settings={settings}
        />
      )}

      {/* Counter / Walk-in Sale Modal */}
      <CounterSaleModal
        isOpen={isCounterSaleModalOpen}
        onClose={() => setIsCounterSaleModalOpen(false)}
      />

    </div>
  );
};
