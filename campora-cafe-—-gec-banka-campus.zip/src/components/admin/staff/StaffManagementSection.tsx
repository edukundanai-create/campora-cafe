import React, { useState, useMemo } from 'react';
import {
  Users,
  UserPlus,
  ShieldCheck,
  Search,
  Filter,
  Phone,
  Mail,
  Calendar,
  MoreVertical,
  CheckCircle2,
  XCircle,
  AlertCircle,
  Clock,
  Eye,
  Edit3,
  UserX,
  UserCheck,
  Shield,
  Briefcase,
  LogIn,
  IdCard,
  FileSpreadsheet,
  AlertTriangle
} from 'lucide-react';
import { StaffMember, StaffAuditLog, StaffRole, StaffStatus, StaffPermission } from '../../../types';
import { StaffRegistrationModal } from './StaffRegistrationModal';
import { StaffProfileModal } from './StaffProfileModal';
import { StaffAuditLogsView } from './StaffAuditLogsView';

interface StaffManagementSectionProps {
  staffMembers: StaffMember[];
  auditLogs: StaffAuditLog[];
  onAddStaff: (staffData: Omit<StaffMember, 'id' | 'createdAt'>, password?: string) => Promise<StaffMember>;
  onUpdateStaff: (staffId: string, updates: Partial<StaffMember>) => Promise<void>;
  onToggleStatus: (staffId: string, status: StaffStatus) => Promise<void>;
  onDeleteStaff: (staffId: string) => Promise<void>;
  onSimulateStaffLogin?: (staff: StaffMember) => Promise<void>;
  currentStaff: StaffMember | null;
  hasPermission: (perm: StaffPermission) => boolean;
  isAdminUser: boolean;
}

export const StaffManagementSection: React.FC<StaffManagementSectionProps> = ({
  staffMembers,
  auditLogs,
  onAddStaff,
  onUpdateStaff,
  onToggleStatus,
  onDeleteStaff,
  onSimulateStaffLogin,
  currentStaff,
  hasPermission,
  isAdminUser
}) => {
  const [activeTab, setActiveTab] = useState<'directory' | 'audit_logs'>('directory');
  const [searchQuery, setSearchQuery] = useState('');
  const [roleFilter, setRoleFilter] = useState<string>('all');
  const [statusFilter, setStatusFilter] = useState<string>('all');
  
  // Modals state
  const [isAddModalOpen, setIsAddModalOpen] = useState(false);
  const [editingStaff, setEditingStaff] = useState<StaffMember | null>(null);
  const [viewingStaff, setViewingStaff] = useState<StaffMember | null>(null);

  const canManageStaff = hasPermission('manage_staff') || isAdminUser;

  // Statistics calculation
  const totalCount = staffMembers.length;
  const activeCount = staffMembers.filter(s => s.status === 'active').length;
  const inactiveCount = staffMembers.filter(s => s.status === 'inactive' || s.status === 'suspended').length;
  const managerCount = staffMembers.filter(s => s.role === 'manager' || s.role === 'owner').length;
  const staffRoleCount = staffMembers.filter(s => s.role === 'staff').length;

  const filteredStaff = useMemo(() => {
    return staffMembers.filter(staff => {
      // Search
      if (searchQuery.trim()) {
        const q = searchQuery.toLowerCase();
        const matchesName = staff.fullName.toLowerCase().includes(q);
        const matchesId = staff.staffId.toLowerCase().includes(q);
        const matchesPosition = staff.position.toLowerCase().includes(q);
        const matchesPhone = staff.mobile.toLowerCase().includes(q);
        const matchesEmail = staff.email.toLowerCase().includes(q);
        if (!matchesName && !matchesId && !matchesPosition && !matchesPhone && !matchesEmail) return false;
      }

      // Role filter
      if (roleFilter !== 'all' && staff.role !== roleFilter) return false;

      // Status filter
      if (statusFilter !== 'all' && staff.status !== statusFilter) return false;

      return true;
    });
  }, [staffMembers, searchQuery, roleFilter, statusFilter]);

  const handleOpenAddModal = () => {
    setEditingStaff(null);
    setIsAddModalOpen(true);
  };

  const handleOpenEditModal = (staff: StaffMember) => {
    setEditingStaff(staff);
    setIsAddModalOpen(true);
  };

  const handleOpenProfileModal = (staff: StaffMember) => {
    setViewingStaff(staff);
  };

  return (
    <div className="space-y-6">
      
      {/* Top Banner & Stats Overview */}
      <div className="bg-gradient-to-r from-stone-900 via-stone-850 to-stone-900 rounded-3xl p-6 text-white border border-stone-800 shadow-xl">
        <div className="flex flex-col lg:flex-row items-start lg:items-center justify-between gap-6">
          <div className="space-y-2">
            <div className="flex items-center gap-2 text-xs font-bold uppercase tracking-widest text-amber-400">
              <ShieldCheck className="w-4 h-4" />
              <span>Campus Staff Management & RBAC System</span>
            </div>
            <h2 className="font-serif text-2xl font-bold text-white">
              Campus Staff Directory & Role-Based Access Control
            </h2>
            <p className="text-xs text-stone-300 max-w-2xl leading-relaxed">
              Authorized Owner/Admin control center for registering campus staff members, assigning granular operational permissions, supervising duties, and inspecting the tamper-evident operational audit trail.
            </p>
          </div>

          {/* Prominent Add Staff Button */}
          <div className="flex items-center gap-3 shrink-0">
            {canManageStaff ? (
              <button
                onClick={handleOpenAddModal}
                className="px-5 py-3 rounded-2xl bg-amber-500 hover:bg-amber-400 text-stone-950 font-bold text-sm shadow-lg shadow-amber-500/20 flex items-center gap-2 transition-all hover:scale-102 active:scale-98 cursor-pointer"
              >
                <UserPlus className="w-5 h-5" />
                <span>Add Staff</span>
              </button>
            ) : (
              <div className="px-4 py-2.5 rounded-xl bg-white/10 text-stone-300 text-xs font-semibold flex items-center gap-2">
                <Shield className="w-4 h-4 text-amber-400" />
                <span>View Only • Restricted to Owner/Admin</span>
              </div>
            )}
          </div>
        </div>

        {/* Stats Metrics Cards */}
        <div className="grid grid-cols-2 sm:grid-cols-4 gap-3.5 mt-6 pt-6 border-t border-stone-800 text-stone-200">
          <div className="p-3 rounded-2xl bg-white/5 border border-white/10">
            <div className="text-[10px] uppercase font-bold text-stone-400 tracking-wider">Total Staff Members</div>
            <div className="text-2xl font-serif font-bold text-white mt-1">{totalCount}</div>
            <div className="text-[10px] text-stone-400 mt-0.5">Enrolled in roster</div>
          </div>

          <div className="p-3 rounded-2xl bg-emerald-950/30 border border-emerald-500/20">
            <div className="text-[10px] uppercase font-bold text-emerald-400 tracking-wider">Active Staff</div>
            <div className="text-2xl font-serif font-bold text-emerald-300 mt-1">{activeCount}</div>
            <div className="text-[10px] text-emerald-400/80 mt-0.5">Authorized for duty</div>
          </div>

          <div className="p-3 rounded-2xl bg-amber-950/30 border border-amber-500/20">
            <div className="text-[10px] uppercase font-bold text-amber-400 tracking-wider">Supervisors / Managers</div>
            <div className="text-2xl font-serif font-bold text-amber-300 mt-1">{managerCount}</div>
            <div className="text-[10px] text-amber-400/80 mt-0.5">{staffRoleCount} floor staff</div>
          </div>

          <div className="p-3 rounded-2xl bg-stone-800/40 border border-stone-700/50">
            <div className="text-[10px] uppercase font-bold text-stone-400 tracking-wider">Inactive / Leave</div>
            <div className="text-2xl font-serif font-bold text-stone-300 mt-1">{inactiveCount}</div>
            <div className="text-[10px] text-stone-400 mt-0.5">Access disabled</div>
          </div>
        </div>
      </div>

      {/* Navigation Sub-Tabs */}
      <div className="flex items-center justify-between border-b border-stone-200 pb-2">
        <div className="flex items-center gap-2">
          <button
            onClick={() => setActiveTab('directory')}
            className={`px-4 py-2 rounded-xl text-xs font-bold flex items-center gap-2 transition-all cursor-pointer ${
              activeTab === 'directory'
                ? 'bg-stone-900 text-white shadow-md'
                : 'bg-stone-100 text-stone-600 hover:bg-stone-200'
            }`}
          >
            <Users className="w-4 h-4" />
            <span>Staff Directory ({filteredStaff.length})</span>
          </button>

          <button
            onClick={() => setActiveTab('audit_logs')}
            className={`px-4 py-2 rounded-xl text-xs font-bold flex items-center gap-2 transition-all cursor-pointer ${
              activeTab === 'audit_logs'
                ? 'bg-stone-900 text-white shadow-md'
                : 'bg-stone-100 text-stone-600 hover:bg-stone-200'
            }`}
          >
            <Clock className="w-4 h-4" />
            <span>Activity & Audit Log ({auditLogs.length})</span>
          </button>
        </div>

        {activeTab === 'directory' && canManageStaff && (
          <button
            onClick={handleOpenAddModal}
            className="text-xs font-bold text-amber-700 hover:text-amber-800 flex items-center gap-1 cursor-pointer"
          >
            <UserPlus className="w-3.5 h-3.5" /> ➕ Add Staff
          </button>
        )}
      </div>

      {/* TAB 1: STAFF DIRECTORY */}
      {activeTab === 'directory' && (
        <div className="space-y-4">
          
          {/* Search and Filters Bar */}
          <div className="bg-white p-4 rounded-2xl border border-stone-200 shadow-xs flex flex-col sm:flex-row items-center justify-between gap-3">
            <div className="relative w-full sm:w-80">
              <Search className="w-4 h-4 absolute left-3 top-3 text-stone-400" />
              <input
                type="text"
                placeholder="Search staff by name, ID, phone, position..."
                value={searchQuery}
                onChange={e => setSearchQuery(e.target.value)}
                className="w-full pl-9 pr-3.5 py-2 text-xs rounded-xl border border-stone-300 bg-stone-50 focus:bg-white focus:border-amber-500 outline-hidden transition-all"
              />
            </div>

            <div className="flex flex-wrap items-center gap-2 w-full sm:w-auto justify-end">
              {/* Role filter */}
              <div className="flex items-center gap-1.5">
                <span className="text-[11px] font-bold text-stone-500">Role:</span>
                <select
                  value={roleFilter}
                  onChange={e => setRoleFilter(e.target.value)}
                  className="px-2.5 py-1.5 text-xs rounded-xl border border-stone-300 bg-stone-50 text-stone-800 font-semibold outline-hidden"
                >
                  <option value="all">All Roles</option>
                  <option value="owner">Owner</option>
                  <option value="manager">Manager</option>
                  <option value="staff">Staff</option>
                </select>
              </div>

              {/* Status filter */}
              <div className="flex items-center gap-1.5">
                <span className="text-[11px] font-bold text-stone-500">Status:</span>
                <select
                  value={statusFilter}
                  onChange={e => setStatusFilter(e.target.value)}
                  className="px-2.5 py-1.5 text-xs rounded-xl border border-stone-300 bg-stone-50 text-stone-800 font-semibold outline-hidden"
                >
                  <option value="all">All Statuses</option>
                  <option value="active">Active Only</option>
                  <option value="inactive">Inactive</option>
                  <option value="suspended">Suspended</option>
                </select>
              </div>

              {(searchQuery || roleFilter !== 'all' || statusFilter !== 'all') && (
                <button
                  onClick={() => {
                    setSearchQuery('');
                    setRoleFilter('all');
                    setStatusFilter('all');
                  }}
                  className="text-xs text-amber-700 font-bold hover:underline cursor-pointer ml-1"
                >
                  Reset
                </button>
              )}
            </div>
          </div>

          {/* Staff Cards Grid */}
          {filteredStaff.length === 0 ? (
            <div className="p-12 text-center bg-white rounded-3xl border border-stone-200 shadow-xs space-y-3">
              <Users className="w-10 h-10 mx-auto text-stone-300" />
              <h3 className="font-serif text-lg font-bold text-stone-800">No staff members found</h3>
              <p className="text-xs text-stone-500 max-w-md mx-auto">
                No staff records match your current search query or active filter settings.
              </p>
              {canManageStaff && (
                <button
                  onClick={handleOpenAddModal}
                  className="px-4 py-2 rounded-xl bg-amber-500 hover:bg-amber-400 text-stone-950 text-xs font-bold inline-flex items-center gap-1.5 cursor-pointer shadow-xs"
                >
                  <UserPlus className="w-4 h-4" /> Add New Staff Member
                </button>
              )}
            </div>
          ) : (
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
              {filteredStaff.map(staff => {
                const isActive = staff.status === 'active';
                const isOwner = staff.role === 'owner';
                const isManager = staff.role === 'manager';

                return (
                  <div
                    key={staff.id}
                    className={`bg-white rounded-2xl border transition-all duration-200 overflow-hidden flex flex-col justify-between shadow-xs hover:shadow-md ${
                      !isActive
                        ? 'border-stone-200 opacity-75'
                        : isOwner
                        ? 'border-amber-300 ring-1 ring-amber-200'
                        : 'border-stone-200 hover:border-amber-400'
                    }`}
                  >
                    {/* Card Header */}
                    <div className="p-4 pb-3">
                      <div className="flex items-start gap-3.5">
                        {/* Avatar */}
                        <div className="w-14 h-14 rounded-2xl overflow-hidden bg-stone-100 border border-stone-200 shrink-0 flex items-center justify-center shadow-xs">
                          {staff.photoUrl ? (
                            <img src={staff.photoUrl} alt={staff.fullName} className="w-full h-full object-cover" />
                          ) : (
                            <span className="font-serif font-bold text-lg text-amber-700">
                              {staff.fullName.charAt(0).toUpperCase()}
                            </span>
                          )}
                        </div>

                        {/* Title & Badges */}
                        <div className="flex-1 min-w-0">
                          <div className="flex items-center justify-between gap-1">
                            <h3 className="font-serif font-bold text-stone-900 text-sm truncate">
                              {staff.fullName}
                            </h3>
                            {isActive ? (
                              <span className="inline-flex items-center gap-1 px-2 py-0.5 rounded-full text-[9px] font-bold bg-emerald-100 text-emerald-800">
                                <span className="w-1.5 h-1.5 rounded-full bg-emerald-500" /> Active
                              </span>
                            ) : (
                              <span className="inline-flex items-center gap-1 px-2 py-0.5 rounded-full text-[9px] font-bold bg-stone-100 text-stone-600">
                                <span className="w-1.5 h-1.5 rounded-full bg-stone-400" /> {staff.status}
                              </span>
                            )}
                          </div>

                          <div className="flex items-center gap-1.5 mt-1 flex-wrap">
                            <span className="font-mono text-[10px] font-bold bg-stone-100 text-stone-700 px-1.5 py-0.2 rounded">
                              {staff.staffId}
                            </span>
                            <span className="text-[11px] font-semibold text-stone-600">
                              {staff.position}
                            </span>
                            <span className={`text-[9px] uppercase font-bold px-1.5 py-0.2 rounded ${
                              isOwner
                                ? 'bg-amber-100 text-amber-800'
                                : isManager
                                ? 'bg-blue-100 text-blue-800'
                                : 'bg-stone-100 text-stone-700'
                            }`}>
                              {staff.role}
                            </span>
                          </div>
                        </div>
                      </div>

                      {/* Contact and Metadata */}
                      <div className="mt-3.5 pt-3 border-t border-stone-100 space-y-1.5 text-xs text-stone-600">
                        <div className="flex items-center gap-2">
                          <Phone className="w-3.5 h-3.5 text-stone-400 shrink-0" />
                          <span className="font-medium text-stone-800">{staff.mobile}</span>
                        </div>
                        <div className="flex items-center gap-2">
                          <Mail className="w-3.5 h-3.5 text-stone-400 shrink-0" />
                          <span className="truncate text-stone-600">{staff.email}</span>
                        </div>
                        <div className="flex items-center justify-between text-[11px] text-stone-400 pt-1">
                          <span className="flex items-center gap-1">
                            <Calendar className="w-3 h-3 text-stone-400" />
                            Joined: {staff.dateOfJoining}
                          </span>
                          {staff.idProofType && (
                            <span className="flex items-center gap-1 text-emerald-700 font-medium">
                              <IdCard className="w-3 h-3" /> {staff.idProofType} verified
                            </span>
                          )}
                        </div>
                      </div>

                      {/* Permissions overview chips */}
                      <div className="mt-3 pt-2.5 border-t border-stone-100">
                        <div className="text-[10px] uppercase font-bold text-stone-400 mb-1.5 flex items-center justify-between">
                          <span>Granted Permissions</span>
                          <span className="font-mono text-stone-600 font-bold">{staff.permissions.length} items</span>
                        </div>
                        <div className="flex flex-wrap gap-1">
                          {staff.permissions.slice(0, 3).map(p => (
                            <span
                              key={p}
                              className="px-2 py-0.5 rounded-md bg-stone-100 text-stone-700 text-[9.5px] font-medium"
                            >
                              {p.replace(/_/g, ' ')}
                            </span>
                          ))}
                          {staff.permissions.length > 3 && (
                            <span className="px-1.5 py-0.5 rounded-md bg-amber-50 text-amber-800 font-bold text-[9.5px]">
                              +{staff.permissions.length - 3} more
                            </span>
                          )}
                        </div>
                      </div>
                    </div>

                    {/* Card Actions Footer */}
                    <div className="p-3 bg-stone-50/80 border-t border-stone-200 flex items-center justify-between gap-1.5">
                      <button
                        onClick={() => handleOpenProfileModal(staff)}
                        className="px-2.5 py-1.5 rounded-xl bg-white hover:bg-stone-200 text-stone-800 text-xs font-bold flex items-center gap-1 border border-stone-300 shadow-2xs transition-colors cursor-pointer"
                      >
                        <Eye className="w-3.5 h-3.5 text-stone-600" />
                        <span>View Profile</span>
                      </button>

                      <div className="flex items-center gap-1">
                        {canManageStaff && (
                          <button
                            onClick={() => handleOpenEditModal(staff)}
                            className="p-1.5 rounded-xl hover:bg-stone-200 text-stone-600 hover:text-stone-900 transition-colors cursor-pointer"
                            title="Edit Staff Info & Permissions"
                          >
                            <Edit3 className="w-3.5 h-3.5" />
                          </button>
                        )}

                        {canManageStaff && !isOwner && (
                          <button
                            onClick={() => onToggleStatus(staff.id, isActive ? 'inactive' : 'active')}
                            className={`p-1.5 rounded-xl transition-colors cursor-pointer ${
                              isActive
                                ? 'text-stone-500 hover:text-red-600 hover:bg-red-50'
                                : 'text-stone-500 hover:text-emerald-600 hover:bg-emerald-50'
                            }`}
                            title={isActive ? 'Deactivate Staff' : 'Activate Staff'}
                          >
                            {isActive ? <UserX className="w-3.5 h-3.5" /> : <UserCheck className="w-3.5 h-3.5" />}
                          </button>
                        )}

                        {onSimulateStaffLogin && isActive && (
                          <button
                            onClick={() => onSimulateStaffLogin(staff)}
                            className="px-2 py-1 rounded-xl bg-amber-500/15 hover:bg-amber-500 text-amber-900 hover:text-stone-950 font-bold text-[10px] flex items-center gap-1 transition-all cursor-pointer"
                            title={`Test Staff Portal as ${staff.fullName}`}
                          >
                            <LogIn className="w-3 h-3" />
                            <span>Login View</span>
                          </button>
                        )}
                      </div>
                    </div>

                  </div>
                );
              })}
            </div>
          )}

        </div>
      )}

      {/* TAB 2: AUDIT LOGS */}
      {activeTab === 'audit_logs' && (
        <StaffAuditLogsView
          logs={auditLogs}
          staffMembers={staffMembers}
        />
      )}

      {/* Registration / Edit Modal */}
      {isAddModalOpen && (
        <StaffRegistrationModal
          isOpen={isAddModalOpen}
          onClose={() => setIsAddModalOpen(false)}
          onSave={async (data, password) => {
            if (editingStaff) {
              await onUpdateStaff(editingStaff.id, data);
            } else {
              await onAddStaff(data, password);
            }
          }}
          editingStaff={editingStaff}
          existingStaffList={staffMembers}
        />
      )}

      {/* Staff Profile Modal */}
      {viewingStaff && (
        <StaffProfileModal
          isOpen={!!viewingStaff}
          onClose={() => setViewingStaff(null)}
          staff={viewingStaff}
          auditLogs={auditLogs}
          onEdit={staff => {
            setViewingStaff(null);
            handleOpenEditModal(staff);
          }}
          onToggleStatus={onToggleStatus}
          onDelete={onDeleteStaff}
          onSimulateLogin={onSimulateStaffLogin}
          isCurrentUserOwnerOrAdmin={canManageStaff}
        />
      )}

    </div>
  );
};
