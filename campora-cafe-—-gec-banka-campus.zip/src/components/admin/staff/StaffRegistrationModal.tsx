import React, { useState, useEffect } from 'react';
import {
  X,
  UserPlus,
  ShieldCheck,
  Upload,
  Image as ImageIcon,
  FileText,
  Lock,
  Sparkles,
  Check,
  AlertCircle,
  Phone,
  Mail,
  Calendar,
  MapPin,
  Briefcase,
  IdCard,
  Eye,
  EyeOff
} from 'lucide-react';
import {
  StaffMember,
  StaffPosition,
  StaffRole,
  StaffStatus,
  IdProofType,
  StaffPermission
} from '../../../types';

interface StaffRegistrationModalProps {
  isOpen: boolean;
  onClose: () => void;
  onSave: (staffData: Omit<StaffMember, 'id' | 'createdAt'>, password?: string) => Promise<void>;
  editingStaff?: StaffMember | null;
  existingStaffList: StaffMember[];
}

const ALL_PERMISSIONS: { key: StaffPermission; label: string; description: string; category: string }[] = [
  { key: 'view_orders', label: 'View Orders', description: 'View live customer orders and table booking requests', category: 'Orders' },
  { key: 'update_order_status', label: 'Update Order Status', description: 'Transition orders from confirmed to preparing, ready, completed', category: 'Orders' },
  { key: 'create_counter_sale', label: 'Create Counter Sale', description: 'Punch manual counter sales for walk-ins and collect payments', category: 'Counter' },
  { key: 'view_counter_sales', label: 'View Counter Sales', description: 'Browse walk-in cash and UPI counter transactions log', category: 'Counter' },
  { key: 'manage_tables', label: 'Manage Tables', description: 'Update table occupancy, reserved, cleaning, and available states', category: 'Operations' },
  { key: 'manage_menu', label: 'Add/Edit Menu Items', description: 'Create, update pricing, tags, and stock for café menu items', category: 'Menu' },
  { key: 'change_cafe_status', label: 'Change Café Open/Closed Status', description: 'Toggle live café open/closed switch for the campus', category: 'Operations' },
  { key: 'view_customer_info', label: 'View Customer Information', description: 'Access customer delivery phone numbers and campus hostel/room info', category: 'CRM' },
  { key: 'view_crm', label: 'View CRM', description: 'Access customer records, loyalty tiers, and order frequency', category: 'CRM' },
  { key: 'view_sales_reports', label: 'View Sales Reports', description: 'Access financial revenue breakdowns and sales analytics charts', category: 'Reports' },
  { key: 'manage_staff', label: 'Manage Staff', description: 'Add, edit, change permissions, or deactivate staff members', category: 'Administration' },
  { key: 'manage_settings', label: 'Access Cafe Settings', description: 'Configure UPI payment VPA, tax rates, operating hours, and announcements', category: 'Administration' }
];

const POSITION_PRESETS: Record<string, { role: StaffRole; permissions: StaffPermission[] }> = {
  'Cashier': {
    role: 'staff',
    permissions: ['view_orders', 'create_counter_sale', 'view_counter_sales', 'manage_tables']
  },
  'Kitchen Staff': {
    role: 'staff',
    permissions: ['view_orders', 'update_order_status', 'manage_tables']
  },
  'Counter Staff': {
    role: 'staff',
    permissions: ['view_orders', 'create_counter_sale', 'view_counter_sales', 'manage_tables']
  },
  'Café Staff': {
    role: 'staff',
    permissions: ['view_orders', 'update_order_status', 'create_counter_sale', 'view_counter_sales', 'manage_tables']
  },
  'Manager': {
    role: 'manager',
    permissions: [
      'view_orders',
      'update_order_status',
      'create_counter_sale',
      'view_counter_sales',
      'manage_menu',
      'manage_tables',
      'view_customer_info',
      'view_crm',
      'view_sales_reports',
      'change_cafe_status'
    ]
  },
  'Owner / Administrator': {
    role: 'owner',
    permissions: ALL_PERMISSIONS.map(p => p.key)
  }
};

export const StaffRegistrationModal: React.FC<StaffRegistrationModalProps> = ({
  isOpen,
  onClose,
  onSave,
  editingStaff,
  existingStaffList
}) => {
  const [fullName, setFullName] = useState('');
  const [mobile, setMobile] = useState('');
  const [email, setEmail] = useState('');
  const [staffId, setStaffId] = useState('');
  const [dateOfJoining, setDateOfJoining] = useState(new Date().toISOString().split('T')[0]);
  const [role, setRole] = useState<StaffRole>('staff');
  const [position, setPosition] = useState<StaffPosition | string>('Café Staff');
  const [customPosition, setCustomPosition] = useState('');
  const [status, setStatus] = useState<StaffStatus>('active');
  const [address, setAddress] = useState('');
  const [emergencyContact, setEmergencyContact] = useState('');
  const [idProofType, setIdProofType] = useState<IdProofType>('College ID');
  const [idProofNumber, setIdProofNumber] = useState('');
  const [idProofDocumentUrl, setIdProofDocumentUrl] = useState<string | undefined>(undefined);
  const [idProofFileName, setIdProofFileName] = useState<string>('');
  const [photoUrl, setPhotoUrl] = useState('');
  const [notes, setNotes] = useState('');
  const [password, setPassword] = useState('');
  const [showPassword, setShowPassword] = useState(false);
  const [permissions, setPermissions] = useState<StaffPermission[]>([
    'view_orders',
    'update_order_status',
    'create_counter_sale',
    'view_counter_sales',
    'manage_tables'
  ]);
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [validationError, setValidationError] = useState<string | null>(null);

  // Generate next unique Staff ID
  const generateNextStaffId = () => {
    const nextNumber = 101 + existingStaffList.length;
    return `CC-STF-${nextNumber}`;
  };

  useEffect(() => {
    if (editingStaff) {
      setFullName(editingStaff.fullName || '');
      setMobile(editingStaff.mobile || '');
      setEmail(editingStaff.email || '');
      setStaffId(editingStaff.staffId || '');
      setDateOfJoining(editingStaff.dateOfJoining || new Date().toISOString().split('T')[0]);
      setRole(editingStaff.role || 'staff');
      if (['Café Staff', 'Cashier', 'Kitchen Staff', 'Counter Staff', 'Manager'].includes(editingStaff.position as string)) {
        setPosition(editingStaff.position);
        setCustomPosition('');
      } else {
        setPosition('Other');
        setCustomPosition(editingStaff.position || '');
      }
      setStatus(editingStaff.status || 'active');
      setAddress(editingStaff.address || '');
      setEmergencyContact(editingStaff.emergencyContact || '');
      setIdProofType(editingStaff.idProofType || 'College ID');
      setIdProofNumber(editingStaff.idProofNumber || '');
      setIdProofDocumentUrl(editingStaff.idProofDocumentUrl);
      setPhotoUrl(editingStaff.photoUrl || '');
      setNotes(editingStaff.notes || '');
      setPermissions(editingStaff.permissions || []);
      setPassword('');
    } else {
      // New staff defaults
      setFullName('');
      setMobile('');
      setEmail('');
      setStaffId(generateNextStaffId());
      setDateOfJoining(new Date().toISOString().split('T')[0]);
      setRole('staff');
      setPosition('Café Staff');
      setCustomPosition('');
      setStatus('active');
      setAddress('');
      setEmergencyContact('');
      setIdProofType('College ID');
      setIdProofNumber('');
      setIdProofDocumentUrl(undefined);
      setIdProofFileName('');
      setPhotoUrl('');
      setNotes('');
      setPassword('CamporaStaff2026!');
      setPermissions([
        'view_orders',
        'update_order_status',
        'create_counter_sale',
        'view_counter_sales',
        'manage_tables'
      ]);
    }
    setValidationError(null);
  }, [editingStaff, isOpen]);

  const handlePositionChange = (pos: string) => {
    setPosition(pos as any);
    const preset = POSITION_PRESETS[pos];
    if (preset) {
      setRole(preset.role);
      setPermissions(preset.permissions);
    }
  };

  const applyPreset = (presetName: string) => {
    const preset = POSITION_PRESETS[presetName];
    if (preset) {
      setRole(preset.role);
      setPermissions(preset.permissions);
    }
  };

  const togglePermission = (key: StaffPermission) => {
    setPermissions(prev =>
      prev.includes(key) ? prev.filter(k => k !== key) : [...prev, key]
    );
  };

  const handleSelectAllPermissions = () => {
    setPermissions(ALL_PERMISSIONS.map(p => p.key));
  };

  const handleClearPermissions = () => {
    setPermissions([]);
  };

  const handleDocumentFileUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;

    if (file.size > 3 * 1024 * 1024) {
      setValidationError('Document size should be less than 3MB.');
      return;
    }

    setIdProofFileName(file.name);
    const reader = new FileReader();
    reader.onload = () => {
      setIdProofDocumentUrl(reader.result as string);
    };
    reader.readAsDataURL(file);
  };

  const handlePhotoFileUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;

    if (file.size > 2 * 1024 * 1024) {
      setValidationError('Photo size should be less than 2MB.');
      return;
    }

    const reader = new FileReader();
    reader.onload = () => {
      setPhotoUrl(reader.result as string);
    };
    reader.readAsDataURL(file);
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setValidationError(null);

    if (!fullName.trim()) {
      setValidationError('Please enter staff member full name.');
      return;
    }

    if (!mobile.trim()) {
      setValidationError('Please provide staff mobile contact number.');
      return;
    }

    if (!email.trim() || !email.includes('@')) {
      setValidationError('Please provide a valid staff login email address.');
      return;
    }

    if (!staffId.trim()) {
      setValidationError('Staff ID cannot be empty.');
      return;
    }

    // Check duplicate staffId or email among other staff
    const duplicate = existingStaffList.find(
      s => (!editingStaff || s.id !== editingStaff.id) &&
           (s.staffId.toLowerCase() === staffId.trim().toLowerCase() ||
            s.email.toLowerCase() === email.trim().toLowerCase())
    );
    if (duplicate) {
      if (duplicate.staffId.toLowerCase() === staffId.trim().toLowerCase()) {
        setValidationError(`Staff ID ${staffId} is already assigned to ${duplicate.fullName}.`);
        return;
      }
      if (duplicate.email.toLowerCase() === email.trim().toLowerCase()) {
        setValidationError(`Email address ${email} is already used by staff member ${duplicate.fullName}.`);
        return;
      }
    }

    const finalPosition = position === 'Other' ? (customPosition.trim() || 'Other') : position;

    setIsSubmitting(true);
    try {
      await onSave({
        staffId: staffId.trim().toUpperCase(),
        fullName: fullName.trim(),
        mobile: mobile.trim(),
        email: email.trim().toLowerCase(),
        dateOfJoining,
        role,
        position: finalPosition,
        status,
        address: address.trim() || undefined,
        emergencyContact: emergencyContact.trim() || undefined,
        idProofType,
        idProofNumber: idProofNumber.trim() || undefined,
        idProofDocumentUrl,
        photoUrl: photoUrl.trim() || undefined,
        notes: notes.trim() || undefined,
        permissions,
        lastLoginAt: editingStaff?.lastLoginAt
      }, password.trim() || undefined);
      onClose();
    } catch (err: any) {
      setValidationError(err?.message || 'Failed to save staff record. Please review inputs.');
    } finally {
      setIsSubmitting(false);
    }
  };

  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 z-50 bg-black/60 backdrop-blur-xs flex items-center justify-center p-3 sm:p-4 overflow-y-auto">
      <div className="bg-white rounded-3xl max-w-3xl w-full my-8 shadow-2xl border border-stone-200 overflow-hidden flex flex-col max-h-[92vh]">
        
        {/* Modal Header */}
        <div className="px-6 py-4.5 bg-gradient-to-r from-stone-900 via-stone-850 to-stone-900 text-white flex items-center justify-between border-b border-stone-800 shrink-0">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-2xl bg-amber-500/20 border border-amber-500/30 flex items-center justify-center text-amber-400">
              <UserPlus className="w-5 h-5" />
            </div>
            <div>
              <h2 className="font-serif text-lg font-bold text-amber-400 flex items-center gap-2">
                {editingStaff ? 'Edit Staff Profile & Authority' : 'Register New Campus Staff Member'}
              </h2>
              <p className="text-xs text-stone-400">
                Authorized Owner & Admin Campus Staff Management System
              </p>
            </div>
          </div>
          <button
            onClick={onClose}
            className="p-1.5 rounded-xl hover:bg-stone-800 text-stone-400 hover:text-white transition-colors cursor-pointer"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Modal Form Body */}
        <form onSubmit={handleSubmit} className="p-6 overflow-y-auto space-y-6 text-stone-800 text-xs">
          
          {validationError && (
            <div className="p-3.5 rounded-2xl bg-red-50 border border-red-200 flex items-start gap-2.5 text-red-700">
              <AlertCircle className="w-4 h-4 shrink-0 mt-0.5 text-red-600" />
              <div className="text-xs font-medium">{validationError}</div>
            </div>
          )}

          {/* SECTION 1: PRIMARY IDENTITY & CREDENTIALS */}
          <div className="space-y-3">
            <div className="flex items-center gap-2 pb-1 border-b border-stone-200">
              <ShieldCheck className="w-4 h-4 text-amber-600" />
              <h3 className="font-bold text-stone-900 text-sm">Primary Identity & Staff Account</h3>
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-2 gap-3.5">
              <div>
                <label className="block font-semibold text-stone-700 mb-1">
                  Full Name <span className="text-amber-600">*</span>
                </label>
                <input
                  type="text"
                  required
                  placeholder="e.g. Rahul Kumar"
                  value={fullName}
                  onChange={e => setFullName(e.target.value)}
                  className="w-full px-3.5 py-2.5 rounded-xl border border-stone-300 bg-stone-50 focus:bg-white focus:border-amber-500 focus:ring-2 focus:ring-amber-200 outline-hidden transition-all"
                />
              </div>

              <div>
                <label className="block font-semibold text-stone-700 mb-1">
                  Mobile Contact Number <span className="text-amber-600">*</span>
                </label>
                <div className="relative">
                  <Phone className="w-4 h-4 absolute left-3 top-3 text-stone-400" />
                  <input
                    type="tel"
                    required
                    placeholder="+91 98765 43210"
                    value={mobile}
                    onChange={e => setMobile(e.target.value)}
                    className="w-full pl-9 pr-3.5 py-2.5 rounded-xl border border-stone-300 bg-stone-50 focus:bg-white focus:border-amber-500 focus:ring-2 focus:ring-amber-200 outline-hidden transition-all"
                  />
                </div>
              </div>

              <div>
                <label className="block font-semibold text-stone-700 mb-1">
                  Email Address (Staff Login ID) <span className="text-amber-600">*</span>
                </label>
                <div className="relative">
                  <Mail className="w-4 h-4 absolute left-3 top-3 text-stone-400" />
                  <input
                    type="email"
                    required
                    placeholder="rahul.cashier@camporacafe.in"
                    value={email}
                    onChange={e => setEmail(e.target.value)}
                    className="w-full pl-9 pr-3.5 py-2.5 rounded-xl border border-stone-300 bg-stone-50 focus:bg-white focus:border-amber-500 focus:ring-2 focus:ring-amber-200 outline-hidden transition-all"
                  />
                </div>
                <p className="text-[10px] text-stone-500 mt-1">
                  Used by the staff member to log in to the Staff Management Panel.
                </p>
              </div>

              <div>
                <div className="flex items-center justify-between mb-1">
                  <label className="block font-semibold text-stone-700">
                    Staff ID / Employee ID <span className="text-amber-600">*</span>
                  </label>
                  <button
                    type="button"
                    onClick={() => setStaffId(generateNextStaffId())}
                    className="text-[10px] text-amber-700 hover:text-amber-800 font-bold underline cursor-pointer"
                  >
                    Auto-Generate
                  </button>
                </div>
                <input
                  type="text"
                  required
                  placeholder="e.g. CC-STF-101"
                  value={staffId}
                  onChange={e => setStaffId(e.target.value.toUpperCase())}
                  className="w-full px-3.5 py-2.5 rounded-xl border border-stone-300 bg-stone-50 focus:bg-white focus:border-amber-500 focus:ring-2 focus:ring-amber-200 outline-hidden uppercase font-mono font-bold text-stone-900 transition-all"
                />
              </div>

              <div>
                <label className="block font-semibold text-stone-700 mb-1">
                  Date of Joining <span className="text-amber-600">*</span>
                </label>
                <div className="relative">
                  <Calendar className="w-4 h-4 absolute left-3 top-3 text-stone-400" />
                  <input
                    type="date"
                    required
                    value={dateOfJoining}
                    onChange={e => setDateOfJoining(e.target.value)}
                    className="w-full pl-9 pr-3.5 py-2.5 rounded-xl border border-stone-300 bg-stone-50 focus:bg-white focus:border-amber-500 focus:ring-2 focus:ring-amber-200 outline-hidden transition-all"
                  />
                </div>
              </div>

              <div>
                <label className="block font-semibold text-stone-700 mb-1">
                  Current Status
                </label>
                <select
                  value={status}
                  onChange={e => setStatus(e.target.value as StaffStatus)}
                  className="w-full px-3.5 py-2.5 rounded-xl border border-stone-300 bg-stone-50 focus:bg-white focus:border-amber-500 outline-hidden transition-all font-semibold"
                >
                  <option value="active">🟢 Active (Full access to assigned duties)</option>
                  <option value="inactive">🔴 Inactive (Leave / Not scheduled)</option>
                  <option value="suspended">⏸️ Suspended (Access disabled)</option>
                </select>
              </div>
            </div>
          </div>

          {/* SECTION 2: ROLE & POSITION ASSIGNMENT */}
          <div className="space-y-3">
            <div className="flex items-center justify-between pb-1 border-b border-stone-200">
              <div className="flex items-center gap-2">
                <Briefcase className="w-4 h-4 text-amber-600" />
                <h3 className="font-bold text-stone-900 text-sm">Role & Position Assignment</h3>
              </div>
              <div className="flex items-center gap-1.5 flex-wrap">
                <span className="text-[10px] text-stone-400 font-semibold">Quick Presets:</span>
                {['Cashier', 'Kitchen Staff', 'Manager'].map(presetKey => (
                  <button
                    key={presetKey}
                    type="button"
                    onClick={() => applyPreset(presetKey)}
                    className="px-2 py-0.5 rounded-md bg-stone-100 hover:bg-amber-100 text-stone-700 hover:text-amber-900 text-[10px] font-bold transition-colors cursor-pointer"
                  >
                    {presetKey}
                  </button>
                ))}
              </div>
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-2 gap-3.5">
              <div>
                <label className="block font-semibold text-stone-700 mb-1">
                  Position / Designation <span className="text-amber-600">*</span>
                </label>
                <select
                  value={position}
                  onChange={e => handlePositionChange(e.target.value)}
                  className="w-full px-3.5 py-2.5 rounded-xl border border-stone-300 bg-stone-50 focus:bg-white focus:border-amber-500 outline-hidden transition-all font-medium"
                >
                  <option value="Café Staff">Café Staff (General Floor)</option>
                  <option value="Cashier">Cashier (Counter Sales & Bills)</option>
                  <option value="Kitchen Staff">Kitchen Staff (Food & Chai Prep)</option>
                  <option value="Counter Staff">Counter Staff (Takeout & Service)</option>
                  <option value="Manager">Manager (Operations Supervisor)</option>
                  <option value="Other">Other (Custom Designation)</option>
                </select>

                {position === 'Other' && (
                  <input
                    type="text"
                    required
                    placeholder="Enter custom position title..."
                    value={customPosition}
                    onChange={e => setCustomPosition(e.target.value)}
                    className="w-full mt-2 px-3.5 py-2 rounded-xl border border-stone-300 bg-white focus:border-amber-500 outline-hidden"
                  />
                )}
              </div>

              <div>
                <label className="block font-semibold text-stone-700 mb-1">
                  RBAC Access Role <span className="text-amber-600">*</span>
                </label>
                <select
                  value={role}
                  onChange={e => setRole(e.target.value as StaffRole)}
                  className="w-full px-3.5 py-2.5 rounded-xl border border-stone-300 bg-stone-50 focus:bg-white focus:border-amber-500 outline-hidden transition-all font-bold"
                >
                  <option value="staff">Staff (Standard staff with assigned modules)</option>
                  <option value="manager">Manager (Elevated operational supervisor)</option>
                  <option value="owner">Owner/Admin (Full master administrative control)</option>
                </select>
                <p className="text-[10px] text-stone-500 mt-1">
                  Determines top-level privilege tier in the backend security layer.
                </p>
              </div>

              <div className="sm:col-span-2">
                <label className="block font-semibold text-stone-700 mb-1">
                  Staff Login Password {editingStaff ? '(Leave blank to retain current password)' : <span className="text-amber-600">*</span>}
                </label>
                <div className="relative">
                  <Lock className="w-4 h-4 absolute left-3 top-3 text-stone-400" />
                  <input
                    type={showPassword ? 'text' : 'password'}
                    placeholder={editingStaff ? '••••••••' : 'Enter secure password or use default'}
                    value={password}
                    onChange={e => setPassword(e.target.value)}
                    className="w-full pl-9 pr-10 py-2.5 rounded-xl border border-stone-300 bg-stone-50 focus:bg-white focus:border-amber-500 focus:ring-2 focus:ring-amber-200 outline-hidden font-mono transition-all"
                  />
                  <button
                    type="button"
                    onClick={() => setShowPassword(!showPassword)}
                    className="absolute right-3 top-2.5 text-stone-400 hover:text-stone-700 cursor-pointer"
                  >
                    {showPassword ? <EyeOff className="w-4 h-4" /> : <Eye className="w-4 h-4" />}
                  </button>
                </div>
                <div className="flex items-center justify-between text-[10px] text-stone-500 mt-1">
                  <span>Staff members will log in using this password and their staff email.</span>
                  {!editingStaff && (
                    <button
                      type="button"
                      onClick={() => setPassword('CamporaStaff2026!')}
                      className="text-amber-700 font-bold hover:underline cursor-pointer"
                    >
                      Default: CamporaStaff2026!
                    </button>
                  )}
                </div>
              </div>
            </div>
          </div>

          {/* SECTION 3: GRANULAR STAFF PERMISSIONS */}
          <div className="space-y-3">
            <div className="flex items-center justify-between pb-1 border-b border-stone-200">
              <div>
                <h3 className="font-bold text-stone-900 text-sm flex items-center gap-2">
                  <ShieldCheck className="w-4 h-4 text-amber-600" />
                  Granular Permissions Control ({permissions.length}/{ALL_PERMISSIONS.length})
                </h3>
                <p className="text-[11px] text-stone-500">
                  Staff member can ONLY access the modules selected below.
                </p>
              </div>
              <div className="flex items-center gap-2">
                <button
                  type="button"
                  onClick={handleSelectAllPermissions}
                  className="px-2 py-0.5 rounded-md bg-stone-100 hover:bg-stone-200 text-stone-700 text-[10px] font-bold cursor-pointer"
                >
                  Select All
                </button>
                <button
                  type="button"
                  onClick={handleClearPermissions}
                  className="px-2 py-0.5 rounded-md bg-stone-100 hover:bg-stone-200 text-stone-700 text-[10px] font-bold cursor-pointer"
                >
                  Clear All
                </button>
              </div>
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-2 gap-2.5">
              {ALL_PERMISSIONS.map(perm => {
                const isSelected = permissions.includes(perm.key);
                return (
                  <label
                    key={perm.key}
                    onClick={() => togglePermission(perm.key)}
                    className={`p-3 rounded-xl border flex items-start gap-3 cursor-pointer transition-all ${
                      isSelected
                        ? 'bg-amber-50/70 border-amber-300 text-amber-950 shadow-xs'
                        : 'bg-stone-50 border-stone-200 text-stone-600 hover:bg-stone-100'
                    }`}
                  >
                    <input
                      type="checkbox"
                      checked={isSelected}
                      onChange={() => {}} // handled by parent onClick
                      className="mt-0.5 h-4 w-4 rounded-md border-stone-300 text-amber-600 focus:ring-amber-500 cursor-pointer"
                    />
                    <div className="space-y-0.5">
                      <div className="flex items-center gap-2">
                        <span className="font-bold text-xs text-stone-900">{perm.label}</span>
                        <span className="px-1.5 py-0.2 rounded bg-stone-200/80 text-[9px] font-mono text-stone-600">
                          {perm.category}
                        </span>
                      </div>
                      <p className="text-[10.5px] text-stone-500 leading-snug">
                        {perm.description}
                      </p>
                    </div>
                  </label>
                );
              })}
            </div>
          </div>

          {/* SECTION 4: ID PROOF & VERIFICATION (PROTECTED PII) */}
          <div className="space-y-3">
            <div className="flex items-center justify-between pb-1 border-b border-stone-200">
              <div className="flex items-center gap-2">
                <IdCard className="w-4 h-4 text-amber-600" />
                <h3 className="font-bold text-stone-900 text-sm">ID Proof & Secure Verification</h3>
              </div>
              <span className="px-2 py-0.5 rounded-full bg-emerald-50 text-emerald-800 border border-emerald-200 text-[10px] font-bold flex items-center gap-1">
                <Lock className="w-2.5 h-2.5" /> Restricted to Owner/Admin
              </span>
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-2 gap-3.5">
              <div>
                <label className="block font-semibold text-stone-700 mb-1">
                  ID Proof Type
                </label>
                <select
                  value={idProofType}
                  onChange={e => setIdProofType(e.target.value as IdProofType)}
                  className="w-full px-3.5 py-2.5 rounded-xl border border-stone-300 bg-stone-50 focus:bg-white focus:border-amber-500 outline-hidden transition-all"
                >
                  <option value="College ID">College ID Card (GEC Banka Student / Staff)</option>
                  <option value="Aadhaar">Aadhaar Card (Govt. of India)</option>
                  <option value="PAN">Permanent Account Number (PAN Card)</option>
                  <option value="Driving Licence">Driving Licence</option>
                  <option value="Other">Other Official Identification</option>
                </select>
              </div>

              <div>
                <label className="block font-semibold text-stone-700 mb-1">
                  ID Proof Number
                </label>
                <input
                  type="text"
                  placeholder="e.g. GECB/2023/EE/042 or XXXX-8921"
                  value={idProofNumber}
                  onChange={e => setIdProofNumber(e.target.value)}
                  className="w-full px-3.5 py-2.5 rounded-xl border border-stone-300 bg-stone-50 focus:bg-white focus:border-amber-500 outline-hidden font-mono uppercase"
                />
              </div>

              {/* Upload ID Document */}
              <div className="sm:col-span-2">
                <label className="block font-semibold text-stone-700 mb-1">
                  Upload ID Proof Document (Photo / Scan / PDF)
                </label>
                <div className="p-3.5 rounded-2xl border-2 border-dashed border-stone-300 bg-stone-50 hover:bg-amber-50/30 transition-colors flex flex-col sm:flex-row items-center justify-between gap-3">
                  <div className="flex items-center gap-3">
                    <div className="w-10 h-10 rounded-xl bg-stone-200 flex items-center justify-center text-stone-600 shrink-0">
                      <FileText className="w-5 h-5" />
                    </div>
                    <div>
                      <div className="font-semibold text-stone-800 text-xs">
                        {idProofFileName || (idProofDocumentUrl ? 'ID Document Attached' : 'Select or drop ID proof copy')}
                      </div>
                      <p className="text-[10px] text-stone-400">
                        Supports JPG, PNG, PDF up to 3MB. Protected strictly under Owner/Admin RBAC.
                      </p>
                    </div>
                  </div>

                  <div className="flex items-center gap-2">
                    {idProofDocumentUrl && (
                      <button
                        type="button"
                        onClick={() => {
                          setIdProofDocumentUrl(undefined);
                          setIdProofFileName('');
                        }}
                        className="px-2.5 py-1 rounded-lg bg-red-100 hover:bg-red-200 text-red-700 text-[10px] font-bold cursor-pointer"
                      >
                        Remove
                      </button>
                    )}
                    <label className="px-3 py-1.5 rounded-xl bg-stone-900 hover:bg-stone-800 text-white font-bold text-xs cursor-pointer flex items-center gap-1.5 transition-colors">
                      <Upload className="w-3.5 h-3.5" />
                      <span>{idProofDocumentUrl ? 'Replace' : 'Upload Document'}</span>
                      <input
                        type="file"
                        accept="image/*,application/pdf"
                        onChange={handleDocumentFileUpload}
                        className="hidden"
                      />
                    </label>
                  </div>
                </div>
              </div>
            </div>
          </div>

          {/* SECTION 5: STAFF PHOTO & OPTIONAL DETAILS */}
          <div className="space-y-3">
            <div className="flex items-center gap-2 pb-1 border-b border-stone-200">
              <ImageIcon className="w-4 h-4 text-amber-600" />
              <h3 className="font-bold text-stone-900 text-sm">Staff Photo & Contact Details</h3>
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-2 gap-3.5">
              {/* Photo preview & upload */}
              <div className="sm:col-span-2 flex flex-col sm:flex-row items-center gap-4 p-3.5 rounded-2xl bg-stone-50 border border-stone-200">
                <div className="w-16 h-16 rounded-2xl overflow-hidden bg-stone-200 border-2 border-amber-500/40 shrink-0 flex items-center justify-center">
                  {photoUrl ? (
                    <img src={photoUrl} alt="Staff preview" className="w-full h-full object-cover" />
                  ) : (
                    <div className="font-bold font-serif text-stone-500 text-lg">
                      {fullName ? fullName.charAt(0).toUpperCase() : 'ST'}
                    </div>
                  )}
                </div>

                <div className="space-y-1 text-center sm:text-left flex-1">
                  <div className="font-semibold text-stone-800 text-xs">Staff Profile Photo</div>
                  <p className="text-[10px] text-stone-500">
                    Displays on staff cards, counter sales receipts, and live operational activity logs.
                  </p>
                  <div className="flex items-center gap-2 pt-1 justify-center sm:justify-start">
                    <label className="px-2.5 py-1 rounded-lg bg-stone-200 hover:bg-stone-300 text-stone-800 text-[11px] font-bold cursor-pointer flex items-center gap-1">
                      <Upload className="w-3 h-3" />
                      <span>Upload Photo</span>
                      <input
                        type="file"
                        accept="image/*"
                        onChange={handlePhotoFileUpload}
                        className="hidden"
                      />
                    </label>
                    {photoUrl && (
                      <button
                        type="button"
                        onClick={() => setPhotoUrl('')}
                        className="px-2 py-1 rounded-lg bg-red-100 hover:bg-red-200 text-red-700 text-[11px] font-bold cursor-pointer"
                      >
                        Remove
                      </button>
                    )}
                  </div>
                </div>
              </div>

              <div>
                <label className="block font-semibold text-stone-700 mb-1">
                  Emergency Contact (Optional)
                </label>
                <input
                  type="tel"
                  placeholder="+91 98765 00000"
                  value={emergencyContact}
                  onChange={e => setEmergencyContact(e.target.value)}
                  className="w-full px-3.5 py-2.5 rounded-xl border border-stone-300 bg-stone-50 focus:bg-white focus:border-amber-500 outline-hidden"
                />
              </div>

              <div>
                <label className="block font-semibold text-stone-700 mb-1">
                  Residential Address (Optional)
                </label>
                <input
                  type="text"
                  placeholder="e.g. Hostel 1 Staff Block, GEC Banka"
                  value={address}
                  onChange={e => setAddress(e.target.value)}
                  className="w-full px-3.5 py-2.5 rounded-xl border border-stone-300 bg-stone-50 focus:bg-white focus:border-amber-500 outline-hidden"
                />
              </div>

              <div className="sm:col-span-2">
                <label className="block font-semibold text-stone-700 mb-1">
                  Internal Notes & Remarks (Optional)
                </label>
                <textarea
                  rows={2}
                  placeholder="Special shift preferences, training certifications, or remarks..."
                  value={notes}
                  onChange={e => setNotes(e.target.value)}
                  className="w-full px-3.5 py-2 rounded-xl border border-stone-300 bg-stone-50 focus:bg-white focus:border-amber-500 outline-hidden resize-none"
                />
              </div>
            </div>
          </div>

          {/* Modal Actions Footer */}
          <div className="pt-4 border-t border-stone-200 flex items-center justify-end gap-3">
            <button
              type="button"
              onClick={onClose}
              className="px-4 py-2.5 rounded-xl border border-stone-300 text-stone-700 font-bold hover:bg-stone-100 transition-colors cursor-pointer"
            >
              Cancel
            </button>
            <button
              type="submit"
              disabled={isSubmitting}
              className="px-5 py-2.5 rounded-xl bg-amber-500 hover:bg-amber-400 text-stone-950 font-bold shadow-md shadow-amber-500/20 flex items-center gap-2 transition-all cursor-pointer disabled:opacity-50"
            >
              <Check className="w-4 h-4" />
              <span>{isSubmitting ? 'Saving Staff Record...' : (editingStaff ? 'Save Staff Updates' : 'Add Staff Member')}</span>
            </button>
          </div>

        </form>

      </div>
    </div>
  );
};
