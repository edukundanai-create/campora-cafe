import React, { useState } from 'react';
import {
  X,
  User,
  Shield,
  ShieldCheck,
  Phone,
  Mail,
  Calendar,
  MapPin,
  IdCard,
  Lock,
  Edit3,
  UserX,
  UserCheck,
  AlertTriangle,
  FileText,
  Clock,
  Briefcase,
  ExternalLink,
  Trash2,
  LogIn,
  CheckCircle2,
  XCircle,
  Eye,
  EyeOff
} from 'lucide-react';
import { StaffMember, StaffAuditLog, StaffStatus, StaffPermission } from '../../../types';
import { useCafe } from '../../../context/CafeContext';
import { StaffAttendanceSection } from './StaffAttendanceSection';

interface StaffProfileModalProps {
  isOpen: boolean;
  onClose: () => void;
  staff: StaffMember | null;
  auditLogs: StaffAuditLog[];
  onEdit: (staff: StaffMember) => void;
  onToggleStatus: (staffId: string, status: StaffStatus) => Promise<void>;
  onDelete: (staffId: string) => Promise<void>;
  onSimulateLogin?: (staff: StaffMember) => Promise<void>;
  isCurrentUserOwnerOrAdmin: boolean;
  initialTab?: 'overview' | 'attendance' | 'permissions' | 'activity' | 'idproof';
}

const ALL_PERMISSIONS: { key: StaffPermission; label: string; description: string }[] = [
  { key: 'view_orders', label: 'View Orders', description: 'Can view incoming orders & table bookings' },
  { key: 'update_order_status', label: 'Update Order Status', description: 'Can transition orders to preparing, ready, completed' },
  { key: 'create_counter_sale', label: 'Create Counter Sale', description: 'Can punch walk-in counter sales & collect payments' },
  { key: 'view_counter_sales', label: 'View Counter Sales', description: 'Can view counter sales register & walk-in receipts' },
  { key: 'manage_tables', label: 'Manage Tables', description: 'Can update dining table occupancy & cleaning status' },
  { key: 'manage_menu', label: 'Add/Edit Menu Items', description: 'Can modify menu offerings, pricing, & stock levels' },
  { key: 'change_cafe_status', label: 'Change Café Live Status', description: 'Can toggle store open/closed campus status' },
  { key: 'view_customer_info', label: 'View Customer Details', description: 'Can view delivery addresses, hostel rooms & phone numbers' },
  { key: 'view_crm', label: 'View CRM & Analytics', description: 'Can view customer loyalty history & engagement' },
  { key: 'view_sales_reports', label: 'View Sales Reports', description: 'Can view revenue totals & sales performance' },
  { key: 'manage_staff', label: 'Manage Staff Directory', description: 'Can register, modify & deactivate campus staff' },
  { key: 'manage_settings', label: 'Manage System Settings', description: 'Can configure UPI VPA, schedules & global settings' }
];

export const StaffProfileModal: React.FC<StaffProfileModalProps> = ({
  isOpen,
  onClose,
  staff,
  auditLogs,
  onEdit,
  onToggleStatus,
  onDelete,
  onSimulateLogin,
  isCurrentUserOwnerOrAdmin,
  initialTab
}) => {
  const {
    staffAttendance,
    markStaffAttendance,
    updateStaffAttendance,
    deleteStaffAttendance,
    hasPermission,
    isAdminUser,
    currentStaff,
    adminProfile
  } = useCafe();

  const [activeTab, setActiveTab] = useState<'overview' | 'attendance' | 'permissions' | 'activity' | 'idproof'>(initialTab || 'overview');
  const [showSensitiveId, setShowSensitiveId] = useState(false);
  const [isConfirmingDelete, setIsConfirmingDelete] = useState(false);
  const [isProcessing, setIsProcessing] = useState(false);

  React.useEffect(() => {
    if (initialTab) {
      setActiveTab(initialTab);
    }
  }, [initialTab, isOpen]);

  // Determine attendance permissions: Owner, Admin, or Manager
  const canManageAttendance =
    isCurrentUserOwnerOrAdmin ||
    isAdminUser ||
    hasPermission('manage_staff') ||
    currentStaff?.role === 'owner' ||
    currentStaff?.role === 'manager';

  if (!isOpen || !staff) return null;

  // Filter audit logs for this specific staff member
  const staffLogs = auditLogs.filter(
    log =>
      log.staffId === staff.staffId ||
      log.staffName.toLowerCase().includes(staff.fullName.toLowerCase()) ||
      (staff.uid && log.staffUid === staff.uid)
  );

  const handleStatusChange = async (newStatus: StaffStatus) => {
    setIsProcessing(true);
    try {
      await onToggleStatus(staff.id, newStatus);
    } finally {
      setIsProcessing(false);
    }
  };

  const handleDeleteStaff = async () => {
    setIsProcessing(true);
    try {
      await onDelete(staff.id);
      setIsConfirmingDelete(false);
      onClose();
    } finally {
      setIsProcessing(false);
    }
  };

  const getStatusBadge = (status: StaffStatus) => {
    switch (status) {
      case 'active':
        return (
          <span className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full text-xs font-bold bg-emerald-100 text-emerald-800 border border-emerald-300">
            <span className="w-2 h-2 rounded-full bg-emerald-500 animate-pulse" />
            Active
          </span>
        );
      case 'inactive':
        return (
          <span className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full text-xs font-bold bg-stone-100 text-stone-700 border border-stone-300">
            <span className="w-2 h-2 rounded-full bg-stone-400" />
            Inactive / On Leave
          </span>
        );
      case 'suspended':
        return (
          <span className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full text-xs font-bold bg-red-100 text-red-800 border border-red-300">
            <span className="w-2 h-2 rounded-full bg-red-500" />
            Suspended
          </span>
        );
    }
  };

  const maskIdNumber = (num?: string) => {
    if (!num) return 'Not Provided';
    if (num.length <= 4) return num;
    return '•••• •••• ' + num.slice(-4);
  };

  return (
    <div className="fixed inset-0 z-50 bg-black/60 backdrop-blur-xs flex items-center justify-center p-3 sm:p-4 overflow-y-auto">
      <div className="bg-white rounded-3xl max-w-2xl w-full my-8 shadow-2xl border border-stone-200 overflow-hidden flex flex-col max-h-[92vh]">
        
        {/* Header with Cover & Staff Avatar */}
        <div className="relative bg-gradient-to-r from-stone-900 via-stone-850 to-amber-950 text-white p-6 pb-5 shrink-0">
          <button
            onClick={onClose}
            className="absolute right-4 top-4 p-1.5 rounded-xl hover:bg-white/10 text-stone-300 hover:text-white transition-colors cursor-pointer"
          >
            <X className="w-5 h-5" />
          </button>

          <div className="flex flex-col sm:flex-row items-center sm:items-start gap-4">
            <div className="w-20 h-20 rounded-3xl overflow-hidden bg-stone-800 border-2 border-amber-500/50 shadow-lg shrink-0 flex items-center justify-center">
              {staff.photoUrl ? (
                <img src={staff.photoUrl} alt={staff.fullName} className="w-full h-full object-cover" />
              ) : (
                <span className="font-serif font-bold text-2xl text-amber-400">
                  {staff.fullName.charAt(0).toUpperCase()}
                </span>
              )}
            </div>

            <div className="space-y-1.5 text-center sm:text-left flex-1">
              <div className="flex flex-wrap items-center justify-center sm:justify-start gap-2">
                <h2 className="font-serif text-xl font-bold text-white tracking-wide">
                  {staff.fullName}
                </h2>
                {getStatusBadge(staff.status)}
              </div>

              <div className="flex flex-wrap items-center justify-center sm:justify-start gap-2 text-xs text-stone-300">
                <span className="font-mono bg-white/10 px-2 py-0.5 rounded-md font-bold text-amber-400">
                  {staff.staffId}
                </span>
                <span>•</span>
                <span className="font-semibold text-stone-200">{staff.position}</span>
                <span>•</span>
                <span className="uppercase tracking-wider px-2 py-0.5 rounded-md bg-amber-500/20 text-amber-300 font-bold text-[10px]">
                  {staff.role} tier
                </span>
              </div>

              <div className="text-[11px] text-stone-400 pt-1 flex flex-wrap items-center justify-center sm:justify-start gap-3">
                <span className="flex items-center gap-1">
                  <Calendar className="w-3.5 h-3.5 text-amber-500" />
                  Joined: {staff.dateOfJoining}
                </span>
                {staff.lastLoginAt && (
                  <span className="flex items-center gap-1">
                    <Clock className="w-3.5 h-3.5 text-stone-400" />
                    Last Active: {new Date(staff.lastLoginAt).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}
                  </span>
                )}
              </div>
            </div>
          </div>

          {/* Navigation Tabs */}
          <div className="flex items-center gap-1 mt-6 border-b border-stone-800 -mb-5 overflow-x-auto">
            {[
              { id: 'overview', label: 'Staff Profile' },
              { id: 'attendance', label: '📅 Attendance & Work Record' },
              { id: 'permissions', label: `Permissions (${staff.permissions.length})` },
              { id: 'activity', label: `Activity History (${staffLogs.length})` },
              { id: 'idproof', label: 'ID Proof & KYC' }
            ].map(tab => (
              <button
                key={tab.id}
                onClick={() => setActiveTab(tab.id as any)}
                className={`px-3.5 py-2 text-xs font-bold transition-colors whitespace-nowrap border-b-2 cursor-pointer ${
                  activeTab === tab.id
                    ? 'border-amber-400 text-amber-400'
                    : 'border-transparent text-stone-400 hover:text-stone-200'
                }`}
              >
                {tab.label}
              </button>
            ))}
          </div>
        </div>

        {/* Modal Tab Content Body */}
        <div className="p-6 overflow-y-auto space-y-6 text-stone-800 flex-1">
          
          {/* TAB: ATTENDANCE & WORK RECORD */}
          {activeTab === 'attendance' && (
            <StaffAttendanceSection
              staff={staff}
              attendanceRecords={staffAttendance}
              onMarkAttendance={markStaffAttendance}
              onUpdateAttendance={updateStaffAttendance}
              onDeleteAttendance={deleteStaffAttendance}
              canManageAttendance={canManageAttendance}
              currentUserDisplayName={adminProfile?.displayName || currentStaff?.fullName || 'Admin'}
              isStaffSelfView={currentStaff?.staffId === staff.staffId && !canManageAttendance}
            />
          )}
          
          {/* TAB 1: OVERVIEW */}
          {activeTab === 'overview' && (
            <div className="space-y-5">
              {/* Contact Information Cards */}
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3.5">
                <div className="p-3.5 rounded-2xl bg-stone-50 border border-stone-200 space-y-1">
                  <div className="text-[10px] font-semibold uppercase text-stone-400 tracking-wider flex items-center gap-1">
                    <Phone className="w-3 h-3 text-stone-500" /> Mobile Contact
                  </div>
                  <div className="font-bold text-stone-900 text-sm">{staff.mobile}</div>
                  <div className="text-[10px] text-stone-500">Authorized for SMS / WhatsApp café dispatches</div>
                </div>

                <div className="p-3.5 rounded-2xl bg-stone-50 border border-stone-200 space-y-1">
                  <div className="text-[10px] font-semibold uppercase text-stone-400 tracking-wider flex items-center gap-1">
                    <Mail className="w-3 h-3 text-stone-500" /> Staff Login Email
                  </div>
                  <div className="font-bold text-stone-900 text-sm break-all">{staff.email}</div>
                  <div className="text-[10px] text-stone-500">Dedicated staff login credential ID</div>
                </div>

                <div className="p-3.5 rounded-2xl bg-stone-50 border border-stone-200 space-y-1">
                  <div className="text-[10px] font-semibold uppercase text-stone-400 tracking-wider flex items-center gap-1">
                    <Phone className="w-3 h-3 text-stone-500" /> Emergency Contact
                  </div>
                  <div className="font-bold text-stone-900 text-sm">
                    {staff.emergencyContact || 'Not Specified'}
                  </div>
                  <div className="text-[10px] text-stone-500">Next of kin / Campus local contact</div>
                </div>

                <div className="p-3.5 rounded-2xl bg-stone-50 border border-stone-200 space-y-1">
                  <div className="text-[10px] font-semibold uppercase text-stone-400 tracking-wider flex items-center gap-1">
                    <MapPin className="w-3 h-3 text-stone-500" /> Residential Address
                  </div>
                  <div className="font-bold text-stone-900 text-sm">
                    {staff.address || 'Campus Staff Quarters, GEC Banka'}
                  </div>
                  <div className="text-[10px] text-stone-500">Campus residence or residential address</div>
                </div>
              </div>

              {/* Notes & Remarks */}
              {staff.notes && (
                <div className="p-4 rounded-2xl bg-amber-50/60 border border-amber-200 space-y-1">
                  <div className="text-xs font-bold text-amber-900 flex items-center gap-1.5">
                    <FileText className="w-3.5 h-3.5 text-amber-700" /> Notes & Operational Remarks
                  </div>
                  <p className="text-xs text-amber-950/80 leading-relaxed">{staff.notes}</p>
                </div>
              )}

              {/* Quick Actions Panel */}
              <div className="p-4 rounded-2xl bg-stone-50 border border-stone-200 space-y-3">
                <div className="text-xs font-bold text-stone-900">Staff Account Management</div>
                <div className="flex flex-wrap items-center gap-2">
                  <button
                    onClick={() => onEdit(staff)}
                    className="px-3.5 py-2 rounded-xl bg-stone-900 hover:bg-stone-800 text-white text-xs font-bold flex items-center gap-1.5 transition-colors cursor-pointer"
                  >
                    <Edit3 className="w-3.5 h-3.5" /> Edit Profile & Role
                  </button>

                  {staff.status === 'active' ? (
                    <button
                      onClick={() => handleStatusChange('inactive')}
                      disabled={isProcessing || staff.role === 'owner'}
                      className="px-3.5 py-2 rounded-xl bg-stone-200 hover:bg-stone-300 text-stone-800 text-xs font-bold flex items-center gap-1.5 transition-colors cursor-pointer disabled:opacity-50"
                    >
                      <UserX className="w-3.5 h-3.5 text-stone-600" /> Deactivate (Set Inactive)
                    </button>
                  ) : (
                    <button
                      onClick={() => handleStatusChange('active')}
                      disabled={isProcessing}
                      className="px-3.5 py-2 rounded-xl bg-emerald-600 hover:bg-emerald-500 text-white text-xs font-bold flex items-center gap-1.5 transition-colors cursor-pointer disabled:opacity-50"
                    >
                      <UserCheck className="w-3.5 h-3.5" /> Activate Staff Account
                    </button>
                  )}

                  {onSimulateLogin && staff.status === 'active' && (
                    <button
                      onClick={() => onSimulateLogin(staff)}
                      className="px-3.5 py-2 rounded-xl bg-amber-500 hover:bg-amber-400 text-stone-950 text-xs font-bold flex items-center gap-1.5 shadow-xs transition-colors cursor-pointer"
                      title="Test the Staff Portal through this staff member's perspective"
                    >
                      <LogIn className="w-3.5 h-3.5" /> Switch to this Staff Session
                    </button>
                  )}
                </div>
              </div>
            </div>
          )}

          {/* TAB 2: PERMISSIONS */}
          {activeTab === 'permissions' && (
            <div className="space-y-4">
              <div className="flex items-center justify-between">
                <div>
                  <h3 className="font-bold text-sm text-stone-900">
                    Assigned Operational Permissions
                  </h3>
                  <p className="text-xs text-stone-500">
                    Controls exactly which Admin Panel sections this staff member can access.
                  </p>
                </div>
                <button
                  onClick={() => onEdit(staff)}
                  className="text-xs text-amber-700 font-bold hover:underline cursor-pointer"
                >
                  Modify Permissions
                </button>
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-2.5">
                {ALL_PERMISSIONS.map(perm => {
                  const hasPerm = staff.permissions.includes(perm.key);
                  return (
                    <div
                      key={perm.key}
                      className={`p-3 rounded-xl border flex items-start gap-2.5 ${
                        hasPerm
                          ? 'bg-emerald-50/70 border-emerald-200 text-emerald-950'
                          : 'bg-stone-50/70 border-stone-200 text-stone-400 opacity-60'
                      }`}
                    >
                      {hasPerm ? (
                        <CheckCircle2 className="w-4 h-4 text-emerald-600 shrink-0 mt-0.5" />
                      ) : (
                        <XCircle className="w-4 h-4 text-stone-400 shrink-0 mt-0.5" />
                      )}
                      <div>
                        <div className="font-bold text-xs text-stone-900 flex items-center gap-2">
                          {perm.label}
                          {hasPerm && (
                            <span className="px-1.5 py-0.2 rounded bg-emerald-200 text-[9px] font-bold text-emerald-800">
                              Granted
                            </span>
                          )}
                        </div>
                        <p className="text-[10.5px] text-stone-500 leading-snug">
                          {perm.description}
                        </p>
                      </div>
                    </div>
                  );
                })}
              </div>
            </div>
          )}

          {/* TAB 3: ACTIVITY HISTORY */}
          {activeTab === 'activity' && (
            <div className="space-y-3">
              <div className="flex items-center justify-between pb-1">
                <div>
                  <h3 className="font-bold text-sm text-stone-900">
                    Recent Staff Activity & Audit Logs
                  </h3>
                  <p className="text-xs text-stone-500">
                    Real-time chronological record of orders, counter sales, and table actions by {staff.fullName}.
                  </p>
                </div>
                <span className="text-xs font-mono bg-stone-100 px-2 py-0.5 rounded text-stone-600 font-bold">
                  {staffLogs.length} events logged
                </span>
              </div>

              {staffLogs.length === 0 ? (
                <div className="text-center py-10 bg-stone-50 rounded-2xl border border-stone-200">
                  <Clock className="w-8 h-8 mx-auto text-stone-300 mb-2" />
                  <p className="text-xs text-stone-500">No operational activities logged yet for this staff member.</p>
                </div>
              ) : (
                <div className="space-y-2 max-h-[350px] overflow-y-auto pr-1">
                  {staffLogs.map(log => (
                    <div
                      key={log.id}
                      className="p-3 rounded-xl bg-stone-50 border border-stone-200 flex items-start justify-between gap-3 text-xs"
                    >
                      <div className="space-y-0.5">
                        <div className="font-bold text-stone-900">{log.action}</div>
                        {log.details && (
                          <div className="text-[11px] text-stone-500">{log.details}</div>
                        )}
                        <div className="flex items-center gap-2 text-[10px] text-stone-400 pt-0.5">
                          <span className="font-mono">{log.date} {log.time}</span>
                          {log.relevantId && (
                            <span className="font-mono bg-stone-200 px-1.5 py-0.2 rounded text-stone-700">
                              Ref: {log.relevantId}
                            </span>
                          )}
                        </div>
                      </div>

                      <span className="px-2 py-0.5 rounded text-[9px] uppercase font-bold bg-amber-100 text-amber-800 border border-amber-200 shrink-0">
                        {log.category.replace('_', ' ')}
                      </span>
                    </div>
                  ))}
                </div>
              )}
            </div>
          )}

          {/* TAB 4: ID PROOF & KYC (PROTECTED) */}
          {activeTab === 'idproof' && (
            <div className="space-y-4">
              <div className="p-3.5 rounded-2xl bg-amber-50/80 border border-amber-200 flex items-start gap-3">
                <Lock className="w-4 h-4 text-amber-700 shrink-0 mt-0.5" />
                <div className="text-xs text-amber-950">
                  <span className="font-bold">Confidential Verification Record</span>
                  <p className="text-[11px] text-amber-900/80 mt-0.5">
                    Staff identification numbers and documents are protected under role-based security and are strictly accessible to authorized Owner/Admin accounts only.
                  </p>
                </div>
              </div>

              <div className="p-4 rounded-2xl bg-stone-50 border border-stone-200 space-y-3">
                <div className="flex items-center justify-between">
                  <div>
                    <div className="text-[10px] uppercase font-bold text-stone-400">ID Proof Type</div>
                    <div className="font-bold text-stone-900 text-sm flex items-center gap-2 mt-0.5">
                      <IdCard className="w-4 h-4 text-amber-600" />
                      {staff.idProofType || 'College ID'}
                    </div>
                  </div>

                  <button
                    onClick={() => setShowSensitiveId(!showSensitiveId)}
                    className="px-2.5 py-1 rounded-lg bg-stone-200 hover:bg-stone-300 text-stone-700 text-xs font-bold flex items-center gap-1.5 cursor-pointer"
                  >
                    {showSensitiveId ? <EyeOff className="w-3.5 h-3.5" /> : <Eye className="w-3.5 h-3.5" />}
                    <span>{showSensitiveId ? 'Hide Number' : 'Reveal Number'}</span>
                  </button>
                </div>

                <div className="p-3 rounded-xl bg-white border border-stone-200 font-mono text-stone-900 font-bold text-sm">
                  {showSensitiveId ? (staff.idProofNumber || 'Not recorded') : maskIdNumber(staff.idProofNumber)}
                </div>
              </div>

              {/* Uploaded ID Document Viewer */}
              <div className="p-4 rounded-2xl bg-stone-50 border border-stone-200 space-y-2">
                <div className="text-xs font-bold text-stone-900 flex items-center gap-2">
                  <FileText className="w-4 h-4 text-stone-600" /> Uploaded ID Proof Document
                </div>

                {staff.idProofDocumentUrl ? (
                  <div className="space-y-3 pt-1">
                    <div className="max-h-60 overflow-hidden rounded-xl border border-stone-300 bg-white flex items-center justify-center p-2">
                      <img
                        src={staff.idProofDocumentUrl}
                        alt="ID Document"
                        className="max-h-56 object-contain rounded-lg"
                      />
                    </div>
                    <div className="flex items-center justify-end">
                      <a
                        href={staff.idProofDocumentUrl}
                        download={`Staff_ID_${staff.staffId}`}
                        target="_blank"
                        rel="noreferrer"
                        className="px-3 py-1.5 rounded-xl bg-stone-900 hover:bg-stone-800 text-white text-xs font-bold flex items-center gap-1.5"
                      >
                        <ExternalLink className="w-3.5 h-3.5" /> Open / Download Document
                      </a>
                    </div>
                  </div>
                ) : (
                  <div className="p-6 text-center text-stone-400 text-xs bg-white rounded-xl border border-dashed border-stone-200">
                    No digital document copy uploaded for this staff member.
                  </div>
                )}
              </div>
            </div>
          )}

          {/* Delete Danger Zone */}
          {isCurrentUserOwnerOrAdmin && staff.role !== 'owner' && (
            <div className="pt-4 border-t border-stone-200">
              {isConfirmingDelete ? (
                <div className="p-3.5 rounded-2xl bg-red-50 border border-red-200 space-y-2">
                  <div className="flex items-center gap-2 text-red-800 font-bold text-xs">
                    <AlertTriangle className="w-4 h-4 text-red-600" />
                    Confirm Permanent Deletion of Staff Record?
                  </div>
                  <p className="text-[11px] text-red-700">
                    This will permanently remove {staff.fullName}'s profile and login account. To retain history while revoking access, consider setting status to "Inactive" instead.
                  </p>
                  <div className="flex items-center gap-2 pt-1">
                    <button
                      onClick={handleDeleteStaff}
                      disabled={isProcessing}
                      className="px-3 py-1.5 rounded-xl bg-red-600 hover:bg-red-700 text-white text-xs font-bold cursor-pointer"
                    >
                      Yes, Delete Record
                    </button>
                    <button
                      onClick={() => setIsConfirmingDelete(false)}
                      className="px-3 py-1.5 rounded-xl bg-stone-200 hover:bg-stone-300 text-stone-800 text-xs font-bold cursor-pointer"
                    >
                      Cancel
                    </button>
                  </div>
                </div>
              ) : (
                <div className="flex items-center justify-between text-xs">
                  <span className="text-stone-400">Need to remove this staff profile permanently?</span>
                  <button
                    onClick={() => setIsConfirmingDelete(true)}
                    className="text-red-600 hover:text-red-700 font-bold flex items-center gap-1 cursor-pointer"
                  >
                    <Trash2 className="w-3.5 h-3.5" /> Delete Staff Member
                  </button>
                </div>
              )}
            </div>
          )}

        </div>

      </div>
    </div>
  );
};
