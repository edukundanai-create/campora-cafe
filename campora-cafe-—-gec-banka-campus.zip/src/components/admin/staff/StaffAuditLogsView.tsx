import React, { useState, useMemo } from 'react';
import {
  Clock,
  Search,
  Filter,
  User,
  Shield,
  ShoppingBag,
  Receipt,
  LayoutGrid,
  UtensilsCrossed,
  Power,
  Users,
  Calendar,
  ArrowUpDown,
  Download,
  RotateCcw,
  CheckCircle2
} from 'lucide-react';
import { StaffAuditLog, StaffMember } from '../../../types';

interface StaffAuditLogsViewProps {
  logs: StaffAuditLog[];
  staffMembers: StaffMember[];
  onRefresh?: () => void;
}

export const StaffAuditLogsView: React.FC<StaffAuditLogsViewProps> = ({
  logs,
  staffMembers,
  onRefresh
}) => {
  const [searchQuery, setSearchQuery] = useState('');
  const [selectedStaffId, setSelectedStaffId] = useState<string>('all');
  const [selectedCategory, setSelectedCategory] = useState<string>('all');
  const [dateFilter, setDateFilter] = useState<string>('');

  const filteredLogs = useMemo(() => {
    return logs.filter(log => {
      // Search query filter
      if (searchQuery.trim()) {
        const q = searchQuery.toLowerCase();
        const matchesName = log.staffName.toLowerCase().includes(q);
        const matchesAction = log.action.toLowerCase().includes(q);
        const matchesId = log.staffId.toLowerCase().includes(q) || (log.relevantId && log.relevantId.toLowerCase().includes(q));
        const matchesDetails = log.details && log.details.toLowerCase().includes(q);
        if (!matchesName && !matchesAction && !matchesId && !matchesDetails) return false;
      }

      // Staff filter
      if (selectedStaffId !== 'all') {
        if (log.staffId !== selectedStaffId) return false;
      }

      // Category filter
      if (selectedCategory !== 'all') {
        if (log.category !== selectedCategory) return false;
      }

      // Date filter
      if (dateFilter) {
        if (log.date !== dateFilter) return false;
      }

      return true;
    });
  }, [logs, searchQuery, selectedStaffId, selectedCategory, dateFilter]);

  const getCategoryBadge = (category: StaffAuditLog['category']) => {
    switch (category) {
      case 'counter_sale':
        return (
          <span className="inline-flex items-center gap-1 px-2.5 py-0.5 rounded-full text-[10px] font-bold bg-amber-100 text-amber-800 border border-amber-200">
            <Receipt className="w-3 h-3 text-amber-700" /> Counter Sale
          </span>
        );
      case 'order':
        return (
          <span className="inline-flex items-center gap-1 px-2.5 py-0.5 rounded-full text-[10px] font-bold bg-blue-100 text-blue-800 border border-blue-200">
            <ShoppingBag className="w-3 h-3 text-blue-700" /> Online Order
          </span>
        );
      case 'table':
        return (
          <span className="inline-flex items-center gap-1 px-2.5 py-0.5 rounded-full text-[10px] font-bold bg-purple-100 text-purple-800 border border-purple-200">
            <LayoutGrid className="w-3 h-3 text-purple-700" /> Table Status
          </span>
        );
      case 'cafe_status':
        return (
          <span className="inline-flex items-center gap-1 px-2.5 py-0.5 rounded-full text-[10px] font-bold bg-emerald-100 text-emerald-800 border border-emerald-200">
            <Power className="w-3 h-3 text-emerald-700" /> Store Status
          </span>
        );
      case 'menu':
        return (
          <span className="inline-flex items-center gap-1 px-2.5 py-0.5 rounded-full text-[10px] font-bold bg-orange-100 text-orange-800 border border-orange-200">
            <UtensilsCrossed className="w-3 h-3 text-orange-700" /> Menu Management
          </span>
        );
      case 'staff':
        return (
          <span className="inline-flex items-center gap-1 px-2.5 py-0.5 rounded-full text-[10px] font-bold bg-rose-100 text-rose-800 border border-rose-200">
            <Users className="w-3 h-3 text-rose-700" /> Staff & RBAC
          </span>
        );
      default:
        return (
          <span className="inline-flex items-center gap-1 px-2.5 py-0.5 rounded-full text-[10px] font-bold bg-stone-100 text-stone-700 border border-stone-200">
            System
          </span>
        );
    }
  };

  const exportLogsAsCSV = () => {
    const headers = ['Date', 'Time', 'Staff Name', 'Staff ID', 'Action Performed', 'Category', 'Reference ID', 'Details'];
    const rows = filteredLogs.map(l => [
      `"${l.date}"`,
      `"${l.time}"`,
      `"${l.staffName}"`,
      `"${l.staffId}"`,
      `"${l.action.replace(/"/g, '""')}"`,
      `"${l.category}"`,
      `"${l.relevantId || ''}"`,
      `"${(l.details || '').replace(/"/g, '""')}"`
    ]);
    const csvContent = 'data:text/csv;charset=utf-8,' + [headers.join(','), ...rows.map(e => e.join(','))].join('\n');
    const encodedUri = encodeURI(csvContent);
    const link = document.createElement('a');
    link.setAttribute('href', encodedUri);
    link.setAttribute('download', `Campora_Staff_Audit_Log_${new Date().toISOString().split('T')[0]}.csv`);
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
  };

  return (
    <div className="space-y-4">
      {/* Top Filter and Search Bar */}
      <div className="bg-white p-4 rounded-2xl border border-stone-200 shadow-xs space-y-3">
        <div className="flex flex-col sm:flex-row items-center justify-between gap-3">
          {/* Search Box */}
          <div className="relative w-full sm:w-80">
            <Search className="w-4 h-4 absolute left-3 top-3 text-stone-400" />
            <input
              type="text"
              placeholder="Search staff, action, or Order/Sale ID..."
              value={searchQuery}
              onChange={e => setSearchQuery(e.target.value)}
              className="w-full pl-9 pr-3.5 py-2 text-xs rounded-xl border border-stone-300 bg-stone-50 focus:bg-white focus:border-amber-500 outline-hidden transition-all"
            />
          </div>

          <div className="flex flex-wrap items-center gap-2 w-full sm:w-auto justify-end">
            {/* Filter by Staff */}
            <div className="flex items-center gap-1.5">
              <span className="text-[11px] font-bold text-stone-500">Staff:</span>
              <select
                value={selectedStaffId}
                onChange={e => setSelectedStaffId(e.target.value)}
                className="px-2.5 py-1.5 text-xs rounded-xl border border-stone-300 bg-stone-50 text-stone-800 font-semibold outline-hidden"
              >
                <option value="all">All Staff Members</option>
                {staffMembers.map(s => (
                  <option key={s.id} value={s.staffId}>
                    {s.fullName} ({s.position})
                  </option>
                ))}
              </select>
            </div>

            {/* Filter by Category */}
            <div className="flex items-center gap-1.5">
              <span className="text-[11px] font-bold text-stone-500">Action:</span>
              <select
                value={selectedCategory}
                onChange={e => setSelectedCategory(e.target.value)}
                className="px-2.5 py-1.5 text-xs rounded-xl border border-stone-300 bg-stone-50 text-stone-800 font-semibold outline-hidden"
              >
                <option value="all">All Categories</option>
                <option value="counter_sale">Counter Sales (Walk-ins)</option>
                <option value="order">Online Customer Orders</option>
                <option value="table">Table Occupancy / Seating</option>
                <option value="cafe_status">Café Open / Closed</option>
                <option value="menu">Menu & Stock Updates</option>
                <option value="staff">Staff Directory & RBAC</option>
              </select>
            </div>

            {/* Filter by Date */}
            <div className="flex items-center gap-1.5">
              <input
                type="date"
                value={dateFilter}
                onChange={e => setDateFilter(e.target.value)}
                className="px-2.5 py-1.5 text-xs rounded-xl border border-stone-300 bg-stone-50 text-stone-700 outline-hidden"
              />
              {dateFilter && (
                <button
                  onClick={() => setDateFilter('')}
                  className="text-[10px] text-amber-700 font-bold hover:underline cursor-pointer"
                >
                  Clear Date
                </button>
              )}
            </div>

            {/* Export CSV Button */}
            <button
              onClick={exportLogsAsCSV}
              className="px-3 py-1.5 rounded-xl bg-stone-100 hover:bg-stone-200 text-stone-800 text-xs font-bold flex items-center gap-1.5 transition-colors cursor-pointer"
              title="Download filtered activity logs as CSV"
            >
              <Download className="w-3.5 h-3.5" />
              <span>Export CSV</span>
            </button>
          </div>
        </div>

        <div className="flex items-center justify-between text-xs text-stone-500 pt-1 border-t border-stone-100">
          <div className="flex items-center gap-2">
            <span className="font-semibold text-stone-700">Showing {filteredLogs.length} of {logs.length} logged activities</span>
            {(selectedStaffId !== 'all' || selectedCategory !== 'all' || searchQuery || dateFilter) && (
              <button
                onClick={() => {
                  setSelectedStaffId('all');
                  setSelectedCategory('all');
                  setSearchQuery('');
                  setDateFilter('');
                }}
                className="text-amber-700 font-bold hover:underline cursor-pointer"
              >
                Reset Filters
              </button>
            )}
          </div>
          <span className="text-[11px] text-stone-400">Chronological append-only operational audit trail</span>
        </div>
      </div>

      {/* Logs Table / List */}
      <div className="bg-white rounded-2xl border border-stone-200 shadow-xs overflow-hidden">
        {filteredLogs.length === 0 ? (
          <div className="p-12 text-center text-stone-500 space-y-2">
            <Clock className="w-8 h-8 mx-auto text-stone-300" />
            <div className="font-bold text-stone-700">No activity logs matched your filter criteria.</div>
            <p className="text-xs text-stone-400">Try adjusting your keyword search or category filter.</p>
          </div>
        ) : (
          <div className="divide-y divide-stone-100">
            {filteredLogs.map(log => (
              <div
                key={log.id}
                className="p-4 hover:bg-stone-50/70 transition-colors flex flex-col sm:flex-row items-start sm:items-center justify-between gap-3 text-xs"
              >
                <div className="flex items-start gap-3">
                  <div className="w-8 h-8 rounded-xl bg-amber-500/10 border border-amber-500/20 text-amber-700 flex items-center justify-center shrink-0 mt-0.5">
                    <Clock className="w-4 h-4" />
                  </div>

                  <div className="space-y-1">
                    <div className="flex flex-wrap items-center gap-2">
                      <span className="font-bold text-stone-900 text-sm">
                        {log.action}
                      </span>
                      {getCategoryBadge(log.category)}
                    </div>

                    {log.details && (
                      <p className="text-stone-600 text-xs">
                        {log.details}
                      </p>
                    )}

                    <div className="flex flex-wrap items-center gap-3 text-[11px] text-stone-400">
                      <span className="font-medium text-stone-700 flex items-center gap-1">
                        <User className="w-3 h-3 text-stone-400" />
                        {log.staffName}
                      </span>
                      <span className="font-mono bg-stone-100 px-1.5 py-0.2 rounded text-stone-600 font-bold">
                        {log.staffId}
                      </span>
                      {log.relevantId && (
                        <span className="font-mono bg-amber-50 border border-amber-200 text-amber-800 px-1.5 py-0.2 rounded font-semibold">
                          ID: {log.relevantId}
                        </span>
                      )}
                    </div>
                  </div>
                </div>

                <div className="text-right shrink-0 self-end sm:self-center font-mono text-[11px] text-stone-500 bg-stone-100/70 px-2.5 py-1 rounded-lg">
                  <div>{log.date}</div>
                  <div className="font-bold text-stone-700">{log.time}</div>
                </div>
              </div>
            ))}
          </div>
        )}
      </div>
    </div>
  );
};
