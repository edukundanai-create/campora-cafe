import React, { useState, useMemo } from 'react';
import {
  Calendar as CalendarIcon,
  Clock,
  CheckCircle2,
  XCircle,
  AlertCircle,
  ChevronLeft,
  ChevronRight,
  Download,
  FileSpreadsheet,
  Edit3,
  Trash2,
  Shield,
  Lock,
  User,
  Check,
  History,
  Info,
  CalendarDays,
  ListFilter
} from 'lucide-react';
import {
  StaffMember,
  StaffAttendanceRecord,
  AttendanceStatus,
  MonthlyAttendanceSummary
} from '../../../types';
import {
  getAttendanceStatusConfig,
  calculateMonthlyAttendanceSummary,
  generateCalendarDays,
  calculateWorkingHours,
  exportStaffAttendanceCSV,
  getMonthName
} from '../../../utils/attendance';

interface StaffAttendanceSectionProps {
  staff: StaffMember;
  attendanceRecords: StaffAttendanceRecord[];
  onMarkAttendance: (
    recordData: Omit<StaffAttendanceRecord, 'id' | 'createdAt'>
  ) => Promise<StaffAttendanceRecord>;
  onUpdateAttendance: (
    attendanceId: string,
    updates: Partial<StaffAttendanceRecord>,
    correctionReason?: string
  ) => Promise<StaffAttendanceRecord>;
  onDeleteAttendance?: (attendanceId: string) => Promise<void>;
  canManageAttendance: boolean;
  currentUserDisplayName?: string;
  isStaffSelfView?: boolean;
}

export const StaffAttendanceSection: React.FC<StaffAttendanceSectionProps> = ({
  staff,
  attendanceRecords,
  onMarkAttendance,
  onUpdateAttendance,
  onDeleteAttendance,
  canManageAttendance,
  currentUserDisplayName = 'Admin',
  isStaffSelfView = false
}) => {
  // Current date context: September 2026
  const currentDate = new Date();
  const [selectedYear, setSelectedYear] = useState<number>(() => {
    // Default to 2026 if current year or 2026
    return currentDate.getFullYear() === 2026 ? 2026 : 2026;
  });
  const [selectedMonth, setSelectedMonth] = useState<number>(9); // September = 9

  // Selected date for daily marking / details
  const todayStr = useMemo(() => {
    const d = new Date();
    const y = 2026;
    const m = '09';
    const day = d.getDate() < 10 ? `0${d.getDate()}` : `${d.getDate()}`;
    return `${y}-${m}-${day}`;
  }, []);

  const [selectedDate, setSelectedDate] = useState<string>(todayStr);
  const [viewMode, setViewMode] = useState<'calendar' | 'table'>('calendar');

  // Daily Marking Form State
  const [status, setStatus] = useState<AttendanceStatus>('present');
  const [checkInTime, setCheckInTime] = useState<string>('09:30');
  const [checkOutTime, setCheckOutTime] = useState<string>('18:00');
  const [notes, setNotes] = useState<string>('');
  const [correctionReason, setCorrectionReason] = useState<string>('');
  const [isSubmitting, setIsSubmitting] = useState<boolean>(false);
  const [actionSuccessMessage, setActionSuccessMessage] = useState<string>('');

  // Find existing record for selectedDate
  const selectedRecord = useMemo(() => {
    return attendanceRecords.find(
      (r) => r.staffId === staff.staffId && r.date === selectedDate
    );
  }, [attendanceRecords, staff.staffId, selectedDate]);

  // When selectedDate changes, populate form with existing record or clean defaults
  React.useEffect(() => {
    if (selectedRecord) {
      setStatus(selectedRecord.status);
      setCheckInTime(selectedRecord.checkInTime || '');
      setCheckOutTime(selectedRecord.checkOutTime || '');
      setNotes(selectedRecord.notes || '');
      setCorrectionReason('');
    } else {
      // Default based on day of week (if Sunday, default to weekly_off, else present)
      const parts = selectedDate.split('-');
      if (parts.length === 3) {
        const d = new Date(parseInt(parts[0], 10), parseInt(parts[1], 10) - 1, parseInt(parts[2], 10));
        if (d.getDay() === 0) {
          setStatus('weekly_off');
          setCheckInTime('');
          setCheckOutTime('');
        } else {
          setStatus('present');
          setCheckInTime('09:30');
          setCheckOutTime('18:00');
        }
      }
      setNotes('');
      setCorrectionReason('');
    }
    setActionSuccessMessage('');
  }, [selectedDate, selectedRecord]);

  // Calculated duration for live preview
  const liveHours = useMemo(() => {
    if (status !== 'present') return { totalMinutes: 0, formatted: '' };
    return calculateWorkingHours(checkInTime, checkOutTime);
  }, [status, checkInTime, checkOutTime]);

  // Monthly summary stats
  const monthlySummary: MonthlyAttendanceSummary = useMemo(() => {
    return calculateMonthlyAttendanceSummary(
      attendanceRecords,
      staff.staffId,
      selectedYear,
      selectedMonth
    );
  }, [attendanceRecords, staff.staffId, selectedYear, selectedMonth]);

  // Calendar grid info
  const calendarData = useMemo(() => {
    return generateCalendarDays(selectedYear, selectedMonth, attendanceRecords, staff.staffId);
  }, [selectedYear, selectedMonth, attendanceRecords, staff.staffId]);

  // Month navigation handlers
  const handlePreviousMonth = () => {
    if (selectedMonth === 1) {
      setSelectedMonth(12);
      setSelectedYear((prev) => prev - 1);
    } else {
      setSelectedMonth((prev) => prev - 1);
    }
  };

  const handleNextMonth = () => {
    if (selectedMonth === 12) {
      setSelectedMonth(1);
      setSelectedYear((prev) => prev + 1);
    } else {
      setSelectedMonth((prev) => prev + 1);
    }
  };

  // Quick Shift Timing Presets
  const applyPresetShift = (inTime: string, outTime: string) => {
    setCheckInTime(inTime);
    setCheckOutTime(outTime);
    setStatus('present');
  };

  // Submit Daily Marking
  const handleSaveAttendance = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!canManageAttendance) return;

    setIsSubmitting(true);
    setActionSuccessMessage('');
    try {
      if (selectedRecord) {
        // Update existing record
        await onUpdateAttendance(
          selectedRecord.id,
          {
            status,
            checkInTime: status === 'present' ? checkInTime : undefined,
            checkOutTime: status === 'present' ? checkOutTime : undefined,
            notes: notes.trim()
          },
          correctionReason.trim() || undefined
        );
        setActionSuccessMessage(`Updated attendance for ${selectedDate}`);
      } else {
        // Mark fresh record
        await onMarkAttendance({
          staffId: staff.staffId,
          staffDocId: staff.id,
          staffName: staff.fullName,
          date: selectedDate,
          status,
          checkInTime: status === 'present' ? checkInTime : undefined,
          checkOutTime: status === 'present' ? checkOutTime : undefined,
          notes: notes.trim(),
          correctionReason: correctionReason.trim() || undefined,
          markedByUid: 'admin',
          markedByName: currentUserDisplayName
        });
        setActionSuccessMessage(`Marked attendance as ${status.toUpperCase()} for ${selectedDate}`);
      }
    } catch (err: any) {
      console.error('Error saving attendance:', err);
    } finally {
      setIsSubmitting(false);
    }
  };

  const handleDeleteRecord = async () => {
    if (!selectedRecord || !onDeleteAttendance || !canManageAttendance) return;
    if (!window.confirm(`Remove attendance record for ${selectedDate}?`)) return;

    setIsSubmitting(true);
    try {
      await onDeleteAttendance(selectedRecord.id);
      setActionSuccessMessage(`Record removed for ${selectedDate}`);
    } finally {
      setIsSubmitting(false);
    }
  };

  const statusOptions: { value: AttendanceStatus; label: string; emoji: string; desc: string }[] = [
    { value: 'present', label: 'Present', emoji: '🟢', desc: 'On-duty at café shift' },
    { value: 'absent', label: 'Absent', emoji: '🔴', desc: 'Unapproved absence' },
    { value: 'weekly_off', label: 'Weekly Off', emoji: '🔵', desc: 'Scheduled weekly off' },
    { value: 'leave', label: 'Leave', emoji: '🟡', desc: 'Approved casual/sick leave' },
    { value: 'holiday', label: 'Holiday', emoji: '⚪', desc: 'Campus official holiday' }
  ];

  return (
    <div className="space-y-6 text-stone-800">
      {/* 1. Header Toolbar with Month Navigation & Actions */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 p-4 rounded-2xl bg-stone-900 text-stone-100 shadow-sm">
        <div className="flex items-center gap-3">
          <div className="p-2.5 rounded-xl bg-amber-500/20 text-amber-400 border border-amber-500/30">
            <CalendarDays className="w-5 h-5" />
          </div>
          <div>
            <div className="flex items-center gap-2">
              <h3 className="font-bold text-base text-stone-100">
                {getMonthName(selectedMonth)} {selectedYear}
              </h3>
              <span className="px-2 py-0.5 rounded-full text-[10px] font-mono font-bold bg-stone-800 text-stone-300 border border-stone-700">
                {staff.staffId}
              </span>
            </div>
            <p className="text-xs text-stone-400">
              Attendance, working timings & monthly service hours for {staff.fullName}
            </p>
          </div>
        </div>

        {/* Month Picker Controls & Export */}
        <div className="flex items-center gap-2 flex-wrap">
          <div className="flex items-center bg-stone-800 rounded-xl p-1 border border-stone-700">
            <button
              onClick={handlePreviousMonth}
              title="Previous Month"
              className="p-1.5 rounded-lg text-stone-300 hover:text-stone-100 hover:bg-stone-700 transition cursor-pointer"
            >
              <ChevronLeft className="w-4 h-4" />
            </button>
            <span className="px-2.5 text-xs font-bold text-stone-200 min-w-[110px] text-center">
              {getMonthName(selectedMonth).slice(0, 3)} {selectedYear}
            </span>
            <button
              onClick={handleNextMonth}
              title="Next Month"
              className="p-1.5 rounded-lg text-stone-300 hover:text-stone-100 hover:bg-stone-700 transition cursor-pointer"
            >
              <ChevronRight className="w-4 h-4" />
            </button>
          </div>

          <button
            onClick={() => exportStaffAttendanceCSV(staff, attendanceRecords, selectedYear, selectedMonth)}
            className="flex items-center gap-1.5 px-3 py-2 rounded-xl bg-emerald-600 hover:bg-emerald-500 text-white font-semibold text-xs transition shadow-xs cursor-pointer"
            title="Export monthly attendance as CSV spreadsheet"
          >
            <Download className="w-3.5 h-3.5" />
            Export CSV
          </button>
        </div>
      </div>

      {/* 2. Monthly Attendance Summary Metrics Cards */}
      <div className="grid grid-cols-2 sm:grid-cols-4 lg:grid-cols-7 gap-2.5">
        {/* Working Days */}
        <div className="p-3 rounded-2xl bg-stone-50 border border-stone-200">
          <div className="text-[10px] font-bold text-stone-500 uppercase tracking-wider">
            Working Days
          </div>
          <div className="text-xl font-black text-stone-900 mt-1">
            {monthlySummary.totalWorkingDays}
          </div>
          <div className="text-[10px] text-stone-500 mt-0.5">Total expected</div>
        </div>

        {/* Present Days */}
        <div className="p-3 rounded-2xl bg-emerald-50/70 border border-emerald-200">
          <div className="text-[10px] font-bold text-emerald-800 uppercase tracking-wider flex items-center gap-1">
            <span>🟢</span> Present
          </div>
          <div className="text-xl font-black text-emerald-900 mt-1">
            {monthlySummary.presentDays} <span className="text-xs font-semibold text-emerald-700">Days</span>
          </div>
          <div className="text-[10px] text-emerald-700 mt-0.5">On duty</div>
        </div>

        {/* Absent Days */}
        <div className="p-3 rounded-2xl bg-rose-50/70 border border-rose-200">
          <div className="text-[10px] font-bold text-rose-800 uppercase tracking-wider flex items-center gap-1">
            <span>🔴</span> Absent
          </div>
          <div className="text-xl font-black text-rose-900 mt-1">
            {monthlySummary.absentDays} <span className="text-xs font-semibold text-rose-700">Days</span>
          </div>
          <div className="text-[10px] text-rose-700 mt-0.5">Unexcused</div>
        </div>

        {/* Weekly Off Days */}
        <div className="p-3 rounded-2xl bg-blue-50/70 border border-blue-200">
          <div className="text-[10px] font-bold text-blue-800 uppercase tracking-wider flex items-center gap-1">
            <span>🔵</span> Weekly Off
          </div>
          <div className="text-xl font-black text-blue-900 mt-1">
            {monthlySummary.weeklyOffDays} <span className="text-xs font-semibold text-blue-700">Days</span>
          </div>
          <div className="text-[10px] text-blue-700 mt-0.5">Scheduled off</div>
        </div>

        {/* Leave Days */}
        <div className="p-3 rounded-2xl bg-amber-50/70 border border-amber-200">
          <div className="text-[10px] font-bold text-amber-800 uppercase tracking-wider flex items-center gap-1">
            <span>🟡</span> Leave
          </div>
          <div className="text-xl font-black text-amber-900 mt-1">
            {monthlySummary.leaveDays} <span className="text-xs font-semibold text-amber-700">Days</span>
          </div>
          <div className="text-[10px] text-amber-700 mt-0.5">Approved</div>
        </div>

        {/* Holidays */}
        <div className="p-3 rounded-2xl bg-purple-50/70 border border-purple-200">
          <div className="text-[10px] font-bold text-purple-800 uppercase tracking-wider flex items-center gap-1">
            <span>⚪</span> Holidays
          </div>
          <div className="text-xl font-black text-purple-900 mt-1">
            {monthlySummary.holidayDays} <span className="text-xs font-semibold text-purple-700">Days</span>
          </div>
          <div className="text-[10px] text-purple-700 mt-0.5">Campus holiday</div>
        </div>

        {/* Attendance Percentage */}
        <div className="p-3 rounded-2xl bg-amber-500/10 border border-amber-400/40">
          <div className="text-[10px] font-bold text-amber-900 uppercase tracking-wider">
            Attendance %
          </div>
          <div className="text-xl font-black text-amber-900 mt-1">
            {monthlySummary.attendancePercentage}%
          </div>
          <div className="text-[10px] text-amber-800 font-medium mt-0.5">
            {monthlySummary.totalWorkingHoursFormatted}
          </div>
        </div>
      </div>

      {/* 3. Main Workspace: Calendar Grid + Daily Attendance Marking Panel */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-5">
        {/* Left / Main Column: Attendance Calendar (7 Cols on desktop) */}
        <div className="lg:col-span-7 space-y-3">
          <div className="flex items-center justify-between p-3 rounded-xl bg-stone-50 border border-stone-200">
            <div className="flex items-center gap-2">
              <span className="text-xs font-bold text-stone-800">
                {getMonthName(selectedMonth)} {selectedYear} Calendar
              </span>
              <span className="text-[11px] text-stone-500 font-normal">
                (Click any day to inspect or mark)
              </span>
            </div>
            {/* View switcher */}
            <div className="flex items-center bg-stone-200/80 p-0.5 rounded-lg text-[11px] font-semibold">
              <button
                onClick={() => setViewMode('calendar')}
                className={`px-2.5 py-1 rounded-md transition cursor-pointer ${
                  viewMode === 'calendar'
                    ? 'bg-white text-stone-900 shadow-2xs'
                    : 'text-stone-600 hover:text-stone-900'
                }`}
              >
                Calendar
              </button>
              <button
                onClick={() => setViewMode('table')}
                className={`px-2.5 py-1 rounded-md transition cursor-pointer ${
                  viewMode === 'table'
                    ? 'bg-white text-stone-900 shadow-2xs'
                    : 'text-stone-600 hover:text-stone-900'
                }`}
              >
                List View
              </button>
            </div>
          </div>

          {viewMode === 'calendar' ? (
            <div className="p-4 rounded-2xl bg-white border border-stone-200 shadow-xs">
              {/* Day of week headers (Monday to Sunday) */}
              <div className="grid grid-cols-7 gap-1 text-center font-bold text-[11px] text-stone-400 uppercase tracking-wider mb-2">
                <span className="py-1">Mon</span>
                <span className="py-1">Tue</span>
                <span className="py-1">Wed</span>
                <span className="py-1">Thu</span>
                <span className="py-1">Fri</span>
                <span className="py-1 text-amber-600">Sat</span>
                <span className="py-1 text-rose-500">Sun</span>
              </div>

              {/* Calendar Grid Cells */}
              <div className="grid grid-cols-7 gap-1.5">
                {/* Empty padding days for first week */}
                {Array.from({ length: calendarData.paddingDays }).map((_, i) => (
                  <div key={`pad-${i}`} className="min-h-[64px] rounded-xl bg-stone-50/40 border border-transparent" />
                ))}

                {/* Day Cells */}
                {calendarData.days.map((day) => {
                  const isSelected = selectedDate === day.dateString;
                  const rec = day.record;
                  const config = rec ? getAttendanceStatusConfig(rec.status) : null;

                  return (
                    <button
                      key={day.dateString}
                      type="button"
                      onClick={() => setSelectedDate(day.dateString)}
                      className={`min-h-[68px] p-1.5 rounded-xl border text-left transition relative flex flex-col justify-between cursor-pointer group ${
                        isSelected
                          ? 'ring-2 ring-amber-500 border-amber-500 shadow-sm bg-amber-50/20'
                          : rec
                          ? `${config?.badgeBg} ${config?.borderColor} hover:border-amber-400`
                          : day.isToday
                          ? 'border-amber-400 bg-amber-50/30'
                          : day.isWeekend
                          ? 'border-stone-200/80 bg-stone-50/50 hover:bg-stone-100/70'
                          : 'border-stone-200 bg-white hover:bg-stone-50'
                      }`}
                    >
                      {/* Top row: day number & today marker */}
                      <div className="flex items-center justify-between w-full">
                        <span
                          className={`text-xs font-bold ${
                            day.isToday
                              ? 'w-5 h-5 rounded-full bg-amber-500 text-stone-950 flex items-center justify-center -ml-0.5'
                              : isSelected
                              ? 'text-amber-900'
                              : 'text-stone-700'
                          }`}
                        >
                          {day.dayNumber}
                        </span>

                        {rec && (
                          <span className="text-[12px]" title={config?.label}>
                            {config?.emoji}
                          </span>
                        )}
                      </div>

                      {/* Bottom status badge / hours */}
                      <div className="mt-1">
                        {rec ? (
                          <div className="space-y-0.5">
                            <span className="text-[10px] font-bold block leading-tight truncate">
                              {config?.shortLabel} - {config?.label}
                            </span>
                            {rec.status === 'present' && rec.totalWorkingHoursFormatted ? (
                              <span className="text-[9px] font-mono text-emerald-800 font-semibold block truncate">
                                {rec.totalWorkingHoursFormatted}
                              </span>
                            ) : null}
                          </div>
                        ) : (
                          <span className="text-[9px] text-stone-400 font-medium block truncate">
                            {day.isWeekend ? 'Off' : 'Unmarked'}
                          </span>
                        )}
                      </div>
                    </button>
                  );
                })}
              </div>

              {/* Status Legend Footnote */}
              <div className="mt-4 pt-3 border-t border-stone-100 flex items-center justify-center gap-3 flex-wrap text-[11px] text-stone-600 font-medium">
                <span className="flex items-center gap-1">🟢 Present</span>
                <span className="flex items-center gap-1">🔴 Absent</span>
                <span className="flex items-center gap-1">🔵 Weekly Off</span>
                <span className="flex items-center gap-1">🟡 Leave</span>
                <span className="flex items-center gap-1">⚪ Holiday</span>
              </div>
            </div>
          ) : (
            /* Table Log View */
            <div className="rounded-2xl border border-stone-200 overflow-hidden bg-white shadow-xs max-h-[460px] overflow-y-auto">
              <table className="w-full text-left text-xs border-collapse">
                <thead className="bg-stone-50 border-b border-stone-200 sticky top-0 z-10 text-stone-600 font-semibold text-[11px]">
                  <tr>
                    <th className="p-3">Date</th>
                    <th className="p-3">Status</th>
                    <th className="p-3">Timings</th>
                    <th className="p-3">Hours</th>
                    <th className="p-3">Notes</th>
                    <th className="p-3">Action</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-stone-100">
                  {calendarData.days.map((day) => {
                    const rec = day.record;
                    const config = rec ? getAttendanceStatusConfig(rec.status) : null;
                    const isSelected = selectedDate === day.dateString;

                    return (
                      <tr
                        key={day.dateString}
                        onClick={() => setSelectedDate(day.dateString)}
                        className={`hover:bg-amber-50/40 cursor-pointer transition ${
                          isSelected ? 'bg-amber-50/60 font-semibold' : ''
                        }`}
                      >
                        <td className="p-3 whitespace-nowrap">
                          <span className="font-bold text-stone-900">{day.dateString}</span>
                          <span className="text-[10px] text-stone-400 ml-1.5">({day.dayName})</span>
                        </td>
                        <td className="p-3">
                          {rec ? (
                            <span
                              className={`inline-flex items-center gap-1 px-2 py-0.5 rounded-full text-[11px] font-bold ${config?.badgeBg}`}
                            >
                              {config?.emoji} {config?.label}
                            </span>
                          ) : (
                            <span className="text-stone-400 italic text-[11px]">Not Marked</span>
                          )}
                        </td>
                        <td className="p-3 font-mono text-[11px] text-stone-700 whitespace-nowrap">
                          {rec?.checkInTime && rec?.checkOutTime
                            ? `${rec.checkInTime} – ${rec.checkOutTime}`
                            : rec?.checkInTime
                            ? `In: ${rec.checkInTime}`
                            : '-'}
                        </td>
                        <td className="p-3 font-mono text-[11px] text-stone-800 whitespace-nowrap">
                          {rec?.totalWorkingHoursFormatted || '-'}
                        </td>
                        <td className="p-3 text-[11px] text-stone-600 max-w-[140px] truncate">
                          {rec?.notes || '-'}
                        </td>
                        <td className="p-3">
                          <button
                            type="button"
                            onClick={(e) => {
                              e.stopPropagation();
                              setSelectedDate(day.dateString);
                            }}
                            className="text-xs text-amber-700 hover:text-amber-900 font-semibold cursor-pointer underline"
                          >
                            {canManageAttendance ? 'Mark/Edit' : 'View'}
                          </button>
                        </td>
                      </tr>
                    );
                  })}
                </tbody>
              </table>
            </div>
          )}
        </div>

        {/* Right Column: Daily Attendance Marking & History Form (5 Cols on desktop) */}
        <div className="lg:col-span-5 space-y-4">
          {/* Action Success Toast Banner */}
          {actionSuccessMessage && (
            <div className="p-3 rounded-xl bg-emerald-50 border border-emerald-300 text-emerald-900 text-xs flex items-center gap-2">
              <CheckCircle2 className="w-4 h-4 text-emerald-600 shrink-0" />
              <span>{actionSuccessMessage}</span>
            </div>
          )}

          {/* Form Card */}
          <div className="p-5 rounded-2xl bg-stone-50 border border-stone-200 shadow-xs space-y-4">
            {/* Header with Selected Date & Record Status */}
            <div className="flex items-center justify-between border-b border-stone-200 pb-3">
              <div>
                <div className="text-[10px] uppercase font-bold text-stone-500 tracking-wider">
                  Selected Attendance Date
                </div>
                <div className="text-base font-bold text-stone-900 flex items-center gap-2 mt-0.5">
                  <CalendarIcon className="w-4 h-4 text-amber-600" />
                  {selectedDate}
                </div>
              </div>

              {selectedRecord ? (
                <div className="text-right">
                  <span className="text-[10px] uppercase font-bold text-stone-400 block">Current Status</span>
                  <span className="text-xs font-bold text-stone-800">
                    {getAttendanceStatusConfig(selectedRecord.status).emoji}{' '}
                    {getAttendanceStatusConfig(selectedRecord.status).label}
                  </span>
                </div>
              ) : (
                <span className="px-2 py-0.5 rounded-full text-[10px] font-semibold bg-stone-200 text-stone-700">
                  Unmarked
                </span>
              )}
            </div>

            {/* Read-Only Banner if Staff Member cannot edit */}
            {!canManageAttendance && (
              <div className="p-3 rounded-xl bg-amber-50 border border-amber-300 text-amber-900 text-xs flex items-start gap-2.5">
                <Lock className="w-4 h-4 text-amber-700 shrink-0 mt-0.5" />
                <div>
                  <div className="font-bold">Read-Only Staff View</div>
                  <p className="text-[11px] text-amber-800 mt-0.5 leading-relaxed">
                    You can view your monthly calendar, working hours, and summaries. For modifications or leave adjustments, contact the café manager or administrator.
                  </p>
                </div>
              </div>
            )}

            {/* Marking / Editing Form */}
            <form onSubmit={handleSaveAttendance} className="space-y-4">
              {/* Status Radio Buttons */}
              <div className="space-y-1.5">
                <label className="block text-xs font-bold text-stone-800">
                  Daily Attendance Status *
                </label>
                <div className="grid grid-cols-2 sm:grid-cols-3 gap-2">
                  {statusOptions.map((opt) => {
                    const isSelected = status === opt.value;
                    const config = getAttendanceStatusConfig(opt.value);

                    return (
                      <button
                        key={opt.value}
                        type="button"
                        disabled={!canManageAttendance}
                        onClick={() => setStatus(opt.value)}
                        className={`p-2.5 rounded-xl border text-left transition flex items-center gap-2 cursor-pointer ${
                          isSelected
                            ? `${config.badgeBg} border-amber-500 ring-1 ring-amber-400 font-bold shadow-xs`
                            : 'bg-white border-stone-200 text-stone-700 hover:border-stone-300'
                        } ${!canManageAttendance ? 'opacity-80 cursor-not-allowed' : ''}`}
                      >
                        <span className="text-sm">{opt.emoji}</span>
                        <div className="leading-tight">
                          <div className="text-xs">{opt.label}</div>
                        </div>
                      </button>
                    );
                  })}
                </div>
              </div>

              {/* Working Timings Section (Show when status is Present) */}
              {status === 'present' && (
                <div className="p-3.5 rounded-xl bg-white border border-stone-200 space-y-3">
                  <div className="flex items-center justify-between">
                    <span className="text-xs font-bold text-stone-800 flex items-center gap-1.5">
                      <Clock className="w-3.5 h-3.5 text-stone-500" /> Work Timing Tracking
                    </span>
                    {liveHours.formatted && (
                      <span className="px-2 py-0.5 rounded-md text-[11px] font-mono font-bold bg-emerald-100 text-emerald-800 border border-emerald-300">
                        Total: {liveHours.formatted}
                      </span>
                    )}
                  </div>

                  <div className="grid grid-cols-2 gap-3">
                    <div>
                      <label className="block text-[11px] font-semibold text-stone-600 mb-1">
                        Check-in Time
                      </label>
                      <input
                        type="time"
                        disabled={!canManageAttendance}
                        value={checkInTime}
                        onChange={(e) => setCheckInTime(e.target.value)}
                        className="w-full p-2 rounded-lg border border-stone-300 text-xs font-mono font-semibold bg-stone-50 focus:bg-white focus:border-amber-500 focus:outline-hidden disabled:bg-stone-100"
                      />
                    </div>

                    <div>
                      <label className="block text-[11px] font-semibold text-stone-600 mb-1">
                        Check-out Time
                      </label>
                      <input
                        type="time"
                        disabled={!canManageAttendance}
                        value={checkOutTime}
                        onChange={(e) => setCheckOutTime(e.target.value)}
                        className="w-full p-2 rounded-lg border border-stone-300 text-xs font-mono font-semibold bg-stone-50 focus:bg-white focus:border-amber-500 focus:outline-hidden disabled:bg-stone-100"
                      />
                    </div>
                  </div>

                  {/* Quick Shift Presets (for fast daily marking) */}
                  {canManageAttendance && (
                    <div className="pt-1">
                      <span className="text-[10px] uppercase font-bold text-stone-400 block mb-1">
                        Quick Shift Presets:
                      </span>
                      <div className="flex items-center gap-1.5 flex-wrap">
                        <button
                          type="button"
                          onClick={() => applyPresetShift('09:30', '18:00')}
                          className="px-2 py-1 rounded bg-stone-100 hover:bg-stone-200 text-[10px] font-mono text-stone-700 transition cursor-pointer"
                        >
                          Regular (9:30 – 18:00)
                        </button>
                        <button
                          type="button"
                          onClick={() => applyPresetShift('08:00', '16:30')}
                          className="px-2 py-1 rounded bg-stone-100 hover:bg-stone-200 text-[10px] font-mono text-stone-700 transition cursor-pointer"
                        >
                          Morning (8:00 – 16:30)
                        </button>
                        <button
                          type="button"
                          onClick={() => applyPresetShift('13:00', '21:30')}
                          className="px-2 py-1 rounded bg-stone-100 hover:bg-stone-200 text-[10px] font-mono text-stone-700 transition cursor-pointer"
                        >
                          Evening (13:00 – 21:30)
                        </button>
                      </div>
                    </div>
                  )}
                </div>
              )}

              {/* Notes / Remarks Input */}
              <div className="space-y-1">
                <label className="block text-[11px] font-semibold text-stone-700">
                  Notes / Shift Remarks (Optional)
                </label>
                <input
                  type="text"
                  disabled={!canManageAttendance}
                  value={notes}
                  onChange={(e) => setNotes(e.target.value)}
                  placeholder="e.g., Counter POS opening, late due to exam, overtime prep"
                  className="w-full p-2.5 rounded-xl border border-stone-300 text-xs bg-white focus:border-amber-500 focus:outline-hidden disabled:bg-stone-100"
                />
              </div>

              {/* Correction Reason (Mandatory/recommended when modifying an existing record) */}
              {selectedRecord && canManageAttendance && (
                <div className="space-y-1 p-3 rounded-xl bg-amber-50/60 border border-amber-200">
                  <label className="block text-[11px] font-bold text-amber-900 flex items-center gap-1">
                    <History className="w-3.5 h-3.5 text-amber-700" /> Correction Reason / Audit Log
                  </label>
                  <input
                    type="text"
                    value={correctionReason}
                    onChange={(e) => setCorrectionReason(e.target.value)}
                    placeholder="State reason (e.g., Verified medical slip, punch-in correction)"
                    className="w-full p-2 rounded-lg border border-amber-300 text-xs bg-white focus:border-amber-600 focus:outline-hidden"
                  />
                  <span className="text-[10px] text-amber-800 block">
                    Permanent audit history is retained with your supervisor ID.
                  </span>
                </div>
              )}

              {/* Form Action Buttons (Only for authorized managers/admins) */}
              {canManageAttendance && (
                <div className="flex items-center gap-2 pt-2">
                  <button
                    type="submit"
                    disabled={isSubmitting}
                    className="flex-1 py-2.5 px-4 rounded-xl bg-stone-900 hover:bg-stone-800 text-white font-bold text-xs transition flex items-center justify-center gap-1.5 shadow-sm cursor-pointer disabled:opacity-50"
                  >
                    <Check className="w-4 h-4 text-emerald-400" />
                    {isSubmitting
                      ? 'Saving...'
                      : selectedRecord
                      ? 'Save Changes'
                      : 'Mark Attendance'}
                  </button>

                  {selectedRecord && onDeleteAttendance && (
                    <button
                      type="button"
                      disabled={isSubmitting}
                      onClick={handleDeleteRecord}
                      className="p-2.5 rounded-xl bg-rose-50 hover:bg-rose-100 text-rose-700 border border-rose-200 transition cursor-pointer disabled:opacity-50"
                      title="Delete record"
                    >
                      <Trash2 className="w-4 h-4" />
                    </button>
                  )}
                </div>
              )}
            </form>

            {/* Record Metadata & Supervisor Info */}
            {selectedRecord && (
              <div className="pt-3 border-t border-stone-200 text-[11px] text-stone-500 space-y-1">
                <div className="flex justify-between">
                  <span>Marked By:</span>
                  <span className="font-semibold text-stone-700">
                    {selectedRecord.markedByName}
                  </span>
                </div>
                <div className="flex justify-between">
                  <span>Recorded At:</span>
                  <span className="font-mono text-stone-700">
                    {new Date(selectedRecord.createdAt).toLocaleString('en-US', {
                      month: 'short',
                      day: 'numeric',
                      hour: '2-digit',
                      minute: '2-digit'
                    })}
                  </span>
                </div>

                {/* Audit Correction Log History Display */}
                {selectedRecord.history && selectedRecord.history.length > 0 && (
                  <div className="mt-3 pt-2 border-t border-stone-200">
                    <span className="font-bold text-stone-700 text-[10px] uppercase tracking-wider block mb-1">
                      Modification History ({selectedRecord.history.length})
                    </span>
                    <div className="space-y-1.5 max-h-32 overflow-y-auto">
                      {selectedRecord.history.map((h, idx) => (
                        <div
                          key={idx}
                          className="p-2 rounded-lg bg-white border border-stone-200 text-[10px] text-stone-600"
                        >
                          <div className="flex justify-between font-semibold text-stone-800">
                            <span>{h.changedByName}</span>
                            <span className="font-mono text-stone-400">
                              {new Date(h.changedAt).toLocaleDateString()}
                            </span>
                          </div>
                          <div className="mt-0.5">
                            Status changed to <span className="font-bold uppercase text-stone-900">{h.newStatus}</span>
                          </div>
                          {h.reason && (
                            <div className="text-stone-500 italic mt-0.5">
                              "{h.reason}"
                            </div>
                          )}
                        </div>
                      ))}
                    </div>
                  </div>
                )}
              </div>
            )}
          </div>
        </div>
      </div>
    </div>
  );
};
