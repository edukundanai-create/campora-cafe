import React from 'react';
import { useCafe } from '../../context/CafeContext';
import {
  X,
  MapPin,
  Clock,
  Phone,
  MessageCircle,
  Mail,
  Navigation,
  Wifi,
  Car,
  ShieldCheck,
  ExternalLink,
  Building2
} from 'lucide-react';
import { motion, AnimatePresence } from 'motion/react';

export const LocationHoursModal: React.FC = () => {
  const {
    isLocationModalOpen,
    setIsLocationModalOpen,
    settings,
    isCafeOpenNow
  } = useCafe();

  const todayName = new Date().toLocaleDateString('en-US', { weekday: 'long' });

  return (
    <AnimatePresence>
      {isLocationModalOpen && (
        <div id="location-hours-modal" className="fixed inset-0 z-50 overflow-y-auto bg-stone-950/70 backdrop-blur-sm flex items-end sm:items-center justify-center p-0 sm:p-4">
          
          {/* Backdrop */}
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            onClick={() => setIsLocationModalOpen(false)}
            className="fixed inset-0"
          />

        {/* Modal Window */}
        <motion.div
          initial={{ opacity: 0, y: 50, scale: 0.95 }}
          animate={{ opacity: 1, y: 0, scale: 1 }}
          exit={{ opacity: 0, y: 50, scale: 0.95 }}
          className="relative z-10 bg-white w-full sm:max-w-xl max-h-[90vh] rounded-t-3xl sm:rounded-3xl shadow-2xl flex flex-col overflow-hidden border border-stone-200"
        >
          {/* Header */}
          <div className="p-4 sm:p-5 border-b border-stone-200 flex items-center justify-between bg-stone-50">
            <div className="flex items-center gap-2">
              <div className="w-8 h-8 rounded-lg bg-amber-100 text-amber-800 flex items-center justify-center">
                <MapPin className="w-4 h-4" />
              </div>
              <div>
                <h3 className="text-base font-bold text-stone-900 font-serif">Campus Location & Hours</h3>
                <p className="text-xs text-stone-500">{settings.name} • {settings.campusName}</p>
              </div>
            </div>

            <button
              onClick={() => setIsLocationModalOpen(false)}
              className="p-1.5 rounded-full hover:bg-stone-200 text-stone-500 transition-colors"
            >
              <X className="w-5 h-5" />
            </button>
          </div>

          {/* Scrollable Content */}
          <div className="p-5 overflow-y-auto space-y-6 text-xs text-stone-700">
            
            {/* Real-time Status Card */}
            <div className={`p-4 rounded-2xl border flex items-center justify-between ${
              isCafeOpenNow
                ? 'bg-emerald-50 border-emerald-200 text-emerald-950'
                : 'bg-rose-50 border-rose-200 text-rose-950'
            }`}>
              <div className="flex items-center gap-2.5">
                <span className={`w-3 h-3 rounded-full ${isCafeOpenNow ? 'bg-emerald-500 animate-ping' : 'bg-rose-400'}`} />
                <div>
                  <p className="font-bold text-sm">
                    {isCafeOpenNow ? 'Campora Cafe is Open Now!' : 'Currently Closed'}
                  </p>
                  <p className="text-xs opacity-80">
                    {isCafeOpenNow ? 'Serving fresh kulhad chai, Maggi, patties & barista brews.' : 'Online advance table reservations and pre-orders active.'}
                  </p>
                </div>
              </div>
            </div>

            {/* Embedded Google Map */}
            <div className="space-y-2">
              <div className="flex justify-between items-center">
                <span className="font-bold uppercase tracking-wider text-stone-800 text-[11px] flex items-center gap-1.5">
                  <Building2 className="w-3.5 h-3.5 text-amber-700" />
                  GEC Banka Campus Google Map
                </span>
                <a
                  href={settings.googleMapsDirectionsUrl}
                  target="_blank"
                  rel="noopener noreferrer"
                  className="text-amber-800 hover:text-amber-900 font-semibold flex items-center gap-1 underline underline-offset-2"
                >
                  <Navigation className="w-3 h-3 text-amber-700" />
                  <span>Reach Here (Directions)</span>
                  <ExternalLink className="w-3 h-3" />
                </a>
              </div>
              
              <div className="w-full h-44 rounded-2xl overflow-hidden border border-stone-200 bg-stone-100 relative">
                <iframe
                  title="Campora Cafe GEC Banka Campus Map"
                  src={settings.googleMapEmbedUrl}
                  className="w-full h-full border-0"
                  loading="lazy"
                  allowFullScreen
                />
              </div>
              <div className="p-3 bg-stone-50 rounded-xl border border-stone-200 space-y-1">
                <p className="text-stone-900 font-bold">{settings.address}</p>
                <p className="text-stone-600">{settings.city} - {settings.pincode}, Bihar, India</p>
              </div>
            </div>

            {/* Operating Hours Table */}
            <div className="space-y-2">
              <span className="font-bold uppercase tracking-wider text-stone-800 text-[11px] flex items-center gap-1.5">
                <Clock className="w-3.5 h-3.5 text-amber-700" />
                Campus Timetable
              </span>
              <div className="rounded-xl border border-stone-200 divide-y divide-stone-100 overflow-hidden bg-stone-50/50">
                {settings.operatingHours.map((hour) => {
                  const isToday = hour.day.toLowerCase() === todayName.toLowerCase();
                  return (
                    <div
                      key={hour.day}
                      className={`p-2.5 flex items-center justify-between ${
                        isToday ? 'bg-amber-100/70 font-bold text-amber-950' : 'text-stone-600'
                      }`}
                    >
                      <div className="flex items-center gap-2">
                        {isToday && <span className="w-1.5 h-1.5 rounded-full bg-amber-800" />}
                        <span>{hour.day}</span>
                        {isToday && <span className="text-[10px] bg-amber-200 px-1.5 py-0.5 rounded text-amber-900">Today</span>}
                      </div>
                      <span>{hour.isClosed ? 'Closed' : `${hour.open} - ${hour.close}`}</span>
                    </div>
                  );
                })}
              </div>
            </div>

            {/* Amenities & Parking Info */}
            <div className="grid grid-cols-2 gap-3">
              <div className="p-3 rounded-xl bg-stone-100 border border-stone-200 space-y-1">
                <div className="flex items-center gap-1.5 font-bold text-stone-900">
                  <Wifi className="w-3.5 h-3.5 text-amber-700" />
                  <span>High-Speed Campus Wi-Fi</span>
                </div>
                <p className="text-[11px] text-stone-500">SSID: <span className="font-mono font-semibold">Campora_GEC_Banka</span></p>
                <p className="text-[11px] text-stone-500">Pass: <span className="font-mono font-semibold">gecbanka@2026</span></p>
              </div>

              <div className="p-3 rounded-xl bg-stone-100 border border-stone-200 space-y-1">
                <div className="flex items-center gap-1.5 font-bold text-stone-900">
                  <Car className="w-3.5 h-3.5 text-amber-700" />
                  <span>Parking & Campus Gate</span>
                </div>
                <p className="text-[11px] text-stone-500">Free two-wheeler and bicycle stands outside Student Center. Auto-rickshaw stand at Main Gate.</p>
              </div>
            </div>

            {/* Direct Contact Action Buttons */}
            <div className="grid grid-cols-2 gap-2 pt-2 border-t border-stone-200">
              <a
                href={`tel:${settings.phone}`}
                className="p-2.5 rounded-xl bg-stone-900 text-white font-semibold flex items-center justify-center gap-2 hover:bg-stone-800 transition-colors"
              >
                <Phone className="w-3.5 h-3.5 text-amber-400" />
                <span>Call Kitchen ({settings.phone})</span>
              </a>

              <a
                href={`https://wa.me/${settings.whatsapp}`}
                target="_blank"
                rel="noopener noreferrer"
                className="p-2.5 rounded-xl bg-emerald-700 text-white font-semibold flex items-center justify-center gap-2 hover:bg-emerald-800 transition-colors"
              >
                <MessageCircle className="w-3.5 h-3.5" />
                <span>WhatsApp Order</span>
              </a>
            </div>

          </div>
        </motion.div>
      </div>
    )}
  </AnimatePresence>
);
};
