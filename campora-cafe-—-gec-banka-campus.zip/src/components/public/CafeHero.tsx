import React, { useState, useEffect } from 'react';
import { useCafe } from '../../context/CafeContext';
import {
  Star,
  Clock,
  MapPin,
  Phone,
  MessageCircle,
  Mail,
  CalendarCheck,
  Award,
  Sparkles,
  ChevronRight,
  ShieldCheck,
  UtensilsCrossed,
  ShoppingBag,
  Truck,
  Flame,
  Info,
  AlertCircle
} from 'lucide-react';
import { motion } from 'motion/react';

const HERO_SLIDES = [
  {
    image: 'https://images.unsplash.com/photo-1501339847302-ac426a4a7cbb?w=1600&auto=format&fit=crop&q=80',
    title: 'Handcrafted Specialty Coffee',
    subtitle: 'Micro-lot single origins roasted to perfection weekly'
  },
  {
    image: 'https://images.unsplash.com/photo-1554118811-1e0d58224f24?w=1600&auto=format&fit=crop&q=80',
    title: 'Artisan Brunch & Bakery',
    subtitle: 'Fresh 72-hr sourdough pastries & organic farm-to-table plates'
  },
  {
    image: 'https://images.unsplash.com/photo-1442512595331-e89e73853f31?w=1600&auto=format&fit=crop&q=80',
    title: 'Warm Heritage Atmosphere',
    subtitle: 'Sunlit terrace seating, cozy window booths & quiet study lounges'
  }
];

export const CafeHero: React.FC = () => {
  const {
    settings,
    isCafeOpenNow,
    currentDaySchedule,
    setIsLocationModalOpen,
    setIsCheckoutOpen,
    applyPromoCode,
    showToast
  } = useCafe();

  const [currentSlideIndex, setCurrentSlideIndex] = useState(0);

  // Auto rotate hero slides gently
  useEffect(() => {
    const timer = setInterval(() => {
      setCurrentSlideIndex((prev) => (prev + 1) % HERO_SLIDES.length);
    }, 6000);
    return () => clearInterval(timer);
  }, []);

  const handleCopyPromo = (code: string) => {
    const res = applyPromoCode(code);
    if (!res.success) {
      showToast('Promo Code Copied!', `Use code "${code}" at checkout.`, 'info');
    }
  };

  return (
    <section id="cafe-hero-section" className="relative overflow-hidden pt-4 pb-8 sm:py-10">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 space-y-6">
        
        {/* Main Hero Card */}
        <div className="relative rounded-3xl overflow-hidden bg-stone-900 text-stone-100 shadow-2xl border border-stone-800">
          
          {/* Background Images with smooth fade */}
          <div className="absolute inset-0 z-0">
            {HERO_SLIDES.map((slide, idx) => (
              <motion.div
                key={idx}
                initial={{ opacity: 0, scale: 1.05 }}
                animate={{
                  opacity: currentSlideIndex === idx ? 1 : 0,
                  scale: currentSlideIndex === idx ? 1 : 1.05
                }}
                transition={{ duration: 1.2, ease: 'easeOut' }}
                className="absolute inset-0 bg-cover bg-center"
                style={{ backgroundImage: `url(${slide.image})` }}
              />
            ))}
            {/* Gradient Overlays for High Legibility */}
            <div className="absolute inset-0 bg-gradient-to-t from-stone-950 via-stone-950/70 to-stone-950/40" />
            <div className="absolute inset-0 bg-gradient-to-r from-stone-950/90 via-stone-950/50 to-transparent" />
          </div>

          {/* Hero Content */}
          <div className="relative z-10 p-6 sm:p-10 lg:p-14 flex flex-col justify-between min-h-[380px] sm:min-h-[440px]">
            
            {/* Top Badges */}
            <div className="flex flex-wrap items-center gap-2.5">
              
              {/* Rating Badge */}
              <div className="inline-flex items-center gap-1.5 px-3 py-1.5 rounded-full bg-stone-900/80 backdrop-blur-md border border-stone-700/60 text-xs font-semibold text-amber-300">
                <Star className="w-3.5 h-3.5 fill-amber-400 text-amber-400" />
                <span>4.9</span>
                <span className="text-stone-400 font-normal">(340+ reviews)</span>
              </div>

              {/* Real-Time Live Status Pill */}
              <button
                onClick={() => setIsLocationModalOpen(true)}
                className={`inline-flex items-center gap-1.5 px-3.5 py-1.5 rounded-full backdrop-blur-md border text-xs font-bold transition-all hover:scale-105 ${
                  isCafeOpenNow
                    ? 'bg-emerald-950/80 border-emerald-500/40 text-emerald-300'
                    : 'bg-rose-950/80 border-rose-500/40 text-rose-300'
                }`}
              >
                <span
                  className={`w-2.5 h-2.5 rounded-full shrink-0 ${
                    isCafeOpenNow ? 'bg-emerald-400 animate-pulse' : 'bg-rose-500'
                  }`}
                />
                <span>
                  {isCafeOpenNow
                    ? '🟢 We Are Open – Order Now'
                    : '🔴 Currently Closed – Ordering is Temporarily Unavailable'}
                </span>
                <ChevronRight className="w-3 h-3 text-stone-400 shrink-0" />
              </button>

              {/* Hygiene Certified Pill */}
              <div className="hidden sm:inline-flex items-center gap-1.5 px-3 py-1.5 rounded-full bg-stone-900/80 backdrop-blur-md border border-stone-700/60 text-xs font-medium text-stone-200">
                <ShieldCheck className="w-3.5 h-3.5 text-emerald-400" />
                <span>Grade A Certified Clean</span>
              </div>

            </div>

            {/* Middle Title & Tagline */}
            <div className="space-y-3 my-6 max-w-2xl">
              <h1 className="text-3xl sm:text-4xl lg:text-5xl font-bold tracking-tight text-stone-50 font-serif leading-tight">
                {settings.name}
              </h1>
              <p className="text-sm sm:text-base text-stone-300 font-normal leading-relaxed">
                {settings.tagline}
              </p>

              {!isCafeOpenNow && (
                <div className="p-3 rounded-2xl bg-rose-950/80 border border-rose-500/40 text-rose-200 text-xs flex items-center gap-2.5 backdrop-blur-xs">
                  <AlertCircle className="w-4 h-4 text-rose-400 shrink-0" />
                  <span>
                    <strong>Notice:</strong> {settings.closedNotice || 'We are temporarily closed for prep. You can explore all our menu items and pricing below.'}
                  </span>
                </div>
              )}
            </div>

            {/* Bottom Actions & Quick Contact Bar */}
            <div className="flex flex-col sm:flex-row items-stretch sm:items-center justify-between gap-4 pt-4 border-t border-stone-800/80">
              
              {/* Primary Call to Actions */}
              <div className="flex flex-wrap items-center gap-3">
                <button
                  id="hero-reserve-table-btn"
                  onClick={() => {
                    if (!isCafeOpenNow) {
                      showToast('Currently Closed', 'Table bookings and online orders are temporarily paused. Feel free to browse our menu below!', 'warning');
                    } else {
                      setIsCheckoutOpen(true);
                    }
                  }}
                  className={`flex-1 sm:flex-initial min-h-[44px] px-5 py-2.5 font-bold text-sm rounded-xl transition-all flex items-center justify-center gap-2 cursor-pointer ${
                    isCafeOpenNow
                      ? 'bg-amber-500 hover:bg-amber-400 active:bg-amber-600 text-stone-950 shadow-lg shadow-amber-500/20'
                      : 'bg-stone-800 text-stone-400 hover:bg-stone-700 border border-stone-700'
                  }`}
                >
                  <CalendarCheck className="w-4 h-4 text-amber-400" />
                  <span>{isCafeOpenNow ? 'Reserve a Table' : 'Table Booking Paused'}</span>
                </button>

                <button
                  id="hero-view-menu-btn"
                  onClick={() => {
                    const menuEl = document.getElementById('menu-section');
                    menuEl?.scrollIntoView({ behavior: 'smooth' });
                  }}
                  className="flex-1 sm:flex-initial min-h-[44px] px-5 py-2.5 bg-stone-800/90 hover:bg-stone-700 active:bg-stone-800 text-stone-100 font-semibold text-sm rounded-xl border border-stone-700 transition-all flex items-center justify-center gap-2 cursor-pointer"
                >
                  <UtensilsCrossed className="w-4 h-4 text-amber-400" />
                  <span>{isCafeOpenNow ? 'Order Menu' : 'Browse Menu & Prices'}</span>
                </button>
              </div>

              {/* Quick Contact Icons (WhatsApp, Phone, Map) */}
              <div className="flex items-center justify-start sm:justify-end gap-2 text-stone-300">
                
                {/* WhatsApp button */}
                <a
                  href={`https://wa.me/${settings.whatsapp}?text=Hello%20${encodeURIComponent(
                    settings.name
                  )},%20I%20would%20like%20to%20inquire%20about%20a%20table%20reservation.`}
                  target="_blank"
                  rel="noopener noreferrer"
                  className="p-2.5 rounded-xl bg-stone-800/80 hover:bg-emerald-900/60 hover:text-emerald-300 border border-stone-700 transition-colors flex items-center gap-1.5 text-xs font-medium"
                  title="Chat on WhatsApp"
                >
                  <MessageCircle className="w-4 h-4 text-emerald-400" />
                  <span className="hidden sm:inline">WhatsApp</span>
                </a>

                {/* Phone Call button */}
                <a
                  href={`tel:${settings.phone}`}
                  className="p-2.5 rounded-xl bg-stone-800/80 hover:bg-stone-700 text-stone-200 border border-stone-700 transition-colors flex items-center gap-1.5 text-xs font-medium"
                  title="Call Cafe Directly"
                >
                  <Phone className="w-4 h-4 text-amber-400" />
                  <span className="hidden sm:inline">Call</span>
                </a>

                {/* Location / Map button */}
                <button
                  onClick={() => setIsLocationModalOpen(true)}
                  className="p-2.5 rounded-xl bg-stone-800/80 hover:bg-stone-700 text-stone-200 border border-stone-700 transition-colors flex items-center gap-1.5 text-xs font-medium"
                  title="Directions & Map"
                >
                  <MapPin className="w-4 h-4 text-amber-400" />
                  <span className="hidden sm:inline">Directions</span>
                </button>

              </div>

            </div>

          </div>

          {/* Slide Indicator Dots */}
          <div className="absolute bottom-2 left-1/2 -translate-x-1/2 z-20 flex items-center gap-1.5">
            {HERO_SLIDES.map((_, i) => (
              <button
                key={i}
                onClick={() => setCurrentSlideIndex(i)}
                className={`h-1.5 rounded-full transition-all ${
                  currentSlideIndex === i ? 'w-6 bg-amber-400' : 'w-2 bg-stone-600'
                }`}
                aria-label={`Slide ${i + 1}`}
              />
            ))}
          </div>

        </div>

        {/* Highlights & Service Options Grid */}
        <div className="grid grid-cols-1 sm:grid-cols-3 gap-3.5">
          
          {/* Dine-In Highlight */}
          <div
            onClick={() => setIsCheckoutOpen(true)}
            className="p-4 rounded-2xl bg-amber-900/10 hover:bg-amber-900/15 border border-amber-900/20 cursor-pointer transition-all flex items-start gap-3.5 group"
          >
            <div className="w-10 h-10 rounded-xl bg-amber-800/20 text-amber-800 flex items-center justify-center shrink-0 group-hover:scale-105 transition-transform">
              <CalendarCheck className="w-5 h-5" />
            </div>
            <div>
              <div className="flex items-center gap-1.5">
                <h2 className="text-sm font-bold text-stone-900">Table Reservation</h2>
                <span className="px-1.5 py-0.5 text-[10px] font-bold bg-amber-200 text-amber-900 rounded">Dine In</span>
              </div>
              <p className="text-xs text-stone-600 mt-0.5 leading-relaxed">
                Choose your favorite booth, sunlit patio or barista bar seat. Pre-order meals.
              </p>
            </div>
          </div>

          {/* Takeout Highlight */}
          <div
            onClick={() => {
              const menuEl = document.getElementById('menu-section');
              menuEl?.scrollIntoView({ behavior: 'smooth' });
            }}
            className="p-4 rounded-2xl bg-stone-100 hover:bg-stone-200/70 border border-stone-200/80 cursor-pointer transition-all flex items-start gap-3.5 group"
          >
            <div className="w-10 h-10 rounded-xl bg-stone-800/10 text-stone-800 flex items-center justify-center shrink-0 group-hover:scale-105 transition-transform">
              <ShoppingBag className="w-5 h-5" />
            </div>
            <div>
              <div className="flex items-center gap-1.5">
                <h2 className="text-sm font-bold text-stone-900">Express Counter Pickup</h2>
                <span className="px-1.5 py-0.5 text-[10px] font-bold bg-stone-200 text-stone-800 rounded">15 Mins</span>
              </div>
              <p className="text-xs text-stone-600 mt-0.5 leading-relaxed">
                Order ahead on mobile, skip the counter line, grab your freshly brewed coffee.
              </p>
            </div>
          </div>

          {/* Special Offers Highlight */}
          <div
            onClick={() => handleCopyPromo('WELCOME15')}
            className="p-4 rounded-2xl bg-emerald-950/10 hover:bg-emerald-950/15 border border-emerald-900/20 cursor-pointer transition-all flex items-start gap-3.5 group"
          >
            <div className="w-10 h-10 rounded-xl bg-emerald-700/20 text-emerald-800 flex items-center justify-center shrink-0 group-hover:scale-105 transition-transform">
              <Sparkles className="w-5 h-5" />
            </div>
            <div>
              <div className="flex items-center gap-1.5">
                <h2 className="text-sm font-bold text-stone-900">Special Promo: 15% OFF</h2>
                <span className="px-1.5 py-0.5 text-[10px] font-bold bg-emerald-200 text-emerald-900 rounded font-mono">WELCOME15</span>
              </div>
              <p className="text-xs text-stone-600 mt-0.5 leading-relaxed">
                Click to apply promo discount code directly to your order or booking.
              </p>
            </div>
          </div>

        </div>

      </div>
    </section>
  );
};
