import React from 'react';
import { MenuItem, DietaryTag } from '../../types';
import { useCafe } from '../../context/CafeContext';
import { Star, Clock, Plus, Flame, Sparkles, Check, ChevronRight, Eye } from 'lucide-react';
import { motion } from 'motion/react';

interface MenuItemCardProps {
  item: MenuItem;
}

export const MenuItemCard: React.FC<MenuItemCardProps> = ({ item }) => {
  const { setSelectedDetailItem, addToCart, cart, settings, isCafeOpenNow } = useCafe();

  // Check if item has multiple sizes or add-ons (needs customization modal)
  const hasCustomizations = (item.sizes && item.sizes.length > 1) || (item.addons && item.addons.length > 0);

  // Check how many of this item is currently in the cart
  const totalInCart = cart
    .filter((c) => c.menuItemId === item.id)
    .reduce((sum, c) => sum + c.quantity, 0);

  const handleQuickAdd = (e: React.MouseEvent) => {
    e.stopPropagation();
    if (!isCafeOpenNow) {
      setSelectedDetailItem(item);
      return;
    }
    if (hasCustomizations) {
      setSelectedDetailItem(item);
    } else {
      addToCart(item, 1, item.sizes?.[0]);
    }
  };

  const renderDietaryTag = (tag: DietaryTag) => {
    switch (tag) {
      case 'vegan':
        return (
          <span key={tag} className="px-2 py-0.5 rounded-md text-[10px] font-bold bg-emerald-100 text-emerald-800 border border-emerald-200">
            Vegan
          </span>
        );
      case 'veg':
        return (
          <span key={tag} className="px-2 py-0.5 rounded-md text-[10px] font-bold bg-green-100 text-green-800 border border-green-200">
            Vegetarian
          </span>
        );
      case 'gluten-free':
        return (
          <span key={tag} className="px-2 py-0.5 rounded-md text-[10px] font-bold bg-amber-100 text-amber-900 border border-amber-200">
            GF
          </span>
        );
      case 'contains-nuts':
        return (
          <span key={tag} className="px-2 py-0.5 rounded-md text-[10px] font-bold bg-stone-200 text-stone-700">
            Nuts
          </span>
        );
      case 'chef-special':
        return (
          <span key={tag} className="px-2 py-0.5 rounded-md text-[10px] font-bold bg-amber-500 text-stone-950 flex items-center gap-1">
            <Sparkles className="w-2.5 h-2.5" />
            Chef's Pick
          </span>
        );
      default:
        return null;
    }
  };

  return (
    <motion.div
      id={`menu-card-${item.id}`}
      layout
      initial={{ opacity: 0, y: 15 }}
      animate={{ opacity: 1, y: 0 }}
      exit={{ opacity: 0, scale: 0.95 }}
      whileHover={{ y: -3 }}
      transition={{ duration: 0.2 }}
      onClick={() => setSelectedDetailItem(item)}
      className="group relative bg-white rounded-2xl border border-stone-200/90 shadow-xs hover:shadow-xl transition-all duration-200 overflow-hidden flex flex-col justify-between cursor-pointer"
    >
      {/* Top Image Box */}
      <div className="relative aspect-16/10 w-full overflow-hidden bg-stone-100">
        <img
          src={item.image}
          alt={item.name}
          loading="lazy"
          className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-300"
        />

        {/* Gradient Shadow */}
        <div className="absolute inset-0 bg-gradient-to-t from-black/40 via-transparent to-transparent opacity-60" />

        {/* Top Badges (Popular / Chef Special) */}
        <div className="absolute top-2.5 left-2.5 flex flex-wrap gap-1.5 z-10">
          {item.isPopular && (
            <span className="px-2.5 py-1 rounded-full text-[10px] font-extrabold bg-stone-900/90 text-amber-300 backdrop-blur-xs flex items-center gap-1 shadow-sm">
              <Flame className="w-3 h-3 text-amber-400 fill-amber-400" />
              Popular
            </span>
          )}
          {item.stockCount <= 8 && item.stockCount > 0 && (
            <span className="px-2 py-1 rounded-full text-[10px] font-bold bg-rose-600/90 text-white backdrop-blur-xs shadow-sm">
              Only {item.stockCount} left
            </span>
          )}
          {item.stockCount === 0 && (
            <span className="px-2.5 py-1 rounded-full text-[10px] font-bold bg-stone-800 text-stone-200">
              Sold Out Today
            </span>
          )}
        </div>

        {/* Rating Pill Top Right */}
        <div className="absolute top-2.5 right-2.5 bg-white/95 backdrop-blur-xs px-2 py-0.5 rounded-full text-stone-900 text-xs font-bold flex items-center gap-1 shadow-sm">
          <Star className="w-3 h-3 fill-amber-400 text-amber-400" />
          <span>{item.rating}</span>
          <span className="text-[10px] text-stone-600 font-normal">({item.reviewCount})</span>
        </div>

        {/* Prep Time Bottom Left */}
        <div className="absolute bottom-2 left-2.5 bg-stone-900/80 backdrop-blur-xs px-2 py-0.5 rounded-md text-stone-200 text-[10px] font-medium flex items-center gap-1">
          <Clock className="w-2.5 h-2.5 text-stone-400" />
          <span>{item.preparationTimeMinutes} mins prep</span>
        </div>
      </div>

      {/* Content Area */}
      <div className="p-4 sm:p-5 flex-1 flex flex-col justify-between space-y-3">
        
        <div className="space-y-1.5">
          {/* Dietary tags */}
          <div className="flex flex-wrap gap-1">
            {item.dietaryTags.slice(0, 3).map(renderDietaryTag)}
          </div>

          {/* Title & Tagline */}
          <h3 className="font-serif text-base sm:text-lg font-bold text-stone-900 group-hover:text-amber-900 transition-colors line-clamp-1">
            {item.name}
          </h3>

          <p className="text-xs text-stone-600 line-clamp-2 leading-relaxed font-normal">
            {item.description}
          </p>
        </div>

        {/* Price & Action Row */}
        <div className="pt-2 flex items-center justify-between gap-2 border-t border-stone-100">
          
          <div>
            <div className="flex items-baseline gap-1.5">
              <span className="text-base sm:text-lg font-bold text-stone-900 font-serif">
                {settings.currency}{item.price.toFixed(2)}
              </span>
              {item.originalPrice && item.originalPrice > item.price && (
                <span className="text-xs text-stone-600 line-through">
                  {settings.currency}{item.originalPrice.toFixed(2)}
                </span>
              )}
            </div>
            {hasCustomizations && (
              <span className="text-[10px] text-stone-600 block">Customizable</span>
            )}
          </div>

          {/* Quick Add or Customize Button */}
          <div>
            {!isCafeOpenNow ? (
              <button
                id={`closed-view-btn-${item.id}`}
                onClick={(e) => {
                  e.stopPropagation();
                  setSelectedDetailItem(item);
                }}
                className="min-h-[38px] px-3.5 py-1.5 rounded-xl text-xs font-semibold bg-stone-100 hover:bg-stone-200 text-stone-700 flex items-center gap-1.5 transition-colors border border-stone-200 cursor-pointer"
                title="Café is closed for ordering. Click to view ingredients and details."
              >
                <Eye className="w-3.5 h-3.5 text-stone-500" />
                <span>View</span>
              </button>
            ) : item.stockCount === 0 ? (
              <button
                disabled
                className="px-3 py-1.5 bg-stone-100 text-stone-600 text-xs font-semibold rounded-xl cursor-not-allowed"
              >
                Unavailable
              </button>
            ) : (
              <button
                id={`add-btn-${item.id}`}
                onClick={handleQuickAdd}
                className={`min-h-[38px] px-3.5 py-1.5 rounded-xl text-xs font-bold flex items-center gap-1.5 transition-all shadow-xs active:scale-95 cursor-pointer ${
                  totalInCart > 0
                    ? 'bg-amber-100 text-amber-900 border border-amber-300 hover:bg-amber-200'
                    : 'bg-stone-900 hover:bg-amber-900 text-white'
                }`}
              >
                {totalInCart > 0 ? (
                  <>
                    <span className="w-4 h-4 rounded-full bg-amber-800 text-white text-[10px] flex items-center justify-center font-bold">
                      {totalInCart}
                    </span>
                    <span>Added</span>
                  </>
                ) : hasCustomizations ? (
                  <>
                    <span>Customize</span>
                    <ChevronRight className="w-3 h-3" />
                  </>
                ) : (
                  <>
                    <Plus className="w-3.5 h-3.5" />
                    <span>Add</span>
                  </>
                )}
              </button>
            )}
          </div>

        </div>

      </div>
    </motion.div>
  );
};
