import React, { useState, useMemo } from 'react';
import { useCafe } from '../../context/CafeContext';
import { MenuItem, MenuItemSize, CartItemAddon } from '../../types';
import {
  X,
  Star,
  Clock,
  Plus,
  Minus,
  Check,
  Flame,
  AlertCircle,
  Leaf,
  Sparkles,
  ShoppingBag,
  Info,
  ChevronLeft,
  ChevronRight
} from 'lucide-react';
import { motion, AnimatePresence } from 'motion/react';

export const ItemDetailModal: React.FC = () => {
  const { selectedDetailItem, setSelectedDetailItem, addToCart, settings, isCafeOpenNow, showToast } = useCafe();

  const item = selectedDetailItem;

  // Selected size state
  const [selectedSize, setSelectedSize] = useState<MenuItemSize | undefined>(() => {
    return item?.sizes?.[0];
  });

  // Selected add-ons state
  const [selectedAddons, setSelectedAddons] = useState<CartItemAddon[]>([]);

  // Special instructions text
  const [specialInstructions, setSpecialInstructions] = useState('');

  // Quantity stepper
  const [quantity, setQuantity] = useState(1);

  // Gallery image index
  const [activeImageIndex, setActiveImageIndex] = useState(0);

  // Active tab in modal: 'customize' | 'nutrition' | 'reviews'
  const [activeTab, setActiveTab] = useState<'customize' | 'nutrition' | 'reviews'>('customize');

  // Reset states when item changes
  React.useEffect(() => {
    if (item) {
      setSelectedSize(item.sizes?.[0]);
      setSelectedAddons([]);
      setSpecialInstructions('');
      setQuantity(1);
      setActiveImageIndex(0);
      setActiveTab('customize');
    }
  }, [item]);

  const images = item ? (item.galleryImages && item.galleryImages.length > 0 ? item.galleryImages : [item.image]) : [];

  // Dynamic calculated unit price (unconditionally declared hooks)
  const unitPrice = useMemo(() => {
    if (!item) return 0;
    const sizeDelta = selectedSize ? selectedSize.priceDelta : 0;
    const addonsDelta = selectedAddons.reduce((sum, a) => sum + a.price, 0);
    return Math.max(0, item.price + sizeDelta + addonsDelta);
  }, [item, selectedSize, selectedAddons]);

  const totalPrice = unitPrice * quantity;

  const toggleAddon = (addon: { id: string; name: string; price: number }) => {
    setSelectedAddons((prev) => {
      const exists = prev.some((a) => a.id === addon.id);
      if (exists) {
        return prev.filter((a) => a.id !== addon.id);
      } else {
        return [...prev, { id: addon.id, name: addon.name, price: addon.price }];
      }
    });
  };

  const handleAddToCart = () => {
    if (!item) return;
    if (!isCafeOpenNow) {
      showToast(
        'Currently Closed',
        'Ordering is Temporarily Unavailable. Customers can view menu items and ingredients while the café is closed.',
        'warning'
      );
      return;
    }
    addToCart(item, quantity, selectedSize, selectedAddons, specialInstructions);
    setSelectedDetailItem(null);
  };

  return (
    <AnimatePresence>
      {item && (
        <div id="item-detail-modal" className="fixed inset-0 z-50 overflow-y-auto bg-stone-950/70 backdrop-blur-sm flex items-end sm:items-center justify-center p-0 sm:p-4">
          
          {/* Backdrop click */}
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            onClick={() => setSelectedDetailItem(null)}
            className="fixed inset-0"
          />

          {/* Modal Container */}
        <motion.div
          initial={{ opacity: 0, y: 50, scale: 0.95 }}
          animate={{ opacity: 1, y: 0, scale: 1 }}
          exit={{ opacity: 0, y: 50, scale: 0.95 }}
          transition={{ type: 'spring', damping: 25, stiffness: 300 }}
          className="relative z-10 bg-white w-full sm:max-w-2xl max-h-[92vh] sm:max-h-[85vh] rounded-t-3xl sm:rounded-3xl shadow-2xl flex flex-col overflow-hidden border border-stone-200"
        >
          
          {/* Header Bar with Close Button */}
          <div className="absolute top-3 right-3 z-30">
            <button
              onClick={() => setSelectedDetailItem(null)}
              className="p-2 rounded-full bg-stone-900/70 hover:bg-stone-900 text-white transition-colors backdrop-blur-xs shadow-md"
              aria-label="Close modal"
            >
              <X className="w-5 h-5" />
            </button>
          </div>

          {/* Scrollable Content Body */}
          <div className="overflow-y-auto flex-1 pb-24 sm:pb-6">
            
            {/* Gallery / Image Carousel */}
            <div className="relative aspect-16/10 w-full bg-stone-100 overflow-hidden">
              <img
                src={images[activeImageIndex]}
                alt={item.name}
                className="w-full h-full object-cover transition-all duration-300"
              />

              {/* Multiple images controls */}
              {images.length > 1 && (
                <>
                  <button
                    onClick={() => setActiveImageIndex((prev) => (prev > 0 ? prev - 1 : images.length - 1))}
                    className="absolute left-2 top-1/2 -translate-y-1/2 p-1.5 rounded-full bg-stone-900/60 text-white hover:bg-stone-900"
                  >
                    <ChevronLeft className="w-4 h-4" />
                  </button>
                  <button
                    onClick={() => setActiveImageIndex((prev) => (prev < images.length - 1 ? prev + 1 : 0))}
                    className="absolute right-2 top-1/2 -translate-y-1/2 p-1.5 rounded-full bg-stone-900/60 text-white hover:bg-stone-900"
                  >
                    <ChevronRight className="w-4 h-4" />
                  </button>
                  {/* Thumbnail indicators */}
                  <div className="absolute bottom-3 left-1/2 -translate-x-1/2 flex items-center gap-1.5 bg-black/40 px-2 py-1 rounded-full backdrop-blur-xs">
                    {images.map((_, idx) => (
                      <button
                        key={idx}
                        onClick={() => setActiveImageIndex(idx)}
                        className={`h-1.5 rounded-full transition-all ${
                          activeImageIndex === idx ? 'w-4 bg-amber-400' : 'w-1.5 bg-white/60'
                        }`}
                      />
                    ))}
                  </div>
                </>
              )}
            </div>

            {/* Content Details */}
            <div className="p-5 sm:p-7 space-y-6">
              
              {/* Title, Category & Price */}
              <div className="space-y-2">
                <div className="flex items-center justify-between gap-2">
                  <span className="text-xs font-bold uppercase tracking-wider text-amber-800 bg-amber-100 px-2.5 py-1 rounded-md">
                    {item.subcategory || item.category}
                  </span>
                  <div className="flex items-center gap-1 text-xs font-bold text-stone-800">
                    <Star className="w-4 h-4 fill-amber-400 text-amber-400" />
                    <span>{item.rating}</span>
                    <span className="text-stone-400">({item.reviewCount} reviews)</span>
                  </div>
                </div>

                <h2 className="font-serif text-2xl sm:text-3xl font-bold text-stone-900">
                  {item.name}
                </h2>

                <p className="text-sm text-stone-600 leading-relaxed">
                  {item.description}
                </p>
              </div>

              {/* Detail Tabs (Customization / Ingredients & Nutrition / Customer Reviews) */}
              <div className="flex border-b border-stone-200 text-xs font-semibold">
                <button
                  onClick={() => setActiveTab('customize')}
                  className={`pb-2.5 px-3 border-b-2 transition-colors ${
                    activeTab === 'customize'
                      ? 'border-amber-800 text-amber-900 font-bold'
                      : 'border-transparent text-stone-500 hover:text-stone-800'
                  }`}
                >
                  Customization
                </button>
                <button
                  onClick={() => setActiveTab('nutrition')}
                  className={`pb-2.5 px-3 border-b-2 transition-colors ${
                    activeTab === 'nutrition'
                      ? 'border-amber-800 text-amber-900 font-bold'
                      : 'border-transparent text-stone-500 hover:text-stone-800'
                  }`}
                >
                  Ingredients & Nutrition
                </button>
                <button
                  onClick={() => setActiveTab('reviews')}
                  className={`pb-2.5 px-3 border-b-2 transition-colors ${
                    activeTab === 'reviews'
                      ? 'border-amber-800 text-amber-900 font-bold'
                      : 'border-transparent text-stone-500 hover:text-stone-800'
                  }`}
                >
                  Reviews ({item.reviews?.length || item.reviewCount})
                </button>
              </div>

              {/* Tab 1: Customization Content */}
              {activeTab === 'customize' && (
                <div className="space-y-6">
                  
                  {/* Sizes Selection (if available) */}
                  {item.sizes && item.sizes.length > 0 && (
                    <div className="space-y-2.5">
                      <div className="flex justify-between items-center">
                        <label className="text-xs font-bold uppercase tracking-wider text-stone-800">
                          Select Size
                        </label>
                        <span className="text-[11px] text-stone-400">Required</span>
                      </div>
                      <div className="grid grid-cols-2 gap-2.5">
                        {item.sizes.map((s) => {
                          const isSelected = selectedSize?.name === s.name;
                          return (
                            <button
                              key={s.name}
                              type="button"
                              onClick={() => setSelectedSize(s)}
                              className={`p-3 rounded-xl border text-left flex items-center justify-between transition-all ${
                                isSelected
                                  ? 'border-amber-800 bg-amber-50/80 text-amber-950 ring-1 ring-amber-800'
                                  : 'border-stone-200 bg-stone-50/50 hover:bg-stone-100 text-stone-700'
                              }`}
                            >
                              <div className="flex items-center gap-2">
                                <div
                                  className={`w-4 h-4 rounded-full border flex items-center justify-center ${
                                    isSelected ? 'border-amber-800 bg-amber-800' : 'border-stone-300 bg-white'
                                  }`}
                                >
                                  {isSelected && <div className="w-1.5 h-1.5 rounded-full bg-white" />}
                                </div>
                                <span className="text-xs font-semibold">{s.name}</span>
                              </div>
                              <span className="text-xs font-bold">
                                {s.priceDelta > 0 ? `+${settings.currency}${s.priceDelta.toFixed(2)}` : 'Standard'}
                              </span>
                            </button>
                          );
                        })}
                      </div>
                    </div>
                  )}

                  {/* Add-ons Selection (if available) */}
                  {item.addons && item.addons.length > 0 && (
                    <div className="space-y-2.5">
                      <div className="flex justify-between items-center">
                        <label className="text-xs font-bold uppercase tracking-wider text-stone-800">
                          Add-ons & Extras
                        </label>
                        <span className="text-[11px] text-stone-400">Optional</span>
                      </div>
                      <div className="space-y-2">
                        {item.addons.map((addon) => {
                          const isChecked = selectedAddons.some((a) => a.id === addon.id);
                          return (
                            <button
                              key={addon.id}
                              type="button"
                              onClick={() => toggleAddon(addon)}
                              className={`w-full p-3 rounded-xl border text-left flex items-center justify-between transition-all ${
                                isChecked
                                  ? 'border-amber-800 bg-amber-50/80 text-amber-950'
                                  : 'border-stone-200 bg-stone-50/40 hover:bg-stone-100 text-stone-700'
                              }`}
                            >
                              <div className="flex items-center gap-2.5">
                                <div
                                  className={`w-4 h-4 rounded-md border flex items-center justify-center ${
                                    isChecked ? 'border-amber-800 bg-amber-800 text-white' : 'border-stone-300 bg-white'
                                  }`}
                                >
                                  {isChecked && <Check className="w-3 h-3 stroke-[3]" />}
                                </div>
                                <span className="text-xs font-semibold">{addon.name}</span>
                              </div>
                              <span className="text-xs font-bold text-stone-900">
                                +{settings.currency}{addon.price.toFixed(2)}
                              </span>
                            </button>
                          );
                        })}
                      </div>
                    </div>
                  )}

                  {/* Special Cooking / Preparation Instructions */}
                  <div className="space-y-1.5">
                    <label className="text-xs font-bold uppercase tracking-wider text-stone-800">
                      Special Preparation Notes
                    </label>
                    <textarea
                      value={specialInstructions}
                      onChange={(e) => setSpecialInstructions(e.target.value)}
                      placeholder="e.g. Extra hot, syrup on the side, no lid, gluten allergy..."
                      rows={2}
                      className="w-full text-xs p-3 rounded-xl border border-stone-200 focus:outline-none focus:ring-2 focus:ring-amber-700/50 bg-stone-50/60"
                    />
                  </div>

                </div>
              )}

              {/* Tab 2: Ingredients & Nutrition Content */}
              {activeTab === 'nutrition' && (
                <div className="space-y-4">
                  {/* Ingredients List */}
                  <div>
                    <h4 className="text-xs font-bold uppercase tracking-wider text-stone-800 mb-2">
                      Fresh Ingredients
                    </h4>
                    <div className="flex flex-wrap gap-1.5">
                      {item.ingredients.map((ing, idx) => (
                        <span key={idx} className="px-2.5 py-1 bg-stone-100 text-stone-700 text-xs rounded-lg">
                          {ing}
                        </span>
                      ))}
                    </div>
                  </div>

                  {/* Allergen Warnings Box */}
                  <div className="p-3.5 rounded-xl bg-amber-50 border border-amber-200/80 flex items-start gap-2.5 text-xs text-amber-900">
                    <AlertCircle className="w-4 h-4 text-amber-700 shrink-0 mt-0.5" />
                    <div>
                      <span className="font-bold">Allergen Information: </span>
                      <span>
                        {item.allergenWarnings.length > 0 ? item.allergenWarnings.join(', ') : 'No common allergens declared.'}
                      </span>
                    </div>
                  </div>

                  {/* Nutritional Grid */}
                  {item.calories !== undefined && (
                    <div>
                      <h4 className="text-xs font-bold uppercase tracking-wider text-stone-800 mb-2">
                        Nutritional Facts (Per Serving)
                      </h4>
                      <div className="grid grid-cols-4 gap-2 text-center">
                        <div className="p-2.5 rounded-xl bg-stone-100 border border-stone-200">
                          <p className="text-[10px] text-stone-500 font-semibold uppercase">Calories</p>
                          <p className="text-sm font-bold text-stone-900">{item.calories} kcal</p>
                        </div>
                        <div className="p-2.5 rounded-xl bg-stone-100 border border-stone-200">
                          <p className="text-[10px] text-stone-500 font-semibold uppercase">Protein</p>
                          <p className="text-sm font-bold text-stone-900">{item.protein || 0}g</p>
                        </div>
                        <div className="p-2.5 rounded-xl bg-stone-100 border border-stone-200">
                          <p className="text-[10px] text-stone-500 font-semibold uppercase">Carbs</p>
                          <p className="text-sm font-bold text-stone-900">{item.carbs || 0}g</p>
                        </div>
                        <div className="p-2.5 rounded-xl bg-stone-100 border border-stone-200">
                          <p className="text-[10px] text-stone-500 font-semibold uppercase">Fat</p>
                          <p className="text-sm font-bold text-stone-900">{item.fat || 0}g</p>
                        </div>
                      </div>
                    </div>
                  )}
                </div>
              )}

              {/* Tab 3: Customer Reviews Content */}
              {activeTab === 'reviews' && (
                <div className="space-y-3">
                  {item.reviews && item.reviews.length > 0 ? (
                    item.reviews.map((rev) => (
                      <div key={rev.id} className="p-3 rounded-xl bg-stone-50 border border-stone-200 space-y-1.5">
                        <div className="flex items-center justify-between text-xs">
                          <span className="font-bold text-stone-900">{rev.userName}</span>
                          <span className="text-stone-400">{rev.date}</span>
                        </div>
                        <div className="flex items-center gap-0.5">
                          {Array.from({ length: 5 }).map((_, i) => (
                            <Star
                              key={i}
                              className={`w-3 h-3 ${
                                i < rev.rating ? 'fill-amber-400 text-amber-400' : 'text-stone-300'
                              }`}
                            />
                          ))}
                        </div>
                        <p className="text-xs text-stone-600 leading-relaxed">
                          "{rev.comment}"
                        </p>
                      </div>
                    ))
                  ) : (
                    <div className="p-6 text-center text-xs text-stone-500">
                      No customer reviews yet. Be the first to try and review this item!
                    </div>
                  )}
                </div>
              )}

            </div>
          </div>

          {/* Sticky Bottom Action Footer Bar */}
          <div className="absolute bottom-0 left-0 right-0 p-4 bg-white/95 backdrop-blur-md border-t border-stone-200 flex items-center justify-between gap-3 shadow-lg z-20">
            {!isCafeOpenNow ? (
              <div className="w-full flex flex-col sm:flex-row items-center justify-between gap-3 p-3 rounded-2xl bg-rose-50 border border-rose-200 text-rose-950">
                <div className="flex items-center gap-2">
                  <span className="w-2.5 h-2.5 rounded-full bg-rose-500 shrink-0" />
                  <div>
                    <p className="text-xs font-bold text-rose-900">
                      🔴 Currently Closed – Ordering is Temporarily Unavailable
                    </p>
                    <p className="text-[11px] text-rose-700">
                      You are viewing item ingredients and dietary specifications.
                    </p>
                  </div>
                </div>
                <button
                  type="button"
                  onClick={() => setSelectedDetailItem(null)}
                  className="w-full sm:w-auto px-4 py-2 rounded-xl bg-stone-900 hover:bg-stone-800 text-white text-xs font-bold cursor-pointer transition-colors"
                >
                  Done Viewing
                </button>
              </div>
            ) : (
              <>
                {/* Quantity Stepper */}
                <div className="flex items-center border border-stone-300 rounded-xl bg-stone-50 p-1">
                  <button
                    type="button"
                    onClick={() => setQuantity((q) => Math.max(1, q - 1))}
                    className="w-8 h-8 rounded-lg flex items-center justify-center hover:bg-stone-200 text-stone-700 transition-colors"
                    aria-label="Decrease quantity"
                  >
                    <Minus className="w-3.5 h-3.5" />
                  </button>
                  <span className="w-8 text-center text-sm font-bold text-stone-900">
                    {quantity}
                  </span>
                  <button
                    type="button"
                    onClick={() => setQuantity((q) => q + 1)}
                    className="w-8 h-8 rounded-lg flex items-center justify-center hover:bg-stone-200 text-stone-700 transition-colors"
                    aria-label="Increase quantity"
                  >
                    <Plus className="w-3.5 h-3.5" />
                  </button>
                </div>

                {/* Add to Cart Submit Button */}
                <button
                  id="modal-add-to-cart-btn"
                  onClick={handleAddToCart}
                  className="flex-1 min-h-[44px] px-5 py-2.5 bg-stone-900 hover:bg-amber-900 active:scale-98 text-white font-bold text-xs sm:text-sm rounded-xl shadow-md transition-all flex items-center justify-between"
                >
                  <span className="flex items-center gap-2">
                    <ShoppingBag className="w-4 h-4 text-amber-300" />
                    <span>Add to Cart</span>
                  </span>
                  <span className="text-amber-300 font-serif font-bold text-sm">
                    {settings.currency}{totalPrice.toFixed(2)}
                  </span>
                </button>
              </>
            )}
          </div>

        </motion.div>
      </div>
    )}
  </AnimatePresence>
);
};
