import React, { useState, useMemo } from 'react';
import { useCafe } from '../../context/CafeContext';
import { MenuItemCard } from './MenuItemCard';
import { MenuItem, DietaryTag } from '../../types';
import {
  Search,
  X,
  Coffee,
  Croissant,
  Utensils,
  Salad,
  Cake,
  Sparkles,
  SlidersHorizontal,
  Flame,
  ArrowUpDown,
  Eye
} from 'lucide-react';
import { motion, AnimatePresence } from 'motion/react';

type CategoryFilter = 'all' | 'beverages' | 'pastries' | 'mains' | 'healthy' | 'desserts';

export const MenuSection: React.FC = () => {
  const { menuItems, settings, isCafeOpenNow } = useCafe();

  const [selectedCategory, setSelectedCategory] = useState<CategoryFilter>('all');
  const [searchQuery, setSearchQuery] = useState('');
  const [selectedDietaryTag, setSelectedDietaryTag] = useState<DietaryTag | 'all'>('all');
  const [sortBy, setSortBy] = useState<'popular' | 'price-low' | 'price-high' | 'rating'>('popular');

  const categories = [
    { id: 'all', label: 'All Delicacies', icon: Sparkles },
    { id: 'beverages', label: 'Specialty Brews', icon: Coffee },
    { id: 'pastries', label: 'Artisan Bakery', icon: Croissant },
    { id: 'mains', label: 'Brunch & Mains', icon: Utensils },
    { id: 'healthy', label: 'Healthy Bowls', icon: Salad },
    { id: 'desserts', label: 'Dolce & Desserts', icon: Cake },
  ];

  const dietaryFilters: { id: DietaryTag | 'all'; label: string }[] = [
    { id: 'all', label: 'All Items' },
    { id: 'chef-special', label: "Chef's Picks" },
    { id: 'veg', label: 'Vegetarian' },
    { id: 'vegan', label: 'Vegan' },
    { id: 'gluten-free', label: 'Gluten-Free' },
  ];

  // Category counts
  const categoryCounts = useMemo(() => {
    const counts: Record<string, number> = { all: menuItems.length };
    menuItems.forEach((item) => {
      counts[item.category] = (counts[item.category] || 0) + 1;
    });
    return counts;
  }, [menuItems]);

  // Filtered & Sorted items
  const filteredItems = useMemo(() => {
    return menuItems.filter((item) => {
      // Category match
      if (selectedCategory !== 'all' && item.category !== selectedCategory) {
        return false;
      }

      // Dietary tag match
      if (selectedDietaryTag !== 'all') {
        if (selectedDietaryTag === 'chef-special' && !item.isChefSpecial) return false;
        if (selectedDietaryTag !== 'chef-special' && !item.dietaryTags.includes(selectedDietaryTag)) {
          return false;
        }
      }

      // Search query match
      if (searchQuery.trim()) {
        const query = searchQuery.toLowerCase().trim();
        const matchesName = item.name.toLowerCase().includes(query);
        const matchesDesc = item.description.toLowerCase().includes(query);
        const matchesSubcategory = item.subcategory?.toLowerCase().includes(query);
        const matchesIngredients = item.ingredients.some((ing) => ing.toLowerCase().includes(query));
        if (!matchesName && !matchesDesc && !matchesSubcategory && !matchesIngredients) {
          return false;
        }
      }

      return true;
    }).sort((a, b) => {
      if (sortBy === 'popular') {
        return (b.isPopular ? 1 : 0) - (a.isPopular ? 1 : 0) || b.rating - a.rating;
      }
      if (sortBy === 'price-low') {
        return a.price - b.price;
      }
      if (sortBy === 'price-high') {
        return b.price - a.price;
      }
      if (sortBy === 'rating') {
        return b.rating - a.rating;
      }
      return 0;
    });
  }, [menuItems, selectedCategory, selectedDietaryTag, searchQuery, sortBy]);

  return (
    <section id="menu-section" className="py-8 sm:py-12 relative scroll-mt-20">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 space-y-6">
        
        {/* Section Heading */}
        <div className="flex flex-col md:flex-row md:items-end justify-between gap-4">
          <div>
            <div className="flex items-center gap-2 text-xs font-bold uppercase tracking-wider text-amber-800 mb-1">
              <Sparkles className="w-3.5 h-3.5 text-amber-600" />
              <span>Artisanal Seasonal Menu</span>
            </div>
            <h2 className="text-2xl sm:text-3xl lg:text-4xl font-bold font-serif text-stone-900">
              Crafted with Passion & Precision
            </h2>
            <p className="text-xs sm:text-sm text-stone-600 mt-1 max-w-xl">
              Freshly ground single-origin brews, twice-baked pastries, and wholesome farm-to-table plates.
            </p>
          </div>

          {/* Search Bar */}
          <div className="relative w-full md:w-80">
            <Search className="absolute left-3.5 top-1/2 -translate-y-1/2 w-4 h-4 text-stone-400" />
            <input
              id="menu-search-input"
              type="text"
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              placeholder="Search coffee, avocado toast, pastries..."
              className="w-full pl-10 pr-9 py-2.5 bg-white rounded-2xl border border-stone-200 shadow-xs text-xs sm:text-sm focus:outline-none focus:ring-2 focus:ring-amber-800/40 text-stone-800 placeholder:text-stone-400"
            />
            {searchQuery && (
              <button
                onClick={() => setSearchQuery('')}
                className="absolute right-3 top-1/2 -translate-y-1/2 p-1 text-stone-400 hover:text-stone-700"
              >
                <X className="w-3.5 h-3.5" />
              </button>
            )}
          </div>
        </div>

        {/* Menu Viewing Notice when Cafe is Closed */}
        {!isCafeOpenNow && (
          <div className="p-4 rounded-2xl bg-amber-50/80 border border-amber-200/80 flex flex-col sm:flex-row items-start sm:items-center justify-between gap-3 text-amber-950 shadow-xs">
            <div className="flex items-center gap-3">
              <div className="w-9 h-9 rounded-xl bg-amber-600/20 text-amber-900 flex items-center justify-center shrink-0 font-bold">
                <Eye className="w-5 h-5" />
              </div>
              <div>
                <p className="font-bold text-sm text-stone-900 flex items-center gap-2">
                  <span>Menu Viewing Mode</span>
                  <span className="text-[10px] px-2 py-0.5 rounded-full bg-rose-100 text-rose-800 font-bold border border-rose-200">
                    🔴 Ordering Temporarily Unavailable
                  </span>
                </p>
                <p className="text-xs text-stone-600 mt-0.5">
                  Feel free to browse all roasts, dishes, ingredients, dietary details, and pricing. Orders will resume when the café reopens!
                </p>
              </div>
            </div>
            <span className="text-xs font-semibold text-amber-900 shrink-0 hidden md:inline">
              {settings.closedNotice || 'Store is currently offline for prep'}
            </span>
          </div>
        )}

        {/* Sticky-like Category Pills Carousel */}
        <div className="flex items-center gap-2 overflow-x-auto pb-2 pt-1 no-scrollbar -mx-4 px-4 sm:mx-0 sm:px-0">
          {categories.map((cat) => {
            const Icon = cat.icon;
            const isSelected = selectedCategory === cat.id;
            const count = categoryCounts[cat.id] || 0;

            return (
              <button
                key={cat.id}
                onClick={() => setSelectedCategory(cat.id as CategoryFilter)}
                className={`shrink-0 flex items-center gap-2 px-4 py-2.5 rounded-2xl text-xs sm:text-sm font-semibold transition-all duration-200 cursor-pointer shadow-xs active:scale-95 ${
                  isSelected
                    ? 'bg-stone-900 text-stone-50 shadow-md ring-2 ring-stone-900/10'
                    : 'bg-white text-stone-700 hover:bg-stone-100 border border-stone-200/80'
                }`}
              >
                <Icon className={`w-4 h-4 ${isSelected ? 'text-amber-400' : 'text-stone-500'}`} />
                <span>{cat.label}</span>
                <span
                  className={`px-1.5 py-0.5 rounded-full text-[10px] font-bold ${
                    isSelected ? 'bg-stone-800 text-amber-300' : 'bg-stone-100 text-stone-500'
                  }`}
                >
                  {count}
                </span>
              </button>
            );
          })}
        </div>

        {/* Sub-Filters: Dietary Tags & Sort Dropdown */}
        <div className="flex flex-wrap items-center justify-between gap-3 pt-1 border-t border-stone-200/60 text-xs">
          
          {/* Dietary Filter Pills */}
          <div className="flex items-center gap-1.5 overflow-x-auto no-scrollbar py-1">
            <span className="text-stone-400 font-medium mr-1 hidden sm:inline">Dietary:</span>
            {dietaryFilters.map((df) => (
              <button
                key={df.id}
                onClick={() => setSelectedDietaryTag(df.id)}
                className={`px-3 py-1.5 rounded-xl font-medium transition-colors whitespace-nowrap ${
                  selectedDietaryTag === df.id
                    ? 'bg-amber-900 text-amber-50 font-bold shadow-xs'
                    : 'bg-stone-100/90 text-stone-600 hover:bg-stone-200 border border-stone-200/60'
                }`}
              >
                {df.label}
              </button>
            ))}
          </div>

          {/* Sort Selector */}
          <div className="flex items-center gap-2 ml-auto">
            <ArrowUpDown className="w-3.5 h-3.5 text-stone-400" />
            <select
              value={sortBy}
              onChange={(e) => setSortBy(e.target.value as any)}
              className="bg-white border border-stone-200 text-stone-700 rounded-xl px-2.5 py-1.5 font-medium text-xs focus:outline-none focus:ring-1 focus:ring-amber-800 cursor-pointer"
            >
              <option value="popular">Most Popular & Recommended</option>
              <option value="rating">Top Customer Rated</option>
              <option value="price-low">Price: Low to High</option>
              <option value="price-high">Price: High to Low</option>
            </select>
          </div>

        </div>

        {/* Menu Items Grid */}
        {filteredItems.length > 0 ? (
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-5 sm:gap-6 pt-2">
            <AnimatePresence mode="popLayout">
              {filteredItems.map((item) => (
                <MenuItemCard key={item.id} item={item} />
              ))}
            </AnimatePresence>
          </div>
        ) : (
          /* Empty Search State */
          <div className="p-12 text-center bg-white rounded-3xl border border-stone-200/80 space-y-4">
            <div className="w-14 h-14 rounded-2xl bg-amber-50 text-amber-800 mx-auto flex items-center justify-center">
              <Search className="w-6 h-6" />
            </div>
            <div className="space-y-1">
              <h3 className="font-serif text-lg font-bold text-stone-900">
                No matching menu items found
              </h3>
              <p className="text-xs text-stone-500 max-w-sm mx-auto">
                We couldn't find anything matching "{searchQuery}". Try searching for coffee, latte, croissant, or reset your filters.
              </p>
            </div>
            <button
              onClick={() => {
                setSearchQuery('');
                setSelectedCategory('all');
                setSelectedDietaryTag('all');
              }}
              className="px-4 py-2 bg-stone-900 text-stone-50 text-xs font-semibold rounded-xl hover:bg-stone-800 transition-colors"
            >
              Reset Filters & Show All Menu
            </button>
          </div>
        )}

      </div>
    </section>
  );
};
