import React, { useState, useMemo } from 'react';
import { QRCodeSVG } from 'qrcode.react';
import {
  Copy,
  Check,
  Smartphone,
  ExternalLink,
  ShieldCheck,
  Sparkles,
  QrCode,
  Coffee
} from 'lucide-react';
import { useCafe } from '../../context/CafeContext';

interface UpiPaymentBoxProps {
  upiId?: string;
  payeeName?: string;
  amount?: number;
  note?: string;
  title?: string;
  subtitle?: string;
  size?: number;
  showPayButton?: boolean;
  showCopyButton?: boolean;
  variant?: 'checkout' | 'counter' | 'admin-preview';
  className?: string;
}

export const UpiPaymentBox: React.FC<UpiPaymentBoxProps> = ({
  upiId: customUpiId,
  payeeName: customPayeeName,
  amount,
  note = 'Campora Cafe Order',
  title = 'Campora Café',
  subtitle = 'Scan & Pay with any UPI app',
  size = 140,
  showPayButton = true,
  showCopyButton = true,
  variant = 'checkout',
  className = ''
}) => {
  const { settings, showToast } = useCafe();
  const [copied, setCopied] = useState(false);

  const activeUpiId = (customUpiId || settings.upiId || '8210794268-4@ybl').trim();
  const activePayeeName = (customPayeeName || settings.upiName || settings.name || 'Campora Café').trim();

  // Generate standard National Payments Corporation of India (NPCI) UPI Intent URI
  // Example: upi://pay?pa=8210794268-4@ybl&pn=Campora%20Caf%C3%A9&am=150.00&cu=INR&tn=Campora%20Cafe%20Order
  const upiIntentUri = useMemo(() => {
    const params = new URLSearchParams();
    params.set('pa', activeUpiId);
    params.set('pn', activePayeeName);
    if (typeof amount === 'number' && amount > 0) {
      params.set('am', amount.toFixed(2));
    }
    params.set('cu', 'INR');
    if (note) {
      params.set('tn', note);
    }
    return `upi://pay?${params.toString()}`;
  }, [activeUpiId, activePayeeName, amount, note]);

  const handleCopyUpiId = () => {
    try {
      if (navigator?.clipboard?.writeText) {
        navigator.clipboard.writeText(activeUpiId);
      } else {
        const textArea = document.createElement('textarea');
        textArea.value = activeUpiId;
        document.body.appendChild(textArea);
        textArea.select();
        document.execCommand('copy');
        document.body.removeChild(textArea);
      }
      setCopied(true);
      showToast('UPI ID Copied', activeUpiId, 'success');
      setTimeout(() => setCopied(false), 2500);
    } catch {
      setCopied(true);
      showToast('UPI ID Copied', activeUpiId, 'success');
      setTimeout(() => setCopied(false), 2500);
    }
  };

  const handlePayViaUpiClick = () => {
    // Attempt standard intent launch on mobile devices
    window.location.href = upiIntentUri;
  };

  const isCounterVariant = variant === 'counter';
  const isAdminPreview = variant === 'admin-preview';

  return (
    <div
      id={`upi-payment-box-${variant}`}
      className={`rounded-2xl border transition-all ${
        isCounterVariant
          ? 'bg-gradient-to-br from-amber-500/10 via-amber-50/70 to-stone-50 border-amber-300/80 p-4'
          : isAdminPreview
          ? 'bg-white border-stone-200 p-4 shadow-xs'
          : 'bg-gradient-to-b from-amber-50/90 to-stone-50/80 border-amber-200/90 p-4 sm:p-5 shadow-xs'
      } ${className}`}
    >
      {/* Brand & Header Section */}
      <div className="flex items-center justify-between gap-3 pb-3 border-b border-amber-200/60">
        <div className="flex items-center gap-2.5">
          <div className="w-8 h-8 rounded-xl bg-amber-500 text-stone-950 flex items-center justify-center font-bold shadow-xs">
            <Coffee className="w-4 h-4" />
          </div>
          <div>
            <div className="flex items-center gap-1.5">
              <h4 className="font-serif font-bold text-stone-900 text-sm tracking-tight">
                {title}
              </h4>
              <span className="inline-flex items-center px-2 py-0.5 rounded-full text-[10px] font-bold bg-emerald-100 text-emerald-800 border border-emerald-200">
                Verified Merchant
              </span>
            </div>
            <p className="text-[11px] text-stone-500 font-medium">
              {subtitle}
            </p>
          </div>
        </div>

        {typeof amount === 'number' && amount > 0 && (
          <div className="text-right">
            <span className="text-[10px] uppercase font-bold text-stone-400 block tracking-wider">
              Amount Due
            </span>
            <span className="text-base sm:text-lg font-serif font-bold text-stone-950">
              {settings.currency}{amount.toFixed(2)}
            </span>
          </div>
        )}
      </div>

      {/* Main QR & Details Layout */}
      <div className="pt-4 flex flex-col sm:flex-row items-center sm:items-start gap-4">
        {/* Scannable High-Contrast QR Code Card */}
        <div className="relative group shrink-0">
          <div className="p-3 bg-white rounded-2xl shadow-sm border-2 border-stone-800/10 hover:border-amber-400 transition-colors flex flex-col items-center">
            {/* Scannable SVG QR Code */}
            <div className="relative bg-white rounded-xl overflow-hidden p-1">
              <QRCodeSVG
                value={upiIntentUri}
                size={size}
                level="M"
                includeMargin={false}
                className="w-full h-auto block"
              />
            </div>
            <div className="mt-2 text-center">
              <span className="text-[10px] font-bold uppercase tracking-wider text-amber-900 flex items-center justify-center gap-1">
                <QrCode className="w-3 h-3 text-amber-600" />
                Scan & Pay
              </span>
            </div>
          </div>
        </div>

        {/* UPI Details & Actions */}
        <div className="flex-1 w-full space-y-3 text-center sm:text-left">
          {/* UPI ID Display Box */}
          <div className="space-y-1">
            <label className="text-[11px] font-bold uppercase tracking-wider text-stone-500 block">
              Merchant UPI ID
            </label>
            <div className="flex flex-wrap items-center justify-center sm:justify-start gap-2">
              <div className="inline-flex items-center gap-1.5 px-3 py-1.5 rounded-xl bg-white border border-stone-300/80 shadow-xs font-mono font-bold text-xs sm:text-sm text-stone-900 select-all">
                <Smartphone className="w-3.5 h-3.5 text-amber-600 shrink-0" />
                <span>{activeUpiId}</span>
              </div>

              {showCopyButton && (
                <button
                  type="button"
                  id={`btn-copy-upi-${variant}`}
                  onClick={handleCopyUpiId}
                  className={`px-3 py-1.5 rounded-xl font-bold text-xs flex items-center gap-1.5 transition-all cursor-pointer shadow-xs ${
                    copied
                      ? 'bg-emerald-600 text-white ring-2 ring-emerald-400/40'
                      : 'bg-stone-900 hover:bg-stone-800 active:bg-stone-950 text-white'
                  }`}
                  title="Copy UPI ID to clipboard"
                >
                  {copied ? (
                    <>
                      <Check className="w-3.5 h-3.5" />
                      <span>Copied!</span>
                    </>
                  ) : (
                    <>
                      <Copy className="w-3.5 h-3.5" />
                      <span>Copy UPI ID</span>
                    </>
                  )}
                </button>
              )}
            </div>
          </div>

          {/* Instructions */}
          <div className="text-xs text-stone-600 space-y-1">
            <p className="leading-relaxed">
              Open <strong>Google Pay</strong>, <strong>PhonePe</strong>, <strong>Paytm</strong>, <strong>BHIM</strong>, or any UPI app on your phone.
            </p>
            {typeof amount === 'number' && amount > 0 ? (
              <p className="text-[11px] text-amber-900 font-medium">
                • The QR code is encoded with the exact bill amount: <strong>{settings.currency}{amount.toFixed(2)}</strong>.
              </p>
            ) : (
              <p className="text-[11px] text-stone-500">
                • Enter your desired order or billing amount when prompted.
              </p>
            )}
          </div>

          {/* Supported UPI Apps Row */}
          <div className="pt-1">
            <span className="text-[10px] font-bold text-stone-400 uppercase tracking-wider block mb-1.5">
              Supported UPI Payment Apps
            </span>
            <div className="flex flex-wrap items-center justify-center sm:justify-start gap-1.5 text-[11px]">
              <span className="px-2 py-0.5 rounded-lg bg-white border border-stone-200 font-semibold text-stone-700 shadow-2xs">
                Google Pay
              </span>
              <span className="px-2 py-0.5 rounded-lg bg-white border border-stone-200 font-semibold text-purple-700 shadow-2xs">
                PhonePe
              </span>
              <span className="px-2 py-0.5 rounded-lg bg-white border border-stone-200 font-semibold text-sky-700 shadow-2xs">
                Paytm
              </span>
              <span className="px-2 py-0.5 rounded-lg bg-white border border-stone-200 font-semibold text-emerald-700 shadow-2xs">
                BHIM UPI
              </span>
              <span className="px-2 py-0.5 rounded-lg bg-stone-100 text-stone-600 font-medium">
                + Any Bank App
              </span>
            </div>
          </div>

          {/* Pay via UPI App Action Button */}
          {showPayButton && !isAdminPreview && (
            <div className="pt-2">
              <a
                href={upiIntentUri}
                onClick={handlePayViaUpiClick}
                className="inline-flex w-full sm:w-auto items-center justify-center gap-2 px-5 py-2.5 rounded-xl bg-amber-500 hover:bg-amber-400 active:bg-amber-600 text-stone-950 font-bold text-xs transition-all shadow-xs cursor-pointer text-center"
              >
                <Sparkles className="w-3.5 h-3.5 text-stone-900" />
                <span>Pay via UPI App</span>
                <ExternalLink className="w-3 h-3 opacity-70" />
              </a>
              <span className="block text-[10px] text-stone-400 mt-1">
                (Clicking opens installed UPI apps directly on mobile devices)
              </span>
            </div>
          )}

          {/* Trust / NPCI note */}
          <div className="flex items-center justify-center sm:justify-start gap-1.5 text-[10px] text-stone-400 pt-1">
            <ShieldCheck className="w-3 h-3 text-emerald-600" />
            <span>Direct Bank-to-Bank Transfer • Zero Gateway Surcharge</span>
          </div>
        </div>
      </div>
    </div>
  );
};
