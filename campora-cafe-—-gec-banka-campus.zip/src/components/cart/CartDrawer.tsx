import React, { useState } from 'react';
import { useCafe } from '../../context/CafeContext';
import {
  X,
  ShoppingBag,
  Plus,
  Minus,
  Trash2,
  Tag,
  ArrowRight,
  Sparkles,
  CheckCircle2,
  AlertCircle,
  MessageSquare,
  Utensils,
  CalendarCheck
} from 'lucide-react';
import { motion, AnimatePresence } from 'motion/react';

export const CartDrawer: React.FC = () => {
  const {
    isCartOpen,
    setIsCartOpen,
    cart,
    updateCartItemQuantity,
    removeCartItem,
    updateCartItemInstructions,
    clearCart,
    appliedPromo,
    applyPromoCode,
    removePromoCode,
    calculatePricing,
    setIsCheckoutOpen,
    settings,
    totalCartItemCount,
    isCafeOpenNow,
    showToast
  } = useCafe();

  const [promoInput, setPromoInput] = useState('');
  const [promoError, setPromoError] = useState('');
  const [editingInstructionsId, setEditingInstructionsId] = useState<string | null>(null);

  // Calculate pricing for dine-in default
  const pricing = calculatePricing('dine-in');

  const handleApplyPromo = (e: React.FormEvent) => {
    e.preventDefault();
    if (!promoInput.trim()) return;
    setPromoError('');
    const res = applyPromoCode(promoInput);
    if (!res.success) {
      setPromoError(res.message);
    } else {
      setPromoInput('');
    }
  };

  const handleProceedToCheckout = () => {
    if (!isCafeOpenNow) {
      showToast(
        'Currently Closed',
        'Ordering is Temporarily Unavailable. Orders will resume once the café reopens.',
        'warning'
      );
      return;
    }
    setIsCartOpen(false);
    setIsCheckoutOpen(true);
  };

  return (
    <AnimatePresence>
      {isCartOpen && (
        <div id="cart-drawer-backdrop" className="fixed inset-0 z-50 overflow-hidden bg-stone-950/70 backdrop-blur-sm flex justify-end">
          
          {/* Backdrop click */}
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            onClick={() => setIsCartOpen(false)}
            className="fixed inset-0"
          />

        {/* Drawer Panel */}
        <motion.div
          initial={{ x: '100%' }}
          animate={{ x: 0 }}
          exit={{ x: '100%' }}
          transition={{ type: 'spring', damping: 25, stiffness: 300 }}
          className="relative z-10 bg-white w-full max-w-md h-full shadow-2xl flex flex-col justify-between overflow-hidden"
        >
          
          {/* Header */}
          <div className="p-4 sm:p-5 border-b border-stone-200 bg-stone-50/80 flex items-center justify-between">
            <div className="flex items-center gap-2.5">
              <div className="w-9 h-9 rounded-xl bg-stone-900 text-amber-400 flex items-center justify-center shadow-xs">
                <ShoppingBag className="w-5 h-5" />
              </div>
              <div>
                <h3 className="font-serif text-lg font-bold text-stone-900 flex items-center gap-2">
                  <span>Your Order Cart</span>
                  <span className="text-xs font-sans px-2 py-0.5 rounded-full bg-stone-200 text-stone-700">
                    {totalCartItemCount} {totalCartItemCount === 1 ? 'item' : 'items'}
                  </span>
                </h3>
                <p className="text-xs text-stone-500">{settings.name}</p>
              </div>
            </div>

            <button
              onClick={() => setIsCartOpen(false)}
              className="p-2 rounded-xl hover:bg-stone-200 text-stone-500 transition-colors"
              aria-label="Close cart"
            >
              <X className="w-5 h-5" />
            </button>
          </div>

          {/* Cart Items List or Empty State */}
          <div className="flex-1 overflow-y-auto p-4 sm:p-5 space-y-4">
            {cart.length > 0 ? (
              <>
                <div className="flex justify-between items-center pb-2 border-b border-stone-100">
                  <span className="text-xs font-bold uppercase tracking-wider text-stone-500">
                    Selected Items
                  </span>
                  <button
                    onClick={clearCart}
                    className="text-xs text-rose-600 hover:text-rose-700 font-medium underline underline-offset-2"
                  >
                    Clear all
                  </button>
                </div>

                <div className="space-y-3">
                  {cart.map((item) => (
                    <motion.div
                      key={item.cartItemId}
                      layout
                      initial={{ opacity: 0, y: 10 }}
                      animate={{ opacity: 1, y: 0 }}
                      exit={{ opacity: 0, scale: 0.9 }}
                      className="p-3.5 rounded-2xl bg-stone-50/70 border border-stone-200/80 flex gap-3 relative group"
                    >
                      {/* Thumbnail */}
                      <img
                        src={item.image}
                        alt={item.name}
                        className="w-16 h-16 rounded-xl object-cover shrink-0 bg-stone-200 border border-stone-200"
                      />

                      {/* Content */}
                      <div className="flex-1 min-w-0 space-y-1">
                        <div className="flex items-start justify-between gap-2">
                          <h4 className="text-xs sm:text-sm font-bold text-stone-900 leading-snug line-clamp-1">
                            {item.name}
                          </h4>
                          <span className="text-xs sm:text-sm font-bold text-stone-900 font-serif">
                            {settings.currency}{(item.calculatedPrice * item.quantity).toFixed(2)}
                          </span>
                        </div>

                        {/* Size & Addons Badges */}
                        <div className="flex flex-wrap gap-1 text-[11px] text-stone-500">
                          {item.selectedSize && (
                            <span className="bg-stone-200/70 px-1.5 py-0.5 rounded text-stone-700 font-medium">
                              {item.selectedSize.name}
                            </span>
                          )}
                          {item.selectedAddons?.map((addon) => (
                            <span key={addon.id} className="bg-amber-100 px-1.5 py-0.5 rounded text-amber-900 font-medium">
                              +{addon.name}
                            </span>
                          ))}
                        </div>

                        {/* Special Instructions display / toggle */}
                        {item.specialInstructions ? (
                          <p className="text-[11px] text-amber-800 italic bg-amber-50/80 px-2 py-0.5 rounded border border-amber-200/60 line-clamp-1">
                            Note: "{item.specialInstructions}"
                          </p>
                        ) : null}

                        {/* Controls: Quantity Stepper & Special Instructions Button */}
                        <div className="flex items-center justify-between pt-1">
                          
                          {/* Quantity Stepper */}
                          <div className="flex items-center border border-stone-300 rounded-lg bg-white p-0.5 shadow-2xs">
                            <button
                              onClick={() => updateCartItemQuantity(item.cartItemId, -1)}
                              className="w-6 h-6 rounded flex items-center justify-center hover:bg-stone-100 text-stone-700 transition-colors"
                              aria-label="Decrease"
                            >
                              <Minus className="w-3 h-3" />
                            </button>
                            <span className="w-6 text-center text-xs font-bold text-stone-900">
                              {item.quantity}
                            </span>
                            <button
                              onClick={() => updateCartItemQuantity(item.cartItemId, 1)}
                              className="w-6 h-6 rounded flex items-center justify-center hover:bg-stone-100 text-stone-700 transition-colors"
                              aria-label="Increase"
                            >
                              <Plus className="w-3 h-3" />
                            </button>
                          </div>

                          {/* Action Buttons (Instructions & Remove) */}
                          <div className="flex items-center gap-1.5">
                            <button
                              onClick={() =>
                                setEditingInstructionsId(
                                  editingInstructionsId === item.cartItemId ? null : item.cartItemId
                                )
                              }
                              className="p-1.5 text-stone-400 hover:text-stone-700 rounded-lg hover:bg-stone-200/60 transition-colors text-xs flex items-center gap-1"
                              title="Add special instructions"
                            >
                              <MessageSquare className="w-3.5 h-3.5" />
                              <span className="text-[10px] hidden sm:inline">Note</span>
                            </button>

                            <button
                              onClick={() => removeCartItem(item.cartItemId)}
                              className="p-1.5 text-stone-400 hover:text-rose-600 rounded-lg hover:bg-rose-50 transition-colors"
                              title="Remove item"
                            >
                              <Trash2 className="w-3.5 h-3.5" />
                            </button>
                          </div>

                        </div>

                        {/* Inline Instructions Input Box if open */}
                        {editingInstructionsId === item.cartItemId && (
                          <div className="pt-2">
                            <input
                              type="text"
                              defaultValue={item.specialInstructions || ''}
                              onBlur={(e) => {
                                updateCartItemInstructions(item.cartItemId, e.target.value);
                                setEditingInstructionsId(null);
                              }}
                              onKeyDown={(e) => {
                                if (e.key === 'Enter') {
                                  updateCartItemInstructions(item.cartItemId, e.currentTarget.value);
                                  setEditingInstructionsId(null);
                                }
                              }}
                              placeholder="e.g. Extra hot, no straw..."
                              autoFocus
                              className="w-full text-xs p-2 rounded-lg border border-amber-300 focus:outline-none focus:ring-1 focus:ring-amber-800 bg-white"
                            />
                          </div>
                        )}

                      </div>
                    </motion.div>
                  ))}
                </div>

                {/* Promo Code Box */}
                <div className="pt-3 border-t border-stone-200">
                  {appliedPromo ? (
                    <div className="p-3 rounded-2xl bg-emerald-50 border border-emerald-200 flex items-center justify-between text-xs text-emerald-900">
                      <div className="flex items-center gap-2">
                        <Tag className="w-4 h-4 text-emerald-700" />
                        <div>
                          <span className="font-bold font-mono">{appliedPromo.code}</span>
                          <p className="text-[11px] text-emerald-700">{appliedPromo.description}</p>
                        </div>
                      </div>
                      <button
                        onClick={removePromoCode}
                        className="text-xs font-semibold text-emerald-800 hover:text-rose-700 underline"
                      >
                        Remove
                      </button>
                    </div>
                  ) : (
                    <form onSubmit={handleApplyPromo} className="space-y-1.5">
                      <div className="flex gap-2">
                        <div className="relative flex-1">
                          <Tag className="absolute left-3 top-1/2 -translate-y-1/2 w-3.5 h-3.5 text-stone-400" />
                          <input
                            type="text"
                            value={promoInput}
                            onChange={(e) => setPromoInput(e.target.value)}
                            placeholder="Enter promo code (e.g. WELCOME15)"
                            className="w-full pl-9 pr-3 py-2 text-xs uppercase font-mono rounded-xl border border-stone-200 focus:outline-none focus:ring-1 focus:ring-amber-800 bg-stone-50"
                          />
                        </div>
                        <button
                          type="submit"
                          className="px-3.5 py-2 bg-stone-900 hover:bg-stone-800 text-white font-semibold text-xs rounded-xl transition-colors cursor-pointer"
                        >
                          Apply
                        </button>
                      </div>
                      {promoError && (
                        <p className="text-[11px] text-rose-600 flex items-center gap-1">
                          <AlertCircle className="w-3 h-3" />
                          <span>{promoError}</span>
                        </p>
                      )}
                    </form>
                  )}
                </div>
              </>
            ) : (
              /* Empty Cart State */
              <div className="h-full flex flex-col items-center justify-center text-center p-6 space-y-4">
                <div className="w-16 h-16 rounded-3xl bg-amber-50 text-amber-800 flex items-center justify-center">
                  <ShoppingBag className="w-8 h-8" />
                </div>
                <div className="space-y-1">
                  <h3 className="font-serif text-lg font-bold text-stone-900">
                    Your cart is empty
                  </h3>
                  <p className="text-xs text-stone-500 max-w-xs leading-relaxed">
                    Explore our handcrafted brews, warm flaky croissants, and delicious brunch items to start your order.
                  </p>
                </div>
                <button
                  onClick={() => setIsCartOpen(false)}
                  className="px-5 py-2.5 bg-stone-900 hover:bg-amber-900 text-white font-semibold text-xs rounded-xl shadow-md transition-colors"
                >
                  Browse Full Menu
                </button>
              </div>
            )}
          </div>

          {/* Sticky Summary & Checkout Footer */}
          {cart.length > 0 && (
            <div className="p-4 sm:p-5 border-t border-stone-200 bg-stone-50/90 space-y-3">
              
              {/* Calculations breakdown */}
              <div className="space-y-1.5 text-xs text-stone-600">
                <div className="flex justify-between">
                  <span>Items Subtotal</span>
                  <span className="font-medium text-stone-900">
                    {settings.currency}{pricing.subtotal.toFixed(2)}
                  </span>
                </div>

                {pricing.discountAmount > 0 && (
                  <div className="flex justify-between text-emerald-700 font-medium">
                    <span className="flex items-center gap-1">
                      <Sparkles className="w-3 h-3" />
                      Discount ({pricing.discountCode})
                    </span>
                    <span>-{settings.currency}{pricing.discountAmount.toFixed(2)}</span>
                  </div>
                )}

                <div className="flex justify-between">
                  <span>Estimated GST ({settings.taxRatePercent}%)</span>
                  <span>{settings.currency}{pricing.gstTax.toFixed(2)}</span>
                </div>

                <div className="flex justify-between text-stone-500 text-[11px]">
                  <span>Service Fee (Dine-in)</span>
                  <span>{settings.currency}{settings.serviceFeeFixed.toFixed(2)}</span>
                </div>

                <div className="flex justify-between pt-2 border-t border-stone-200 text-base font-bold text-stone-900">
                  <span className="font-serif">Estimated Total</span>
                  <span className="font-serif text-amber-950 text-lg">
                    {settings.currency}{pricing.total.toFixed(2)}
                  </span>
                </div>
              </div>

              {/* Action Buttons (Proceed to Booking / Checkout) */}
              {!isCafeOpenNow ? (
                <div className="space-y-2">
                  <button
                    id="cart-closed-disabled-btn"
                    disabled
                    className="w-full min-h-[48px] py-3 px-4 bg-stone-200 text-stone-600 font-bold text-xs sm:text-sm rounded-2xl flex items-center justify-center gap-2 cursor-not-allowed border border-stone-300"
                  >
                    <span>🔴 Currently Closed – Ordering is Temporarily Unavailable</span>
                  </button>
                  <p className="text-[11px] text-center text-stone-500">
                    Your tray items remain saved. You can place your order as soon as the café reopens.
                  </p>
                </div>
              ) : (
                <button
                  id="cart-proceed-checkout-btn"
                  onClick={handleProceedToCheckout}
                  className="w-full min-h-[48px] py-3 px-4 bg-amber-500 hover:bg-amber-400 active:bg-amber-600 text-stone-950 font-bold text-sm rounded-2xl shadow-lg shadow-amber-500/20 transition-all flex items-center justify-center gap-2 cursor-pointer"
                >
                  <span>Proceed to Booking & Checkout</span>
                  <ArrowRight className="w-4 h-4" />
                </button>
              )}

            </div>
          )}

        </motion.div>
      </div>
    )}
  </AnimatePresence>
);
};
