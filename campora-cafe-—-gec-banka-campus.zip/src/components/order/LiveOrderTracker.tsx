import React, { useState, useEffect } from 'react';
import { useCafe } from '../../context/CafeContext';
import { OrderStatus } from '../../types';
import { formatBookingTimeElapsed } from '../../utils/session';
import {
  X,
  CheckCircle2,
  Clock,
  Coffee,
  MapPin,
  Calendar,
  Share2,
  Star,
  MessageCircle,
  Download,
  Utensils,
  ChevronRight,
  ShieldCheck,
  Sparkles,
  QrCode,
  PhoneCall,
  AlertTriangle,
  Info,
  Smartphone,
  HelpCircle,
  Ban
} from 'lucide-react';
import { motion, AnimatePresence } from 'motion/react';

export const LiveOrderTracker: React.FC = () => {
  const {
    isOrderTrackerOpen,
    setIsOrderTrackerOpen,
    activeOrder,
    settings,
    submitOrderFeedback,
    cancelOrder,
    showToast
  } = useCafe();

  const [rating, setRating] = useState(5);
  const [feedbackComment, setFeedbackComment] = useState('');
  const [feedbackSubmitted, setFeedbackSubmitted] = useState(false);
  const [currentTime, setCurrentTime] = useState(Date.now());
  const [isPolicyInfoOpen, setIsPolicyInfoOpen] = useState(false);
  const [isCancelConfirmOpen, setIsCancelConfirmOpen] = useState(false);
  const [isCancelling, setIsCancelling] = useState(false);

  // Live timer tick every second for real-time countdown
  useEffect(() => {
    const timer = setInterval(() => {
      setCurrentTime(Date.now());
    }, 1000);
    return () => clearInterval(timer);
  }, []);

  if (!isOrderTrackerOpen || !activeOrder) return null;

  const order = activeOrder;
  const timeElapsedInfo = formatBookingTimeElapsed(order.createdAt);

  // Status timeline definition
  const steps: { status: OrderStatus; label: string; desc: string }[] = [
    { status: 'confirmed', label: 'Booking Confirmed', desc: 'Order received and logged in cafe system' },
    { status: 'preparing', label: 'Barista Crafting', desc: 'Brewing espresso, baking and plating items' },
    { status: 'ready', label: order.bookingMode === 'dine-in' ? 'Table & Dishes Ready' : 'Ready for Pickup', desc: 'Ready for you at the counter or your reserved table' },
    { status: 'completed', label: 'Completed', desc: 'Served and closed' },
  ];

  const getStepIndex = (status: OrderStatus) => {
    switch (status) {
      case 'confirmed': return 0;
      case 'preparing': return 1;
      case 'ready': return 2;
      case 'completed': return 3;
      case 'cancelled': return -1;
    }
  };

  const currentStepIdx = getStepIndex(order.status);

  // Generate downloadable Calendar ICS file
  const handleAddToCalendar = () => {
    const title = `Reservation at ${settings.name} (Booking #${order.id})`;
    const desc = `Table reservation and order at ${settings.name}, ${settings.address}. Booking Ref: ${order.id}, Device Slug: ${order.deviceSessionSlug || 'N/A'}`;
    const icsData = `BEGIN:VCALENDAR\nVERSION:2.0\nBEGIN:VEVENT\nSUMMARY:${title}\nDESCRIPTION:${desc}\nLOCATION:${settings.address}\nSTATUS:CONFIRMED\nEND:VEVENT\nEND:VCALENDAR`;

    const blob = new Blob([icsData], { type: 'text/calendar;charset=utf-8' });
    const link = document.createElement('a');
    link.href = window.URL.createObjectURL(blob);
    link.setAttribute('download', `Cafe-Booking-${order.id}.ics`);
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
    showToast('Calendar Event Created', 'Downloaded .ics event for your calendar.', 'success');
  };

  // WhatsApp receipt share
  const handleShareReceipt = () => {
    const text = `*${settings.name} Booking Receipt*\nBooking ID: #${order.id}\nDevice Session: ${order.deviceSessionSlug || 'N/A'}\nMode: ${order.bookingMode.toUpperCase()}\nTotal: ${settings.currency}${order.pricing.total.toFixed(2)}\nEstimated Time: ${order.estimatedReadyTime}\nAddress: ${settings.address}`;
    const url = `https://wa.me/?text=${encodeURIComponent(text)}`;
    window.open(url, '_blank');
  };

  // Direct cancellation WhatsApp link
  const getCancellationWhatsAppUrl = () => {
    const text = `Hello ${settings.name} Kitchen,\nI am requesting cancellation for my order:\n• Order ID: #${order.id}\n• Customer: ${order.customer.name}\n• Phone: ${order.customer.phone}\n• Device Session: ${order.deviceSessionSlug || 'N/A'}\n• Placed: ${new Date(order.createdAt).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}\n\nPlease confirm cancellation and record my request in the system.`;
    return `https://wa.me/${settings.whatsapp.replace(/\D/g, '')}?text=${encodeURIComponent(text)}`;
  };

  const handleFeedbackSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    submitOrderFeedback(order.id, rating, feedbackComment);
    setFeedbackSubmitted(true);
  };

  return (
    <AnimatePresence>
      <div id="live-order-tracker-modal" className="fixed inset-0 z-50 overflow-y-auto bg-stone-950/80 backdrop-blur-sm flex items-end sm:items-center justify-center p-0 sm:p-4">
        
        {/* Backdrop */}
        <motion.div
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          exit={{ opacity: 0 }}
          onClick={() => setIsOrderTrackerOpen(false)}
          className="fixed inset-0"
        />

        {/* Modal Window */}
        <motion.div
          initial={{ opacity: 0, y: 50, scale: 0.95 }}
          animate={{ opacity: 1, y: 0, scale: 1 }}
          exit={{ opacity: 0, y: 50, scale: 0.95 }}
          className="relative z-10 bg-white w-full sm:max-w-xl max-h-[92vh] rounded-t-3xl sm:rounded-3xl shadow-2xl flex flex-col overflow-hidden border border-stone-200"
        >
          
          {/* Header Bar */}
          <div className="p-4 sm:p-5 border-b border-stone-200 bg-stone-900 text-stone-100 flex items-center justify-between">
            <div className="flex items-center gap-2.5">
              <div className="w-9 h-9 rounded-xl bg-amber-500 text-stone-950 flex items-center justify-center font-bold shadow-md">
                <Coffee className="w-5 h-5" />
              </div>
              <div>
                <div className="flex items-center gap-2">
                  <h3 className="font-serif text-base font-bold text-stone-100">Live Booking Tracker</h3>
                  <span className="px-2 py-0.5 rounded-full text-[10px] font-mono font-bold bg-amber-500/20 text-amber-300 border border-amber-500/40">
                    #{order.id}
                  </span>
                </div>
                <div className="flex items-center gap-1.5 text-xs text-stone-400">
                  <span>{order.bookingMode === 'dine-in' ? 'Table Reservation' : order.bookingMode === 'takeout' ? 'Express Takeout' : 'Hostel Delivery'}</span>
                  <span>•</span>
                  <span className="text-amber-300 font-mono text-[11px]">{order.deviceSessionSlug || 'Device Linked'}</span>
                </div>
              </div>
            </div>

            <button
              onClick={() => setIsOrderTrackerOpen(false)}
              className="p-1.5 rounded-full hover:bg-stone-800 text-stone-400 hover:text-stone-100 transition-colors"
            >
              <X className="w-5 h-5" />
            </button>
          </div>

          {/* Scrollable Content */}
          <div className="overflow-y-auto p-5 sm:p-6 space-y-5 text-xs text-stone-700">
            
            {/* Cancelled Order Notice (if status is cancelled) */}
            {order.status === 'cancelled' && (
              <div className="p-4 rounded-2xl bg-rose-50 border border-rose-200 text-rose-900 space-y-1.5">
                <div className="flex items-center gap-2 font-bold text-rose-800 text-sm">
                  <Ban className="w-4 h-4 text-rose-600" />
                  <span>This Booking Has Been Cancelled</span>
                </div>
                <p className="text-xs text-rose-700">
                  {order.adminNotes || 'Order was cancelled by customer contact / kitchen supervisor.'}
                </p>
              </div>
            )}

            {/* Status Timeline Progress Card */}
            {order.status !== 'cancelled' && (
              <div className="p-5 rounded-2xl bg-amber-50/80 border border-amber-200/90 space-y-4 shadow-xs">
                <div className="flex items-center justify-between">
                  <div>
                    <span className="text-[10px] font-bold uppercase tracking-wider text-amber-800">
                      Live Kitchen Status
                    </span>
                    <p className="text-base font-bold text-stone-900 capitalize font-serif">
                      {order.status === 'confirmed' && 'Order Confirmed & Logged'}
                      {order.status === 'preparing' && '☕ Barista & Kitchen Crafting Order'}
                      {order.status === 'ready' && '🎉 Order Ready for You!'}
                      {order.status === 'completed' && '✨ Order Completed & Served'}
                    </p>
                  </div>

                  <div className="text-right">
                    <span className="text-[10px] text-stone-500">Estimated Ready</span>
                    <p className="text-sm font-bold text-amber-900">{order.estimatedReadyTime}</p>
                  </div>
                </div>

                {/* Progress Steps Visualizer */}
                <div className="relative pl-6 space-y-4 before:absolute before:left-2 before:top-2 before:bottom-2 before:w-0.5 before:bg-amber-200">
                  {steps.map((step, idx) => {
                    const isCurrent = currentStepIdx === idx;
                    const isPast = currentStepIdx > idx;

                    return (
                      <div key={step.status} className="relative flex items-start gap-3">
                        <span
                          className={`absolute -left-6 top-0.5 w-4 h-4 rounded-full border-2 flex items-center justify-center ${
                            isPast
                              ? 'bg-amber-800 border-amber-800 text-white'
                              : isCurrent
                              ? 'bg-amber-500 border-amber-600 animate-ping'
                              : 'bg-white border-stone-300'
                          }`}
                        >
                          {isPast && <CheckCircle2 className="w-3 h-3" />}
                        </span>

                        <div>
                          <p className={`font-bold ${isCurrent ? 'text-amber-950 font-bold' : isPast ? 'text-stone-800' : 'text-stone-400'}`}>
                            {step.label}
                          </p>
                          <p className="text-[11px] text-stone-500">{step.desc}</p>
                        </div>
                      </div>
                    );
                  })}
                </div>
              </div>
            )}

            {/* MANDATORY CANCELLATION POLICY & DIRECT CONTACT SECTION */}
            {order.status !== 'completed' && order.status !== 'cancelled' && (
              <div className={`p-4 rounded-2xl border transition-all ${
                timeElapsedInfo.isWithin10MinWindow
                  ? 'bg-gradient-to-br from-emerald-50 to-amber-50/50 border-emerald-300/80 shadow-xs'
                  : 'bg-stone-50 border-amber-300/80'
              }`}>
                <div className="flex items-start justify-between gap-3">
                  <div className="space-y-1">
                    <div className="flex items-center gap-2">
                      <span className={`px-2 py-0.5 rounded-md text-[10px] font-mono font-extrabold uppercase ${
                        timeElapsedInfo.isWithin10MinWindow
                          ? 'bg-emerald-600 text-white animate-pulse'
                          : 'bg-rose-100 text-rose-800 border border-rose-200'
                      }`}>
                        {timeElapsedInfo.isWithin10MinWindow
                          ? `⏱️ ${timeElapsedInfo.formattedCountdown} Min Free Cancel Window`
                          : '⚠️ 10-Min Free Cancel Expired'}
                      </span>
                      <button
                        type="button"
                        onClick={() => setIsPolicyInfoOpen(!isPolicyInfoOpen)}
                        className="text-[11px] text-stone-500 hover:text-stone-900 underline flex items-center gap-0.5"
                      >
                        <HelpCircle className="w-3 h-3 text-amber-700" />
                        <span>Policy</span>
                      </button>
                    </div>

                    <h4 className="font-bold text-stone-900 text-xs">
                      {timeElapsedInfo.isWithin10MinWindow
                        ? 'Need to cancel? Direct cafe call required within 10 minutes.'
                        : 'Cancellation after 10 minutes: 100% cost borne by customer'}
                    </h4>
                  </div>
                </div>

                <p className="text-[11px] text-stone-600 mt-2 leading-relaxed">
                  {timeElapsedInfo.isWithin10MinWindow ? (
                    <>
                      Under college cafe policy, cancellations are <strong>strictly permitted within 10 minutes</strong> of placement with <strong>zero penalty</strong>. You must <strong>call or WhatsApp the kitchen directly</strong> to authorize the cancellation.
                    </>
                  ) : (
                    <>
                      Food preparation and seating allocation are in progress. Because ingredients are made fresh per order, cancellations after 10 minutes <strong>cannot be refunded</strong> and the full order value of <strong>{settings.currency}{order.pricing.total.toFixed(2)}</strong> must be borne by the customer.
                    </>
                  )}
                </p>

                {/* Direct Contact & Cancel Actions */}
                <div className="mt-3.5 pt-3 border-t border-stone-200/80 space-y-2">
                  <div className="flex flex-wrap gap-2">
                    <a
                      href={`tel:${settings.phone.replace(/\s+/g, '')}`}
                      className="flex-1 min-w-[130px] py-2 px-3 rounded-xl bg-stone-900 hover:bg-stone-800 text-white font-bold text-xs flex items-center justify-center gap-1.5 shadow-xs transition-colors"
                    >
                      <PhoneCall className="w-3.5 h-3.5 text-amber-400" />
                      <span>Call Cafe</span>
                    </a>

                    <a
                      href={getCancellationWhatsAppUrl()}
                      target="_blank"
                      rel="noreferrer"
                      className="flex-1 min-w-[130px] py-2 px-3 rounded-xl bg-emerald-700 hover:bg-emerald-800 text-white font-bold text-xs flex items-center justify-center gap-1.5 shadow-xs transition-colors"
                    >
                      <MessageCircle className="w-3.5 h-3.5" />
                      <span>WhatsApp Kitchen</span>
                    </a>

                    {timeElapsedInfo.isWithin10MinWindow && (
                      <button
                        type="button"
                        onClick={() => setIsCancelConfirmOpen(true)}
                        className="py-2 px-3 rounded-xl bg-rose-50 text-rose-700 hover:bg-rose-100 border border-rose-200 font-bold text-xs flex items-center justify-center gap-1.5 transition-colors"
                      >
                        <Ban className="w-3.5 h-3.5 text-rose-600" />
                        <span>Cancel Order</span>
                      </button>
                    )}
                  </div>

                  {/* Cancellation In-App Confirmation Banner */}
                  {isCancelConfirmOpen && (
                    <motion.div
                      initial={{ opacity: 0, y: -6 }}
                      animate={{ opacity: 1, y: 0 }}
                      className="p-3 bg-rose-50 border border-rose-200 rounded-xl space-y-2 text-xs"
                    >
                      <p className="font-bold text-rose-900">
                        Confirm cancellation for Booking #{order.id}?
                      </p>
                      <p className="text-rose-700 text-[11px]">
                        Since this order is within the 10-minute window, it will be cancelled immediately in the kitchen system with zero penalty.
                      </p>
                      <div className="flex items-center gap-2 pt-1">
                        <button
                          type="button"
                          disabled={isCancelling}
                          onClick={async () => {
                            setIsCancelling(true);
                            await cancelOrder(order.id, 'Customer cancelled within 10-minute grace window');
                            setIsCancelling(false);
                            setIsCancelConfirmOpen(false);
                          }}
                          className="px-3 py-1.5 bg-rose-600 hover:bg-rose-700 text-white font-bold rounded-lg text-xs transition-colors shadow-xs"
                        >
                          {isCancelling ? 'Cancelling...' : 'Yes, Cancel Order'}
                        </button>
                        <button
                          type="button"
                          disabled={isCancelling}
                          onClick={() => setIsCancelConfirmOpen(false)}
                          className="px-3 py-1.5 bg-white border border-stone-200 text-stone-700 font-medium rounded-lg text-xs hover:bg-stone-50"
                        >
                          Keep Order
                        </button>
                      </div>
                    </motion.div>
                  )}
                </div>

                {/* Policy Detail Collapsible */}
                {isPolicyInfoOpen && (
                  <motion.div
                    initial={{ opacity: 0, height: 0 }}
                    animate={{ opacity: 1, height: 'auto' }}
                    className="mt-3 p-3 rounded-xl bg-white border border-stone-200 text-[11px] text-stone-600 space-y-1.5"
                  >
                    <p className="font-bold text-stone-900">Campora Cafe GEC Banka Cancellation Policy:</p>
                    <ul className="list-disc list-inside space-y-1 text-stone-600">
                      <li>Free cancellation is exclusively available within <strong>10 minutes</strong> of placing the booking.</li>
                      <li>To cancel, the customer must directly contact cafe staff via telephone or WhatsApp with their <strong>Order ID (#{order.id})</strong> and <strong>Device Session ({order.deviceSessionSlug})</strong>.</li>
                      <li>Orders cancelled after 10 minutes incur a 100% preparation charge to prevent food wastage in the campus dining facility.</li>
                    </ul>
                  </motion.div>
                )}
              </div>
            )}

            {/* Comprehensive Booking Specifics & QR Pass Card */}
            <div className="p-4 rounded-2xl bg-white border border-stone-200 shadow-xs space-y-4">
              
              <div className="flex flex-col sm:flex-row items-center justify-between gap-4 pb-3 border-b border-stone-100">
                <div className="flex items-center gap-3">
                  <div className="w-20 h-20 bg-stone-900 rounded-xl p-2 flex flex-col items-center justify-center shrink-0 shadow-xs text-white">
                    <QrCode className="w-12 h-12 text-amber-300" />
                    <span className="text-[8px] font-mono font-bold tracking-widest mt-0.5">CHECK-IN</span>
                  </div>
                  <div className="space-y-1">
                    <span className="text-[10px] font-bold uppercase tracking-wider text-stone-400">
                      Fast Check-in Pass
                    </span>
                    <p className="text-sm font-bold text-stone-900 font-mono">
                      {order.qrCodePayload}
                    </p>
                    <p className="text-[11px] text-stone-500">
                      Present at counter or table for express serving.
                    </p>
                  </div>
                </div>

                <div className="text-right sm:text-right w-full sm:w-auto bg-stone-50 p-2.5 rounded-xl border border-stone-200">
                  <div className="flex items-center justify-end gap-1 text-stone-400 text-[10px] uppercase font-bold">
                    <Smartphone className="w-3 h-3 text-amber-700" />
                    <span>Device Session Token</span>
                  </div>
                  <p className="text-xs font-mono font-bold text-stone-800">
                    {order.deviceSessionSlug || 'gec-dev-session'}
                  </p>
                  <p className="text-[10px] text-stone-500">
                    Placed on {new Date(order.createdAt).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}
                  </p>
                </div>
              </div>

              {/* Specific Booking Mode Breakdown */}
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 text-xs">
                {order.bookingMode === 'dine-in' && order.dineInDetails && (
                  <div className="p-3 bg-amber-50/60 rounded-xl border border-amber-200/80">
                    <span className="text-[10px] font-bold uppercase text-amber-900">Dine-In Table Details</span>
                    <p className="font-bold text-stone-900 mt-0.5">
                      {order.dineInDetails.tableNumber || 'Table Assigned on Arrival'} ({order.dineInDetails.zone.toUpperCase()})
                    </p>
                    <p className="text-[11px] text-stone-600">
                      {order.dineInDetails.date} at {order.dineInDetails.timeSlot} • {order.dineInDetails.guestCount} Guests
                    </p>
                    {order.dineInDetails.occasion && (
                      <p className="text-[10px] text-amber-800 font-semibold mt-1 capitalize">
                        Occasion: {order.dineInDetails.occasion}
                      </p>
                    )}
                  </div>
                )}

                {order.bookingMode === 'takeout' && order.takeoutDetails && (
                  <div className="p-3 bg-stone-50 rounded-xl border border-stone-200">
                    <span className="text-[10px] font-bold uppercase text-stone-500">Takeout Pickup</span>
                    <p className="font-bold text-stone-900 mt-0.5">
                      {order.takeoutDetails.pickupTime}
                    </p>
                    {order.takeoutDetails.vehicleOrNote && (
                      <p className="text-[11px] text-stone-600 mt-1">
                        Note: {order.takeoutDetails.vehicleOrNote}
                      </p>
                    )}
                  </div>
                )}

                {order.bookingMode === 'delivery' && order.deliveryDetails && (
                  <div className="p-3 bg-stone-50 rounded-xl border border-stone-200">
                    <span className="text-[10px] font-bold uppercase text-stone-500">Campus & Hostel Delivery</span>
                    <p className="font-bold text-stone-900 mt-0.5">
                      {order.deliveryDetails.deliveryAddress}
                    </p>
                    {order.deliveryDetails.landmark && (
                      <p className="text-[11px] text-stone-600">
                        Landmark: {order.deliveryDetails.landmark}
                      </p>
                    )}
                  </div>
                )}

                <div className="p-3 bg-stone-50 rounded-xl border border-stone-200">
                  <span className="text-[10px] font-bold uppercase text-stone-500">Customer Profile</span>
                  <p className="font-bold text-stone-900 mt-0.5">{order.customer.name}</p>
                  <p className="text-[11px] text-stone-600">{order.customer.phone}</p>
                  {order.customer.specialRequests && (
                    <p className="text-[10px] text-amber-800 italic mt-1">
                      "{order.customer.specialRequests}"
                    </p>
                  )}
                </div>
              </div>

            </div>

            {/* Ordered Items Summary */}
            <div className="space-y-2">
              <span className="font-bold uppercase tracking-wider text-stone-800 text-[11px]">
                Itemized Order Bill
              </span>
              <div className="rounded-xl border border-stone-200 divide-y divide-stone-100 overflow-hidden bg-stone-50/50">
                {order.items.map((item) => (
                  <div key={item.cartItemId} className="p-3 flex items-center justify-between">
                    <div className="flex items-center gap-2.5">
                      <img
                        src={item.image}
                        alt={item.name}
                        className="w-10 h-10 rounded-lg object-cover bg-stone-200 shrink-0"
                      />
                      <div>
                        <p className="font-bold text-stone-900">
                          {item.quantity}x {item.name}
                        </p>
                        <div className="flex flex-wrap gap-1 text-[10px] text-stone-500">
                          {item.selectedSize && <span>{item.selectedSize.name}</span>}
                          {item.selectedAddons?.map((a) => (
                            <span key={a.id}>+{a.name}</span>
                          ))}
                        </div>
                        {item.specialInstructions && (
                          <p className="text-[10px] text-amber-800 italic">
                            Note: {item.specialInstructions}
                          </p>
                        )}
                      </div>
                    </div>
                    <span className="font-bold text-stone-900 font-serif">
                      {settings.currency}{(item.calculatedPrice * item.quantity).toFixed(2)}
                    </span>
                  </div>
                ))}

                {/* Subtotal / GST / Discount / Total */}
                <div className="p-3 bg-stone-100/70 text-xs space-y-1 text-stone-600">
                  <div className="flex justify-between">
                    <span>Subtotal</span>
                    <span>{settings.currency}{order.pricing.subtotal.toFixed(2)}</span>
                  </div>
                  {order.pricing.discountAmount > 0 && (
                    <div className="flex justify-between text-emerald-700 font-semibold">
                      <span>Discount ({order.pricing.discountCode || 'Applied'})</span>
                      <span>-{settings.currency}{order.pricing.discountAmount.toFixed(2)}</span>
                    </div>
                  )}
                  <div className="flex justify-between">
                    <span>GST (5%)</span>
                    <span>{settings.currency}{order.pricing.gstTax.toFixed(2)}</span>
                  </div>
                  {order.pricing.serviceFee > 0 && (
                    <div className="flex justify-between">
                      <span>Dine-in Service Fee</span>
                      <span>{settings.currency}{order.pricing.serviceFee.toFixed(2)}</span>
                    </div>
                  )}
                  {order.pricing.deliveryFee > 0 && (
                    <div className="flex justify-between">
                      <span>Hostel Delivery Fee</span>
                      <span>{settings.currency}{order.pricing.deliveryFee.toFixed(2)}</span>
                    </div>
                  )}
                </div>

                <div className="p-3 bg-white flex justify-between font-bold text-stone-900 text-sm">
                  <span>Total Amount ({order.paymentMethod.toUpperCase()} • {order.paymentStatus})</span>
                  <span className="text-amber-950 font-serif text-base">
                    {settings.currency}{order.pricing.total.toFixed(2)}
                  </span>
                </div>
              </div>
            </div>

            {/* Quick Sharing & Calendar Actions */}
            <div className="grid grid-cols-2 gap-2.5">
              <button
                onClick={handleAddToCalendar}
                className="p-2.5 rounded-xl border border-stone-200 hover:bg-stone-100 font-semibold flex items-center justify-center gap-1.5 transition-colors"
              >
                <Calendar className="w-3.5 h-3.5 text-amber-700" />
                <span>Add to Calendar</span>
              </button>

              <button
                onClick={handleShareReceipt}
                className="p-2.5 rounded-xl bg-emerald-700 text-white hover:bg-emerald-800 font-semibold flex items-center justify-center gap-1.5 transition-colors"
              >
                <Share2 className="w-3.5 h-3.5" />
                <span>Share Receipt</span>
              </button>
            </div>

            {/* Feedback & Star Rating Form */}
            <div className="p-4 rounded-2xl bg-stone-50 border border-stone-200 space-y-3">
              <div className="flex items-center justify-between">
                <span className="font-bold text-stone-900">How was your booking experience?</span>
                <div className="flex items-center gap-1">
                  {[1, 2, 3, 4, 5].map((star) => (
                    <button
                      key={star}
                      type="button"
                      onClick={() => setRating(star)}
                      className="p-1 focus:outline-none"
                    >
                      <Star
                        className={`w-4 h-4 ${
                          star <= rating
                            ? 'fill-amber-400 text-amber-400'
                            : 'text-stone-300'
                        }`}
                      />
                    </button>
                  ))}
                </div>
              </div>

              {feedbackSubmitted ? (
                <p className="text-emerald-700 font-semibold flex items-center gap-1">
                  <CheckCircle2 className="w-4 h-4" />
                  <span>Thank you for your review and rating!</span>
                </p>
              ) : (
                <form onSubmit={handleFeedbackSubmit} className="space-y-2">
                  <textarea
                    value={feedbackComment}
                    onChange={(e) => setFeedbackComment(e.target.value)}
                    placeholder="Leave a quick note for the barista or chef..."
                    rows={2}
                    className="w-full text-xs p-2.5 rounded-xl border border-stone-200 bg-white focus:outline-none focus:ring-1 focus:ring-amber-800"
                  />
                  <button
                    type="submit"
                    className="px-3.5 py-1.5 bg-stone-900 text-white font-semibold text-xs rounded-xl hover:bg-stone-800 transition-colors"
                  >
                    Submit Feedback
                  </button>
                </form>
              )}
            </div>

          </div>

        </motion.div>
      </div>
    </AnimatePresence>
  );
};

