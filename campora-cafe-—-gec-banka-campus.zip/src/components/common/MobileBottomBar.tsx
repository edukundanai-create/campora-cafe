import React from 'react';
import { useCafe } from '../../context/CafeContext';
import { ShoppingBag, CalendarCheck, ArrowRight, Utensils, User } from 'lucide-react';
import { motion, AnimatePresence } from 'motion/react';

export const MobileBottomBar: React.FC = () => {
  const {
    totalCartItemCount,
    cart,
    settings,
    setIsCartOpen,
    setIsCheckoutOpen,
    setIsCustomerAccountOpen,
    customerOrders
  } = useCafe();

  const cartSubtotal = cart.reduce((sum, item) => sum + item.calculatedPrice * item.quantity, 0);

  return (
    <div id="mobile-sticky-bottom-bar" className="fixed bottom-0 left-0 right-0 z-30 p-3 bg-gradient-to-t from-[#FAF6F0] via-[#FAF6F0]/95 to-transparent sm:hidden pointer-events-none">
      <div className="max-w-md mx-auto flex items-center gap-2 pointer-events-auto">
        
        {/* Customer Account & Orders Button */}
        <button
          id="mobile-account-btn"
          onClick={() => setIsCustomerAccountOpen(true)}
          className="min-h-[48px] w-14 px-2 bg-stone-900 text-amber-400 font-semibold text-xs rounded-2xl shadow-lg border border-stone-800 flex flex-col items-center justify-center relative transition-transform active:scale-95 shrink-0"
          aria-label="My Account & Orders"
        >
          <div className="relative">
            <User className="w-4 h-4 text-amber-400" />
            {customerOrders.length > 0 && (
              <span className="absolute -top-1 -right-2 bg-amber-500 text-stone-950 text-[9px] font-black w-3.5 h-3.5 rounded-full flex items-center justify-center">
                {customerOrders.length}
              </span>
            )}
          </div>
          <span className="text-[9px] text-stone-300 font-medium leading-none mt-1">Orders</span>
        </button>

        {/* Table Reservation Button (Always accessible) */}
        <button
          id="mobile-book-table-btn"
          onClick={() => setIsCheckoutOpen(true)}
          className="flex-1 min-h-[48px] px-3.5 py-2.5 bg-amber-900/90 active:bg-amber-950 text-amber-100 font-semibold text-xs rounded-2xl shadow-lg border border-amber-800/40 flex items-center justify-center gap-2 transition-transform active:scale-95"
        >
          <CalendarCheck className="w-4 h-4 text-amber-300" />
          <span>Book Table</span>
        </button>

        {/* View Cart Button (Expands or highlights when items > 0) */}
        <button
          id="mobile-cart-action-btn"
          onClick={() => setIsCartOpen(true)}
          className={`flex-1 min-h-[48px] px-3.5 py-2.5 rounded-2xl font-semibold text-xs shadow-xl flex items-center justify-between gap-2 transition-all active:scale-95 ${
            totalCartItemCount > 0
              ? 'bg-stone-900 text-stone-50 border border-stone-800 shadow-stone-900/20'
              : 'bg-stone-800 text-stone-300 border border-stone-700/60'
          }`}
        >
          <div className="flex items-center gap-2">
            <div className="relative">
              <ShoppingBag className="w-4 h-4 text-amber-400" />
              {totalCartItemCount > 0 && (
                <span className="absolute -top-1.5 -right-2 bg-amber-500 text-stone-950 text-[9px] font-extrabold w-4 h-4 rounded-full flex items-center justify-center">
                  {totalCartItemCount}
                </span>
              )}
            </div>
            <span>Cart</span>
          </div>

          <div className="flex items-center gap-1">
            <span className="text-amber-300 font-bold">
              {settings.currency}
              {cartSubtotal.toFixed(2)}
            </span>
            <ArrowRight className="w-3.5 h-3.5 text-stone-400" />
          </div>
        </button>

      </div>
    </div>
  );
};
