import React from 'react';
import { useCafe } from '../../context/CafeContext';
import { Sparkles, AlertCircle, Clock } from 'lucide-react';

export const AnnouncementBanner: React.FC = () => {
  const { settings, isCafeOpenNow } = useCafe();
  const activeAnnouncements = settings.announcements?.filter((a) => a.active) || [];

  if (!isCafeOpenNow) {
    return (
      <div id="cafe-closed-banner" className="bg-rose-950 text-rose-100 text-xs sm:text-sm font-medium py-2.5 px-3 border-b border-rose-900/60 shadow-inner">
        <div className="max-w-7xl mx-auto flex items-center justify-center gap-2 text-center flex-wrap">
          <span className="inline-flex items-center gap-1.5 px-2 py-0.5 rounded-full bg-rose-900/80 text-rose-200 border border-rose-700/60 text-[11px] font-bold">
            <span className="w-2 h-2 rounded-full bg-rose-400 animate-pulse" />
            <span>Currently Closed</span>
          </span>
          <span className="font-bold text-white">Ordering is Temporarily Unavailable</span>
          <span className="text-rose-200/90 text-xs hidden sm:inline">
            — {settings.closedNotice || 'Browse our full menu & prices below. Orders resume when we reopen.'}
          </span>
        </div>
      </div>
    );
  }

  if (activeAnnouncements.length === 0) {
    return (
      <div id="cafe-open-banner" className="bg-stone-900 text-emerald-300 text-xs sm:text-sm font-medium py-1.5 px-3 border-b border-stone-800">
        <div className="max-w-7xl mx-auto flex items-center justify-center gap-2 text-center">
          <span className="inline-block w-2 h-2 rounded-full bg-emerald-400 animate-pulse" />
          <span className="font-bold text-white">🟢 We Are Open – Order Now</span>
          <span className="text-stone-400 text-xs hidden sm:inline">— Fresh kitchen preparations ready for dine-in, takeout & delivery</span>
        </div>
      </div>
    );
  }

  return (
    <div id="announcement-banner" className="bg-stone-900 text-amber-100 text-xs sm:text-sm font-medium py-2 px-3 border-b border-amber-900/40">
      <div className="max-w-7xl mx-auto flex items-center justify-center gap-2 text-center flex-wrap">
        <span className="inline-flex items-center gap-1.5 px-2 py-0.5 rounded-full bg-emerald-950 text-emerald-300 border border-emerald-700/60 text-[11px] font-bold">
          <span className="w-2 h-2 rounded-full bg-emerald-400 animate-pulse" />
          <span>We Are Open – Order Now</span>
        </span>
        <span className="inline-flex items-center gap-1 text-stone-300">
          <Sparkles className="w-3.5 h-3.5 text-amber-400" />
          <span className="line-clamp-1">{activeAnnouncements[0].text}</span>
        </span>
      </div>
    </div>
  );
};
