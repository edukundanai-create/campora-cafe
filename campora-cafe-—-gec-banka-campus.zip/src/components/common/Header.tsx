import React from 'react';
import { useCafe } from '../../context/CafeContext';
import { Coffee, ShoppingBag, Clock, MapPin, ShieldCheck, Utensils, CalendarCheck, Sparkles, Activity, User } from 'lucide-react';

export const Header: React.FC = () => {
  const {
    settings,
    isCafeOpenNow,
    totalCartItemCount,
    cart,
    setIsCartOpen,
    setIsCheckoutOpen,
    setIsLocationModalOpen,
    isAdminMode,
    setIsAdminMode,
    activeOrder,
    setIsOrderTrackerOpen,
    setIsCustomerAccountOpen,
    currentUser,
    currentUserProfile,
    customerOrders,
    customerActiveOrders
  } = useCafe();

  const cartSubtotal = cart.reduce((sum, i) => sum + i.calculatedPrice * i.quantity, 0);

  return (
    <header id="main-header" className="sticky top-0 z-40 bg-[#FAF6F0]/95 backdrop-blur-md border-b border-stone-200/80 transition-all">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex items-center justify-between h-16 sm:h-20 gap-3">
          
          {/* Logo & Cafe Brand */}
          <div className="flex items-center gap-3">
            <button
              onClick={() => {
                if (isAdminMode) setIsAdminMode(false);
                window.scrollTo({ top: 0, behavior: 'smooth' });
              }}
              className="flex items-center gap-2.5 text-left group focus:outline-none"
            >
              <div className="w-10 h-10 sm:w-11 sm:h-11 rounded-xl bg-stone-900 flex items-center justify-center text-amber-400 shadow-md group-hover:scale-105 transition-transform duration-200">
                <Coffee className="w-5 h-5 sm:w-6 sm:h-6" />
              </div>
              <div>
                <span className="font-serif text-lg sm:text-xl font-bold tracking-tight text-stone-900 flex items-center gap-1.5">
                  {settings.name}
                </span>
                <div className="flex items-center gap-2 text-xs font-medium">
                  <span className="flex items-center gap-1.5">
                    <span
                      className={`inline-block w-2.5 h-2.5 rounded-full shrink-0 ${
                        isCafeOpenNow ? 'bg-emerald-500 animate-pulse' : 'bg-rose-500'
                      }`}
                    />
                    <span
                      className={`font-bold text-[11px] sm:text-xs ${
                        isCafeOpenNow ? 'text-emerald-700' : 'text-rose-700'
                      }`}
                    >
                      {isCafeOpenNow ? (
                        <>
                          <span className="hidden sm:inline">We Are Open – Order Now</span>
                          <span className="sm:hidden">Open – Order Now</span>
                        </>
                      ) : (
                        <>
                          <span className="hidden sm:inline">Currently Closed – Ordering is Temporarily Unavailable</span>
                          <span className="sm:hidden">Currently Closed</span>
                        </>
                      )}
                    </span>
                  </span>
                  <span className="text-stone-300 hidden md:inline">•</span>
                  <span className="hidden md:inline-block text-stone-500 truncate max-w-[140px] md:max-w-[200px]">
                    {settings.city}
                  </span>
                </div>
              </div>
            </button>
          </div>

          {/* Center/Right Nav Actions */}
          <div className="flex items-center gap-2 sm:gap-3">
            {/* Location & Hours Button */}
            <button
              id="header-hours-btn"
              onClick={() => setIsLocationModalOpen(true)}
              className="hidden md:flex items-center gap-1.5 px-3 py-2 text-xs font-semibold text-stone-700 hover:text-stone-950 bg-stone-100/80 hover:bg-stone-200/80 rounded-lg transition-colors border border-stone-200/60"
            >
              <MapPin className="w-3.5 h-3.5 text-amber-700" />
              <span>Hours & Location</span>
            </button>

            {/* Active Order Tracker Pill (if customer has active order) */}
            {activeOrder && (
              <button
                id="header-live-order-btn"
                onClick={() => setIsOrderTrackerOpen(true)}
                className={`flex items-center gap-1.5 px-3 py-1.5 text-xs font-semibold rounded-xl border shadow-xs transition-all animate-pulse-subtle ${
                  activeOrder.status === 'ready'
                    ? 'bg-emerald-50 text-emerald-800 border-emerald-300 hover:bg-emerald-100'
                    : activeOrder.status === 'preparing'
                    ? 'bg-sky-50 text-sky-800 border-sky-300 hover:bg-sky-100'
                    : 'bg-amber-50 text-amber-800 border-amber-300 hover:bg-amber-100'
                }`}
                title="View real-time order status"
              >
                <span className="relative flex h-2 w-2">
                  <span className={`animate-ping absolute inline-flex h-full w-full rounded-full opacity-75 ${
                    activeOrder.status === 'ready' ? 'bg-emerald-400' : 'bg-amber-400'
                  }`} />
                  <span className={`relative inline-flex rounded-full h-2 w-2 ${
                    activeOrder.status === 'ready' ? 'bg-emerald-600' : 'bg-amber-600'
                  }`} />
                </span>
                <span className="hidden sm:inline font-bold">
                  {activeOrder.status === 'ready' ? 'Order Ready' : activeOrder.status === 'preparing' ? 'Crafting' : 'Active'}
                </span>
                <span className="font-mono font-bold">#{activeOrder.id}</span>
              </button>
            )}

            {/* Customer Account & Order History Button */}
            <button
              id="header-customer-account-btn"
              onClick={() => setIsCustomerAccountOpen(true)}
              className="flex items-center gap-1.5 px-3 py-2 text-xs font-semibold rounded-xl transition-all border bg-stone-100/90 hover:bg-stone-200/90 text-stone-800 border-stone-200 shadow-xs active:scale-95"
              title="Customer Account & Order History"
            >
              <div className="relative">
                <User className="w-3.5 h-3.5 text-amber-700" />
                {customerActiveOrders.length > 0 ? (
                  <span className="absolute -top-1.5 -right-2 px-1 py-0.2 bg-amber-500 text-stone-950 font-bold text-[9px] rounded-full ring-2 ring-white">
                    {customerActiveOrders.length}
                  </span>
                ) : customerOrders.length > 0 ? (
                  <span className="absolute -top-1 -right-1 w-2 h-2 rounded-full bg-stone-400 ring-2 ring-white" />
                ) : null}
              </div>
              <span className="hidden sm:inline">
                {currentUser ? (currentUserProfile?.displayName?.split(' ')[0] || 'My Account') : 'My Orders'}
              </span>
            </button>

            {/* Table Reservation Button (Desktop CTA) */}
            <button
              id="header-reserve-btn"
              onClick={() => setIsCheckoutOpen(true)}
              className="hidden sm:flex items-center gap-1.5 px-3.5 py-2 text-xs font-semibold text-stone-900 bg-amber-100/90 hover:bg-amber-200/90 border border-amber-300/80 rounded-xl shadow-xs transition-colors"
            >
              <CalendarCheck className="w-3.5 h-3.5 text-amber-800" />
              <span>Book Table</span>
            </button>

            {/* Cart Button */}
            <button
              id="header-cart-btn"
              onClick={() => setIsCartOpen(true)}
              className="relative flex items-center gap-2 px-3 sm:px-3.5 py-2 bg-stone-900 text-stone-50 hover:bg-stone-800 rounded-xl shadow-md transition-all active:scale-95"
              aria-label="View Shopping Cart"
            >
              <div className="relative">
                <ShoppingBag className="w-4 h-4 sm:w-5 sm:h-5 text-amber-300" />
                {totalCartItemCount > 0 && (
                  <span className="absolute -top-2 -right-2 bg-amber-500 text-stone-950 text-[10px] font-extrabold w-4 h-4 rounded-full flex items-center justify-center border-2 border-stone-900">
                    {totalCartItemCount}
                  </span>
                )}
              </div>
              <span className="text-xs sm:text-sm font-semibold tracking-tight">
                {settings.currency}
                {cartSubtotal.toFixed(2)}
              </span>
            </button>

            {/* Admin Management Panel Toggle */}
            <button
              id="header-admin-toggle-btn"
              onClick={() => setIsAdminMode(!isAdminMode)}
              className={`p-2 rounded-xl border transition-all text-xs font-medium flex items-center gap-1.5 ${
                isAdminMode
                  ? 'bg-amber-800 text-amber-100 border-amber-900 shadow-inner'
                  : 'bg-stone-100 text-stone-700 border-stone-200 hover:bg-stone-200'
              }`}
              title={isAdminMode ? 'Exit Admin Dashboard' : 'Open Admin Control Panel'}
            >
              <ShieldCheck className={`w-4 h-4 ${isAdminMode ? 'text-amber-300' : 'text-stone-500'}`} />
              <span className="hidden lg:inline text-xs font-semibold">
                {isAdminMode ? 'Staff Panel' : 'Admin'}
              </span>
            </button>

          </div>
        </div>
      </div>
    </header>
  );
};
