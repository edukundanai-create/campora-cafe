import React from 'react';
import { useCafe } from '../../context/CafeContext';
import { Coffee, MapPin, Phone, Mail, Award, Clock, Heart, ArrowUp } from 'lucide-react';

export const Footer: React.FC = () => {
  const { settings, setIsLocationModalOpen } = useCafe();

  const scrollToTop = () => {
    window.scrollTo({ top: 0, behavior: 'smooth' });
  };

  return (
    <footer id="main-footer" className="bg-stone-900 text-stone-300 pt-12 pb-24 sm:pb-12 border-t border-stone-800">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        
        {/* Top Grid */}
        <div className="grid grid-cols-1 md:grid-cols-4 gap-8 pb-10 border-b border-stone-800">
          
          {/* Col 1: Brand */}
          <div className="space-y-4 md:col-span-1">
            <div className="flex items-center gap-2.5">
              <div className="w-9 h-9 rounded-xl bg-amber-500/20 text-amber-400 flex items-center justify-center border border-amber-500/30">
                <Coffee className="w-5 h-5" />
              </div>
              <span className="font-serif text-xl font-bold text-stone-100 tracking-tight">
                {settings.name}
              </span>
            </div>
            <p className="text-xs text-stone-400 leading-relaxed">
              {settings.tagline}
            </p>
            <div className="flex items-center gap-2 text-xs text-amber-400 font-medium">
              <Award className="w-4 h-4 text-amber-400" />
              <span>Specialty Coffee Guild Member</span>
            </div>
          </div>

          {/* Col 2: Operating Hours */}
          <div className="space-y-3">
            <h4 className="text-xs font-bold uppercase tracking-wider text-stone-100 flex items-center gap-2">
              <Clock className="w-4 h-4 text-amber-400" />
              Operating Hours
            </h4>
            <div className="space-y-1.5 text-xs text-stone-400">
              {settings.operatingHours.map((h) => (
                <div key={h.day} className="flex justify-between items-center py-0.5 border-b border-stone-800/40">
                  <span className="text-stone-300 font-medium">{h.day.slice(0, 3)}</span>
                  <span>{h.isClosed ? 'Closed' : `${h.open} - ${h.close}`}</span>
                </div>
              ))}
            </div>
          </div>

          {/* Col 3: Location & Contact */}
          <div className="space-y-3">
            <h4 className="text-xs font-bold uppercase tracking-wider text-stone-100 flex items-center gap-2">
              <MapPin className="w-4 h-4 text-amber-400" />
              Contact & Location
            </h4>
            <div className="space-y-2 text-xs text-stone-400">
              <p className="text-stone-300 font-medium leading-snug">
                {settings.address}, {settings.city}
              </p>
              <div className="flex items-center gap-2">
                <Phone className="w-3.5 h-3.5 text-amber-400" />
                <a href={`tel:${settings.phone}`} className="hover:text-amber-300 transition-colors">
                  {settings.phone}
                </a>
              </div>
              <div className="flex items-center gap-2">
                <Mail className="w-3.5 h-3.5 text-amber-400" />
                <a href={`mailto:${settings.email}`} className="hover:text-amber-300 transition-colors">
                  {settings.email}
                </a>
              </div>
              <button
                onClick={() => setIsLocationModalOpen(true)}
                className="mt-2 text-xs font-semibold text-amber-400 hover:text-amber-300 underline underline-offset-2"
              >
                View Interactive Map & Directions →
              </button>
            </div>
          </div>

          {/* Col 4: Hygiene & Safety Badges */}
          <div className="space-y-3">
            <h4 className="text-xs font-bold uppercase tracking-wider text-stone-100 flex items-center gap-2">
              <Award className="w-4 h-4 text-amber-400" />
              Hygiene & Safety
            </h4>
            <div className="space-y-2">
              {settings.hygieneCertifications.map((badge, idx) => (
                <div key={idx} className="p-2.5 rounded-lg bg-stone-800/80 border border-stone-700/60 flex items-start gap-2.5">
                  <div className="w-2 h-2 rounded-full bg-emerald-400 mt-1.5 shrink-0" />
                  <div>
                    <p className="text-xs font-bold text-stone-100">{badge.title}</p>
                    <p className="text-[11px] text-stone-400">{badge.badge} • {badge.issuer}</p>
                  </div>
                </div>
              ))}
            </div>
          </div>

        </div>

        {/* Bottom Bar */}
        <div className="pt-6 flex flex-col sm:flex-row items-center justify-between gap-4 text-xs text-stone-500">
          <p>© {new Date().getFullYear()} {settings.name}. Handcrafted with precision.</p>
          <div className="flex items-center gap-4">
            <span className="flex items-center gap-1">
              Freshly Brewed & Served with <Heart className="w-3 h-3 text-rose-500 fill-rose-500" />
            </span>
            <button
              onClick={scrollToTop}
              className="p-2 rounded-lg bg-stone-800 hover:bg-stone-700 text-stone-300 transition-colors flex items-center gap-1"
              title="Scroll to top"
            >
              <ArrowUp className="w-3.5 h-3.5" />
            </button>
          </div>
        </div>

      </div>
    </footer>
  );
};
