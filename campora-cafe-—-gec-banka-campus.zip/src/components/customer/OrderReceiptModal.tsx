import React from 'react';
import { BookingOrder, CafeSettings } from '../../types';
import { X, Printer, Share2, CheckCircle2, Coffee, MapPin, Phone, ShieldCheck, Download } from 'lucide-react';
import { motion, AnimatePresence } from 'motion/react';

interface OrderReceiptModalProps {
  order: BookingOrder | null;
  isOpen: boolean;
  onClose: () => void;
  settings: CafeSettings;
}

export const OrderReceiptModal: React.FC<OrderReceiptModalProps> = ({
  order,
  isOpen,
  onClose,
  settings
}) => {
  if (!isOpen || !order) return null;

  const handlePrint = () => {
    window.print();
  };

  const handleShareWhatsApp = () => {
    const text = `*${settings.name} Official Receipt*\n` +
      `Token: #${order.id}\n` +
      `Date: ${new Date(order.createdAt).toLocaleString()}\n` +
      `Customer: ${order.customer.name} (${order.customer.phone})\n` +
      `Type: ${order.bookingMode.toUpperCase()}\n` +
      `Items: ${order.items.map(i => `${i.quantity}x ${i.name}`).join(', ')}\n` +
      `Total: ${settings.currency}${order.pricing.total.toFixed(2)}\n` +
      `Payment: ${order.paymentStatus === 'paid' ? 'PAID' : 'PAY ON ARRIVAL'} (${order.paymentMethod.toUpperCase()})\n` +
      `Campora Cafe • GEC Banka Campus`;
    window.open(`https://wa.me/?text=${encodeURIComponent(text)}`, '_blank');
  };

  const formattedDate = new Date(order.createdAt).toLocaleDateString('en-IN', {
    day: 'numeric',
    month: 'short',
    year: 'numeric',
    hour: '2-digit',
    minute: '2-digit'
  });

  return (
    <AnimatePresence>
      <div id="receipt-modal-backdrop" className="fixed inset-0 z-50 overflow-y-auto bg-stone-950/80 backdrop-blur-sm flex items-center justify-center p-3 sm:p-4 print:p-0 print:bg-white">
        <motion.div
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          exit={{ opacity: 0 }}
          onClick={onClose}
          className="fixed inset-0 print:hidden"
        />

        <motion.div
          initial={{ opacity: 0, scale: 0.95, y: 20 }}
          animate={{ opacity: 1, scale: 1, y: 0 }}
          exit={{ opacity: 0, scale: 0.95, y: 20 }}
          className="relative z-10 bg-white w-full max-w-md rounded-2xl sm:rounded-3xl shadow-2xl overflow-hidden border border-stone-200 print:border-none print:shadow-none print:w-full print:max-w-none text-stone-900"
        >
          {/* Action Bar (Hidden in Print) */}
          <div className="p-3.5 bg-stone-900 text-stone-100 flex items-center justify-between print:hidden">
            <div className="flex items-center gap-2">
              <Coffee className="w-4 h-4 text-amber-400" />
              <span className="text-xs font-bold tracking-wider uppercase text-stone-300">Dining Receipt</span>
            </div>
            <div className="flex items-center gap-1.5">
              <button
                type="button"
                id="btn-print-receipt"
                onClick={handlePrint}
                className="flex items-center gap-1 text-xs font-semibold px-2.5 py-1.5 rounded-lg bg-stone-800 hover:bg-stone-700 text-stone-200 transition-colors"
                title="Print Receipt"
              >
                <Printer className="w-3.5 h-3.5" />
                <span className="hidden sm:inline">Print</span>
              </button>
              <button
                type="button"
                id="btn-share-receipt"
                onClick={handleShareWhatsApp}
                className="flex items-center gap-1 text-xs font-semibold px-2.5 py-1.5 rounded-lg bg-amber-500 hover:bg-amber-400 text-stone-950 transition-colors"
                title="Share via WhatsApp"
              >
                <Share2 className="w-3.5 h-3.5" />
                <span className="hidden sm:inline">Share</span>
              </button>
              <button
                type="button"
                id="btn-close-receipt"
                onClick={onClose}
                className="p-1 rounded-lg hover:bg-stone-800 text-stone-400 hover:text-stone-200 transition-colors"
              >
                <X className="w-5 h-5" />
              </button>
            </div>
          </div>

          {/* Printable Receipt Body */}
          <div className="p-5 sm:p-6 space-y-4 font-sans text-xs print:p-8">
            {/* Cafe Brand Header */}
            <div className="text-center pb-3 border-b border-dashed border-stone-300 space-y-1">
              <h2 className="font-serif text-xl font-bold text-stone-950 tracking-tight">{settings.name}</h2>
              <p className="text-stone-600 text-xs">Government Engineering College, Banka</p>
              <p className="text-[11px] text-stone-500">{settings.address}</p>
              <div className="inline-flex items-center gap-1 text-[11px] font-medium text-amber-700 bg-amber-50 px-2 py-0.5 rounded border border-amber-200/60 mt-1">
                <span>Campus Food Services & Roastery</span>
              </div>
            </div>

            {/* Order Meta Info */}
            <div className="grid grid-cols-2 gap-2 text-stone-600 text-[11px] pb-3 border-b border-stone-200">
              <div>
                <span className="text-stone-400 block uppercase font-mono text-[10px]">Order Token</span>
                <span className="font-bold text-sm text-stone-900 font-mono">#{order.id}</span>
              </div>
              <div className="text-right">
                <span className="text-stone-400 block uppercase font-mono text-[10px]">Date & Time</span>
                <span className="font-medium text-stone-800">{formattedDate}</span>
              </div>
              <div>
                <span className="text-stone-400 block uppercase font-mono text-[10px]">Customer</span>
                <span className="font-semibold text-stone-800">{order.customer.name}</span>
                <span className="block text-stone-500">{order.customer.phone}</span>
              </div>
              <div className="text-right">
                <span className="text-stone-400 block uppercase font-mono text-[10px]">Mode & Destination</span>
                <span className="font-semibold uppercase text-stone-800">
                  {order.bookingMode === 'dine-in' ? `Dine In • Table ${order.dineInDetails?.tableNumber || 'Auto'}` :
                   order.bookingMode === 'delivery' ? `Campus Delivery` : `Takeout Counter`}
                </span>
                {order.bookingMode === 'delivery' && (
                  <span className="block text-stone-500 truncate max-w-[150px] ml-auto">
                    {order.deliveryDetails?.deliveryAddress || 'Campus Hostel'}
                  </span>
                )}
              </div>
            </div>

            {/* Items Table */}
            <div>
              <div className="flex justify-between text-[11px] font-bold text-stone-400 uppercase tracking-wider pb-1.5 border-b border-stone-200">
                <span>Item Description</span>
                <span>Qty & Price</span>
              </div>
              <div className="divide-y divide-stone-100 py-1 space-y-1">
                {order.items.map((item, idx) => (
                  <div key={idx} className="flex justify-between items-start pt-1.5 text-stone-800">
                    <div className="pr-2">
                      <div className="font-semibold text-stone-900">{item.name}</div>
                      {item.selectedSize && (
                        <div className="text-[10px] text-stone-500">Size: {item.selectedSize.name}</div>
                      )}
                      {item.selectedAddons && item.selectedAddons.length > 0 && (
                        <div className="text-[10px] text-stone-500">
                          + {item.selectedAddons.map(a => a.name).join(', ')}
                        </div>
                      )}
                      {item.specialInstructions && (
                        <div className="text-[10px] text-amber-700 italic">Note: "{item.specialInstructions}"</div>
                      )}
                    </div>
                    <div className="text-right whitespace-nowrap">
                      <span className="text-stone-500 text-[11px]">{item.quantity} × {settings.currency}{item.calculatedPrice.toFixed(2)}</span>
                      <div className="font-bold text-stone-900">
                        {settings.currency}{(item.quantity * item.calculatedPrice).toFixed(2)}
                      </div>
                    </div>
                  </div>
                ))}
              </div>
            </div>

            {/* Pricing Summary */}
            <div className="pt-2 border-t border-dashed border-stone-300 space-y-1 text-stone-700">
              <div className="flex justify-between text-[11px]">
                <span>Items Subtotal:</span>
                <span>{settings.currency}{order.pricing.subtotal.toFixed(2)}</span>
              </div>
              {order.pricing.discountAmount > 0 && (
                <div className="flex justify-between text-[11px] text-emerald-700 font-medium">
                  <span>Student Coupon Discount ({order.pricing.discountCode || 'Promo'}):</span>
                  <span>-{settings.currency}{order.pricing.discountAmount.toFixed(2)}</span>
                </div>
              )}
              <div className="flex justify-between text-[11px]">
                <span>GST Tax ({settings.taxRatePercent}%):</span>
                <span>{settings.currency}{order.pricing.gstTax.toFixed(2)}</span>
              </div>
              {order.pricing.serviceFee > 0 && (
                <div className="flex justify-between text-[11px]">
                  <span>Table Service Fee:</span>
                  <span>{settings.currency}{order.pricing.serviceFee.toFixed(2)}</span>
                </div>
              )}
              {order.pricing.deliveryFee > 0 && (
                <div className="flex justify-between text-[11px]">
                  <span>Campus Delivery Fee:</span>
                  <span>{settings.currency}{order.pricing.deliveryFee.toFixed(2)}</span>
                </div>
              )}
              {order.pricing.tip > 0 && (
                <div className="flex justify-between text-[11px]">
                  <span>Barista Tip:</span>
                  <span>{settings.currency}{order.pricing.tip.toFixed(2)}</span>
                </div>
              )}
              <div className="flex justify-between text-sm font-bold text-stone-950 pt-2 border-t border-stone-300">
                <span>Grand Total:</span>
                <span className="font-mono text-base text-amber-700 font-bold">
                  {settings.currency}{order.pricing.total.toFixed(2)}
                </span>
              </div>
            </div>

            {/* Payment & Verification Footer */}
            <div className="p-3 bg-stone-50 rounded-xl border border-stone-200 text-center space-y-1.5">
              <div className="flex items-center justify-center gap-1 text-[11px] font-bold text-stone-900 uppercase">
                <CheckCircle2 className="w-3.5 h-3.5 text-emerald-600" />
                <span>
                  {order.paymentStatus === 'paid' ? `Payment Successful • ${order.paymentMethod.toUpperCase()}` : `Payment on Arrival (${order.paymentMethod.toUpperCase()})`}
                </span>
              </div>
              <p className="text-[10px] text-stone-500">
                Token #{order.id} • Verified by Campora Cafe Barista Terminal
              </p>
              <p className="text-[10px] text-stone-400 italic">
                Thank you for dining with us! For assistance, contact {settings.phone}
              </p>
            </div>
          </div>
        </motion.div>
      </div>
    </AnimatePresence>
  );
};
