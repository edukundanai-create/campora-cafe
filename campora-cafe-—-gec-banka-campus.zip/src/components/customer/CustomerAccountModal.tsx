import React, { useState, useMemo } from 'react';
import { useCafe } from '../../context/CafeContext';
import { BookingOrder, OrderStatus, UserProfile } from '../../types';
import { OrderReceiptModal } from './OrderReceiptModal';
import { formatBookingTimeElapsed } from '../../utils/session';
import {
  X,
  User,
  ShoppingBag,
  Clock,
  CheckCircle2,
  Calendar,
  Sparkles,
  Award,
  ChevronRight,
  RotateCcw,
  Receipt,
  FileText,
  MapPin,
  Phone,
  Mail,
  Building,
  KeyRound,
  ShieldCheck,
  Search,
  Filter,
  Check,
  Tag,
  Copy,
  ExternalLink,
  AlertCircle,
  HelpCircle,
  Coffee,
  HeartHandshake,
  Ban,
  Star
} from 'lucide-react';
import { motion, AnimatePresence } from 'motion/react';

const CAMPUS_LOCATIONS = [
  'Boys Hostel 1 (BH-1)',
  'Boys Hostel 2 (BH-2)',
  'Girls Hostel (GH)',
  'Computer Science & IT Block',
  'Mechanical & Civil Wing',
  'ECE & Electrical Wing',
  'Central College Library',
  'Administrative Block',
  'Faculty & Staff Quarters'
];

export const CustomerAccountModal: React.FC = () => {
  const {
    isCustomerAccountOpen,
    setIsCustomerAccountOpen,
    currentUser,
    currentUserProfile,
    loginWithEmail,
    signupWithEmail,
    loginDemoStudent,
    signupCustomer,
    resetPassword,
    logout,
    customerOrders,
    customerActiveOrders,
    customerOrderHistory,
    hasMoreOrders,
    isLoadingMoreOrders,
    loadMoreOrders,
    cancelOrder,
    submitOrderFeedback,
    reorderPastOrder,
    updateCustomerProfile,
    setActiveOrder,
    setIsOrderTrackerOpen,
    setIsCartOpen,
    setIsAdminMode,
    settings,
    promoCodes,
    applyPromoCode,
    showToast
  } = useCafe();

  // Active view tab when logged in: 'orders' | 'profile' | 'perks'
  const [activeTab, setActiveTab] = useState<'orders' | 'profile' | 'perks'>('orders');

  // Sub-view inside orders: 'active' (real-time in-progress) | 'history' (permanent fulfilled/cancelled archive)
  const [ordersSubTab, setOrdersSubTab] = useState<'active' | 'history'>('active');

  // Auth view mode when NOT logged in: 'signin' | 'signup' | 'lookup'
  const [authMode, setAuthMode] = useState<'signin' | 'signup' | 'lookup'>('signin');

  // Customer cancellation confirmation dialog state
  const [confirmCancelOrder, setConfirmCancelOrder] = useState<BookingOrder | null>(null);
  const [cancelReasonInput, setCancelReasonInput] = useState('');
  const [isCancelling, setIsCancelling] = useState(false);

  // Customer feedback review modal state
  const [feedbackModalOrder, setFeedbackModalOrder] = useState<BookingOrder | null>(null);
  const [feedbackRating, setFeedbackRating] = useState(5);
  const [feedbackComment, setFeedbackComment] = useState('');
  const [isSubmittingFeedback, setIsSubmittingFeedback] = useState(false);

  // Auth form states
  const [emailInput, setEmailInput] = useState('');
  const [passwordInput, setPasswordInput] = useState('');
  const [nameInput, setNameInput] = useState('');
  const [phoneInput, setPhoneInput] = useState('');
  const [hostelInput, setHostelInput] = useState(CAMPUS_LOCATIONS[0]);
  const [roomInput, setRoomInput] = useState('');
  const [authLoading, setAuthLoading] = useState(false);
  const [authError, setAuthError] = useState('');
  const [isEmailAlreadyRegistered, setIsEmailAlreadyRegistered] = useState(false);
  const [forgotSent, setForgotSent] = useState(false);

  // Guest lookup state (to search orders by phone or token)
  const [lookupQuery, setLookupQuery] = useState('');
  const [lookupFilterPhone, setLookupFilterPhone] = useState('');

  // Orders Filter & Search state for History view
  const [orderSearchQuery, setOrderSearchQuery] = useState('');
  const [statusFilter, setStatusFilter] = useState<'all' | 'active' | 'completed' | 'cancelled'>('all');

  // Receipt Modal state
  const [selectedReceiptOrder, setSelectedReceiptOrder] = useState<BookingOrder | null>(null);

  // Profile edit states
  const [profileName, setProfileName] = useState('');
  const [profilePhone, setProfilePhone] = useState('');
  const [profileHostel, setProfileHostel] = useState(CAMPUS_LOCATIONS[0]);
  const [profileRoom, setProfileRoom] = useState('');
  const [isSavingProfile, setIsSavingProfile] = useState(false);
  const [profileSavedSuccess, setProfileSavedSuccess] = useState(false);

  // Synchronize profile edit state when currentUserProfile changes
  React.useEffect(() => {
    if (currentUserProfile) {
      setProfileName(currentUserProfile.displayName || '');
      setProfilePhone(currentUserProfile.phone || '');
      if (currentUserProfile.departmentOrHostel) {
        setProfileHostel(currentUserProfile.departmentOrHostel);
      }
      if (currentUserProfile.roomNumber) {
        setProfileRoom(currentUserProfile.roomNumber);
      }
    } else if (currentUser) {
      setProfileName(currentUser.displayName || '');
    }
  }, [currentUserProfile, currentUser]);

  // Combined order list: registered orders or matching guest lookup
  const visibleOrders = useMemo(() => {
    let list = [...customerOrders];

    // If guest lookup phone was specified
    if (!currentUser && lookupFilterPhone.trim().length >= 4) {
      const cleanPhone = lookupFilterPhone.replace(/\D/g, '');
      list = list.filter(o => 
        (cleanPhone.length >= 4 && o.customer?.phone?.replace(/\D/g, '').includes(cleanPhone)) || 
        o.id.toLowerCase().includes(lookupFilterPhone.toLowerCase().trim())
      );
    }

    // Status filter
    if (statusFilter === 'active') {
      list = list.filter(o => o.status === 'confirmed' || o.status === 'preparing' || o.status === 'ready');
    } else if (statusFilter === 'completed') {
      list = list.filter(o => o.status === 'completed');
    } else if (statusFilter === 'cancelled') {
      list = list.filter(o => o.status === 'cancelled');
    }

    // Text search query
    if (orderSearchQuery.trim()) {
      const q = orderSearchQuery.toLowerCase().trim();
      list = list.filter(o => 
        o.id.toLowerCase().includes(q) ||
        o.items.some(item => item.name.toLowerCase().includes(q)) ||
        o.bookingMode.toLowerCase().includes(q) ||
        o.customer.name.toLowerCase().includes(q)
      );
    }

    return list;
  }, [customerOrders, currentUser, lookupFilterPhone, statusFilter, orderSearchQuery]);

  // Real-time Active in-progress orders (live confirmed, preparing, ready)
  const activeOrders = useMemo(() => {
    let list = [...customerActiveOrders];
    if (!currentUser && lookupFilterPhone.trim().length >= 4) {
      const cleanPhone = lookupFilterPhone.replace(/\D/g, '');
      list = list.filter(o => 
        (cleanPhone.length >= 4 && o.customer?.phone?.replace(/\D/g, '').includes(cleanPhone)) || 
        o.id.toLowerCase().includes(lookupFilterPhone.toLowerCase().trim())
      );
    }
    return list;
  }, [customerActiveOrders, currentUser, lookupFilterPhone]);

  // Permanent Order History (completed & cancelled)
  const historyOrders = useMemo(() => {
    let list = [...customerOrderHistory];
    if (!currentUser && lookupFilterPhone.trim().length >= 4) {
      const cleanPhone = lookupFilterPhone.replace(/\D/g, '');
      list = list.filter(o => 
        (cleanPhone.length >= 4 && o.customer?.phone?.replace(/\D/g, '').includes(cleanPhone)) || 
        o.id.toLowerCase().includes(lookupFilterPhone.toLowerCase().trim())
      );
    }
    if (statusFilter === 'completed') {
      list = list.filter(o => o.status === 'completed');
    } else if (statusFilter === 'cancelled') {
      list = list.filter(o => o.status === 'cancelled');
    }
    if (orderSearchQuery.trim()) {
      const q = orderSearchQuery.toLowerCase().trim();
      list = list.filter(o => 
        o.id.toLowerCase().includes(q) ||
        o.items.some(item => item.name.toLowerCase().includes(q)) ||
        o.bookingMode.toLowerCase().includes(q) ||
        o.customer.name.toLowerCase().includes(q)
      );
    }
    return list;
  }, [customerOrderHistory, currentUser, lookupFilterPhone, statusFilter, orderSearchQuery]);

  // Handle Order Cancellation by customer
  const handleConfirmCancel = async () => {
    if (!confirmCancelOrder) return;
    setIsCancelling(true);
    try {
      await cancelOrder(
        confirmCancelOrder.id,
        cancelReasonInput.trim() || 'Cancelled by customer within 10-minute grace window'
      );
      setConfirmCancelOrder(null);
      setCancelReasonInput('');
    } catch (err: any) {
      showToast?.('error', err.message || 'Failed to cancel order.');
    } finally {
      setIsCancelling(false);
    }
  };

  // Handle Review Submission
  const handleSubmitFeedback = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!feedbackModalOrder) return;
    setIsSubmittingFeedback(true);
    try {
      await submitOrderFeedback(feedbackModalOrder.id, feedbackRating, feedbackComment.trim());
      setFeedbackModalOrder(null);
      setFeedbackComment('');
      setFeedbackRating(5);
    } catch (err: any) {
      showToast?.('error', err.message || 'Failed to submit review.');
    } finally {
      setIsSubmittingFeedback(false);
    }
  };

  if (!isCustomerAccountOpen) return null;

  // Handle Sign In
  const handleSignIn = async (e: React.FormEvent) => {
    e.preventDefault();
    setAuthError('');
    setAuthLoading(true);
    try {
      await loginWithEmail(emailInput.trim(), passwordInput);
      setAuthLoading(false);
      setEmailInput('');
      setPasswordInput('');
    } catch (err: any) {
      setAuthLoading(false);
      setAuthError(err.message || 'Failed to sign in. Please verify your email and password.');
    }
  };

  // Handle Customer Registration
  const handleSignUp = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!nameInput.trim() || !emailInput.trim() || !passwordInput.trim() || !phoneInput.trim()) {
      setAuthError('Please fill in all required fields.');
      return;
    }
    if (passwordInput.length < 6) {
      setAuthError('Password must be at least 6 characters.');
      return;
    }

    setAuthError('');
    setIsEmailAlreadyRegistered(false);
    setAuthLoading(true);
    try {
      await signupCustomer(
        nameInput.trim(),
        emailInput.trim(),
        passwordInput,
        phoneInput.trim(),
        `${hostelInput}${roomInput ? `, Room ${roomInput.trim()}` : ''}`
      );
      setAuthLoading(false);
      setNameInput('');
      setEmailInput('');
      setPasswordInput('');
      setPhoneInput('');
      setRoomInput('');
      setIsEmailAlreadyRegistered(false);
    } catch (err: any) {
      setAuthLoading(false);
      const isEmailInUse =
        err.code === 'auth/email-already-in-use' ||
        err.message?.includes('already exists') ||
        err.message?.includes('already registered') ||
        err.message?.includes('email-already-in-use');

      if (isEmailInUse) {
        setIsEmailAlreadyRegistered(true);
        setAuthError(
          `An account with ${emailInput.trim()} already exists. You can sign in below or reset your password.`
        );
      } else {
        setIsEmailAlreadyRegistered(false);
        setAuthError(err.message || 'Registration could not be completed.');
      }
    }
  };

  // Quick Demo Student Login for seamless evaluation
  const handleQuickDemoStudentLogin = async () => {
    setAuthLoading(true);
    setAuthError('');
    setIsEmailAlreadyRegistered(false);
    try {
      await loginDemoStudent();
      setAuthLoading(false);
    } catch (err: any) {
      setAuthLoading(false);
      setAuthError(err.message || 'Could not start demo student session.');
    }
  };

  // Handle Forgot Password
  const handleForgotPassword = async () => {
    if (!emailInput.trim()) {
      setAuthError('Please enter your email address above to reset password.');
      return;
    }
    try {
      await resetPassword(emailInput.trim());
      setForgotSent(true);
      setAuthError('');
      setTimeout(() => setForgotSent(false), 5000);
    } catch (err: any) {
      setAuthError(err.message || 'Could not send password reset email.');
    }
  };

  // Save Profile Changes
  const handleSaveProfile = async (e: React.FormEvent) => {
    e.preventDefault();
    setIsSavingProfile(true);
    try {
      await updateCustomerProfile({
        displayName: profileName.trim(),
        phone: profilePhone.trim(),
        departmentOrHostel: profileHostel,
        roomNumber: profileRoom.trim(),
        savedDeliveryAddress: `${profileHostel}${profileRoom ? `, Room ${profileRoom.trim()}` : ''}`
      });
      setIsSavingProfile(false);
      setProfileSavedSuccess(true);
      setTimeout(() => setProfileSavedSuccess(false), 3500);
    } catch (err: any) {
      setIsSavingProfile(false);
      showToast('Error', err.message || 'Failed to save profile', 'error');
    }
  };

  // Order status badge styling
  const getStatusBadge = (status: OrderStatus) => {
    switch (status) {
      case 'confirmed':
        return (
          <span className="inline-flex items-center gap-1 text-[11px] font-bold px-2.5 py-1 rounded-full bg-blue-900/30 text-blue-400 border border-blue-500/30">
            <Check className="w-3 h-3" /> Confirmed
          </span>
        );
      case 'preparing':
        return (
          <span className="inline-flex items-center gap-1 text-[11px] font-bold px-2.5 py-1 rounded-full bg-amber-900/30 text-amber-400 border border-amber-500/30 animate-pulse">
            <Coffee className="w-3 h-3" /> Preparing Order
          </span>
        );
      case 'ready':
        return (
          <span className="inline-flex items-center gap-1 text-[11px] font-bold px-2.5 py-1 rounded-full bg-emerald-900/30 text-emerald-400 border border-emerald-500/30 animate-bounce">
            <CheckCircle2 className="w-3 h-3" /> Ready for Pickup
          </span>
        );
      case 'completed':
        return (
          <span className="inline-flex items-center gap-1 text-[11px] font-bold px-2.5 py-1 rounded-full bg-stone-800 text-stone-300 border border-stone-700">
            <CheckCircle2 className="w-3 h-3 text-emerald-500" /> Completed
          </span>
        );
      case 'cancelled':
        return (
          <span className="inline-flex items-center gap-1 text-[11px] font-bold px-2.5 py-1 rounded-full bg-rose-900/30 text-rose-400 border border-rose-500/30">
            <X className="w-3 h-3" /> Cancelled
          </span>
        );
    }
  };

  return (
    <>
      <AnimatePresence>
        <div id="customer-account-modal" className="fixed inset-0 z-50 overflow-y-auto bg-stone-950/85 backdrop-blur-md flex items-end sm:items-center justify-center p-0 sm:p-4">
          {/* Backdrop */}
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            onClick={() => setIsCustomerAccountOpen(false)}
            className="fixed inset-0"
          />

          {/* Modal Container */}
          <motion.div
            initial={{ opacity: 0, y: 40, scale: 0.96 }}
            animate={{ opacity: 1, y: 0, scale: 1 }}
            exit={{ opacity: 0, y: 40, scale: 0.96 }}
            className="relative z-10 bg-stone-900 w-full sm:max-w-3xl max-h-[92vh] sm:max-h-[88vh] rounded-t-3xl sm:rounded-3xl shadow-2xl flex flex-col overflow-hidden border border-stone-800 text-stone-100"
          >
            {/* Modal Header */}
            <div className="p-4 sm:p-5 border-b border-stone-800/80 bg-stone-900/90 backdrop-blur flex items-center justify-between">
              <div className="flex items-center gap-3">
                <div className="w-10 h-10 rounded-2xl bg-amber-500/15 border border-amber-500/30 flex items-center justify-center text-amber-400">
                  <User className="w-5 h-5" />
                </div>
                <div>
                  <h3 className="font-serif text-lg font-bold text-stone-100 flex items-center gap-2">
                    Customer Account & Orders
                    {currentUser && (
                      <span className="text-[11px] font-sans font-medium px-2 py-0.5 rounded-full bg-amber-500/20 text-amber-300 border border-amber-500/30">
                        {currentUserProfile?.loyaltyPoints || 0} Pts
                      </span>
                    )}
                  </h3>
                  <p className="text-xs text-stone-400">
                    Campora Cafe & Roastery • Government Engineering College, Banka
                  </p>
                </div>
              </div>

              <div className="flex items-center gap-2">
                {currentUser && (currentUserProfile?.role === 'admin' || currentUserProfile?.role === 'staff') && (
                  <button
                    type="button"
                    onClick={() => {
                      setIsCustomerAccountOpen(false);
                      setIsAdminMode(true);
                    }}
                    className="hidden sm:inline-flex items-center gap-1.5 text-xs font-semibold px-3 py-1.5 rounded-xl bg-stone-800 hover:bg-stone-700 text-amber-400 border border-stone-700 transition-colors"
                  >
                    <ShieldCheck className="w-3.5 h-3.5" />
                    <span>Admin Portal</span>
                  </button>
                )}

                <button
                  type="button"
                  id="btn-close-customer-account"
                  onClick={() => setIsCustomerAccountOpen(false)}
                  className="p-2 rounded-xl hover:bg-stone-800 text-stone-400 hover:text-stone-200 transition-colors"
                >
                  <X className="w-5 h-5" />
                </button>
              </div>
            </div>

            {/* If NOT Signed In: Auth Tabs */}
            {!currentUser ? (
              <div className="flex-1 overflow-y-auto p-5 sm:p-8 space-y-6">
                {/* Auth Mode Toggle */}
                <div className="grid grid-cols-3 gap-1.5 p-1 bg-stone-950/60 rounded-2xl border border-stone-800">
                  <button
                    type="button"
                    id="tab-auth-signin"
                    onClick={() => { setAuthMode('signin'); setAuthError(''); }}
                    className={`py-2 px-3 rounded-xl text-xs font-bold transition-all ${
                      authMode === 'signin'
                        ? 'bg-amber-500 text-stone-950 shadow-md font-bold'
                        : 'text-stone-400 hover:text-stone-200'
                    }`}
                  >
                    Sign In
                  </button>
                  <button
                    type="button"
                    id="tab-auth-signup"
                    onClick={() => { setAuthMode('signup'); setAuthError(''); }}
                    className={`py-2 px-3 rounded-xl text-xs font-bold transition-all ${
                      authMode === 'signup'
                        ? 'bg-amber-500 text-stone-950 shadow-md font-bold'
                        : 'text-stone-400 hover:text-stone-200'
                    }`}
                  >
                    Create Account
                  </button>
                  <button
                    type="button"
                    id="tab-auth-lookup"
                    onClick={() => { setAuthMode('lookup'); setAuthError(''); }}
                    className={`py-2 px-3 rounded-xl text-xs font-bold transition-all ${
                      authMode === 'lookup'
                        ? 'bg-amber-500 text-stone-950 shadow-md font-bold'
                        : 'text-stone-400 hover:text-stone-200'
                    }`}
                  >
                    Track Orders
                  </button>
                </div>

                {/* Quick 1-Click Demo Sign-In Banner */}
                {authMode !== 'lookup' && (
                  <div className="p-3.5 rounded-2xl bg-amber-500/10 border border-amber-500/30 flex items-center justify-between gap-3">
                    <div className="flex items-center gap-2.5">
                      <Sparkles className="w-5 h-5 text-amber-400 shrink-0" />
                      <div>
                        <div className="text-xs font-bold text-amber-300">Quick Testing & Instant Access</div>
                        <div className="text-[11px] text-stone-400">Explore customer order history & loyalty points in 1 click</div>
                      </div>
                    </div>
                    <button
                      type="button"
                      id="btn-demo-student-login"
                      onClick={handleQuickDemoStudentLogin}
                      disabled={authLoading}
                      className="px-3 py-1.5 rounded-xl bg-amber-500 hover:bg-amber-400 text-stone-950 text-xs font-bold shrink-0 transition-transform active:scale-95 disabled:opacity-50"
                    >
                      {authLoading ? 'Signing in...' : '1-Click Student Demo'}
                    </button>
                  </div>
                )}

                {/* Existing Account Smart Recovery Banner */}
                {isEmailAlreadyRegistered && (
                  <div className="p-3.5 rounded-2xl bg-amber-500/15 border border-amber-500/40 text-amber-200 text-xs flex flex-col sm:flex-row items-start sm:items-center justify-between gap-3">
                    <div className="flex items-center gap-2">
                      <AlertCircle className="w-4 h-4 shrink-0 text-amber-400" />
                      <span>
                        An account with <strong>{emailInput || 'this email'}</strong> already exists.
                      </span>
                    </div>
                    <div className="flex items-center gap-2 shrink-0 w-full sm:w-auto">
                      <button
                        type="button"
                        id="btn-switch-to-signin"
                        onClick={() => {
                          setAuthMode('signin');
                          setAuthError('');
                          setIsEmailAlreadyRegistered(false);
                        }}
                        className="flex-1 sm:flex-none px-3.5 py-1.5 rounded-xl bg-amber-500 hover:bg-amber-400 text-stone-950 font-bold text-xs transition-colors shadow-sm"
                      >
                        Sign In Now
                      </button>
                      <button
                        type="button"
                        onClick={handleForgotPassword}
                        className="px-3 py-1.5 rounded-xl bg-stone-800 hover:bg-stone-700 text-amber-300 text-xs transition-colors border border-stone-700"
                      >
                        Reset Password
                      </button>
                    </div>
                  </div>
                )}

                {/* Error Banner */}
                {authError && !isEmailAlreadyRegistered && (
                  <div className="p-3 rounded-xl bg-rose-950/40 border border-rose-800 text-rose-300 text-xs flex items-center gap-2">
                    <AlertCircle className="w-4 h-4 shrink-0 text-rose-400" />
                    <span>{authError}</span>
                  </div>
                )}

                {/* Forgot Password Notification */}
                {forgotSent && (
                  <div className="p-3 rounded-xl bg-emerald-950/40 border border-emerald-800 text-emerald-300 text-xs flex items-center gap-2">
                    <CheckCircle2 className="w-4 h-4 shrink-0 text-emerald-400" />
                    <span>Password reset email has been sent! Please check your inbox.</span>
                  </div>
                )}

                {/* 1. Sign In Form */}
                {authMode === 'signin' && (
                  <form onSubmit={handleSignIn} className="space-y-4 max-w-md mx-auto pt-2">
                    <div className="space-y-1.5">
                      <label className="text-xs font-medium text-stone-300">College Email or Email Address</label>
                      <div className="relative">
                        <Mail className="w-4 h-4 text-stone-500 absolute left-3.5 top-1/2 -translate-y-1/2" />
                        <input
                          type="email"
                          id="input-signin-email"
                          required
                          value={emailInput}
                          onChange={(e) => setEmailInput(e.target.value)}
                          placeholder="e.g. aman.kumar@gecbanka.ac.in"
                          className="w-full bg-stone-950/70 border border-stone-800 focus:border-amber-500 rounded-xl pl-10 pr-4 py-2.5 text-sm text-stone-100 placeholder-stone-600 outline-none transition-colors"
                        />
                      </div>
                    </div>

                    <div className="space-y-1.5">
                      <div className="flex justify-between items-center">
                        <label className="text-xs font-medium text-stone-300">Password</label>
                        <button
                          type="button"
                          onClick={handleForgotPassword}
                          className="text-[11px] text-amber-400 hover:text-amber-300 transition-colors"
                        >
                          Forgot password?
                        </button>
                      </div>
                      <div className="relative">
                        <KeyRound className="w-4 h-4 text-stone-500 absolute left-3.5 top-1/2 -translate-y-1/2" />
                        <input
                          type="password"
                          id="input-signin-password"
                          required
                          value={passwordInput}
                          onChange={(e) => setPasswordInput(e.target.value)}
                          placeholder="••••••••"
                          className="w-full bg-stone-950/70 border border-stone-800 focus:border-amber-500 rounded-xl pl-10 pr-4 py-2.5 text-sm text-stone-100 placeholder-stone-600 outline-none transition-colors"
                        />
                      </div>
                    </div>

                    <button
                      type="submit"
                      id="btn-submit-signin"
                      disabled={authLoading}
                      className="w-full py-3 rounded-xl bg-amber-500 hover:bg-amber-400 text-stone-950 text-sm font-bold shadow-lg shadow-amber-500/10 transition-all active:scale-[0.99] disabled:opacity-50 mt-2"
                    >
                      {authLoading ? 'Authenticating...' : 'Sign In to My Account'}
                    </button>

                    <div className="text-center pt-2">
                      <p className="text-xs text-stone-500">
                        New patron at Campora Cafe?{' '}
                        <button
                          type="button"
                          onClick={() => { setAuthMode('signup'); setAuthError(''); }}
                          className="text-amber-400 font-semibold hover:underline"
                        >
                          Create an account (+100 Bonus Points)
                        </button>
                      </p>
                    </div>
                  </form>
                )}

                {/* 2. Customer Registration Form */}
                {authMode === 'signup' && (
                  <form onSubmit={handleSignUp} className="space-y-4 max-w-md mx-auto">
                    <div className="space-y-1.5">
                      <label className="text-xs font-medium text-stone-300">Full Name *</label>
                      <div className="relative">
                        <User className="w-4 h-4 text-stone-500 absolute left-3.5 top-1/2 -translate-y-1/2" />
                        <input
                          type="text"
                          id="input-signup-name"
                          required
                          value={nameInput}
                          onChange={(e) => setNameInput(e.target.value)}
                          placeholder="e.g. Priya Sharma"
                          className="w-full bg-stone-950/70 border border-stone-800 focus:border-amber-500 rounded-xl pl-10 pr-4 py-2.5 text-sm text-stone-100 placeholder-stone-600 outline-none transition-colors"
                        />
                      </div>
                    </div>

                    <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                      <div className="space-y-1.5">
                        <label className="text-xs font-medium text-stone-300">WhatsApp Phone *</label>
                        <div className="relative">
                          <Phone className="w-4 h-4 text-stone-500 absolute left-3.5 top-1/2 -translate-y-1/2" />
                          <input
                            type="tel"
                            id="input-signup-phone"
                            required
                            value={phoneInput}
                            onChange={(e) => setPhoneInput(e.target.value)}
                            placeholder="+91 98765 43210"
                            className="w-full bg-stone-950/70 border border-stone-800 focus:border-amber-500 rounded-xl pl-10 pr-4 py-2.5 text-sm text-stone-100 placeholder-stone-600 outline-none transition-colors"
                          />
                        </div>
                      </div>

                      <div className="space-y-1.5">
                        <label className="text-xs font-medium text-stone-300">College or Personal Email *</label>
                        <div className="relative">
                          <Mail className="w-4 h-4 text-stone-500 absolute left-3.5 top-1/2 -translate-y-1/2" />
                          <input
                            type="email"
                            id="input-signup-email"
                            required
                            value={emailInput}
                            onChange={(e) => setEmailInput(e.target.value)}
                            placeholder="priya@gecbanka.ac.in"
                            className="w-full bg-stone-950/70 border border-stone-800 focus:border-amber-500 rounded-xl pl-10 pr-4 py-2.5 text-sm text-stone-100 placeholder-stone-600 outline-none transition-colors"
                          />
                        </div>
                      </div>
                    </div>

                    <div className="space-y-1.5">
                      <label className="text-xs font-medium text-stone-300">Create Password *</label>
                      <div className="relative">
                        <KeyRound className="w-4 h-4 text-stone-500 absolute left-3.5 top-1/2 -translate-y-1/2" />
                        <input
                          type="password"
                          id="input-signup-password"
                          required
                          value={passwordInput}
                          onChange={(e) => setPasswordInput(e.target.value)}
                          placeholder="At least 6 characters"
                          className="w-full bg-stone-950/70 border border-stone-800 focus:border-amber-500 rounded-xl pl-10 pr-4 py-2.5 text-sm text-stone-100 placeholder-stone-600 outline-none transition-colors"
                        />
                      </div>
                    </div>

                    <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                      <div className="space-y-1.5">
                        <label className="text-xs font-medium text-stone-300">Hostel / Campus Wing</label>
                        <select
                          id="input-signup-hostel"
                          value={hostelInput}
                          onChange={(e) => setHostelInput(e.target.value)}
                          className="w-full bg-stone-950/70 border border-stone-800 focus:border-amber-500 rounded-xl px-3 py-2.5 text-xs text-stone-200 outline-none"
                        >
                          {CAMPUS_LOCATIONS.map((loc) => (
                            <option key={loc} value={loc} className="bg-stone-900 text-stone-100">
                              {loc}
                            </option>
                          ))}
                        </select>
                      </div>

                      <div className="space-y-1.5">
                        <label className="text-xs font-medium text-stone-300">Room / Desk No.</label>
                        <input
                          type="text"
                          id="input-signup-room"
                          value={roomInput}
                          onChange={(e) => setRoomInput(e.target.value)}
                          placeholder="e.g. 204 or Lab 3"
                          className="w-full bg-stone-950/70 border border-stone-800 focus:border-amber-500 rounded-xl px-3.5 py-2.5 text-xs text-stone-100 placeholder-stone-600 outline-none"
                        />
                      </div>
                    </div>

                    <button
                      type="submit"
                      id="btn-submit-signup"
                      disabled={authLoading}
                      className="w-full py-3 rounded-xl bg-amber-500 hover:bg-amber-400 text-stone-950 text-sm font-bold shadow-lg shadow-amber-500/10 transition-all active:scale-[0.99] disabled:opacity-50 mt-3"
                    >
                      {authLoading ? 'Creating Account...' : 'Register & Claim 100 Loyalty Points'}
                    </button>

                    <div className="text-center pt-2">
                      <p className="text-xs text-stone-500">
                        Already have an account?{' '}
                        <button
                          type="button"
                          onClick={() => { setAuthMode('signin'); setAuthError(''); }}
                          className="text-amber-400 font-semibold hover:underline"
                        >
                          Sign In here
                        </button>
                      </p>
                    </div>
                  </form>
                )}

                {/* 3. Quick Guest Order Lookup */}
                {authMode === 'lookup' && (
                  <div className="space-y-5 max-w-lg mx-auto">
                    <div className="p-4 rounded-2xl bg-stone-950/60 border border-stone-800 space-y-3">
                      <div className="flex items-center gap-2 text-amber-400">
                        <Search className="w-4 h-4" />
                        <h4 className="text-xs font-bold uppercase tracking-wider text-stone-300">
                          Find Guest Orders by Phone Number or Token
                        </h4>
                      </div>
                      <p className="text-xs text-stone-400">
                        Placed an order without an account? Enter your phone number or Order Token (e.g. <span className="font-mono text-amber-300">#BK-9421</span>) to view order status and history.
                      </p>
                      <div className="flex gap-2">
                        <input
                          type="text"
                          id="input-guest-lookup"
                          value={lookupQuery}
                          onChange={(e) => setLookupQuery(e.target.value)}
                          placeholder="e.g. 9876543210 or BK-8910"
                          className="flex-1 bg-stone-900 border border-stone-700 rounded-xl px-3.5 py-2.5 text-xs text-stone-100 placeholder-stone-500 outline-none focus:border-amber-500"
                        />
                        <button
                          type="button"
                          id="btn-guest-lookup"
                          onClick={() => setLookupFilterPhone(lookupQuery.trim())}
                          className="px-4 py-2.5 rounded-xl bg-amber-500 hover:bg-amber-400 text-stone-950 font-bold text-xs shrink-0 transition-colors"
                        >
                          Find
                        </button>
                      </div>
                    </div>

                    {/* Orders found under device or lookup */}
                    <div className="space-y-3">
                      <div className="flex justify-between items-center text-xs text-stone-400">
                        <span>Orders on this device / matching search ({visibleOrders.length})</span>
                        {lookupFilterPhone && (
                          <button
                            type="button"
                            onClick={() => { setLookupFilterPhone(''); setLookupQuery(''); }}
                            className="text-amber-400 hover:underline text-[11px]"
                          >
                            Reset filter
                          </button>
                        )}
                      </div>

                      {visibleOrders.length === 0 ? (
                        <div className="p-8 text-center bg-stone-950/40 rounded-2xl border border-stone-800/80 space-y-2">
                          <Coffee className="w-8 h-8 text-stone-600 mx-auto" />
                          <p className="text-xs text-stone-400">No matching orders found.</p>
                          <button
                            type="button"
                            onClick={() => {
                              setIsCustomerAccountOpen(false);
                              setIsCartOpen(true);
                            }}
                            className="text-xs text-amber-400 font-semibold hover:underline"
                          >
                            Browse cafe menu & order now
                          </button>
                        </div>
                      ) : (
                        <div className="space-y-3 max-h-72 overflow-y-auto pr-1">
                          {visibleOrders.map((order) => (
                            <div
                              key={order.id}
                              className="p-3.5 rounded-2xl bg-stone-950/60 border border-stone-800 space-y-2 hover:border-stone-700 transition-colors"
                            >
                              <div className="flex justify-between items-start">
                                <div>
                                  <span className="font-mono text-xs font-bold text-amber-400">#{order.id}</span>
                                  <span className="text-[11px] text-stone-400 ml-2">
                                    {new Date(order.createdAt).toLocaleDateString()}
                                  </span>
                                </div>
                                {getStatusBadge(order.status)}
                              </div>
                              <p className="text-xs text-stone-300 font-medium truncate">
                                {order.items.map(i => `${i.quantity}x ${i.name}`).join(', ')}
                              </p>
                              <div className="flex justify-between items-center pt-2 border-t border-stone-800/60 text-xs">
                                <span className="font-bold text-stone-100">
                                  {settings.currency}{order.pricing.total.toFixed(2)}
                                </span>
                                <div className="flex gap-2">
                                  <button
                                    type="button"
                                    onClick={() => setSelectedReceiptOrder(order)}
                                    className="px-2.5 py-1 rounded-lg bg-stone-800 hover:bg-stone-700 text-stone-300 text-[11px] font-medium"
                                  >
                                    Receipt
                                  </button>
                                  <button
                                    type="button"
                                    onClick={() => {
                                      setActiveOrder(order);
                                      setIsOrderTrackerOpen(true);
                                      setIsCustomerAccountOpen(false);
                                    }}
                                    className="px-2.5 py-1 rounded-lg bg-amber-500 hover:bg-amber-400 text-stone-950 text-[11px] font-bold"
                                  >
                                    Track Live
                                  </button>
                                </div>
                              </div>
                            </div>
                          ))}
                        </div>
                      )}
                    </div>
                  </div>
                )}
              </div>
            ) : (
              /* If SIGNED IN: Profile Header + Navigation Tabs */
              <div className="flex-1 flex flex-col overflow-hidden">
                {/* User Info Strip */}
                <div className="p-4 sm:p-5 bg-stone-950/40 border-b border-stone-800 flex flex-col sm:flex-row sm:items-center justify-between gap-3">
                  <div className="flex items-center gap-3">
                    <div className="w-12 h-12 rounded-2xl bg-gradient-to-br from-amber-500 to-amber-700 text-stone-950 flex items-center justify-center font-bold text-lg shadow-md shrink-0">
                      {(currentUserProfile?.displayName || currentUser.displayName || currentUser.email || 'U')[0].toUpperCase()}
                    </div>
                    <div>
                      <div className="flex items-center gap-2">
                        <h4 className="font-serif font-bold text-stone-100 text-base">
                          {currentUserProfile?.displayName || currentUser.displayName || 'Campus Patron'}
                        </h4>
                        <span className="text-[10px] uppercase font-bold tracking-wider px-2 py-0.5 rounded-md bg-stone-800 text-amber-400 border border-stone-700">
                          {currentUserProfile?.role === 'admin' ? 'Administrator' : currentUserProfile?.role === 'staff' ? 'Staff' : 'Student Member'}
                        </span>
                      </div>
                      <p className="text-xs text-stone-400 flex items-center gap-2 mt-0.5">
                        <span>{currentUser.email}</span>
                        {currentUserProfile?.phone && (
                          <>
                            <span>•</span>
                            <span>{currentUserProfile.phone}</span>
                          </>
                        )}
                      </p>
                    </div>
                  </div>

                  <div className="flex items-center gap-2.5 self-end sm:self-center">
                    <div className="px-3 py-1.5 rounded-xl bg-amber-500/15 border border-amber-500/30 text-right">
                      <div className="text-[10px] text-amber-300 uppercase tracking-wider font-semibold">Loyalty Balance</div>
                      <div className="text-sm font-bold text-amber-400 font-mono">
                        ⭐ {currentUserProfile?.loyaltyPoints || 0} Pts
                      </div>
                    </div>

                    <button
                      type="button"
                      id="btn-customer-logout"
                      onClick={() => logout()}
                      className="px-3 py-2 rounded-xl bg-stone-800 hover:bg-stone-700 text-stone-300 hover:text-stone-100 text-xs font-semibold transition-colors"
                      title="Sign Out"
                    >
                      Sign Out
                    </button>
                  </div>
                </div>

                {/* Sub-navigation Tabs */}
                <div className="px-4 sm:px-6 pt-3 border-b border-stone-800 flex gap-4 text-xs font-bold text-stone-400">
                  <button
                    type="button"
                    id="tab-customer-orders"
                    onClick={() => setActiveTab('orders')}
                    className={`pb-3 flex items-center gap-1.5 border-b-2 transition-colors cursor-pointer ${
                      activeTab === 'orders'
                        ? 'border-amber-500 text-amber-400'
                        : 'border-transparent hover:text-stone-200'
                    }`}
                  >
                    <ShoppingBag className="w-4 h-4" />
                    <span>Order History</span>
                    <span className="ml-1 px-1.5 py-0.2 rounded-full bg-stone-800 text-[10px] text-stone-300">
                      {customerOrders.length}
                    </span>
                  </button>

                  <button
                    type="button"
                    id="tab-customer-profile"
                    onClick={() => setActiveTab('profile')}
                    className={`pb-3 flex items-center gap-1.5 border-b-2 transition-colors cursor-pointer ${
                      activeTab === 'profile'
                        ? 'border-amber-500 text-amber-400'
                        : 'border-transparent hover:text-stone-200'
                    }`}
                  >
                    <Building className="w-4 h-4" />
                    <span>Campus Profile & Address</span>
                  </button>

                  <button
                    type="button"
                    id="tab-customer-perks"
                    onClick={() => setActiveTab('perks')}
                    className={`pb-3 flex items-center gap-1.5 border-b-2 transition-colors cursor-pointer ${
                      activeTab === 'perks'
                        ? 'border-amber-500 text-amber-400'
                        : 'border-transparent hover:text-stone-200'
                    }`}
                  >
                    <Award className="w-4 h-4" />
                    <span>Loyalty & Coupons</span>
                  </button>
                </div>

                {/* Tab 1: Real-time Active Orders & Permanent History */}
                {activeTab === 'orders' && (
                  <div className="flex-1 overflow-y-auto p-4 sm:p-6 space-y-4">
                    {/* Active vs History Sub-Navigation Bar */}
                    <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 pb-3 border-b border-stone-800">
                      <div className="flex p-1 bg-stone-950/70 border border-stone-800 rounded-2xl gap-1">
                        <button
                          type="button"
                          id="btn-customer-subtab-active"
                          onClick={() => setOrdersSubTab('active')}
                          className={`px-3.5 py-1.5 rounded-xl text-xs font-bold transition-all flex items-center gap-1.5 ${
                            ordersSubTab === 'active'
                              ? 'bg-amber-500 text-stone-950 shadow-sm'
                              : 'text-stone-400 hover:text-stone-200'
                          }`}
                        >
                          <Clock className={`w-3.5 h-3.5 ${activeOrders.length > 0 ? 'text-stone-950 animate-spin' : ''}`} />
                          <span>Active Orders</span>
                          <span className={`px-1.5 py-0.2 rounded-full text-[10px] font-bold ${
                            ordersSubTab === 'active'
                              ? 'bg-stone-950/20 text-stone-950'
                              : activeOrders.length > 0 ? 'bg-amber-500/20 text-amber-300' : 'bg-stone-800 text-stone-400'
                          }`}>
                            {activeOrders.length}
                          </span>
                        </button>

                        <button
                          type="button"
                          id="btn-customer-subtab-history"
                          onClick={() => setOrdersSubTab('history')}
                          className={`px-3.5 py-1.5 rounded-xl text-xs font-bold transition-all flex items-center gap-1.5 ${
                            ordersSubTab === 'history'
                              ? 'bg-amber-500 text-stone-950 shadow-sm'
                              : 'text-stone-400 hover:text-stone-200'
                          }`}
                        >
                          <ShoppingBag className="w-3.5 h-3.5" />
                          <span>Order History</span>
                          <span className={`px-1.5 py-0.2 rounded-full text-[10px] font-bold ${
                            ordersSubTab === 'history'
                              ? 'bg-stone-950/20 text-stone-950'
                              : 'bg-stone-800 text-stone-400'
                          }`}>
                            {customerOrderHistory.length}
                          </span>
                        </button>
                      </div>

                      {ordersSubTab === 'active' ? (
                        <div className="flex items-center gap-1.5 text-xs text-stone-400">
                          <span className="w-2 h-2 rounded-full bg-emerald-500 animate-pulse" />
                          <span>Live updates: Confirmed, In Prep, Ready for Pickup</span>
                        </div>
                      ) : (
                        <div className="text-xs text-stone-400">
                          Permanent archive of all fulfilled & cancelled orders
                        </div>
                      )}
                    </div>

                    {/* SUB-VIEW 1: Real-time Active In-Progress Orders */}
                    {ordersSubTab === 'active' && (
                      <div className="space-y-3.5">
                        {activeOrders.length === 0 ? (
                          <div className="p-10 text-center bg-stone-950/40 rounded-3xl border border-stone-800/80 space-y-3 my-2">
                            <Coffee className="w-10 h-10 text-amber-500/40 mx-auto" />
                            <h4 className="font-serif font-bold text-stone-300 text-base">No active orders right now</h4>
                            <p className="text-xs text-stone-500 max-w-sm mx-auto">
                              Your kitchen queue is clear! Order freshly brewed coffees, frappes, or warm campus snacks and track their preparation live.
                            </p>
                            <button
                              type="button"
                              id="btn-active-empty-browse"
                              onClick={() => {
                                setIsCustomerAccountOpen(false);
                                setIsCartOpen(false);
                              }}
                              className="px-4 py-2 rounded-xl bg-amber-500 hover:bg-amber-400 text-stone-950 text-xs font-bold transition-all mt-1 shadow-md"
                            >
                              Browse Cafe Menu
                            </button>
                          </div>
                        ) : (
                          activeOrders.map((ord) => {
                            const timeElapsed = formatBookingTimeElapsed(ord.createdAt);

                            return (
                              <div
                                key={ord.id}
                                className="p-4 sm:p-5 rounded-2xl bg-gradient-to-r from-amber-500/10 via-stone-900 to-stone-900 border border-amber-500/40 space-y-3.5 shadow-lg relative overflow-hidden"
                              >
                                {/* Top Header */}
                                <div className="flex flex-wrap items-center justify-between gap-2">
                                  <div className="flex items-center gap-2">
                                    <span className="font-mono font-bold text-amber-400 text-sm">Token #{ord.id}</span>
                                    <span className="text-[11px] font-medium text-stone-400 uppercase bg-stone-900 px-2 py-0.5 rounded border border-stone-800">
                                      {ord.bookingMode}
                                    </span>
                                    <span className="text-xs text-stone-400">
                                      {new Date(ord.createdAt).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}
                                    </span>
                                  </div>
                                  <div>
                                    {getStatusBadge(ord.status)}
                                  </div>
                                </div>

                                {/* Destination details */}
                                <div className="text-xs text-stone-300 flex items-center gap-1.5">
                                  <MapPin className="w-3.5 h-3.5 text-amber-400 shrink-0" />
                                  <span>
                                    {ord.bookingMode === 'dine-in'
                                      ? `Dine-In • Reserved Table ${ord.dineInDetails?.tableNumber || 'Assigned by Host'} (${ord.dineInDetails?.guestCount || 1} Guests)`
                                      : ord.bookingMode === 'delivery'
                                      ? `Hostel Delivery • ${ord.deliveryDetails?.deliveryAddress || 'GEC Banka Campus'}`
                                      : 'Express Takeout • Pickup Counter'}
                                  </span>
                                </div>

                                {/* Items breakdown */}
                                <div className="p-3 rounded-xl bg-stone-950/70 border border-stone-800/80 space-y-2">
                                  {ord.items.map((item, idx) => (
                                    <div key={idx} className="flex justify-between items-center text-xs">
                                      <div className="flex items-center gap-2">
                                        {item.image ? (
                                          <img
                                            src={item.image}
                                            alt={item.name}
                                            referrerPolicy="no-referrer"
                                            className="w-7 h-7 rounded-lg object-cover border border-stone-800 shrink-0"
                                          />
                                        ) : (
                                          <div className="w-7 h-7 rounded-lg bg-stone-800 flex items-center justify-center text-[10px] text-amber-400 shrink-0">
                                            ☕
                                          </div>
                                        )}
                                        <div>
                                          <span className="text-stone-200 font-medium">{item.name}</span>
                                          <span className="text-stone-500 ml-1.5">× {item.quantity}</span>
                                          {item.selectedSize && (
                                            <span className="text-[10px] text-stone-500 ml-1">({item.selectedSize.name})</span>
                                          )}
                                        </div>
                                      </div>
                                      <span className="text-stone-300 font-mono text-xs">
                                        {settings.currency}{(item.calculatedPrice * item.quantity).toFixed(2)}
                                      </span>
                                    </div>
                                  ))}
                                </div>

                                {/* 10-Minute Free Cancellation Window Banner */}
                                <div className="p-2.5 rounded-xl bg-stone-950/50 border border-stone-800/80 flex flex-col sm:flex-row sm:items-center justify-between gap-2 text-xs">
                                  <div className="flex items-center gap-2">
                                    {timeElapsed.isWithin10MinWindow ? (
                                      <>
                                        <span className="w-2 h-2 rounded-full bg-emerald-400 animate-ping shrink-0" />
                                        <span className="text-emerald-300 font-medium">
                                          10m Free Cancellation Window: <strong>{timeElapsed.formattedCountdown} remaining</strong>
                                        </span>
                                      </>
                                    ) : (
                                      <span className="text-stone-400 text-[11px]">
                                        Est. Ready: <strong className="text-stone-200">{ord.estimatedReadyTime || '15-20 mins'}</strong> • Preparation locked
                                      </span>
                                    )}
                                  </div>

                                  {timeElapsed.isWithin10MinWindow && (
                                    <button
                                      type="button"
                                      id={`btn-cancel-active-${ord.id}`}
                                      onClick={() => setConfirmCancelOrder(ord)}
                                      className="px-2.5 py-1 rounded-lg bg-rose-950/60 hover:bg-rose-900/80 border border-rose-800/60 text-rose-300 text-[11px] font-bold flex items-center gap-1 transition-colors self-start sm:self-auto"
                                    >
                                      <Ban className="w-3 h-3 text-rose-400" />
                                      <span>Cancel Order</span>
                                    </button>
                                  )}
                                </div>

                                {/* Bottom Meta and Actions */}
                                <div className="flex flex-wrap items-center justify-between gap-3 pt-2 border-t border-amber-500/20 text-xs">
                                  <div>
                                    <span className="text-stone-400">Total: </span>
                                    <span className="font-mono text-sm font-bold text-amber-400">
                                      {settings.currency}{ord.pricing.total.toFixed(2)}
                                    </span>
                                    <span className="text-[11px] text-stone-500 ml-2">
                                      ({ord.paymentStatus === 'paid' ? 'Paid' : 'Pay on Arrival'} • {ord.paymentMethod.toUpperCase()})
                                    </span>
                                  </div>

                                  <div className="flex items-center gap-2">
                                    <button
                                      type="button"
                                      id={`btn-receipt-active-${ord.id}`}
                                      onClick={() => setSelectedReceiptOrder(ord)}
                                      className="px-3 py-1.5 rounded-xl bg-stone-800 hover:bg-stone-700 text-stone-300 hover:text-stone-100 text-xs font-semibold transition-colors"
                                    >
                                      Receipt
                                    </button>
                                    <button
                                      type="button"
                                      id={`btn-track-active-${ord.id}`}
                                      onClick={() => {
                                        setActiveOrder(ord);
                                        setIsOrderTrackerOpen(true);
                                        setIsCustomerAccountOpen(false);
                                      }}
                                      className="px-3.5 py-1.5 rounded-xl bg-amber-500 hover:bg-amber-400 text-stone-950 text-xs font-bold transition-all shadow-md active:scale-95 flex items-center gap-1"
                                    >
                                      <span>Track Live Status</span>
                                      <ExternalLink className="w-3 h-3" />
                                    </button>
                                  </div>
                                </div>
                              </div>
                            );
                          })
                        )}
                      </div>
                    )}

                    {/* SUB-VIEW 2: Permanent Order History (Completed & Cancelled) */}
                    {ordersSubTab === 'history' && (
                      <div className="space-y-4">
                        {/* Search & Status Filters */}
                        <div className="flex flex-col sm:flex-row gap-2 pt-1">
                          <div className="relative flex-1">
                            <Search className="w-4 h-4 text-stone-500 absolute left-3.5 top-1/2 -translate-y-1/2" />
                            <input
                              type="text"
                              id="input-search-orders"
                              value={orderSearchQuery}
                              onChange={(e) => setOrderSearchQuery(e.target.value)}
                              placeholder="Search order history by item, token, or mode..."
                              className="w-full bg-stone-950/70 border border-stone-800 rounded-xl pl-10 pr-4 py-2 text-xs text-stone-100 placeholder-stone-600 outline-none focus:border-amber-500"
                            />
                          </div>

                          {/* Status Chips */}
                          <div className="flex gap-1.5 overflow-x-auto pb-1 sm:pb-0 shrink-0 text-xs font-semibold">
                            {(['all', 'completed', 'cancelled'] as const).map((filter) => (
                              <button
                                key={filter}
                                type="button"
                                onClick={() => setStatusFilter(filter)}
                                className={`px-3 py-1.5 rounded-xl capitalize transition-colors whitespace-nowrap ${
                                  statusFilter === filter
                                    ? 'bg-amber-500 text-stone-950 font-bold'
                                    : 'bg-stone-950/60 border border-stone-800 text-stone-400 hover:text-stone-200'
                                }`}
                              >
                                {filter === 'all'
                                  ? `All History (${customerOrderHistory.length})`
                                  : filter === 'completed'
                                  ? `Completed (${customerOrderHistory.filter(o => o.status === 'completed').length})`
                                  : `Cancelled (${customerOrderHistory.filter(o => o.status === 'cancelled').length})`}
                              </button>
                            ))}
                          </div>
                        </div>

                        {/* History Order Cards List */}
                        {historyOrders.length === 0 ? (
                          <div className="p-10 text-center bg-stone-950/40 rounded-3xl border border-stone-800/80 space-y-3 my-2">
                            <Coffee className="w-10 h-10 text-stone-600 mx-auto" />
                            <h4 className="font-serif font-bold text-stone-300 text-base">No past orders found</h4>
                            <p className="text-xs text-stone-500 max-w-sm mx-auto">
                              You don't have any past fulfilled or cancelled orders matching your filter criteria.
                            </p>
                            <button
                              type="button"
                              id="btn-empty-orders-browse"
                              onClick={() => {
                                setIsCustomerAccountOpen(false);
                                setIsCartOpen(false);
                              }}
                              className="px-4 py-2 rounded-xl bg-amber-500 hover:bg-amber-400 text-stone-950 text-xs font-bold transition-all mt-1"
                            >
                              Explore Cafe Menu
                            </button>
                          </div>
                        ) : (
                          <div className="space-y-3.5">
                            {historyOrders.map((order) => (
                              <div
                                key={order.id}
                                className="p-4 sm:p-5 rounded-2xl bg-stone-950/60 border border-stone-800/90 space-y-3 hover:border-stone-700 transition-colors"
                              >
                                {/* Top meta row */}
                                <div className="flex flex-wrap items-center justify-between gap-2">
                                  <div className="flex items-center gap-2">
                                    <span className="font-mono text-sm font-bold text-amber-400">#{order.id}</span>
                                    <span className="text-xs text-stone-400">
                                      {new Date(order.createdAt).toLocaleDateString('en-IN', {
                                        day: 'numeric',
                                        month: 'short',
                                        year: 'numeric',
                                        hour: '2-digit',
                                        minute: '2-digit'
                                      })}
                                    </span>
                                  </div>
                                  <div className="flex items-center gap-2">
                                    <span className="text-[11px] font-medium text-stone-400 uppercase bg-stone-900 px-2 py-0.5 rounded border border-stone-800">
                                      {order.bookingMode}
                                    </span>
                                    {getStatusBadge(order.status)}
                                  </div>
                                </div>

                                {/* Destination info */}
                                <div className="text-xs text-stone-400 flex items-center gap-1.5">
                                  <MapPin className="w-3.5 h-3.5 text-stone-500 shrink-0" />
                                  <span>
                                    {order.bookingMode === 'dine-in'
                                      ? `Dine In Table ${order.dineInDetails?.tableNumber || 'Assigned by host'}`
                                      : order.bookingMode === 'delivery'
                                      ? `Delivered to: ${order.deliveryDetails?.deliveryAddress || 'GEC Banka Campus'}`
                                      : 'Takeout at Express Barista Counter'}
                                  </span>
                                </div>

                                {/* Cancellation Note or Completion Note */}
                                {order.status === 'cancelled' && (
                                  <div className="p-2.5 rounded-xl bg-rose-950/30 border border-rose-900/40 text-xs text-rose-300 flex items-start gap-2">
                                    <Ban className="w-4 h-4 text-rose-400 shrink-0 mt-0.5" />
                                    <div>
                                      <div className="font-semibold text-rose-300">Order Cancelled</div>
                                      <p className="text-stone-400 text-[11px] mt-0.5">
                                        Reason: {order.cancellationReason || 'Cancelled by customer / admin request'}
                                      </p>
                                    </div>
                                  </div>
                                )}

                                {order.status === 'completed' && order.completedAt && (
                                  <div className="text-[11px] text-stone-400 flex items-center gap-1.5">
                                    <CheckCircle2 className="w-3 h-3 text-emerald-400" />
                                    <span>Fulfilled at {new Date(order.completedAt).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}</span>
                                  </div>
                                )}

                                {/* Item thumbnails and breakdown */}
                                <div className="p-3 rounded-xl bg-stone-900/80 border border-stone-800/60 space-y-2">
                                  {order.items.map((item, idx) => (
                                    <div key={idx} className="flex justify-between items-center text-xs">
                                      <div className="flex items-center gap-2">
                                        {item.image ? (
                                          <img
                                            src={item.image}
                                            alt={item.name}
                                            referrerPolicy="no-referrer"
                                            className="w-7 h-7 rounded-lg object-cover border border-stone-800 shrink-0"
                                          />
                                        ) : (
                                          <div className="w-7 h-7 rounded-lg bg-stone-800 flex items-center justify-center text-[10px] text-amber-400 shrink-0">
                                            ☕
                                          </div>
                                        )}
                                        <div>
                                          <span className="text-stone-200 font-medium">{item.name}</span>
                                          <span className="text-stone-500 ml-1.5">× {item.quantity}</span>
                                          {item.selectedSize && (
                                            <span className="text-[10px] text-stone-500 ml-1">({item.selectedSize.name})</span>
                                          )}
                                        </div>
                                      </div>
                                      <span className="text-stone-300 font-mono text-xs">
                                        {settings.currency}{(item.calculatedPrice * item.quantity).toFixed(2)}
                                      </span>
                                    </div>
                                  ))}
                                </div>

                                {/* Customer Review / Feedback if present or button to leave feedback */}
                                {order.feedback ? (
                                  <div className="p-3 rounded-xl bg-amber-500/10 border border-amber-500/20 text-xs space-y-1">
                                    <div className="flex items-center justify-between">
                                      <div className="flex items-center gap-1 text-amber-400">
                                        {[...Array(5)].map((_, i) => (
                                          <Star
                                            key={i}
                                            className={`w-3.5 h-3.5 ${
                                              i < (order.feedback?.rating || 5)
                                                ? 'fill-amber-400 text-amber-400'
                                                : 'text-stone-700'
                                            }`}
                                          />
                                        ))}
                                        <span className="font-bold ml-1 text-amber-300">
                                          {order.feedback.rating}/5
                                        </span>
                                      </div>
                                      <span className="text-[10px] text-stone-500">Your Review</span>
                                    </div>
                                    {order.feedback.comment && (
                                      <p className="text-stone-300 text-xs italic">
                                        "{order.feedback.comment}"
                                      </p>
                                    )}
                                  </div>
                                ) : order.status === 'completed' && (
                                  <div className="flex items-center justify-between p-2 rounded-xl bg-stone-900/50 border border-stone-800/60 text-xs">
                                    <span className="text-stone-400 text-[11px]">How was your food and barista experience?</span>
                                    <button
                                      type="button"
                                      id={`btn-review-${order.id}`}
                                      onClick={() => {
                                        setFeedbackModalOrder(order);
                                        setFeedbackRating(5);
                                        setFeedbackComment('');
                                      }}
                                      className="px-2.5 py-1 rounded-lg bg-amber-500/20 hover:bg-amber-500/30 text-amber-300 text-[11px] font-bold flex items-center gap-1 transition-colors"
                                    >
                                      <Star className="w-3 h-3 fill-amber-300" />
                                      <span>Rate & Review</span>
                                    </button>
                                  </div>
                                )}

                                {/* Price and Action Buttons */}
                                <div className="flex flex-wrap items-center justify-between gap-3 pt-2 border-t border-stone-800/60">
                                  <div className="text-xs">
                                    <span className="text-stone-400">Total: </span>
                                    <span className="font-mono text-sm font-bold text-amber-400">
                                      {settings.currency}{order.pricing.total.toFixed(2)}
                                    </span>
                                    <span className="text-[11px] text-stone-500 ml-2">
                                      ({order.paymentStatus === 'paid' ? 'Paid' : 'Pay on Arrival'} • {order.paymentMethod.toUpperCase()})
                                    </span>
                                  </div>

                                  <div className="flex items-center gap-2">
                                    <button
                                      type="button"
                                      id={`btn-receipt-${order.id}`}
                                      onClick={() => setSelectedReceiptOrder(order)}
                                      className="flex items-center gap-1 px-3 py-1.5 rounded-xl bg-stone-800 hover:bg-stone-700 text-stone-300 hover:text-stone-100 text-xs font-semibold transition-colors"
                                    >
                                      <Receipt className="w-3.5 h-3.5" />
                                      <span>Receipt</span>
                                    </button>

                                    <button
                                      type="button"
                                      id={`btn-reorder-${order.id}`}
                                      onClick={() => reorderPastOrder(order)}
                                      className="flex items-center gap-1 px-3.5 py-1.5 rounded-xl bg-amber-500 hover:bg-amber-400 text-stone-950 text-xs font-bold transition-all active:scale-95 shadow-sm"
                                      title="Add all items from this order to tray"
                                    >
                                      <RotateCcw className="w-3.5 h-3.5" />
                                      <span>Reorder</span>
                                    </button>
                                  </div>
                                </div>
                              </div>
                            ))}
                          </div>
                        )}

                        {/* Customer Orders Pagination Button */}
                        {hasMoreOrders && (
                          <div className="pt-2 text-center">
                            <button
                              type="button"
                              id="btn-customer-load-more"
                              onClick={() => loadMoreOrders()}
                              disabled={isLoadingMoreOrders}
                              className="px-5 py-2 rounded-xl bg-stone-800 hover:bg-stone-700 text-stone-300 text-xs font-semibold transition-colors disabled:opacity-50 inline-flex items-center gap-2 cursor-pointer"
                            >
                              {isLoadingMoreOrders ? (
                                <>
                                  <span className="w-3 h-3 border-2 border-stone-400 border-t-amber-400 rounded-full animate-spin"></span>
                                  <span>Loading Orders...</span>
                                </>
                              ) : (
                                <>
                                  <RotateCcw className="w-3 h-3 text-amber-400" />
                                  <span>Load Earlier Orders</span>
                                </>
                              )}
                            </button>
                          </div>
                        )}
                      </div>
                    )}
                  </div>
                )}

                {/* Tab 2: Campus Profile & Address Preferences */}
                {activeTab === 'profile' && (
                  <form onSubmit={handleSaveProfile} className="flex-1 overflow-y-auto p-4 sm:p-7 space-y-5 max-w-lg mx-auto w-full">
                    <div className="p-3.5 rounded-2xl bg-amber-500/10 border border-amber-500/20 text-xs text-amber-300 flex items-center gap-2">
                      <Sparkles className="w-4 h-4 shrink-0 text-amber-400" />
                      <span>
                        Your saved campus details will automatically pre-fill at checkout so you never have to re-enter them!
                      </span>
                    </div>

                    {profileSavedSuccess && (
                      <div className="p-3 rounded-xl bg-emerald-950/40 border border-emerald-800 text-emerald-300 text-xs flex items-center gap-2">
                        <CheckCircle2 className="w-4 h-4 shrink-0 text-emerald-400" />
                        <span>Campus profile & delivery preferences saved successfully!</span>
                      </div>
                    )}

                    <div className="space-y-1.5">
                      <label className="text-xs font-medium text-stone-300">Full Name</label>
                      <input
                        type="text"
                        id="input-profile-name"
                        value={profileName}
                        onChange={(e) => setProfileName(e.target.value)}
                        placeholder="Your full name"
                        className="w-full bg-stone-950/70 border border-stone-800 focus:border-amber-500 rounded-xl px-3.5 py-2.5 text-xs text-stone-100 outline-none"
                      />
                    </div>

                    <div className="space-y-1.5">
                      <label className="text-xs font-medium text-stone-300">Registered Email</label>
                      <input
                        type="email"
                        disabled
                        value={currentUser.email || ''}
                        className="w-full bg-stone-950/40 border border-stone-800/80 rounded-xl px-3.5 py-2.5 text-xs text-stone-500 cursor-not-allowed outline-none"
                      />
                    </div>

                    <div className="space-y-1.5">
                      <label className="text-xs font-medium text-stone-300">WhatsApp / Contact Phone</label>
                      <input
                        type="tel"
                        id="input-profile-phone"
                        value={profilePhone}
                        onChange={(e) => setProfilePhone(e.target.value)}
                        placeholder="+91 98765 43210"
                        className="w-full bg-stone-950/70 border border-stone-800 focus:border-amber-500 rounded-xl px-3.5 py-2.5 text-xs text-stone-100 outline-none"
                      />
                    </div>

                    <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                      <div className="space-y-1.5">
                        <label className="text-xs font-medium text-stone-300">Campus Building / Hostel</label>
                        <select
                          id="input-profile-hostel"
                          value={profileHostel}
                          onChange={(e) => setProfileHostel(e.target.value)}
                          className="w-full bg-stone-950/70 border border-stone-800 focus:border-amber-500 rounded-xl px-3 py-2.5 text-xs text-stone-200 outline-none"
                        >
                          {CAMPUS_LOCATIONS.map((loc) => (
                            <option key={loc} value={loc} className="bg-stone-900 text-stone-100">
                              {loc}
                            </option>
                          ))}
                        </select>
                      </div>

                      <div className="space-y-1.5">
                        <label className="text-xs font-medium text-stone-300">Room / Floor / Desk No.</label>
                        <input
                          type="text"
                          id="input-profile-room"
                          value={profileRoom}
                          onChange={(e) => setProfileRoom(e.target.value)}
                          placeholder="e.g. Room 204 or Lab 3"
                          className="w-full bg-stone-950/70 border border-stone-800 focus:border-amber-500 rounded-xl px-3.5 py-2.5 text-xs text-stone-100 outline-none"
                        />
                      </div>
                    </div>

                    <button
                      type="submit"
                      id="btn-save-profile"
                      disabled={isSavingProfile}
                      className="w-full py-3 rounded-xl bg-amber-500 hover:bg-amber-400 text-stone-950 text-sm font-bold shadow-lg shadow-amber-500/10 transition-all active:scale-[0.99] disabled:opacity-50 mt-2"
                    >
                      {isSavingProfile ? 'Saving Preferences...' : 'Save Campus Profile'}
                    </button>
                  </form>
                )}

                {/* Tab 3: Loyalty & Coupons */}
                {activeTab === 'perks' && (
                  <div className="flex-1 overflow-y-auto p-4 sm:p-7 space-y-6 max-w-xl mx-auto w-full">
                    {/* Loyalty Membership Card */}
                    <div className="p-5 sm:p-6 rounded-3xl bg-gradient-to-br from-amber-600 via-amber-700 to-stone-900 text-stone-950 shadow-2xl relative overflow-hidden">
                      <div className="absolute right-[-20px] bottom-[-20px] opacity-10 text-stone-950 pointer-events-none">
                        <Coffee className="w-48 h-48" />
                      </div>
                      <div className="relative z-10 flex justify-between items-start">
                        <div>
                          <span className="text-[10px] font-bold uppercase tracking-widest text-amber-200">
                            Campus Foodie Privilege Club
                          </span>
                          <h4 className="font-serif text-2xl font-bold text-white mt-1">
                            {currentUserProfile?.displayName || currentUser.displayName || 'Patron Member'}
                          </h4>
                          <p className="text-xs text-amber-100/90 font-mono mt-0.5">
                            GEC Banka Student Pass
                          </p>
                        </div>
                        <div className="w-10 h-10 rounded-2xl bg-amber-400/30 backdrop-blur border border-amber-300/40 flex items-center justify-center text-white">
                          <Award className="w-6 h-6" />
                        </div>
                      </div>

                      <div className="relative z-10 mt-8 flex justify-between items-end">
                        <div>
                          <span className="text-[10px] text-amber-200/90 uppercase tracking-wider block">Available Balance</span>
                          <span className="font-mono text-3xl font-black text-white">
                            {currentUserProfile?.loyaltyPoints || 0}
                          </span>
                          <span className="text-xs text-amber-200 ml-1.5">Points</span>
                        </div>
                        <div className="text-right">
                          <span className="text-[10px] text-amber-200 uppercase tracking-wider block">Reward Rate</span>
                          <span className="text-xs font-bold text-white">5 Pts per ₹1 Spent</span>
                        </div>
                      </div>
                    </div>

                    {/* Active Student Promo Coupons */}
                    <div className="space-y-3">
                      <h4 className="text-xs font-bold uppercase tracking-wider text-stone-400 flex items-center gap-2">
                        <Tag className="w-4 h-4 text-amber-400" />
                        <span>Exclusive Campus Student Coupons</span>
                      </h4>

                      <div className="space-y-2.5">
                        {promoCodes.filter(p => p.isActive).map((promo) => (
                          <div
                            key={promo.code}
                            className="p-3.5 rounded-2xl bg-stone-950/70 border border-stone-800 flex items-center justify-between gap-3 hover:border-amber-500/40 transition-colors"
                          >
                            <div>
                              <div className="flex items-center gap-2">
                                <span className="font-mono font-bold text-xs px-2.5 py-1 rounded-lg bg-amber-500/15 text-amber-300 border border-amber-500/30">
                                  {promo.code}
                                </span>
                                <span className="text-xs font-semibold text-stone-200">
                                  {promo.discountType === 'percentage' ? `${promo.discountValue}% OFF` : `₹${promo.discountValue} FLAT OFF`}
                                </span>
                              </div>
                              <p className="text-[11px] text-stone-400 mt-1">
                                {promo.description} • Min order: {settings.currency}{promo.minOrderAmount}
                              </p>
                            </div>

                            <button
                              type="button"
                              id={`btn-apply-promo-${promo.code}`}
                              onClick={() => {
                                applyPromoCode(promo.code);
                                setIsCustomerAccountOpen(false);
                                setIsCartOpen(true);
                              }}
                              className="px-3 py-1.5 rounded-xl bg-amber-500 hover:bg-amber-400 text-stone-950 text-xs font-bold shrink-0 transition-colors"
                            >
                              Apply to Cart
                            </button>
                          </div>
                        ))}
                      </div>
                    </div>
                  </div>
                )}
              </div>
            )}
          </motion.div>
        </div>
      </AnimatePresence>

      {/* Printable Receipt Modal */}
      <OrderReceiptModal
        order={selectedReceiptOrder}
        isOpen={!!selectedReceiptOrder}
        onClose={() => setSelectedReceiptOrder(null)}
        settings={settings}
      />

      {/* 10-Minute Free Cancellation Confirmation Modal */}
      {confirmCancelOrder && (
        <div className="fixed inset-0 z-[100] overflow-y-auto bg-stone-950/80 backdrop-blur-sm flex items-center justify-center p-4">
          <div className="relative bg-stone-900 border border-stone-800 rounded-3xl p-5 sm:p-6 max-w-md w-full shadow-2xl space-y-4 text-stone-100">
            <div className="flex items-center gap-3">
              <div className="w-10 h-10 rounded-2xl bg-rose-500/20 border border-rose-500/30 flex items-center justify-center text-rose-400 shrink-0">
                <Ban className="w-5 h-5" />
              </div>
              <div>
                <h3 className="font-serif font-bold text-base text-stone-100">Cancel Order #{confirmCancelOrder.id}?</h3>
                <p className="text-xs text-stone-400">10-Minute Zero-Charge Grace Window</p>
              </div>
            </div>

            <p className="text-xs text-stone-300 leading-relaxed">
              You are within the 10-minute free cancellation window. Cancelling will notify the barista team immediately, release any reserved seating, and move this record into your permanent archive.
            </p>

            <div className="space-y-1.5">
              <label className="text-xs font-medium text-stone-300">Cancellation Reason (optional):</label>
              <input
                type="text"
                id="input-customer-cancel-reason"
                value={cancelReasonInput}
                onChange={(e) => setCancelReasonInput(e.target.value)}
                placeholder="e.g., Plan change, class rescheduled, duplicate order..."
                className="w-full bg-stone-950 border border-stone-800 focus:border-amber-500 rounded-xl px-3.5 py-2.5 text-xs text-stone-100 placeholder-stone-600 outline-none"
              />
            </div>

            <div className="flex justify-end gap-2 pt-2">
              <button
                type="button"
                id="btn-cancel-modal-close"
                onClick={() => {
                  setConfirmCancelOrder(null);
                  setCancelReasonInput('');
                }}
                disabled={isCancelling}
                className="px-4 py-2 rounded-xl bg-stone-800 hover:bg-stone-700 text-stone-300 text-xs font-semibold transition-colors"
              >
                Keep Order
              </button>
              <button
                type="button"
                id="btn-confirm-cancel-order"
                onClick={handleConfirmCancel}
                disabled={isCancelling}
                className="px-4 py-2 rounded-xl bg-rose-600 hover:bg-rose-500 text-stone-100 text-xs font-bold transition-all flex items-center gap-1.5 shadow-lg shadow-rose-600/20 disabled:opacity-50"
              >
                {isCancelling ? 'Cancelling...' : 'Confirm Cancellation'}
              </button>
            </div>
          </div>
        </div>
      )}

      {/* Customer Feedback and Rating Modal */}
      {feedbackModalOrder && (
        <div className="fixed inset-0 z-[100] overflow-y-auto bg-stone-950/80 backdrop-blur-sm flex items-center justify-center p-4">
          <form onSubmit={handleSubmitFeedback} className="relative bg-stone-900 border border-stone-800 rounded-3xl p-5 sm:p-6 max-w-md w-full shadow-2xl space-y-4 text-stone-100">
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-2.5">
                <div className="w-10 h-10 rounded-2xl bg-amber-500/20 border border-amber-500/30 flex items-center justify-center text-amber-400">
                  <Star className="w-5 h-5 fill-amber-400" />
                </div>
                <div>
                  <h3 className="font-serif font-bold text-base text-stone-100">Review Order #{feedbackModalOrder.id}</h3>
                  <p className="text-xs text-stone-400">Share your coffee & service experience</p>
                </div>
              </div>
              <button
                type="button"
                id="btn-close-feedback-modal"
                onClick={() => setFeedbackModalOrder(null)}
                className="p-1.5 rounded-lg text-stone-400 hover:text-stone-200 transition-colors"
              >
                <X className="w-4 h-4" />
              </button>
            </div>

            <div className="space-y-1.5 text-center py-2">
              <label className="text-xs font-medium text-stone-300">Your Rating</label>
              <div className="flex justify-center gap-2 pt-1">
                {[1, 2, 3, 4, 5].map((star) => (
                  <button
                    key={star}
                    type="button"
                    onClick={() => setFeedbackRating(star)}
                    className="p-1.5 transition-transform hover:scale-110"
                    title={`${star} star${star > 1 ? 's' : ''}`}
                  >
                    <Star
                      className={`w-7 h-7 ${
                        star <= feedbackRating
                          ? 'text-amber-400 fill-amber-400'
                          : 'text-stone-700 hover:text-stone-500'
                      }`}
                    />
                  </button>
                ))}
              </div>
            </div>

            <div className="space-y-1.5">
              <label className="text-xs font-medium text-stone-300">Your Review (optional)</label>
              <textarea
                rows={3}
                id="textarea-customer-feedback"
                value={feedbackComment}
                onChange={(e) => setFeedbackComment(e.target.value)}
                placeholder="How was the espresso blend, food temperature, packaging, or barista hospitality?"
                className="w-full bg-stone-950 border border-stone-800 focus:border-amber-500 rounded-xl p-3 text-xs text-stone-100 placeholder-stone-600 outline-none resize-none"
              />
            </div>

            <div className="flex justify-end gap-2 pt-2">
              <button
                type="button"
                onClick={() => setFeedbackModalOrder(null)}
                disabled={isSubmittingFeedback}
                className="px-4 py-2 rounded-xl bg-stone-800 hover:bg-stone-700 text-stone-300 text-xs font-semibold transition-colors"
              >
                Cancel
              </button>
              <button
                type="submit"
                id="btn-submit-feedback"
                disabled={isSubmittingFeedback}
                className="px-4 py-2 rounded-xl bg-amber-500 hover:bg-amber-400 text-stone-950 text-xs font-bold transition-all shadow-md disabled:opacity-50"
              >
                {isSubmittingFeedback ? 'Submitting...' : 'Submit Review'}
              </button>
            </div>
          </form>
        </div>
      )}
    </>
  );
};
