import React, { useState, useMemo, useEffect } from 'react';
import { useCafe } from '../../context/CafeContext';
import {
  BookingMode,
  TableZone,
  DineInDetails,
  TakeoutDetails,
  DeliveryDetails,
  BookingCustomer
} from '../../types';
import {
  X,
  CalendarCheck,
  ShoppingBag,
  Truck,
  Clock,
  Calendar,
  Users,
  MapPin,
  Sparkles,
  CreditCard,
  Banknote,
  Smartphone,
  ShieldCheck,
  CheckCircle2,
  AlertCircle,
  QrCode,
  Heart,
  Briefcase,
  PartyPopper,
  Copy,
  ExternalLink
} from 'lucide-react';
import { motion, AnimatePresence } from 'motion/react';
import { QRCodeSVG } from 'qrcode.react';
import confetti from 'canvas-confetti';
import { UpiPaymentBox } from '../payment/UpiPaymentBox';

const CAMPUS_TIME_SLOTS = [
  { time: '08:30 AM', label: 'Morning Tea & Samosa', available: true },
  { time: '10:30 AM', label: 'Post-Lecture Break', available: true },
  { time: '12:30 PM', label: 'Campus Lunch Break', available: true },
  { time: '02:00 PM', label: 'Afternoon Kaapi', available: true },
  { time: '04:30 PM', label: 'Evening Chai Hangout', available: true },
  { time: '06:30 PM', label: 'Snacks & Study Group', available: true },
  { time: '08:30 PM', label: 'Hostel Dinner Meals', available: true },
  { time: '10:00 PM', label: 'Exam Night Combo', available: true },
];

const CAMPUS_BUILDINGS = [
  'Boys Hostel 1 (BH-1)',
  'Boys Hostel 2 (BH-2)',
  'Girls Hostel (GH)',
  'Computer Science & IT Block',
  'Mechanical & Civil Wing',
  'ECE & Electrical Wing',
  'Central College Library',
  'Administrative Block',
  'Faculty & Staff Quarters'
];

export const CheckoutModal: React.FC = () => {
  const {
    isCheckoutOpen,
    setIsCheckoutOpen,
    cart,
    tables,
    settings,
    calculatePricing,
    createBookingOrder,
    setIsOrderTrackerOpen,
    currentUser,
    currentUserProfile,
    showToast,
    isCafeOpenNow
  } = useCafe();

  // Booking mode state
  const [bookingMode, setBookingMode] = useState<BookingMode>('dine-in');

  // Customer details
  const [customerName, setCustomerName] = useState('');
  const [customerPhone, setCustomerPhone] = useState('');
  const [customerEmail, setCustomerEmail] = useState('');
  const [specialRequests, setSpecialRequests] = useState('');
  const [sendWhatsApp, setSendWhatsApp] = useState(true);

  // Dine-in specifics
  const [selectedDate, setSelectedDate] = useState<string>(() => {
    return new Date().toISOString().split('T')[0];
  });
  const [selectedTimeSlot, setSelectedTimeSlot] = useState('04:30 PM');
  const [guestCount, setGuestCount] = useState(2);
  const [selectedZone, setSelectedZone] = useState<TableZone>('indoor');
  const [selectedTableId, setSelectedTableId] = useState<string>('');
  const [occasion, setOccasion] = useState<'casual' | 'birthday' | 'anniversary' | 'business' | 'date'>('casual');

  // Takeout specifics
  const [pickupTime, setPickupTime] = useState('⚡ ASAP (10-15 mins)');
  const [vehicleInfo, setVehicleInfo] = useState('');

  // Delivery specifics
  const [campusBuilding, setCampusBuilding] = useState('Boys Hostel 1 (BH-1)');
  const [roomNumber, setRoomNumber] = useState('');
  const [deliveryInstructions, setDeliveryInstructions] = useState('');

  // Payment method
  const [paymentMethod, setPaymentMethod] = useState<'upi' | 'cash' | 'counter' | 'card'>('upi');
  const [selectedTip, setSelectedTip] = useState<number>(10);
  const [copiedUpi, setCopiedUpi] = useState(false);

  // Submission loading
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [errorMsg, setErrorMsg] = useState('');

  // Auto-fill from signed-in customer profile
  useEffect(() => {
    if (currentUserProfile) {
      if (!customerName && currentUserProfile.displayName) {
        setCustomerName(currentUserProfile.displayName);
      }
      if (!customerPhone && currentUserProfile.phone) {
        setCustomerPhone(currentUserProfile.phone);
      }
      if (!customerEmail && currentUserProfile.email) {
        setCustomerEmail(currentUserProfile.email);
      }
      if (currentUserProfile.departmentOrHostel) {
        setCampusBuilding(currentUserProfile.departmentOrHostel);
      }
      if (currentUserProfile.roomNumber) {
        setRoomNumber(currentUserProfile.roomNumber);
      }
    } else if (currentUser) {
      if (!customerName && currentUser.displayName) {
        setCustomerName(currentUser.displayName);
      }
      if (!customerEmail && currentUser.email) {
        setCustomerEmail(currentUser.email);
      }
    }
  }, [currentUserProfile, currentUser, isCheckoutOpen]);

  // Tables available in selected zone for guest count
  const availableTablesInZone = useMemo(() => {
    return tables.filter(
      (t) => t.zone === selectedZone && (t.status === 'available' || t.id === selectedTableId)
    );
  }, [tables, selectedZone, selectedTableId]);

  if (!isCheckoutOpen) return null;

  const pricing = calculatePricing(bookingMode, selectedTip);

  // Construct standard Indian UPI intent string
  const upiIntentString = `upi://pay?pa=${settings.upiId}&pn=${encodeURIComponent(
    settings.upiName
  )}&am=${pricing.total.toFixed(2)}&cu=INR&tn=${encodeURIComponent('Campora Cafe GEC Banka')}`;

  const handleCopyUpiId = () => {
    navigator.clipboard.writeText(settings.upiId);
    setCopiedUpi(true);
    showToast('UPI ID Copied', settings.upiId, 'info');
    setTimeout(() => setCopiedUpi(false), 3000);
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setErrorMsg('');

    if (!isCafeOpenNow) {
      setErrorMsg('Currently Closed – Ordering is Temporarily Unavailable. New orders cannot be placed at this time.');
      showToast('Café Closed', 'Ordering is Temporarily Unavailable. Please check back when the café reopens.', 'warning');
      return;
    }

    if (!customerName.trim()) {
      setErrorMsg('Please enter your student / customer name.');
      return;
    }
    if (!customerPhone.trim() || customerPhone.length < 10) {
      setErrorMsg('Please provide a valid 10-digit mobile contact number.');
      return;
    }

    if (bookingMode === 'delivery' && !roomNumber.trim()) {
      setErrorMsg('Please specify your Room No. / Department Desk for campus delivery.');
      return;
    }

    setIsSubmitting(true);

    try {
      const customer: BookingCustomer = {
        name: customerName.trim(),
        phone: customerPhone.trim(),
        email: customerEmail.trim() || `${customerPhone.trim()}@gecbanka.ac.in`,
        specialRequests: specialRequests.trim(),
        sendWhatsAppNotification: sendWhatsApp
      };

      const selectedTable = tables.find((t) => t.id === selectedTableId);

      const dineInDetails: DineInDetails | undefined =
        bookingMode === 'dine-in'
          ? {
              date: selectedDate,
              timeSlot: selectedTimeSlot,
              guestCount,
              tableId: selectedTableId || (availableTablesInZone[0]?.id || undefined),
              tableNumber: selectedTable?.tableNumber || (availableTablesInZone[0]?.tableNumber || undefined),
              zone: selectedZone,
              occasion
            }
          : undefined;

      const takeoutDetails: TakeoutDetails | undefined =
        bookingMode === 'takeout'
          ? {
              pickupTime,
              vehicleOrNote: vehicleInfo.trim()
            }
          : undefined;

      const deliveryDetails: DeliveryDetails | undefined =
        bookingMode === 'delivery'
          ? {
              deliveryAddress: `${campusBuilding}, Room/Desk: ${roomNumber.trim()}`,
              landmark: 'GEC Banka Campus',
              deliveryInstructions: deliveryInstructions.trim(),
              hostelOrBuilding: campusBuilding,
              roomOrFloor: roomNumber.trim()
            }
          : undefined;

      const newOrder = await createBookingOrder(
        bookingMode,
        customer,
        paymentMethod,
        dineInDetails,
        takeoutDetails,
        deliveryDetails,
        selectedTip
      );

      // Trigger Celebration Confetti
      try {
        confetti({
          particleCount: 75,
          spread: 70,
          origin: { y: 0.6 }
        });
      } catch (err) {
        // ignore
      }

      setIsSubmitting(false);
      setIsCheckoutOpen(false);
      setIsOrderTrackerOpen(true);
      showToast('Order Placed!', `Your token #${newOrder.id} is confirmed with Campora Cafe.`, 'success');
    } catch (err) {
      setIsSubmitting(false);
      setErrorMsg('An unexpected error occurred. Please try again.');
    }
  };

  return (
    <AnimatePresence>
      <div id="checkout-modal" className="fixed inset-0 z-50 overflow-y-auto bg-stone-950/75 backdrop-blur-sm flex items-end sm:items-center justify-center p-0 sm:p-4">
        
        {/* Backdrop */}
        <motion.div
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          exit={{ opacity: 0 }}
          onClick={() => setIsCheckoutOpen(false)}
          className="fixed inset-0"
        />

        {/* Modal Card */}
        <motion.div
          initial={{ opacity: 0, y: 50, scale: 0.95 }}
          animate={{ opacity: 1, y: 0, scale: 1 }}
          exit={{ opacity: 0, y: 50, scale: 0.95 }}
          className="relative z-10 bg-white w-full sm:max-w-2xl max-h-[94vh] sm:max-h-[90vh] rounded-t-3xl sm:rounded-3xl shadow-2xl flex flex-col overflow-hidden border border-stone-200"
        >
          
          {/* Header */}
          <div className="p-4 sm:p-5 border-b border-stone-200 bg-stone-50 flex items-center justify-between">
            <div className="flex items-center gap-2.5">
              <div className="w-9 h-9 rounded-xl bg-amber-500 text-stone-950 flex items-center justify-center font-bold">
                <CalendarCheck className="w-5 h-5" />
              </div>
              <div>
                <h3 className="font-serif text-lg font-bold text-stone-900">
                  {bookingMode === 'dine-in' ? 'Table Reservation & Order' : 'Campora Cafe Campus Order'}
                </h3>
                <p className="text-xs text-stone-500">
                  GEC Banka Campus • {cart.length > 0 ? `${cart.length} food items on tray` : 'Table booking'}
                </p>
              </div>
            </div>

            <button
              onClick={() => setIsCheckoutOpen(false)}
              className="p-1.5 rounded-full hover:bg-stone-200 text-stone-500 transition-colors"
            >
              <X className="w-5 h-5" />
            </button>
          </div>

          {/* Form Body */}
          <form onSubmit={handleSubmit} className="overflow-y-auto flex-1 p-5 sm:p-7 space-y-6">
            
            {/* Cafe Closed Warning Notice */}
            {!isCafeOpenNow && (
              <div className="p-4 rounded-2xl bg-rose-50 border border-rose-200 text-rose-950 flex items-start gap-3 shadow-xs">
                <AlertCircle className="w-5 h-5 text-rose-600 shrink-0 mt-0.5" />
                <div className="text-xs space-y-1">
                  <p className="font-bold text-rose-900 text-sm">
                    🔴 Currently Closed – Ordering is Temporarily Unavailable
                  </p>
                  <p className="text-rose-700">
                    {settings.closedNotice || 'Campora Café is not accepting orders at this time. Please check back when we reopen!'}
                  </p>
                </div>
              </div>
            )}

            {/* 1. Mode Selection Tabs */}
            <div className="space-y-2">
              <label className="text-xs font-bold uppercase tracking-wider text-stone-800">
                1. Select Booking & Order Type
              </label>
              <div className="grid grid-cols-3 gap-2 p-1 bg-stone-100 rounded-2xl border border-stone-200/80">
                
                <button
                  type="button"
                  onClick={() => setBookingMode('dine-in')}
                  className={`py-2.5 px-3 rounded-xl text-xs font-bold flex flex-col sm:flex-row items-center justify-center gap-1.5 transition-all cursor-pointer ${
                    bookingMode === 'dine-in'
                      ? 'bg-white text-stone-900 shadow-sm ring-1 ring-stone-900/10'
                      : 'text-stone-600 hover:text-stone-900'
                  }`}
                >
                  <CalendarCheck className="w-4 h-4 text-amber-700" />
                  <span>Dine In / Table</span>
                </button>

                <button
                  type="button"
                  onClick={() => setBookingMode('takeout')}
                  className={`py-2.5 px-3 rounded-xl text-xs font-bold flex flex-col sm:flex-row items-center justify-center gap-1.5 transition-all cursor-pointer ${
                    bookingMode === 'takeout'
                      ? 'bg-white text-stone-900 shadow-sm ring-1 ring-stone-900/10'
                      : 'text-stone-600 hover:text-stone-900'
                  }`}
                >
                  <ShoppingBag className="w-4 h-4 text-stone-700" />
                  <span>Takeout Counter</span>
                </button>

                <button
                  type="button"
                  onClick={() => setBookingMode('delivery')}
                  className={`py-2.5 px-3 rounded-xl text-xs font-bold flex flex-col sm:flex-row items-center justify-center gap-1.5 transition-all cursor-pointer ${
                    bookingMode === 'delivery'
                      ? 'bg-white text-stone-900 shadow-sm ring-1 ring-stone-900/10'
                      : 'text-stone-600 hover:text-stone-900'
                  }`}
                >
                  <Truck className="w-4 h-4 text-emerald-700" />
                  <span>Hostel Delivery</span>
                </button>

              </div>
            </div>

            {/* 2. Specific Booking Mode Config */}
            {bookingMode === 'dine-in' && (
              <div className="p-4 sm:p-5 rounded-2xl bg-amber-50/60 border border-amber-200 space-y-4 text-xs">
                <div className="flex items-center gap-2 font-bold text-amber-950">
                  <Calendar className="w-4 h-4 text-amber-800" />
                  <span>Table & Seating Details</span>
                </div>

                {/* Date & Guest Count */}
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                  <div>
                    <label className="block text-[11px] font-semibold text-stone-700 mb-1">
                      Reservation Date
                    </label>
                    <input
                      type="date"
                      value={selectedDate}
                      min={new Date().toISOString().split('T')[0]}
                      onChange={(e) => setSelectedDate(e.target.value)}
                      className="w-full p-2.5 bg-white rounded-xl border border-stone-200 text-stone-900 font-medium focus:outline-none focus:ring-1 focus:ring-amber-800"
                    />
                  </div>

                  <div>
                    <label className="block text-[11px] font-semibold text-stone-700 mb-1">
                      Number of People
                    </label>
                    <div className="flex items-center justify-between p-1.5 bg-white rounded-xl border border-stone-200">
                      <button
                        type="button"
                        onClick={() => setGuestCount((g) => Math.max(1, g - 1))}
                        className="w-8 h-8 rounded-lg bg-stone-100 hover:bg-stone-200 text-stone-700 font-bold"
                      >
                        -
                      </button>
                      <span className="font-bold text-stone-900">{guestCount} Seats</span>
                      <button
                        type="button"
                        onClick={() => setGuestCount((g) => Math.min(16, g + 1))}
                        className="w-8 h-8 rounded-lg bg-stone-100 hover:bg-stone-200 text-stone-700 font-bold"
                      >
                        +
                      </button>
                    </div>
                  </div>
                </div>

                {/* Time Slot Cards */}
                <div>
                  <label className="block text-[11px] font-semibold text-stone-700 mb-1.5">
                    Select Time Window
                  </label>
                  <div className="grid grid-cols-2 sm:grid-cols-4 gap-2">
                    {CAMPUS_TIME_SLOTS.map((slot) => {
                      const isSelected = selectedTimeSlot === slot.time;
                      return (
                        <button
                          key={slot.time}
                          type="button"
                          onClick={() => setSelectedTimeSlot(slot.time)}
                          className={`p-2 rounded-xl border text-center transition-all cursor-pointer ${
                            isSelected
                              ? 'bg-stone-900 text-amber-300 border-stone-900 font-bold shadow-xs'
                              : 'bg-white text-stone-700 border-stone-200 hover:bg-stone-50'
                          }`}
                        >
                          <p className="text-xs font-bold">{slot.time}</p>
                          <p className="text-[10px] opacity-75">{slot.label}</p>
                        </button>
                      );
                    })}
                  </div>
                </div>

                {/* Seating Zone Preference */}
                <div>
                  <label className="block text-[11px] font-semibold text-stone-700 mb-1.5">
                    Campus Zone Preference
                  </label>
                  <div className="grid grid-cols-2 sm:grid-cols-4 gap-2">
                    {[
                      { id: 'indoor', name: 'Central Food Court' },
                      { id: 'lounge', name: 'Study & Coding Nook' },
                      { id: 'patio', name: 'Green Lawn & Terrace' },
                      { id: 'booth', name: 'Project & Club Booth' },
                    ].map((z) => (
                      <button
                        key={z.id}
                        type="button"
                        onClick={() => setSelectedZone(z.id as TableZone)}
                        className={`p-2 rounded-xl border text-center font-medium transition-all ${
                          selectedZone === z.id
                            ? 'bg-amber-900 text-white border-amber-900 font-bold'
                            : 'bg-white text-stone-700 border-stone-200 hover:bg-stone-50'
                        }`}
                      >
                        {z.name}
                      </button>
                    ))}
                  </div>
                </div>

                {/* Interactive Table Picker */}
                <div>
                  <label className="block text-[11px] font-semibold text-stone-700 mb-1.5">
                    Select Specific Table (Optional)
                  </label>
                  <div className="grid grid-cols-3 sm:grid-cols-4 gap-2">
                    {availableTablesInZone.length > 0 ? (
                      availableTablesInZone.map((t) => (
                        <button
                          key={t.id}
                          type="button"
                          onClick={() => setSelectedTableId(selectedTableId === t.id ? '' : t.id)}
                          className={`p-2 rounded-xl border text-center transition-all ${
                            selectedTableId === t.id
                              ? 'bg-emerald-800 text-white border-emerald-900 font-bold'
                              : 'bg-white text-stone-800 border-stone-200 hover:border-amber-400'
                          }`}
                        >
                          <span className="font-bold text-xs">{t.tableNumber}</span>
                          <span className="block text-[10px] opacity-75">Max {t.capacity} seats</span>
                        </button>
                      ))
                    ) : (
                      <p className="col-span-full text-stone-500 italic py-1">
                        Any available table in this zone will be allocated on arrival.
                      </p>
                    )}
                  </div>
                </div>

              </div>
            )}

            {bookingMode === 'takeout' && (
              <div className="p-4 sm:p-5 rounded-2xl bg-stone-100 border border-stone-200 space-y-3 text-xs">
                <div className="flex items-center gap-2 font-bold text-stone-900">
                  <ShoppingBag className="w-4 h-4 text-amber-700" />
                  <span>Express Counter Pickup</span>
                </div>
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                  <div>
                    <label className="block text-[11px] font-semibold text-stone-700 mb-1">
                      Ready Time
                    </label>
                    <select
                      value={pickupTime}
                      onChange={(e) => setPickupTime(e.target.value)}
                      className="w-full p-2.5 bg-white rounded-xl border border-stone-200 font-medium text-stone-900 focus:outline-none"
                    >
                      <option value="⚡ ASAP (10-15 mins)">⚡ ASAP (10-15 mins)</option>
                      <option value="In 20 mins (After class)">In 20 mins (After class)</option>
                      <option value="In 30 mins (Lab break)">In 30 mins (Lab break)</option>
                      <option value="In 45 mins">In 45 mins</option>
                      <option value="In 1 hour">In 1 hour</option>
                    </select>
                  </div>

                  <div>
                    <label className="block text-[11px] font-semibold text-stone-700 mb-1">
                      Student Note (Optional)
                    </label>
                    <input
                      type="text"
                      value={vehicleInfo}
                      onChange={(e) => setVehicleInfo(e.target.value)}
                      placeholder="e.g. CSE Dept - Packing required"
                      className="w-full p-2.5 bg-white rounded-xl border border-stone-200 text-stone-900 focus:outline-none"
                    />
                  </div>
                </div>
              </div>
            )}

            {bookingMode === 'delivery' && (
              <div className="p-4 sm:p-5 rounded-2xl bg-emerald-50/80 border border-emerald-200 space-y-3 text-xs">
                <div className="flex items-center gap-2 font-bold text-emerald-950">
                  <Truck className="w-4 h-4 text-emerald-800" />
                  <span>Campus & Hostel Delivery</span>
                </div>
                <div className="space-y-2.5">
                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-2.5">
                    <div>
                      <label className="block text-[11px] font-semibold text-stone-700 mb-1">
                        Campus Building / Hostel *
                      </label>
                      <select
                        value={campusBuilding}
                        onChange={(e) => setCampusBuilding(e.target.value)}
                        className="w-full p-2.5 bg-white rounded-xl border border-stone-200 font-medium text-stone-900 focus:outline-none"
                      >
                        {CAMPUS_BUILDINGS.map((b) => (
                          <option key={b} value={b}>{b}</option>
                        ))}
                      </select>
                    </div>

                    <div>
                      <label className="block text-[11px] font-semibold text-stone-700 mb-1">
                        Room No. / Lab / Desk No. *
                      </label>
                      <input
                        type="text"
                        value={roomNumber}
                        onChange={(e) => setRoomNumber(e.target.value)}
                        placeholder="e.g. Room 204, 2nd Floor"
                        required
                        className="w-full p-2.5 bg-white rounded-xl border border-stone-200 text-stone-900 focus:outline-none"
                      />
                    </div>
                  </div>

                  <div>
                    <label className="block text-[11px] font-semibold text-stone-700 mb-1">
                      Delivery Note
                    </label>
                    <input
                      type="text"
                      value={deliveryInstructions}
                      onChange={(e) => setDeliveryInstructions(e.target.value)}
                      placeholder="e.g. Call on arrival at hostel gate"
                      className="w-full p-2.5 bg-white rounded-xl border border-stone-200 text-stone-900 focus:outline-none"
                    />
                  </div>
                </div>
              </div>
            )}

            {/* 3. Customer Contact Details */}
            <div className="space-y-3">
              <label className="text-xs font-bold uppercase tracking-wider text-stone-800">
                2. Student / Customer Details
              </label>
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 text-xs">
                <div>
                  <label className="block text-[11px] font-semibold text-stone-700 mb-1">
                    Your Name *
                  </label>
                  <input
                    type="text"
                    value={customerName}
                    onChange={(e) => setCustomerName(e.target.value)}
                    placeholder="e.g. Aman Kumar (CSE)"
                    required
                    className="w-full p-2.5 rounded-xl border border-stone-200 bg-stone-50 focus:bg-white focus:outline-none focus:ring-1 focus:ring-amber-800"
                  />
                </div>

                <div>
                  <label className="block text-[11px] font-semibold text-stone-700 mb-1">
                    WhatsApp / Mobile Number *
                  </label>
                  <input
                    type="tel"
                    value={customerPhone}
                    onChange={(e) => setCustomerPhone(e.target.value)}
                    placeholder="+91 98765 43210"
                    required
                    className="w-full p-2.5 rounded-xl border border-stone-200 bg-stone-50 focus:bg-white focus:outline-none focus:ring-1 focus:ring-amber-800"
                  />
                </div>

                <div className="sm:col-span-2">
                  <label className="block text-[11px] font-semibold text-stone-700 mb-1">
                    Email Address (Optional)
                  </label>
                  <input
                    type="email"
                    value={customerEmail}
                    onChange={(e) => setCustomerEmail(e.target.value)}
                    placeholder="student@gecbanka.ac.in"
                    className="w-full p-2.5 rounded-xl border border-stone-200 bg-stone-50 focus:bg-white focus:outline-none focus:ring-1 focus:ring-amber-800"
                  />
                </div>

                <div className="sm:col-span-2">
                  <label className="block text-[11px] font-semibold text-stone-700 mb-1">
                    Special Cooking Instructions (Optional)
                  </label>
                  <textarea
                    value={specialRequests}
                    onChange={(e) => setSpecialRequests(e.target.value)}
                    placeholder="e.g. Extra adrak in chai, less spicy momos, extra butter on Maggi..."
                    rows={2}
                    className="w-full p-2.5 rounded-xl border border-stone-200 bg-stone-50 focus:bg-white focus:outline-none focus:ring-1 focus:ring-amber-800 text-xs"
                  />
                </div>
              </div>

              {/* WhatsApp notification consent */}
              <label className="flex items-center gap-2 text-xs text-stone-600 cursor-pointer pt-1">
                <input
                  type="checkbox"
                  checked={sendWhatsApp}
                  onChange={(e) => setSendWhatsApp(e.target.checked)}
                  className="rounded text-amber-800 focus:ring-amber-800"
                />
                <span>Send token confirmation & live kitchen status via WhatsApp</span>
              </label>
            </div>

            {/* 4. Payment Method & Tip */}
            <div className="space-y-3 pt-2 border-t border-stone-200">
              <label className="text-xs font-bold uppercase tracking-wider text-stone-800">
                3. Payment Method
              </label>

              {/* Payment Methods */}
              <div className="grid grid-cols-2 sm:grid-cols-4 gap-2 text-xs font-medium">
                {[
                  { id: 'upi', label: '💳 Pay via UPI', icon: QrCode },
                  { id: 'counter', label: 'Cash at Counter', icon: Banknote },
                  { id: 'card', label: 'Debit / Credit Card', icon: CreditCard },
                  { id: 'cash', label: 'Pay on Delivery', icon: Banknote },
                ].map((pm) => (
                  <button
                    key={pm.id}
                    type="button"
                    onClick={() => setPaymentMethod(pm.id as any)}
                    className={`p-2.5 rounded-xl border flex flex-col items-center justify-center gap-1 transition-all cursor-pointer ${
                      paymentMethod === pm.id
                        ? 'bg-stone-900 text-amber-300 border-stone-900 font-bold shadow-xs'
                        : 'bg-stone-50 text-stone-700 border-stone-200 hover:bg-stone-100'
                    }`}
                  >
                    <pm.icon className="w-4 h-4" />
                    <span>{pm.label}</span>
                  </button>
                ))}
              </div>

              {/* Dynamic UPI Payment Box */}
              {paymentMethod === 'upi' && (
                <UpiPaymentBox
                  upiId={settings.upiId || '8210794268-4@ybl'}
                  payeeName={settings.name || 'Campora Café'}
                  amount={pricing.total}
                  note={`Campora Cafe Order ${bookingMode.toUpperCase()}`}
                  title="Campora Café"
                  subtitle="Scan & Pay with any UPI app"
                  variant="checkout"
                />
              )}
            </div>

            {/* Error Banner */}
            {errorMsg && (
              <div className="p-3 rounded-xl bg-rose-50 border border-rose-200 text-xs text-rose-700 flex items-center gap-2">
                <AlertCircle className="w-4 h-4 shrink-0" />
                <span>{errorMsg}</span>
              </div>
            )}

            {/* Sticky Submit Footer */}
            <div className="pt-4 border-t border-stone-200 flex flex-col sm:flex-row items-center justify-between gap-3">
              <div className="w-full sm:w-auto text-left">
                <p className="text-[11px] text-stone-500 font-medium">Total Amount Due</p>
                <p className="text-xl font-bold font-serif text-stone-900">
                  {settings.currency}{pricing.total.toFixed(2)}
                </p>
              </div>

              <button
                type="submit"
                disabled={isSubmitting || !isCafeOpenNow}
                className={`w-full sm:w-auto min-h-[48px] px-8 py-3 font-bold text-sm rounded-2xl shadow-lg transition-all flex items-center justify-center gap-2 ${
                  !isCafeOpenNow
                    ? 'bg-stone-200 text-stone-500 cursor-not-allowed border border-stone-300 shadow-none'
                    : 'bg-amber-500 hover:bg-amber-400 active:bg-amber-600 disabled:opacity-50 text-stone-950 shadow-amber-500/20 cursor-pointer'
                }`}
              >
                {!isCafeOpenNow ? (
                  <span>🔴 Currently Closed – Ordering Unavailable</span>
                ) : isSubmitting ? (
                  <span>Generating Order Token...</span>
                ) : (
                  <>
                    <span>Confirm & Generate Order Token</span>
                    <CheckCircle2 className="w-4 h-4" />
                  </>
                )}
              </button>
            </div>

          </form>

        </motion.div>
      </div>
    </AnimatePresence>
  );
};
